SEED = parse(Int64, ARGS[1])
NB_SOURCES = parse(Int64, ARGS[2])
NB_DESTINATIONS = parse(Int64, ARGS[3])
NB_STORAGES = parse(Int64,ARGS[4])
DEMAND_MAGNITUDE = ARGS[5] 
DISSATISFACTION_MAGNITUDE = ARGS[6] 

Random.seed!(SEED) 

DAYS = 1:7 #set of days 

HOURS = 1:24 #set of hours 

START_HOUR = 8 #h0
SWAP_TIME = 0 #The duration of a swap 

SOURCES = 1:NB_SOURCES 
DESTINATIONS = NB_SOURCES+1:NB_SOURCES+NB_DESTINATIONS 
STORAGES = 1:NB_STORAGES 


LOCATIONS = union(SOURCES,DESTINATIONS) #The set of nodes (locations)

MAXIMUM_STORAGES_PER_SOURCE = 4 #Maximum number of storages that can be present at a source 


ARCS = union([(i,j) for (i,j) in collect(Iterators.product(SOURCES,DESTINATIONS))], [(j,i) for (i,j) in collect(Iterators.product(SOURCES,DESTINATIONS))]) #The set of arcs linking the sources and destinations
ARCS = union(ARCS,[(d,d) for d in DESTINATIONS]) #The complete set of arcs 

MAXIMAL_DISTANCE = 123 #in km
TRUCK_SPEED = 83 #in km/h

transport_distances = Dict(arc => (arc[1]==arc[2] ? 0 : rand(1:MAXIMAL_DISTANCE)) for arc in ARCS)     #transport distance is generated randomly according to a uniform distribution
transport_hours = Dict(arc=>Int(max(1, round(distance/TRUCK_SPEED))) for (arc, distance) in transport_distances) 

REFILLING_RATES= Dict(1=>1300, 2=>1500, 3=>1700,4=>1000, 5=>1000, 6=>800, 7=>500) #hydrogen refill rates per source 

REFILLING_PRICES = Dict(1=>9,2=>8 ,3=>8.3 ,4=>8, 5=>8, 6=>10, 7=>7)


if DEMAND_MAGNITUDE =="MEDIUM" 
    DEMAND_COEF = 0.85
else 
    DEMAND_COEF = 1.3
end


#Demand initialization 

global DEMANDS = Dict(j=>Dict(d=>[] for d in DESTINATIONS) for j in DAYS)

peaks = [(8, 50 ), (14, 50), (17, 50)]  

for j in DAYS
     for d in DESTINATIONS
    
      	random_demand_sum = rand(Uniform(90,110))
    
       	demand = zeros(Float64, 24)
    
       	for hour in HOURS
            # Combine the effect of all peaks, weighted by their Gaussian influence
            for (peak_hour, peak_demand) in peaks
                # Gaussian influence: higher closer to the peak hour
                influence = exp(-((hour - peak_hour)^2)/2)
                demand[hour] += influence * peak_demand
            end
    
            # Add some randomness to simulate variability
            demand[hour] += rand(-4:4)
        end
    
        # Ensure demand is non-negative
        demand = max.(demand, 0)
        #normalize the demand over a day for a station so that the sum is equal to 100
        if j%7==6 #saturday
            demand = demand/sum(demand)*random_demand_sum*0.5
        elseif j%7==0 #sunday
            demand = demand/sum(demand)*random_demand_sum*0.25
        else #weekday
            demand = demand/sum(demand)*random_demand_sum
        end 
    
        global DEMANDS[j][d] = DEMAND_COEF*demand
    end
end  



if DISSATISFACTION_MAGNITUDE=="MEDIUM" 
    UNITARY_DEMAND_DISSATISFACTION_COST = 12  #euros/kg
    FIXED_DEMAND_DISSATISFACTION_COST = 1500   #euros
elseif DISSATISFACTION_MAGNITUDE=="HIGH" 
    UNITARY_DEMAND_DISSATISFACTION_COST = 14   #euros/kg
    FIXED_DEMAND_DISSATISFACTION_COST = 2500  #euros
end 






STOCK_MAX = 300   #maximum stock of a storage
STOCK_MIN = 0   #minimum stock of a storage 
TRANSPORT_PRICE = 2.25   #unitary transport price in euros/hour
INITIAL_STOCK = Dict(l=>2/3*STOCK_MAX for l in LOCATIONS) #initial stock of each storage 
