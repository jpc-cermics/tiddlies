for i in 2,10,15 2,12,16 2,14,18 3,13,19 3,15,21 3,18,25 4,20,29 4,22,30 4,24,33 4,34,45 5,22,31 5,25,34 5,27,38 5,30,41 5,31,43 6,32,46 6,33,46 6,35,48 6,40,51 6,41,56 7,42,54 7,43,56 7,45,57 7,48,64; do
  IFS=, read -r s d b <<< "$i"

  for seed in 1 2; do

    for p in HIGH MEDIUM; do

      for q in HIGH MEDIUM; do

        julia method.jl "$seed" "$s" "$d" "$b" "$p" "$q"

      done

    done

  done

done