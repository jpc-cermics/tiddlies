libname  = 'libnspmpi' 	
libtitle='MPI: nsp interface with mpi';

// macros. 

add_lib('macros',compile=%t);

// loader for src 

exec('src/loader.sce');

printf(libtitle+' loaded\n');

// path to here 
mpinsp_path = get_current_exec_dir()

