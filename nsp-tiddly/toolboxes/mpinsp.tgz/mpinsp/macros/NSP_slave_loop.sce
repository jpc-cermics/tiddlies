// This script is executed by a nsp child 
// when the nsp child is spawned with NSP_spawn
// and a second argument set to %t.
// it enters a while loop 
// waiting for messages with tag 7 or 8 
// and enabling gtk events. 
// 
// Note that [stat]=MPI_Probe(0,-1,NEWORLD) 
// blocks but consumes too much CPU 
// thus we prefer to use xpause enabling Gtk events 
// during the pause and detect MPI jobs whit MPI_Iprobe. 

print('cmd-controlled loop (send break to quit the loop\n')

MPILoopIdx=0;
while %t 
  MPILoopIdx=MPILoopIdx+1;
  [stat]=MPI_Iprobe(0,-1,NEWORLD);
  if stat.len <> 0 then 
    [stat]=MPI_Probe(0,-1,NEWORLD);
    Obj = MPI_Recv_Obj(0,-1,NEWORLD);
    select stat.tag
     case 7 then
      // TAG 7 is used to get a command 
      if Obj == 'quit' then break;end 
      ok = execstr(Obj,errcatch=%t);
      if ~ok then 
	printf('execution of command %s failed\n",Obj);
      else
	printf('execution of command %s is ok\n",Obj);
      end
     case 8 then
      printf('getting data\n");
      data = Obj;
      // TAG 8 is used to get data 
    end
  else 
    // just wait a few time letting events a chance 
    // to be executed 
    // printf('wait \n');
    xpause(10000,%t);
  end
end
printf('quit the loop \n');







