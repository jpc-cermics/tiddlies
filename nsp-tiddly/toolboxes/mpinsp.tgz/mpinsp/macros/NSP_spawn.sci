function [world,children]=NSP_spawn(numbers,loop)
// spawn a set of number nsp instances 
// returning the common communicator 
// if loop is TRUE then each child
// will enter a loop waiting for 
// data and command to execute.
//
  if nargin <= 1 then loop =%f; end 
  if ~MPI_Initialized() then MPI_Init();end 
  COMM_SELF=mpicomm_create('SELF');
  INFO_NULL=mpiinfo_create('NULL');
  cmd = "exec(''src/loader.sce'');MPI_Init();";
  cmd = cmd + "parent=MPI_Comm_get_parent();";
  cmd = cmd + "[NEWORLD]=MPI_Intercomm_merge(parent,1);";
  if loop then 
    cmd = cmd + "exec(''macros/NSP_slave_loop.sce'');"
  end
  nsp_exe = getenv('SCI')+'/bin/nsp';
  args=["-name","Nsp-child","-e", cmd];
  [children errs] = MPI_Comm_spawn (nsp_exe,args,numbers,INFO_NULL,0, COMM_SELF);
  // child will execute cmd 
  [world] = MPI_Intercomm_merge (children, 0);
endfunction

