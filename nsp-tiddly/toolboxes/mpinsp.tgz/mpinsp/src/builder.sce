// This is the builder.sce 
// must be run from this directory 

// [1] generate Path.incl 

ilib_path_incl()

// [3] the part devoted to shared lib generation 

ilib_name  = 'libnspmpi' 		// interface library name 

// objects files (but do not give mexfiles here)

files = ['mpigroup.o', 'mpiinfo.o','mpicomm.o','mpinsp.o',...
	 'mpipack.o', 'mpireq.o', 'mpibuf.o' ];

// other libs needed for linking (must be shared library names)

libs  = [];

// table of (scilab_name,interface-name or mexfile-name, type) 


unfinished=[    'MPI_DUP_FN','MPI_DUP_FN','cmex';
    'MPI_ERRHANDLER','MPI_ERRHANDLER','cmex';
    'MPI_Errhandler_get','MPI_Errhandler_get','cmex';
    'MPI_ERRHANDLER_NULL','MPI_ERRHANDLER_NULL','cmex';
    'MPI_Errhandler_set','MPI_Errhandler_set','cmex';
    'MPI_ERRORS_ARE_FATAL','MPI_ERRORS_ARE_FATAL','cmex';
    'MPI_ERRORS_RETURN','MPI_ERRORS_RETURN','cmex';
    'MPI_KEYVAL','MPI_KEYVAL','cmex';
    'MPI_NULL_COPY_FN','MPI_NULL_COPY_FN','cmex';
    'MPI_NULL_DELETE_FN','MPI_NULL_DELETE_FN','cmex'];


table = [...
    'mpicomm_create','int_mpicomm_create','csci'	;
    'mpigroup_create','int_mpigroup_create','csci'	;
    'mpiinfo_create','int_mpiinfo_create','csci'	;
    'mpibuf_create','int_mpibuf_create','csci'	;
    'MPI_Buffer_attach','int_nsp_mpi_Buffer_attach','csci';
    'MPI_Buffer_detach','int_nsp_mpi_Buffer_detach','csci';
    'MPI_Comm_free','int_mpicomm_free','csci';
    'MPI_Open_port','int_nsp_mpi_Open_port','csci';
    'MPI_Pack_size','int_nsp_mpi_Pack_size','csci';
    'MPI_Error_string','int_nsp_mpi_Error_string','csci';
    'MPI_Error_class','int_nsp_mpi_Error_class','csci';
    'MPI_Topo_test','int_mpicomm_Topo_test','csci';
    'MPI_Dims_create','int_nsp_mpi_Dims_create','csci';
    'MPI_Alltoall','int_nsp_mpi_Alltoall','csci';
    'MPI_Alltoallv','int_nsp_mpi_Alltoallv','csci';
    'MPI_Scatterv','int_nsp_mpi_Scatterv','csci';
    'MPI_Scan','int_nsp_mpi_Scan','csci';
    'MPI_Sendrecv','int_nsp_mpi_Sendrecv','csci';
    'MPI_Sendrecv_replace','int_nsp_mpi_Sendrecv_replace','csci';
    'MPI_Graph_create','int_mpicomm_Graph_create','csci';
    'MPI_Graphdims_get','int_mpicomm_Graphdims_get','csci';
    'MPI_Graph_get','int_mpicomm_Graph_get','csci';
    'MPI_Graph_map','int_mpicomm_Graph_map','csci';
    'MPI_Graph_neighbors','int_mpicomm_Graph_neighbors','csci';
    'MPI_Graph_neighbors_count','int_mpicomm_Graph_neighbors_count','csci';
    'MPI_Abort','int_nsp_mpi_Abort','csci';
    'MPI_Cancel','int_nsp_mpi_Cancel','csci';
    'MPI_Cart_coords','int_mpicomm_Cart_coords','csci';
    'MPI_Cart_create','int_mpicomm_Cart_create','csci';
    'MPI_Cartdim_get','int_mpicomm_Cartdim_get','csci';
    'MPI_Cart_get','int_mpicomm_Cart_get','csci';
    'MPI_Cart_map','int_mpicomm_Cart_map','csci';
    'MPI_Cart_rank','int_mpicomm_Cart_rank','csci';
    'MPI_Cart_shift','int_mpicomm_Cart_shift','csci';
    'MPI_Cart_sub','int_mpicomm_Cart_sub','csci';
    'MPI_Start','int_nsp_mpi_Start','csci';
    'MPI_Startall','int_nsp_mpi_Startall','csci';
    'MPI_Waitall','int_nsp_mpi_Waitall','csci';
    'MPI_Waitany','int_nsp_mpi_Waitany','csci';
    'MPI_Wait','int_nsp_mpi_Wait','csci';
    'MPI_Waitsome','int_nsp_mpi_Waitsome','csci';
    'MPI_Testall','int_nsp_mpi_Testall','csci';
    'MPI_Testany','int_nsp_mpi_Testany','csci';
    'MPI_Test','int_nsp_mpi_Test','csci';
    'MPI_Test_cancelled','int_nsp_mpi_Test_cancelled','csci';
    'MPI_Testsome','int_nsp_mpi_Testsome','csci';
    'MPI_Unpack','int_nsp_mpi_Unpack','csci';
    'MPI_Pack','int_nsp_mpi_Pack','csci';
    'MPI_Attr_delete','int_nsp_mpi_Attr_delete','csci';
    'MPI_Attr_get','int_nsp_mpi_Attr_get','csci';
    'MPI_Attr_put','int_nsp_mpi_Attr_put','csci';
    'MPI_Scatter','int_nsp_mpi_Scatter','csci';
    'MPI_Barrier','int_nsp_mpi_Barrier','csci';
    'MPI_Bcast','int_nsp_mpi_Bcast','csci';
    'MPI_Reduce','int_nsp_mpi_Reduce','csci';
    'MPI_Reduce_scatter','int_nsp_mpi_Reduce_scatter','csci';
    'MPI_Gather','int_nsp_mpi_Gather','csci';
    'MPI_Gatherv','int_nsp_mpi_Gatherv','csci';
    'MPI_Allgather','int_nsp_mpi_Allgather','csci';
    'MPI_Allgatherv','int_nsp_mpi_Allgatherv','csci';
    'MPI_Allreduce','int_nsp_mpi_Allreduce','csci';
    'MPI_Ssend','int_nsp_mpi_Ssend','csci';
    'MPI_Ssend_init','int_nsp_mpi_Ssend_init','csci';
    'MPI_Rsend','int_nsp_mpi_Rsend','csci';
    'MPI_Rsend_init','int_nsp_mpi_Rsend_init','csci';
    'MPI_Bsend','int_nsp_mpi_Bsend','csci';
    'MPI_Bsend_init','int_nsp_mpi_Bsend_init','csci';
    'MPI_Ibsend','int_nsp_mpi_Ibsend','csci';
    'MPI_Irecv','int_nsp_mpi_Irecv','csci';
    'MPI_Irsend','int_nsp_mpi_Irsend','csci';
    'MPI_Isend','int_nsp_mpi_Isend','csci';
    'MPI_Issend','int_nsp_mpi_Issend','csci';
    'MPI_Send_init','int_nsp_mpi_Send_init','csci';
    'MPI_Recv_init','int_nsp_mpi_Recv_init','csci';
    'MPI_Send','int_nsp_mpi_Send','csci';
    'MPI_Recv','int_nsp_mpi_Recv','csci';
    'MPI_Probe','int_nsp_mpi_Probe','csci';
    'MPI_Intercomm_create','int_mpicomm_Intercomm_create','csci';
    'MPI_Intercomm_merge','int_mpicomm_Intercomm_merge','csci';
    'MPI_Get_count','int_nsp_mpi_Get_count','csci';
    'MPI_Get_elements','int_nsp_mpi_Get_elements','csci';
    'MPI_Iprobe','int_nsp_mpi_Iprobe','csci';
    'MPI_Send_Obj','int_nsp_mpi_Send_obj','csci'; 
    'MPI_Recv_Obj','int_nsp_mpi_Recv_obj','csci'; 
    'MPI_Get_processor_name','int_nsp_mpi_Get_processor_name','csci';
    'MPI_Get_version','int_nsp_mpi_Get_version','csci';
    'MPI_Wtick','int_nsp_mpi_Wtick','csci';
    'MPI_Wtime','int_nsp_mpi_Wtime','csci';
    'MPI_Info_delete','int_mpiinfo_delete','csci';
    'MPI_Info_dup','int_mpiinfo_dup','csci';
    'MPI_Info_get','int_mpiinfo_get','csci';
    'MPI_Info_get_nkeys','int_mpiinfo_get_nkeys','csci';
    'MPI_Info_get_nthkey','int_mpiinfo_get_nthkey','csci';
    'MPI_Info_get_valuelen','int_mpiinfo_get_valuelen','csci';
    'MPI_Info_set','int_mpiinfo_set','csci';
    'MPI_Comm_accept','int_mpicomm_accept','csci';
    'MPI_Comm_compare','int_mpicomm_compare','csci';
    'MPI_Comm_connect','int_mpicomm_connect','csci';
    'MPI_Comm_create','xxx_int_mpicomm_create','csci';
    'MPI_Comm_disconnect','int_mpicomm_disconnect','csci';
    'MPI_Comm_dup','int_mpicomm_dup','csci';
    'MPI_Comm_get_parent','int_mpicomm_get_parent','csci';
    'MPI_Comm_group','int_mpicomm_group','csci';
    'MPI_Comm_rank','int_mpicomm_rank','csci';
    'MPI_Comm_remote_group','int_mpicomm_remote_group','csci';
    'MPI_Comm_remote_size','int_mpicomm_remote_size','csci';
    'MPI_Comm_size','int_mpicomm_size','csci';
    'MPI_Comm_spawn','int_mpicomm_spawn','csci';
    'MPI_Comm_split','int_mpicomm_split','csci';
    'MPI_Comm_test_inter','int_mpicomm_test_inter','csci';
    'MPI_Init','int_nsp_mpi_init','csci';
    'MPI_Finalize','int_nsp_mpi_finalize','csci';
    'MPI_Initialized','int_nsp_mpi_initialized','csci';
    'MPI_Finalized','int_nsp_mpi_finalized','csci';
    'MPI_Group','int_mpigroup_create','csci';
    'MPI_Group_difference','int_mpi_group_difference','csci';
    'MPI_Group_union','int_mpi_group_union','csci';
    'MPI_Group_intersection','int_mpi_group_intersection','csci';
    'MPI_Group_excl','int_mpi_group_excl','csci';
    'MPI_Group_incl','int_mpi_group_incl','csci';
    'MPI_Group_range_excl','int_mpi_group_range_excl','csci';
    'MPI_Group_range_incl','int_mpi_group_range_incl','csci';
    'MPI_Group_rank','int_mpi_group_rank','csci';
    'MPI_Group_size','int_mpi_group_size','csci';
    'MPI_Group_translate_ranks','int_mpi_group_translate_ranks','csci';
    'MPI_Group_compare','int_mpi_group_compare','csci'	]


//to be added: 'MPI_Comm_spawn_multiple','int_mpicomm_spawn_multiple','csci';

cflags=" -I./ `mpicc.openmpi -showme:compile`";

ldflags="`mpicc.openmpi -showme:link`";

// do not modify below 
// ----------------------------------------------
ilib_build(ilib_name,table,files,libs,cflags=cflags,ldflags=ldflags)

