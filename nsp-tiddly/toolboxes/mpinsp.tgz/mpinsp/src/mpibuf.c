/*
 * Copyright (C) 2006-2013 Jean-Philippe Chancelier Enpc/Cermics
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public
 * License along with this library; if not, write to the
 * Free Software Foundation, Inc., 59 Temple Place - Suite 330,
 * Boston, MA 02111-1307, USA.
 *
 * MpiBuf Object. This object is used to receive objects 
 * which are packed. Could be rename MpiPack
 * 
 */

#define  MpiBuf_Private 
#include "nsp/objects.h"
#include "mpicomm.h"
#include "mpiinfo.h"
#include "mpigroup.h"
#include "mpibuf.h"
#include "nsp/interf.h"

/* 
 * NspMpiBuf inherits from NspObject
 */

int nsp_type_mpibuf_id=0;
NspTypeMpiBuf *nsp_type_mpibuf=NULL;

/*
 * Type object for MpiBuf 
 * all the instance of NspTypeMpiBuf share the same id. 
 * nsp_type_mpibuf: is an instance of NspTypeMpiBuf 
 *    used for objects of NspMpiBuf type (i.e built with new_mpibuf) 
 * other instances are used for derived classes 
 */

NspTypeMpiBuf *new_type_mpibuf(type_mode mode)
{
  NspTypeMpiBuf *type= NULL;
  NspTypeObject *top;
  if (  nsp_type_mpibuf != 0 && mode == T_BASE ) 
    {
      /* initialization performed and T_BASE requested */
      return nsp_type_mpibuf;
    }
  
  if ((type =  malloc(sizeof(NspTypeMpiBuf))) == NULL) return NULL;
  type->interface = NULL;
  type->surtype = (NspTypeBase *) new_type_object(T_DERIVED);
  if ( type->surtype == NULL) return NULL;
  type->attrs = NULL;
  type->get_attrs = (attrs_func *) int_get_attribute; 
  type->set_attrs = (attrs_func *) int_set_attribute; 
  type->methods = mpibuf_get_methods; 
  type->new = (new_func *) new_mpibuf;

  top = NSP_TYPE_OBJECT(type->surtype);
  while ( top->surtype != NULL ) top= NSP_TYPE_OBJECT(top->surtype);
  
  /* object methods redefined for mpibuf */ 
  
  top->pr = (print_func *) nsp_mpibuf_print;                    
  top->dealloc = (dealloc_func *) nsp_mpibuf_destroy;
  top->copy  =  (copy_func *) nsp_mpibuf_copy;                   
  top->size  = (size_func *) nsp_mpibuf_size;                  
  top->s_type =  (s_type_func *) nsp_mpibuf_type_as_string;    
  top->sh_type = (sh_type_func *) nsp_mpibuf_type_short_string;
  top->info = (info_func *) nsp_mpibuf_info ;                    
  /* top->is_true = (is_true_func  *) MpiBufIsTrue; */
  /* top->loop =(loop_func *) mpibuf_loop;*/
  top->path_extract = (path_func *)  object_path_extract ; 
  top->get_from_obj = (get_from_obj_func *) nsp_mpibuf_object;
  top->eq  = (eq_func *) nsp_mpibuf_eq;
  top->neq  = (eq_func *) nsp_mpibuf_neq;
  top->save  = (save_func *) nsp_mpibuf_xdr_save;
  top->load  = (load_func *) nsp_mpibuf_xdr_load;

  /* specific methods for mpibuf */
      
  type->init = (init_func *) init_mpibuf;
      
  /* 
   * MpiBuf interfaces can be added here 
   * type->interface = (NspTypeBase *) new_type_b();
   * type->interface->interface = (NspTypeBase *) new_type_C()
   * ....
   */
  
  if ( nsp_type_mpibuf_id == 0 ) 
    {
      /* 
       * the first time we get here we initialize the type id and
       * an instance of NspTypeMpiBuf called nsp_type_mpibuf
       */
      type->id =  nsp_type_mpibuf_id = nsp_new_type_id();
      nsp_type_mpibuf = type;
      if ( nsp_register_type(nsp_type_mpibuf) == FALSE) return NULL;
      return ( mode == T_BASE ) ? type : new_type_mpibuf(mode);
    }
  else 
    {
      type->id = nsp_type_mpibuf_id;
      return type;
    }
}

/*
 * initialize MpiBuf instances 
 * locally and by calling initializer on parent class 
 */

static int init_mpibuf(NspMpiBuf *o,NspTypeMpiBuf *type)
{
  /* to be done always */ 
  if ( type->surtype->init(&o->father,type->surtype) == FAIL) return FAIL;
  o->type = type; 
  NSP_OBJECT(o)->basetype = (NspTypeBase *)type;
  o->val = NULL;
  o->nbytes = 0;
  o->pos = 0;
  return OK;
}

/*
 * new instance of MpiBuf 
 */

NspMpiBuf *new_mpibuf() 
{
  NspMpiBuf *loc; 
  /* type must exists */
  nsp_type_mpibuf = new_type_mpibuf(T_BASE);
  if ( (loc = malloc(sizeof(NspMpiBuf)))== NULLMPIBUF) return loc;
  /* initialize object */
  if ( init_mpibuf(loc,nsp_type_mpibuf) == FAIL) return NULLMPIBUF;
  return loc;
}

/*----------------------------------------------
 * Object method redefined for MpiBuf 
 *-----------------------------------------------*/

/*
 * size 
 */

static int nsp_mpibuf_size(NspMpiBuf *H, int flag)
{
  switch (flag) 
    {
    case 0: return H->pos;
    case 1: return H->pos;
    case 2: return H->nbytes;
    }
  return 0;
}

/*
 * type as string 
 */

static char mpibuf_type_name[]="MpiBuf";
static char mpibuf_short_type_name[]="mpibuf";

static char *nsp_mpibuf_type_as_string(void)
{
  return(mpibuf_type_name);
}

static char *nsp_mpibuf_type_short_string(NspObject *v)
{
  return(mpibuf_short_type_name);
}

static int nsp_mpibuf_full_comp(NspMpiBuf * A,NspMpiBuf * B,char *op,int *err)
{
  Scierror("mpibuf_full_comp: to be implemented \n");
  return FALSE;
}

/*
 * A == B 
 */

static int nsp_mpibuf_eq(NspMpiBuf *A, NspObject *B)
{
  int err,rep;
  if ( check_cast(B,nsp_type_mpibuf_id) == FALSE) return FALSE ;
  rep = nsp_mpibuf_full_comp(A,(NspMpiBuf *) B,"==",&err);
  if ( err == 1) return FALSE ; 
  return rep;
}

/*
 * A != B 
 */

static int nsp_mpibuf_neq(NspMpiBuf *A, NspObject *B)
{
  int err=0,rep;
  if ( check_cast(B,nsp_type_mpibuf_id) == FALSE) return TRUE;
  rep = nsp_mpibuf_full_comp(A,(NspMpiBuf *) B,"<>",&err);
  if ( err == 1) return TRUE ; 
  return rep;
}

/*
 * save 
 */

static int nsp_mpibuf_xdr_save(XDR  *xdrs, NspMpiBuf *M)
{
  if (nsp_xdr_save_i(xdrs,M->type->id) == FAIL) return FAIL;
  if (nsp_xdr_save_string(xdrs, NSP_OBJECT(M)->name) == FAIL) return FAIL;
  if (nsp_xdr_save_i(xdrs,M->nbytes) == FAIL) return FAIL;
  if (nsp_xdr_save_i(xdrs,M->pos) == FAIL) return FAIL;
  if (nsp_xdr_save_array_c(xdrs,M->val,M->nbytes) == FAIL) return FAIL;
  return OK;
}

/*
 * load 
 */

static NspMpiBuf  *nsp_mpibuf_xdr_load(XDR *xdrs)
{
  int nbytes,pos;
  NspMpiBuf *M = NULL;
  static char name[NAME_MAXL];
  if (nsp_xdr_load_string(xdrs,name,NAME_MAXL) == FAIL) return NULLMPIBUF;
  if (nsp_xdr_load_i(xdrs,&nbytes) == FAIL) return NULLMPIBUF;
  if (nsp_xdr_load_i(xdrs,&pos) == FAIL) return NULLMPIBUF;
  if ((M = nsp_mpibuf_create(name,NULL,nbytes))== NULLMPIBUF) return NULLMPIBUF;
  M->pos = pos;
  if (nsp_xdr_load_array_c(xdrs,M->val,M->nbytes) == FAIL) return  NULLMPIBUF;
  return M;
}

/*
 * delete 
 */

void nsp_mpibuf_destroy(NspMpiBuf *H)
{
  nsp_object_destroy_name(NSP_OBJECT(H));
  FREE(H->val);
  FREE(H);
}

/*
 * info 
 */

int nsp_mpibuf_info(NspMpiBuf *H, int indent,const char *name, int rec_level)
{
  int i;
  const char *pname = (name != NULL) ? name : NSP_OBJECT(H)->name;
  for ( i=0 ; i < indent ; i++) Sciprintf(" ");
  Sciprintf("%s\t= <%d-bytes:%d used>\t\t mpibuf\n",pname,H->nbytes,H->pos);
  return TRUE;
}

/*
 * print 
 */

int nsp_mpibuf_print(NspMpiBuf *H, int indent,const char *name, int rec_level)
{
  nsp_mpibuf_info(H,indent,name,rec_level);
  return TRUE;
}

/*-----------------------------------------------------
 * a set of functions used when writing interfaces 
 * for MpiBuf objects 
 * Note that some of these functions could become MACROS XXXXX 
 *-----------------------------------------------------*/

NspMpiBuf   *nsp_mpibuf_object(NspObject *O)
{
  /* Follow pointer */
  HOBJ_GET_OBJECT(O,NULL);
  /* Check type */
  if ( check_cast(O,nsp_type_mpibuf_id) == TRUE) return ((NspMpiBuf *) O);
  else 
    Scierror("Error:\tArgument should be a %s\n",type_get_name(nsp_type_mpibuf));
  return(NULL);
}

int IsMpiBufObj(Stack stack, int i)
{
  return nsp_object_type(NthObj(i) , nsp_type_mpibuf_id);
}

int IsMpiBuf(NspObject *O)
{
  return nsp_object_type(O,nsp_type_mpibuf_id);
}

NspMpiBuf  *GetMpiBufCopy(Stack stack, int i)
{
  if (  GetMpiBuf(stack,i) == NULL ) return NULL;
  return MaybeObjCopy(&NthObj(i));
}

NspMpiBuf  *GetMpiBuf(Stack stack, int i)
{
  NspMpiBuf *M;
  if (( M = nsp_mpibuf_object(NthObj(i))) == NULLMPIBUF)
     ArgMessage(stack,i);
  return M;
}

/*-----------------------------------------------------
 * constructor 
 * if type is non NULL it is a subtype which can be used to 
 * create a NspMpiBuf instance 
 *
 * creates a mpibuf buffer which can store nbytes 
 * If buf is present buf is copied into the mpibuf buffer 
 * When filled we start val whith a string to get the 
 * opportunity of checking an incorrect mpibuf.
 *-----------------------------------------------------*/

static NspMpiBuf *_nsp_mpibuf_create(const char *name,const char *buf,int nbytes,NspTypeBase *type)
{
  NspMpiBuf *H  = (type == NULL) ? new_mpibuf() : type->new();
  if ( H ==  NULLMPIBUF)
    {
      Sciprintf("No more memory\n");
      return NULLMPIBUF;
    }
  /* should be unsigned */
  H->nbytes = Max(0,nbytes);
  if ( nsp_object_set_initial_name(NSP_OBJECT(H),name) == NULL)
    return(NULLMPIBUF);
  NSP_OBJECT(H)->ret_pos = -1 ;
  if ((H->val = malloc((H->nbytes)*sizeof(char)))== NULL) 
    {
      Sciprintf("No more memory\n");
      return NULLMPIBUF;
    }
  if ( buf != NULL) 
    {
      memcpy(H->val,buf,H->nbytes);
    }
  else 
    {
      memset(H->val,0,H->nbytes);
    }
  return H;
}

NspMpiBuf *nsp_mpibuf_create(const char *name,const char *buf,int nbytes)
{
  return _nsp_mpibuf_create(name,buf,nbytes,NULL);
}

/*
 * copy 
 */

NspMpiBuf *nsp_mpibuf_copy(NspMpiBuf *H)
{
  return _nsp_mpibuf_create(NVOID,H->val,H->nbytes,NULL);
}

/*-------------------------------------------------------------------
 * wrappers for the MpiBuf
 * i.e functions at Nsp level 
 *-------------------------------------------------------------------*/

/*------------------------------------------------------
 * attributes  (set/get methods) 
 *------------------------------------------------------*/

/*------------------------------------------------------
 * methods 
 *------------------------------------------------------*/

int int_mpibuf_create(Stack stack, int rhs, int opt, int lhs)
{
  int nbytes;
  NspMpiBuf *H;
  CheckStdRhs(1,1);
  CheckLhs(0,1);
  if (GetScalarInt(stack,1,&nbytes) == FAIL) return RET_BUG;
  /* want to be sure that type mpicomm is initialized */
  nsp_type_mpibuf = new_type_mpibuf(T_BASE);
  if (( H = nsp_mpibuf_create(NVOID,NULL, nbytes)) == NULL) 
    return RET_BUG;
  MoveObj(stack,1,(NspObject  *) H);
  return 1;
} 

static NspMethods mpibuf_methods[] = {
  { (char *) 0, NULL}
};

static NspMethods *mpibuf_get_methods(void) { return mpibuf_methods;};

/*----------------------------------------------------
 * Interface 
 * i.e a set of function which are accessible at nsp level
 *----------------------------------------------------*/

static OpTab MpiBuf_func[]={
  {(char *) 0, NULL}
};

/* call ith function in the MpiBuf interface */

int MpiBuf_Interf(int i, Stack stack, int rhs, int opt, int lhs)
{
  return (*(MpiBuf_func[i].fonc))(stack,rhs,opt,lhs);
}

/* used to walk through the interface table 
    (for adding or removing functions) */

void MpiBuf_Interf_Info(int i, char **fname, function (**f))
{
  *fname = MpiBuf_func[i].name;
  *f = MpiBuf_func[i].fonc;
}






