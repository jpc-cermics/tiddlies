/* -*- Mode: C -*- */
#ifndef NSP_INC_MpiBuf
#define NSP_INC_MpiBuf

/*
 * This Software is GPL (Copyright ENPC 1998-2013) 
 * Jean-Philippe Chancelier Enpc/Cermics         
 */
  
/* MpiBuf */

#include "nsp/object.h"

/*
 * NspMpiBuf inherits from NspObject
 */

/**
 * NspMpiBuf: 
 * @val: character array used to store the mpi packed object
 * @nbytes: size of the packed object.
 * 
 * inherits from #NspObject, used to store serialized objects.
 */

typedef struct _NspMpiBuf NspMpiBuf;
typedef struct _NspTypeMpiBuf NspTypeMpiBuf;

typedef int (*mpibuf_save) (XDR  *xdrs, NspMpiBuf *M);

struct _NspTypeMpiBuf { 
  /*< private >*/
  NSP_TYPE_OBJECT__ 
  /*< public >*/
};

struct _NspMpiBuf {
  /*< private >*/
  NspObject father; 
  NspTypeMpiBuf *type; 
  /*< public >*/
  char *val; /* buffer */
  int nbytes;/* buffer capacity */
  int pos;   /* last position */
};


extern int nsp_type_mpibuf_id;
extern NspTypeMpiBuf *nsp_type_mpibuf;

/* type instances for classa */

NspTypeMpiBuf *new_type_mpibuf(type_mode mode);

/* instance for MpiBuf */

NspMpiBuf *new_mpibuf();

/*
 * Object methods redefined for mpibuf 
 */

#define NULLMPIBUF (NspMpiBuf*) 0

extern NspMpiBuf *nsp_mpibuf_create(const char *name,const char *buf,int nbytes);
extern NspMpiBuf *nsp_mpibuf_copy(NspMpiBuf *H);
extern void nsp_mpibuf_destroy(NspMpiBuf *H);
extern int nsp_mpibuf_info(NspMpiBuf *H, int indent,const char *name, int rec_level);
extern int nsp_mpibuf_print(NspMpiBuf *H, int indent,const char *name, int rec_level);

/* from MpiBufObj.c */

extern NspMpiBuf *nsp_mpibuf_object (NspObject *O); 
extern int IsMpiBufObj (Stack stack, int i); 
extern int IsMpiBuf(NspObject *O);
extern NspMpiBuf *GetMpiBufCopy (Stack stack, int i); 
extern NspMpiBuf *GetMpiBuf (Stack stack, int i); 

extern NspObject *nsp_object_unmpibufize(const NspMpiBuf *S);
extern NspObject * nsp_object_mpibufize(const NspObject *O);

extern NspMatrix *nsp_mpibuf_to_matrix(const NspMpiBuf *S);
extern NspMpiBuf *nsp_matrix_to_mpibuf(const NspMatrix *A);


#endif 

/* private part */

#ifdef MpiBuf_Private 
static NspMpiBuf *_nsp_mpibuf_create(const char *name,const char *buf,int nbytes,NspTypeBase *type);
static int init_mpibuf(NspMpiBuf *o,NspTypeMpiBuf *type);
static int nsp_mpibuf_size(NspMpiBuf *Mat, int flag);
static char *nsp_mpibuf_type_as_string(void);
static char *nsp_mpibuf_type_short_string(NspObject *v);
static int nsp_mpibuf_eq(NspMpiBuf *A, NspObject *B);
static int nsp_mpibuf_neq(NspMpiBuf *A, NspObject *B);
static int nsp_mpibuf_xdr_save(XDR *xdrs, NspMpiBuf *M);
static NspMpiBuf  *nsp_mpibuf_xdr_load(XDR *xdrs);
static AttrTab mpibuf_attrs[];
static NspMethods *mpibuf_get_methods(void); 
/* static int int_mpibuf_create(Stack stack, int rhs, int opt, int lhs); */
#endif /* MpiBuf_Private */
