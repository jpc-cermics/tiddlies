/* Nsp
 * Copyright (C) 2009-2013 Jean-Philippe Chancelier Enpc/Cermics
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public
 * License along with this library; if not, write to the
 * Free Software Foundation, Inc., 59 Temple Place - Suite 330,
 * Boston, MA 02111-1307, USA.
 *
 * Communicator object for MPI. 
 * we always set   MPI_Errhandler_set(comm,MPI_ERRORS_RETURN);
 * at creation. 
 *
 * To be finished: free 
 */

#define  MpiComm_Private 
#include "nsp/objects.h"
#include "mpicomm.h"
#include "mpiinfo.h"
#include "mpigroup.h"
#include "nsp/interf.h"

/* 
 * NspMpiComm inherits from NspObject 
 */

int nsp_type_mpicomm_id=0;
NspTypeMpiComm *nsp_type_mpicomm=NULL;

/*
 * Type object for MpiComm 
 * all the instance of NspTypeMpiComm share the same id. 
 * nsp_type_mpicomm: is an instance of NspTypeMpiComm 
 *    used for objects of NspMpiComm type (i.e built with new_mpicomm) 
 * other instances are used for derived classes 
 */
NspTypeMpiComm *new_type_mpicomm(type_mode mode)
{
  NspTypeMpiComm *type= NULL;
  NspTypeObject *top;
  if (  nsp_type_mpicomm != 0 && mode == T_BASE ) 
    {
      /* initialization performed and T_BASE requested */
      return nsp_type_mpicomm;
    }
  if ((type =  malloc(sizeof(NspTypeMpiComm))) == NULL) return NULL;
  type->interface = NULL;
  type->surtype = (NspTypeBase *) new_type_object(T_DERIVED);
  if ( type->surtype == NULL) return NULL;
  type->attrs = mpicomm_attrs ; 
  type->get_attrs = (attrs_func *) int_get_attribute;
  type->set_attrs = (attrs_func *) int_set_attribute;
  type->methods = mpicomm_get_methods; 
  type->new = (new_func *) new_mpicomm;

  
  top = NSP_TYPE_OBJECT(type->surtype);
  while ( top->surtype != NULL ) top= NSP_TYPE_OBJECT(top->surtype);
  
  /* object methods redefined for mpicomm */ 

  top->pr = (print_func *) nsp_mpicomm_print;                  
  top->dealloc = (dealloc_func *) nsp_mpicomm_destroy;
  top->copy  =  (copy_func *) nsp_mpicomm_copy;                 
  top->size  = (size_func *) nsp_mpicomm_size;                
  top->s_type =  (s_type_func *) nsp_mpicomm_type_as_string;  
  top->sh_type = (sh_type_func *) nsp_mpicomm_type_short_string;
  top->info = (info_func *) nsp_mpicomm_info ;                  
  /* top->is_true = (is_true_func  *) nsp_mpicomm_is_true; */
  /* top->loop =(loop_func *) nsp_mpicomm_loop;*/
  top->path_extract = (path_func *)  object_path_extract; 
  top->get_from_obj = (get_from_obj_func *) nsp_mpicomm_object;
  top->eq  = (eq_func *) nsp_mpicomm_eq;
  top->neq  = (eq_func *) nsp_mpicomm_neq;
  top->save  = (save_func *) nsp_mpicomm_xdr_save;
  top->load  = (load_func *) nsp_mpicomm_xdr_load;
  top->create = (create_func*) int_mpicomm_create;
  top->latex = (print_func *) nsp_mpicomm_latex;
  
  /* specific methods for mpicomm */
      
  type->init = (init_func *) init_mpicomm;

  /* 
   * MpiComm interfaces can be added here 
   * type->interface = (NspTypeBase *) new_type_b();
   * type->interface->interface = (NspTypeBase *) new_type_C()
   * ....
   */
  if ( nsp_type_mpicomm_id == 0 ) 
    {
      /* 
       * the first time we get here we initialize the type id and
       * an instance of NspTypeMpiComm called nsp_type_mpicomm
       */
      type->id =  nsp_type_mpicomm_id = nsp_new_type_id();
      nsp_type_mpicomm = type;
      if ( nsp_register_type(nsp_type_mpicomm) == FALSE) return NULL;
      return ( mode == T_BASE ) ? type : new_type_mpicomm(mode);
    }
  else 
    {
       type->id = nsp_type_mpicomm_id;
       return type;
    }
}

/*
 * initialize MpiComm instances 
 * locally and by calling initializer on parent class 
 */

static int init_mpicomm(NspMpiComm *Obj,NspTypeMpiComm *type)
{
  /* jump the first surtype */ 
  if ( type->surtype->init(&Obj->father,type->surtype) == FAIL) return FAIL;
  Obj->type = type; 
  NSP_OBJECT(Obj)->basetype = (NspTypeBase *)type;
  /* specific */
  Obj->obj = NULL;
  return OK;
}

/*
 * new instance of MpiComm 
 */

NspMpiComm *new_mpicomm() 
{
  NspMpiComm *loc; 
  /* type must exists */
  nsp_type_mpicomm = new_type_mpicomm(T_BASE);
  if ( (loc = malloc(sizeof(NspMpiComm)))== NULLMPICOMM) return loc;
  /* initialize object */
  if ( init_mpicomm(loc,nsp_type_mpicomm) == FAIL) return NULLMPICOMM;
  return loc;
}

/*----------------------------------------------
 * Object method redefined for MpiComm 
 *-----------------------------------------------*/
/*
 * size 
 */

static int nsp_mpicomm_size(NspMpiComm *Mat, int flag)
{
  return 0;
}

/*
 * type as string 
 */

static char mpicomm_type_name[]="MpiComm";
static char mpicomm_short_type_name[]="mpicomm";

static char *nsp_mpicomm_type_as_string(void)
{
  return(mpicomm_type_name);
}

static char *nsp_mpicomm_type_short_string(NspObject *v)
{
  return(mpicomm_short_type_name);
}

/*
 * A == B 
 */

static int nsp_mpicomm_eq(NspMpiComm *A, NspObject *B)
{
  NspMpiComm *loc = (NspMpiComm *) B;
  if ( check_cast(B,nsp_type_mpicomm_id) == FALSE) return FALSE ;
  if ( A->obj == loc->obj ) return TRUE;
  if ( A->obj->comm != loc->obj->comm) return FALSE;
  return TRUE;
}

/*
 * A != B 
 */

static int nsp_mpicomm_neq(NspMpiComm *A, NspObject *B)
{
  return ( nsp_mpicomm_eq(A,B) == TRUE ) ? FALSE : TRUE;
}

/*
 * save 
 */

int nsp_mpicomm_xdr_save(XDR *xdrs, NspMpiComm *M)
{
  if (nsp_xdr_save_i(xdrs,M->type->id) == FAIL) return FAIL;
  if (nsp_xdr_save_string(xdrs, NSP_OBJECT(M)->name) == FAIL) return FAIL;
  return OK;
}

/*
 * load 
 */

NspMpiComm  *nsp_mpicomm_xdr_load_partial(XDR *xdrs, NspMpiComm *M)
{
  if ((M->obj = malloc(sizeof(nsp_mpicomm))) == NULL) return NULL;
 return M;
}

static NspMpiComm  *nsp_mpicomm_xdr_load(XDR *xdrs)
{
  NspMpiComm *M = NULL;
  static char name[NAME_MAXL];
  if (nsp_xdr_load_string(xdrs,name,NAME_MAXL) == FAIL) return NULLMPICOMM;
  if ((M  = nsp_mpicomm_create_void(name,(NspTypeBase *) nsp_type_mpicomm))== NULLMPICOMM) return M;
  return nsp_mpicomm_xdr_load_partial(xdrs,M);
}

/*
 * delete 
 */

void nsp_mpicomm_destroy_partial(NspMpiComm *H)
{
  H->obj->ref_count--;
  if ( H->obj->ref_count == 0 )
   {
     if ( H->obj->comm != MPI_COMM_NULL  
	  && H->obj->comm != MPI_COMM_WORLD 
	  && H->obj->comm != MPI_COMM_SELF )
       {
	 Sciprintf("calling MPI_Comm_free\n");
	 MPI_Comm_free(&H->obj->comm);
       }
     FREE(H->obj);
   }
}

void nsp_mpicomm_destroy(NspMpiComm *H)
{
  nsp_object_destroy_name(NSP_OBJECT(H));
  nsp_mpicomm_destroy_partial(H);
  FREE(H);
}

/*
 * info 
 */

int nsp_mpicomm_info(NspMpiComm *M,int indent,const char *name,int rec_level)
{
  const char *pname;
  if ( M == NULLMPICOMM) 
    {
      Sciprintf("Null Pointer MpiComm \n");
      return TRUE;
    }
  pname = (name != NULL) ? name : NSP_OBJECT(M)->name;
  Sciprintf1(indent,"%s\t=\t\t%s\n", (pname==NULL) ? "" : pname,
             nsp_mpicomm_type_short_string(NSP_OBJECT(M)));
  return TRUE;
}

/*
 * print 
 */

int nsp_mpicomm_print(NspMpiComm *M, int indent,const char *name, int rec_level)
{
  const char *pname = (name != NULL) ? name : NSP_OBJECT(M)->name;
  if ( M == NULLMPICOMM) 
    {
      Sciprintf("Null Pointer MpiComm \n");
      return TRUE;
    }
  if (user_pref.pr_as_read_syntax) 
    { 
      Sciprintf1(indent,"%s=TO_BE_DONE();\n",pname);
    } 
  else 
    { 
      if ( user_pref.pr_depth  <= rec_level -1 ) 
        {
          nsp_mpicomm_info(M,indent,pname,rec_level);
          return TRUE;
        }
      Sciprintf1(indent,"%s\t=\t\t%s (nref=%d)\n",pname, nsp_mpicomm_type_short_string(NSP_OBJECT(M)) ,M->obj->ref_count);
    }
  return TRUE;
}

/*
 * latex print 
 */

int nsp_mpicomm_latex(NspMpiComm *M, int indent,const char *name, int rec_level)
{
  const char *pname = (name != NULL) ? name : NSP_OBJECT(M)->name;
  if ( nsp_from_texmacs() == TRUE ) Sciprintf("\002latex:\\[");
  Sciprintf1(indent,"%s\t=\t\t%s\n",pname, nsp_mpicomm_type_short_string(NSP_OBJECT(M)));
  if ( nsp_from_texmacs() == TRUE ) Sciprintf("\\]\005");
  return TRUE;
}
/*-----------------------------------------------------
 * a set of functions used when writing interfaces 
 * for MpiComm objects 
 * Note that some of these functions could become MACROS 
 *-----------------------------------------------------*/

NspMpiComm   *nsp_mpicomm_object(NspObject *O)
{
  /* Follow pointer */
  if ( check_cast(O,nsp_type_hobj_id) == TRUE)  O = ((NspHobj *) O)->O ;
  /* Check type */
  if ( check_cast (O,nsp_type_mpicomm_id) == TRUE ) return ((NspMpiComm *) O);
  else 
    Scierror("Error:	Argument should be a %s\n",type_get_name(nsp_type_mpicomm));
  return NULL;
}

int IsMpiCommObj(Stack stack, int i)
{
  return nsp_object_type(NthObj(i) , nsp_type_mpicomm_id);
}

int IsMpiComm(NspObject *O)
{
  return nsp_object_type(O,nsp_type_mpicomm_id);
}

NspMpiComm  *GetMpiCommCopy(Stack stack, int i)
{
  if (  GetMpiComm(stack,i) == NULL ) return NULL;
  return MaybeObjCopy(&NthObj(i));
}

NspMpiComm  *GetMpiComm(Stack stack, int i)
{
  NspMpiComm *M;
  if (( M = nsp_mpicomm_object(NthObj(i))) == NULLMPICOMM)
     ArgMessage(stack,i);
  return M;
}

/*-----------------------------------------------------
  * constructor 
 * if type is non NULL it is a subtype which can be used to 
 * create a NspClassB instance 
 *-----------------------------------------------------*/

static NspMpiComm *nsp_mpicomm_create_void(char *name,NspTypeBase *type)
{
 NspMpiComm *H  = (type == NULL) ? new_mpicomm() : type->new();
 if ( H ==  NULLMPICOMM)
  {
   Sciprintf("No more memory\n");
   return NULLMPICOMM;
  }
 if ( nsp_object_set_initial_name(NSP_OBJECT(H),name) == NULLSTRING) return NULLMPICOMM;
 NSP_OBJECT(H)->ret_pos = -1 ;
 return H;
}

int nsp_mpicomm_create_partial(NspMpiComm *H)
{
  if((H->obj = calloc(1,sizeof(nsp_mpicomm)))== NULL ) return FAIL;
  H->obj->ref_count=1;
  return OK;
}

int nsp_mpicomm_check_values(NspMpiComm *H)
{
  return OK;
}

NspMpiComm *nsp_mpicomm_create(char *name,MPI_Comm comm,NspTypeBase *type)
{
 NspMpiComm *H  = nsp_mpicomm_create_void(name,type);
 if ( H ==  NULLMPICOMM) return NULLMPICOMM;
  if ( nsp_mpicomm_create_partial(H) == FAIL) return NULLMPICOMM;
  H->obj->comm=comm;
  /* default error mode is to return 
   */ 
  MPI_Errhandler_set(comm,MPI_ERRORS_RETURN);
  if ( nsp_mpicomm_check_values(H) == FAIL) return NULLMPICOMM;
  return H;
}

/*
 * copy for gobject derived class  
 */

NspMpiComm *nsp_mpicomm_copy_partial(NspMpiComm *H,NspMpiComm *self)
{
  H->obj = self->obj; self->obj->ref_count++;
  return H;
}

NspMpiComm *nsp_mpicomm_copy(NspMpiComm *self)
{
  NspMpiComm *H  =nsp_mpicomm_create_void(NVOID,(NspTypeBase *) nsp_type_mpicomm);
  if ( H ==  NULLMPICOMM) return NULLMPICOMM;
  if ( nsp_mpicomm_copy_partial(H,self)== NULL) return NULLMPICOMM;

  return H;
}
/*
 * full copy for gobject derived class  
 */

NspMpiComm *nsp_mpicomm_full_copy_partial(NspMpiComm *H,NspMpiComm *self)
{
  if ((H->obj = calloc(1,sizeof(nsp_mpicomm))) == NULL) return NULLMPICOMM;
  H->obj->ref_count=1;
  H->obj->comm=self->obj->comm;
  return H;
}

NspMpiComm *nsp_mpicomm_full_copy(NspMpiComm *self)
{
  NspMpiComm *H  =nsp_mpicomm_create_void(NVOID,(NspTypeBase *) nsp_type_mpicomm);
  if ( H ==  NULLMPICOMM) return NULLMPICOMM;
  if ( nsp_mpicomm_full_copy_partial(H,self)== NULL) return NULLMPICOMM;
  return H;
}

/*-------------------------------------------------------------------
 * wrappers for the MpiComm
 * i.e functions at Nsp level 
 *-------------------------------------------------------------------*/

int int_mpicomm_create(Stack stack, int rhs, int opt, int lhs)
{
  char *str ;
  NspMpiComm *H;
  CheckStdRhs(1,1);
  /* want to be sure that type mpicomm is initialized */
  nsp_type_mpicomm = new_type_mpicomm(T_BASE);
  if(( H = nsp_mpicomm_create_void(NVOID,(NspTypeBase *) nsp_type_mpicomm)) == NULLMPICOMM) return RET_BUG;
  /* then we use optional arguments to fill attributes */
  if ( nsp_mpicomm_create_partial(H) == FAIL) return RET_BUG;
  if ((str=GetString(stack,1)) == NULL) return RET_BUG;
  if (!strcmp(str,"NULL"  )) 
    H->obj->comm =MPI_COMM_NULL  ;
  else if (!strcmp(str,"WORLD" ))
    H->obj->comm =MPI_COMM_WORLD ;
  else if (!strcmp(str,"SELF" ))
    H->obj->comm =MPI_COMM_SELF ;
  else			
    {
      Scierror("Error: unable to create MPI Group %s\n",str);
      return RET_BUG;
    }
  MoveObj(stack,1,(NspObject  *) H);
  return 1;
} 


static NspMethods mpicomm_methods[] = {
  { NULL, NULL}
};

static NspMethods *mpicomm_get_methods(void) { return mpicomm_methods;};
/*-------------------------------------------
 * Attributes
 *-------------------------------------------*/

static AttrTab mpicomm_attrs[] = {{NULL,NULL,NULL,NULL,NULL}} ;

/*-------------------------------------------
 * functions 
 *-------------------------------------------*/

/*----------------------------------------------------
 * Interface 
 * i.e a set of function which are accessible at nsp level
 *----------------------------------------------------*/

static OpTab mpicomm_func[]={
  { "mpicomm_create", int_mpicomm_create},
  { NULL, NULL}
};

/* call ith function in the mpicomm interface */

int mpicomm_Interf(int i, Stack stack, int rhs, int opt, int lhs)
{
  return (*(mpicomm_func[i].fonc))(stack,rhs,opt,lhs);
}

/* used to walk through the interface table 
    (for adding or removing functions) */

void mpicomm_Interf_Info(int i, char **fname, function (**f))
{
  *fname = mpicomm_func[i].name;
  *f = mpicomm_func[i].fonc;
}


int int_mpicomm_accept(Stack stack, int rhs, int opt, int lhs)
{ 
  char *port; 
  int root, info;
  NspMpiInfo *inf; 
  NspMpiComm *comm;
  MPI_Comm CLCOMM; 
  int_types T[] = {string,obj_check,s_int,obj_check,t_end};
  if ( GetArgs(stack,rhs,opt,T,&port,&nsp_type_mpiinfo, &inf,&root,&nsp_type_mpicomm, &comm) == FAIL)
    return RET_BUG;
  info = MPI_Comm_accept(port,inf->obj->info,root,comm->obj->comm, &CLCOMM);
  if ( info == MPI_SUCCESS)
    {
      NspMpiComm *res = nsp_mpicomm_create(NVOID,CLCOMM,NULL);
      if ( res == NULL) return RET_BUG;
      MoveObj(stack,1,NSP_OBJECT(res));
      return 1;
    }
  Scierror("Error: %s failed\n",NspFname(stack));
  return RET_BUG;
}

int int_mpicomm_compare(Stack stack, int rhs, int opt, int lhs)
{
  int_types T[] = {obj_check,obj_check, t_end};
  NspMpiComm *comm1,*comm2;
  int result,info;
  CheckLhs(0,1);
  if ( GetArgs(stack,rhs,opt,T,&nsp_type_mpicomm, &comm1,&nsp_type_mpicomm,&comm2) == FAIL) return RET_BUG;
  info = MPI_Comm_compare(comm1->obj->comm, comm2->obj->comm, &result);
  if ( info == MPI_SUCCESS) 
    {
      if ( nsp_move_double(stack,1,result) == FAIL ) return RET_BUG;
      return 1;
    }
  Scierror("Error: %s failed\n",NspFname(stack));
  return RET_BUG;
}

int int_mpicomm_connect(Stack stack, int rhs, int opt, int lhs)
{ 
  char *port; int root; 
  NspMpiInfo *inf; NspMpiComm *comm;
  MPI_Comm CLCOMM; 
  int_types T[] = {string,obj_check,s_int,obj_check,t_end};
  int info;
  if ( GetArgs(stack,rhs,opt,T,&port,&nsp_type_mpiinfo, &inf,&root,&nsp_type_mpicomm, &comm) == FAIL)
    return RET_BUG;
  info = MPI_Comm_connect(port,inf->obj->info,root,comm->obj->comm, &CLCOMM);
  if ( info == MPI_SUCCESS)
    {
      NspMpiComm *res = nsp_mpicomm_create(NVOID,CLCOMM,NULL);
      if ( res == NULL) return RET_BUG;
      MoveObj(stack,1,NSP_OBJECT(res));
      return 1;
    }
  Scierror("Error: %s failed\n",NspFname(stack));
  return RET_BUG;
}

int xxx_int_mpicomm_create(Stack stack, int rhs, int opt, int lhs)
{
  NspMpiGroup *grp; 
  NspMpiComm *comm;
  MPI_Comm COMM2;
  int_types T[] = {obj_check,obj_check,t_end};
  int info;
  if ( GetArgs(stack,rhs,opt,T,&nsp_type_mpicomm,&comm,&nsp_type_mpigroup, &grp) == FAIL)
    return RET_BUG;
  info = MPI_Comm_create(comm->obj->comm, grp->obj->group, &COMM2);
  if ( info == MPI_SUCCESS)
    {
      NspMpiComm *res = nsp_mpicomm_create(NVOID,COMM2,NULL);
      if ( res == NULL) return RET_BUG;
      MoveObj(stack,1,NSP_OBJECT(res));
      return 1;
    }
  Scierror("Error: %s failed\n",NspFname(stack));
  return RET_BUG;
}


int int_mpicomm_disconnect(Stack stack, int rhs, int opt, int lhs)
{ 
  NspMpiComm *comm;
  int_types T[] = {obj_check,t_end};
  int info;
  if ( GetArgs(stack,rhs,opt,T,&nsp_type_mpicomm,&comm) == FAIL)
    return RET_BUG;
  info = MPI_Comm_disconnect(&(comm->obj->comm));
  if ( info == MPI_SUCCESS)
    {
      return 0;
    }
  Scierror("Error: %s failed\n",NspFname(stack));
  return RET_BUG;
}


int int_mpicomm_dup(Stack stack, int rhs, int opt, int lhs)
{
  MPI_Comm COM_OUT;
  NspMpiComm *comm;
  int_types T[] = {obj_check,t_end};
  int info;
  if ( GetArgs(stack,rhs,opt,T,&nsp_type_mpicomm,&comm) == FAIL)
    return RET_BUG;
  info = MPI_Comm_dup(comm->obj->comm, &COM_OUT);
  if ( info == MPI_SUCCESS)
    {
      NspMpiComm *res = nsp_mpicomm_create(NVOID,COM_OUT,NULL);
      if ( res == NULL) return RET_BUG;
      MoveObj(stack,1,NSP_OBJECT(res));
      return 1;
    }
  Scierror("Error: %s failed\n",NspFname(stack));
  return RET_BUG;
}

int int_mpicomm_free(Stack stack, int rhs, int opt, int lhs)
{ 
  int info;
  NspMpiComm *comm;
  int_types T[] = {obj_check,t_end};
  if ( GetArgs(stack,rhs,opt,T,&nsp_type_mpicomm, &comm) == FAIL) return RET_BUG;
  info = MPI_Comm_free(&comm->obj->comm);
  comm->obj->comm = MPI_COMM_NULL;
  if ( info == MPI_SUCCESS)
    {
      return 0;
    }
  Scierror("Error: %s failed\n",NspFname(stack));
  return RET_BUG;
}



int int_mpicomm_get_parent(Stack stack, int rhs, int opt, int lhs)
{
  MPI_Comm COM_OUT;
  int info;
  CheckRhs(0,0);
  CheckLhs(0,1);
  info = MPI_Comm_get_parent(&COM_OUT);
  if ( info == MPI_SUCCESS)
    {
      NspMpiComm *res = nsp_mpicomm_create(NVOID,COM_OUT,NULL);
      if ( res == NULL) return RET_BUG;
      MoveObj(stack,1,NSP_OBJECT(res));
      return 1;
    }
  Scierror("Error: %s failed\n",NspFname(stack));
  return RET_BUG;
}

int int_mpicomm_group(Stack stack, int rhs, int opt, int lhs)
{ 
  MPI_Group GRP;
  NspMpiComm *comm;
  int_types T[] = {obj_check,t_end};
  int info;
  if ( GetArgs(stack,rhs,opt,T,&nsp_type_mpicomm,&comm) == FAIL)
    return RET_BUG;
  info = MPI_Comm_group(comm->obj->comm, &GRP);
  if ( info == MPI_SUCCESS)
    {
      NspMpiGroup *res = nsp_mpigroup_create(NVOID,GRP,NULL);
      if ( res == NULL) return RET_BUG;
      MoveObj(stack,1,NSP_OBJECT(res));
      return 1;
    }
  Scierror("Error: %s failed\n",NspFname(stack));
  return RET_BUG;
}


int int_mpicomm_rank(Stack stack, int rhs, int opt, int lhs)
{ 
  int rank,info;
  NspMpiComm *comm;
  int_types T[] = {obj_check,t_end};
  if ( GetArgs(stack,rhs,opt,T,&nsp_type_mpicomm,&comm) == FAIL)
    return RET_BUG;
  info = MPI_Comm_rank(comm->obj->comm, &rank);
  if ( info == MPI_SUCCESS)
    {
      if ( nsp_move_double(stack,1,rank) == FAIL ) return RET_BUG;
      return 1;
    }
  Scierror("Error: %s failed\n",NspFname(stack));
  return RET_BUG;
}

int int_mpicomm_remote_group(Stack stack, int rhs, int opt, int lhs)
{ 
  MPI_Group GRP;
  NspMpiComm *comm;
  int info;
  int_types T[] = {obj_check,t_end};
  if ( GetArgs(stack,rhs,opt,T,&nsp_type_mpicomm,&comm) == FAIL)
    return RET_BUG;
  info = MPI_Comm_remote_group(comm->obj->comm, &GRP);
  if ( info == MPI_SUCCESS)
    {
      NspMpiGroup *res = nsp_mpigroup_create(NVOID,GRP,NULL);
      if ( res == NULL) return RET_BUG;
      MoveObj(stack,1,NSP_OBJECT(res));
      return 1;
    }
  Scierror("Error: %s failed\n",NspFname(stack));
  return RET_BUG;
}

int int_mpicomm_remote_size(Stack stack, int rhs, int opt, int lhs)
{ 
  int size,info;
  NspMpiComm *comm;
  int_types T[] = {obj_check,t_end};
  if ( GetArgs(stack,rhs,opt,T,&nsp_type_mpicomm,&comm) == FAIL)
    return RET_BUG;
  info = MPI_Comm_remote_size(comm->obj->comm, &size);
  if ( info == MPI_SUCCESS)
    {
      if ( nsp_move_double(stack,1,size) == FAIL ) return RET_BUG;
      return 1;
    }
  Scierror("Error: %s failed\n",NspFname(stack));
  return RET_BUG;
}

int int_mpicomm_size(Stack stack, int rhs, int opt, int lhs)
{ 
  int size,info;
  NspMpiComm *comm;
  int_types T[] = {obj_check,t_end};
  if ( GetArgs(stack,rhs,opt,T,&nsp_type_mpicomm,&comm) == FAIL)
    return RET_BUG;
  info = MPI_Comm_size(comm->obj->comm, &size);
  if ( info == MPI_SUCCESS)
    {
      if ( nsp_move_double(stack,1,size) == FAIL ) return RET_BUG;
      return 1;
    }
  Scierror("Error: %s failed\n",NspFname(stack));
  return RET_BUG;
}

int int_mpicomm_split(Stack stack, int rhs, int opt, int lhs)
{
  int color, key,info;
  NspMpiComm *comm;
  MPI_Comm COMM2;
  int_types T[] = {obj_check,s_int,s_int, t_end};
  if ( GetArgs(stack,rhs,opt,T,&nsp_type_mpicomm,&comm,&color, &key) == FAIL)
    return RET_BUG;
  info = MPI_Comm_split(comm->obj->comm,color,key, &COMM2);
  if ( info == MPI_SUCCESS)
    {
      NspMpiComm *res = nsp_mpicomm_create(NVOID,COMM2,NULL);
      if ( res == NULL) return RET_BUG;
      MoveObj(stack,1,NSP_OBJECT(res));
      return 1;
    }
  Scierror("Error: %s failed\n",NspFname(stack));
  return RET_BUG;
}

int int_mpicomm_test_inter(Stack stack, int rhs, int opt, int lhs)
{ 
  int size,info;
  NspMpiComm *comm;
  int_types T[] = {obj_check,t_end};
  if ( GetArgs(stack,rhs,opt,T,&nsp_type_mpicomm,&comm) == FAIL)
    return RET_BUG;
  info = MPI_Comm_test_inter(comm->obj->comm, &size);
  if ( info == MPI_SUCCESS)
    {
      if ( nsp_move_double(stack,1,size) == FAIL ) return RET_BUG;
      return 1;
    }
  Scierror("Error: %s failed\n",NspFname(stack));
  return RET_BUG;
}


int int_mpicomm_spawn(Stack stack, int rhs, int opt, int lhs)
{
  NspMpiComm *res;
  NspMatrix *Res;
  NspSMatrix *Argv;
  NspMpiInfo *inf;
  NspMpiComm *parents;
  MPI_Comm children;
  int root, nproc,info;
  char *prog;
  int_types T[] = {string,smat,s_int,obj_check,s_int,obj_check,t_end};
  CheckLhs(0,2);
  if ( GetArgs(stack,rhs,opt,T,&prog,&Argv,&nproc,&nsp_type_mpiinfo,&inf,&root,&nsp_type_mpicomm,&parents) == FAIL) 
    return RET_BUG;
  if ( (Res = nsp_matrix_create(NVOID,'r',1,nproc))== NULL) return RET_BUG;
  info = MPI_Comm_spawn(prog,Argv->S, nproc,inf->obj->info, root, parents->obj->comm, &children, Res->I);
  if ( info != MPI_SUCCESS)
    {
      Scierror("Error: %s failed\n",NspFname(stack));
      return RET_BUG;
    }
  if ( lhs >= 2 ) 
    {
      Res->convert = 'i';
      Mat2double (Res);
      MoveObj(stack,2,NSP_OBJECT(Res));
    }
  else 
    {
      nsp_matrix_destroy(Res);
    }
  res = nsp_mpicomm_create(NVOID,children,NULL);
  if ( res == NULL) return RET_BUG;
  MoveObj(stack,1,NSP_OBJECT(res));
  return Max(lhs,1);
}



int int_mpicomm_Intercomm_create(Stack stack, int rhs, int opt, int lhs)
{
  int info,l_leader,r_leader,tag; 
  NspMpiComm *l_comm,*r_comm;
  MPI_Comm COMM;
  int_types T[] = {obj_check,s_int,obj_check,s_int,s_int, t_end};
  if ( GetArgs(stack,rhs,opt,T,&nsp_type_mpicomm,&l_comm,&l_leader,
	       &nsp_type_mpicomm,&r_comm,&r_leader,&tag) == FAIL)
    return RET_BUG;
  info = MPI_Intercomm_create(l_comm->obj->comm,l_leader,r_comm->obj->comm,r_leader,tag,&COMM);
  if ( info == MPI_SUCCESS)
    {
      NspMpiComm *res = nsp_mpicomm_create(NVOID,COMM,NULL);
      if ( res == NULL) return RET_BUG;
      MoveObj(stack,1,NSP_OBJECT(res));
      return 1;
    }
  Scierror("Error: %s failed\n",NspFname(stack));
  return RET_BUG;
}




int int_mpicomm_Intercomm_merge(Stack stack, int rhs, int opt, int lhs)
{
  int high,info;
  NspMpiComm *comm;
  MPI_Comm COMM;
  int_types T[] = {obj_check,s_int, t_end};
  if ( GetArgs(stack,rhs,opt,T,&nsp_type_mpicomm,&comm,&high) == FAIL)
    return RET_BUG;
  info = MPI_Intercomm_merge(comm->obj->comm,high,&COMM);
  if ( info == MPI_SUCCESS)
    {
      NspMpiComm *res = nsp_mpicomm_create(NVOID,COMM,NULL);
      if ( res == NULL) return RET_BUG;
      MoveObj(stack,1,NSP_OBJECT(res));
      return 1;
    }
  Scierror("Error: %s failed\n",NspFname(stack));
  return RET_BUG;
}




int int_mpicomm_Cart_coords(Stack stack, int rhs, int opt, int lhs)
{ 
  NspMatrix *coords;
  int rank,info,ndims;
  NspMpiComm *comm;
  int_types T[] = {obj_check,s_int, t_end};
  if ( GetArgs(stack,rhs,opt,T,&nsp_type_mpicomm,&comm,&rank) == FAIL)
    return RET_BUG;
  info=MPI_Cartdim_get(comm->obj->comm, &ndims);
  if ( info == MPI_SUCCESS)
    {
      if ( (coords = nsp_matrix_create(NVOID,'r',1,ndims))== NULL) return RET_BUG;
      info = MPI_Cart_coords(comm->obj->comm, rank, ndims, coords->I);
      if ( info == MPI_SUCCESS)
	{
	  coords->convert = 'i';
	  Mat2double (coords);
	  MoveObj(stack,1,NSP_OBJECT(coords));
	  return 1;
	}
      nsp_matrix_destroy(coords);
    }
  Scierror("Error: %s failed\n",NspFname(stack));
  return RET_BUG;
}

int int_mpicomm_Cart_create(Stack stack, int rhs, int opt, int lhs)
{
  NspMatrix *dims,*periods;
  int info, reorder;
  MPI_Comm comm_cart;
  NspMpiComm *comm;
  int_types T[] = {obj_check,mat_int, mat_int, s_int, t_end};
  if ( GetArgs(stack,rhs,opt,T,&nsp_type_mpicomm,&comm,&dims,&periods,&reorder) == FAIL)
    return RET_BUG;
  if ( dims->mn != periods->mn) 
    {
      Scierror("Error: dims and periods must have same size\n");
      return RET_BUG;
    }
  info = MPI_Cart_create(comm->obj->comm,dims->mn,dims->I,periods->I,reorder,&comm_cart);
  if ( info == MPI_SUCCESS)
    {
      NspMpiComm *res = nsp_mpicomm_create(NVOID,comm_cart,NULL);
      if ( res == NULL) return RET_BUG;
      MoveObj(stack,1,NSP_OBJECT(res));
      return 1;
    }
  Scierror("Error: %s failed\n",NspFname(stack));
  return RET_BUG;
}

int int_mpicomm_Cartdim_get(Stack stack, int rhs, int opt, int lhs)
{
  int ndims,info;
  NspMpiComm *comm;
  int_types T[] = {obj_check, t_end};
  if ( GetArgs(stack,rhs,opt,T,&nsp_type_mpicomm,&comm) == FAIL)
    return RET_BUG;
  info = MPI_Cartdim_get(comm->obj->comm, &ndims);
  if ( info == MPI_SUCCESS)
    {
      if ( nsp_move_double(stack,1,ndims) == FAIL ) return RET_BUG;
      return 1;
    }
  Scierror("Error: %s failed\n",NspFname(stack));
  return RET_BUG;
}

int int_mpicomm_Cart_get(Stack stack, int rhs, int opt, int lhs)
{
  NspMatrix *vals[3];
  int info,ndims,i;
  NspMpiComm *comm;
  int_types T[] = {obj_check, t_end};
  CheckLhs(0,3);
  if ( GetArgs(stack,rhs,opt,T,&nsp_type_mpicomm,&comm) == FAIL)
    return RET_BUG;
  info=MPI_Cartdim_get(comm->obj->comm, &ndims);
  if ( info == MPI_SUCCESS)
    {
      for ( i= 0; i < 3 ; i++) 
	if ( (vals[i] = nsp_matrix_create(NVOID,'r',1,ndims))== NULL) return RET_BUG;
      info = MPI_Cart_get(comm->obj->comm, ndims,vals[0]->I,vals[1]->I,vals[2]->I);
      if ( info != MPI_SUCCESS)
	{
	  for ( i= 0; i < 3 ; i++)  nsp_matrix_destroy(vals[i]);
	  return RET_BUG;
	}
      for ( i = 1 ; i <= lhs ; i++) 
	{
	  vals[i-1]->convert = 'i';
	  Mat2double (vals[i-1]);
	  MoveObj(stack,i,NSP_OBJECT(vals[i-1]));
	}
      for ( i = lhs+1 ; i < 4 ; i++) 
	nsp_matrix_destroy(vals[i-1]);
      return Max(1,lhs);
    }
  Scierror("Error: %s failed\n",NspFname(stack));
  return RET_BUG;
}

int int_mpicomm_Cart_map(Stack stack, int rhs, int opt, int lhs)
{
  NspMatrix *dims,*periods;
  int rank, info ;
  NspMpiComm *comm;
  int_types T[] = {obj_check,mat_int, mat_int, t_end};
  if ( GetArgs(stack,rhs,opt,T,&nsp_type_mpicomm,&comm,&dims,&periods) == FAIL)
    return RET_BUG;
  if ( dims->mn != periods->mn) 
    {
      Scierror("Error: dims and periods must have same size\n");
      return RET_BUG;
    }
  info = MPI_Cart_map(comm->obj->comm,dims->mn,dims->I,periods->I,&rank);
  if ( info == MPI_SUCCESS)
    {
      if ( nsp_move_double(stack,1,rank) == FAIL ) return RET_BUG;
      return 1;
    }
  Scierror("Error: %s failed\n",NspFname(stack));
  return RET_BUG;
}

int int_mpicomm_Cart_rank(Stack stack, int rhs, int opt, int lhs)
{
  int info,rank;
  NspMatrix *coords;
  NspMpiComm *comm;
  int_types T[] = {obj_check,mat_int, t_end};
  if ( GetArgs(stack,rhs,opt,T,&nsp_type_mpicomm,&comm,&coords) == FAIL)
    return RET_BUG;
  info = MPI_Cart_rank(comm->obj->comm, coords->I, &rank);
  if ( info == MPI_SUCCESS)
    {
      if ( nsp_move_double(stack,1,rank) == FAIL ) return RET_BUG;
      return 1;
    }
  Scierror("Error: %s failed\n",NspFname(stack));
  return RET_BUG;
}


int int_mpicomm_Cart_shift(Stack stack, int rhs, int opt, int lhs)
{
  int dir,disp,rsrc,rdst,info;
  NspMpiComm *comm;
  int_types T[] = {obj_check,s_int, s_int, t_end};
  if ( GetArgs(stack,rhs,opt,T,&nsp_type_mpicomm,&comm,&dir,&disp) == FAIL)
    return RET_BUG;
  info = MPI_Cart_shift(comm->obj->comm, dir,disp, &rsrc,&rdst);
  if ( info == MPI_SUCCESS)
    {
      if ( lhs >= 2 )
	{
	  if ( nsp_move_double(stack,1,rdst) == FAIL ) return RET_BUG;
	}
      if ( nsp_move_double(stack,1,rsrc) == FAIL ) return RET_BUG;
      return Max(1,lhs);
    }
  Scierror("Error: %s failed\n",NspFname(stack));
  return RET_BUG;
}

int int_mpicomm_Cart_sub(Stack stack, int rhs, int opt, int lhs)
{
  NspMatrix *dims;
  int info;
  MPI_Comm comm_sub;
  NspMpiComm *comm;
  int_types T[] = {obj_check, mat_int, t_end};
  if ( GetArgs(stack,rhs,opt,T,&nsp_type_mpicomm,&comm,&dims) == FAIL)
    return RET_BUG;
  info = MPI_Cart_sub(comm->obj->comm, dims->I, &comm_sub);
  if ( info == MPI_SUCCESS)
    {
      NspMpiComm *res = nsp_mpicomm_create(NVOID,comm_sub,NULL);
      if ( res == NULL) return RET_BUG;
      MoveObj(stack,1,NSP_OBJECT(res));
      return 1;
    }
  Scierror("Error: %s failed\n",NspFname(stack));
  return RET_BUG;
}



/*
 * Makes a new communicator to which topology information has been attached
 * [info comm_graph] = MPI_Graph_create (comm, index, edges, reorder)
 */

int int_mpicomm_Graph_create(Stack stack, int rhs, int opt, int lhs)
{
  NspMatrix *index,*edges;
  int info, reorder;
  MPI_Comm comm_graph;
  NspMpiComm *comm;
  int_types T[] = {obj_check,mat_int, mat_int, s_int, t_end};
  if ( GetArgs(stack,rhs,opt,T,&nsp_type_mpicomm,&comm,&index,&edges,&reorder) == FAIL)
    return RET_BUG;
  info = MPI_Graph_create(comm->obj->comm,index->mn,index->I,edges->I,reorder,&comm_graph);
  if ( info == MPI_SUCCESS)
    {
      NspMpiComm *res = nsp_mpicomm_create(NVOID,comm_graph,NULL);
      if ( res == NULL) return RET_BUG;
      MoveObj(stack,1,NSP_OBJECT(res));
      return 1;
    }
  Scierror("Error: %s failed\n",NspFname(stack));
  return RET_BUG;
}

/*
 * Retrieves  graph topology information associated with a  communicator
 * [info nnodes nedges] = MPI_Graphdims_get (comm)
 */

int int_mpicomm_Graphdims_get(Stack stack, int rhs, int opt, int lhs)
{
  int nnodes,nedges,info;
  NspMpiComm *comm;
  int_types T[] = {obj_check, t_end};
  if ( GetArgs(stack,rhs,opt,T,&nsp_type_mpicomm,&comm) == FAIL)
    return RET_BUG;
  info = MPI_Graphdims_get(comm->obj->comm, &nnodes, &nedges);
  if ( info == MPI_SUCCESS)
    {
      if ( lhs >= 2 )
	{
	  if ( nsp_move_double(stack,2,nedges) == FAIL ) return RET_BUG;
	}
      if ( nsp_move_double(stack,1,nnodes) == FAIL ) return RET_BUG;
      return Max(lhs,1);
    }
  Scierror("Error: %s failed\n",NspFname(stack));
  return RET_BUG;
}

/*
 * Retrieves graph topology information associated with a communicator
 * [info index edges] = MPI_Graph_get (comm)
 */

int int_mpicomm_Graph_get(Stack stack, int rhs, int opt, int lhs)
{
  NspMatrix *vals[2];
  int info,nvals[2],i;
  NspMpiComm *comm;
  int_types T[] = {obj_check, t_end};
  CheckLhs(0,2);
  if ( GetArgs(stack,rhs,opt,T,&nsp_type_mpicomm,&comm) == FAIL)
    return RET_BUG;
  info=MPI_Graphdims_get(comm->obj->comm, &nvals[0], &nvals[1]);
  if ( info == MPI_SUCCESS)
    {
      for ( i= 0; i < 2 ; i++) 
	if ( (vals[i] = nsp_matrix_create(NVOID,'r',1,nvals[i]))== NULL) return RET_BUG;
      info = MPI_Graph_get(comm->obj->comm,nvals[0],nvals[1],vals[0]->I,vals[1]->I);
      if ( info != MPI_SUCCESS)
	{
	  for ( i= 0; i < 2 ; i++)  nsp_matrix_destroy(vals[i]);
	  return RET_BUG;
	}
      for ( i = 1 ; i <= lhs ; i++) 
	{
	  vals[i-1]->convert = 'i';
	  Mat2double (vals[i-1]);
	  MoveObj(stack,i,NSP_OBJECT(vals[i-1]));
	}
      for ( i = lhs+1 ; i < 4 ; i++) 
	nsp_matrix_destroy(vals[i-1]);
      return Max(1,lhs);
    }
  Scierror("Error: %s failed\n",NspFname(stack));
  return RET_BUG;
}

/*
 * Maps process to graph topology information
 * Low-level topo function. Don't use it.
 * [info nrank] = MPI_Graph_map (comm, index, edges)
 *
 * The graph described by index and edges is as follows; The three parameters
 * nnodes, index and edges define the graph structure. nnodes is the number of
 * nodes of the graph. The nodes are numbered from 0 to nnodes-1. The ith entry
 * of array index stores the total number of neighbors of the first i graph
 * nodes. The lists of neighbors of nodes 0, 1, ..., nnodes-1 are stored in
 * consecutive locations in array edges. The array edges is a flattened
 * representation of the edge lists. The total number of entries in index is
 * nnodes and the total number of entries in edges is equal to the number of
 * graph edges.
 */

int int_mpicomm_Graph_map(Stack stack, int rhs, int opt, int lhs)
{
  NspMatrix *index,*edges;
  int info,  nrank;
  NspMpiComm *comm;
  int_types T[] = {obj_check,mat_int, mat_int, t_end};
  CheckLhs(0,1);
  if ( GetArgs(stack,rhs,opt,T,&nsp_type_mpicomm,&comm,&index,&edges) == FAIL)
    return RET_BUG;
  if ( edges->mn != index->I[index->mn -1] ) 
    {
      Scierror("Error: %s failed index and edges are not compatible\n",NspFname(stack));
      return RET_BUG;
    }
  info = MPI_Graph_map(comm->obj->comm, index->mn,index->I,edges->I, &nrank);
  if ( info == MPI_SUCCESS)
    {
      if ( nsp_move_double(stack,1,nrank) == FAIL ) return RET_BUG;
      return Max(lhs,1);
    }
  Scierror("Error: %s failed\n",NspFname(stack));
  return RET_BUG;
}

/*
 * Returns the neighbors of a node associated  with a graph topology
 * [info neighs] = MPI_Graph_neighbors (comm, rank)
 */

int int_mpicomm_Graph_neighbors(Stack stack, int rhs, int opt, int lhs)
{
  NspMatrix *neighs;
  int rank,nneighs,info;
  NspMpiComm *comm;
  int_types T[] = {obj_check, s_int, t_end};
  if ( GetArgs(stack,rhs,opt,T,&nsp_type_mpicomm,&comm,&rank) == FAIL)
    return RET_BUG;
  info=MPI_Graph_neighbors_count(comm->obj->comm, rank, &nneighs);
  if (  info == MPI_SUCCESS)
    {
      if ((neighs = nsp_matrix_create(NVOID,'r',1,nneighs))== NULL) return RET_BUG;
      info = MPI_Graph_neighbors(comm->obj->comm, rank, nneighs, neighs->I);
      if ( info != MPI_SUCCESS)
	{
	  nsp_matrix_destroy(neighs);
	  return RET_BUG;
	}
      neighs->convert = 'i';
      Mat2double (neighs);
      MoveObj(stack,1,NSP_OBJECT(neighs));
      return Max(1,lhs);
    }
  Scierror("Error: %s failed\n",NspFname(stack));
  return RET_BUG;
}

/*
 * Returns the number of neighbors of a node associated with a graph topology
 * [info nneighs] = MPI_Graph_neighbors_count (comm, rank)
 */

int int_mpicomm_Graph_neighbors_count (Stack stack, int rhs, int opt, int lhs)
{
  int rank,nneighs,info;
  NspMpiComm *comm;
  int_types T[] = {obj_check, s_int, t_end};
  if ( GetArgs(stack,rhs,opt,T,&nsp_type_mpicomm,&comm,&rank) == FAIL)
    return RET_BUG;
  info = MPI_Graph_neighbors_count(comm->obj->comm,rank, &nneighs);
  if ( info == MPI_SUCCESS)
    {
      if ( nsp_move_double(stack,1,nneighs) == FAIL ) return RET_BUG;
      return Max(lhs,1);
    }
  Scierror("Error: %s failed\n",NspFname(stack));
  return RET_BUG;
}


int int_mpicomm_Topo_test(Stack stack, int rhs, int opt, int lhs)
{ 
  int topo,info;
  NspMpiComm *comm;
  int_types T[] = {obj_check,t_end};
  if ( GetArgs(stack,rhs,opt,T,&nsp_type_mpicomm,&comm) == FAIL)
    return RET_BUG;
  info = MPI_Topo_test(comm->obj->comm, &topo);
  if ( info == MPI_SUCCESS)
    {
      if ( nsp_move_double(stack,1,topo) == FAIL ) return RET_BUG;
      return 1;
    }
  Scierror("Error: %s failed\n",NspFname(stack));
  return RET_BUG;
}
