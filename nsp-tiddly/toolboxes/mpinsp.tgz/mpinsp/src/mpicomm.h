/* -*- Mode: C -*- */
#ifndef NSP_INC_MpiComm
#define NSP_INC_MpiComm

/*
 * This Software is GPL (Copyright ENPC 1998-2013) 
 * Jean-Philippe Chancelier Enpc/Cermics         
 */

/* MpiComm */

#include <mpi.h>
#include "nsp/object.h"

/*
 * NspMpiComm inherits from NspObject
 */

typedef struct _NspMpiComm NspMpiComm ;
typedef struct _NspTypeMpiComm NspTypeMpiComm ;


struct _NspTypeMpiComm {
  /*< private >*/
  NSP_TYPE_OBJECT__
  /*< public >*/
  
};

typedef struct _nsp_mpicomm nsp_mpicomm;
struct _nsp_mpicomm {
  MPI_Comm comm;
  int ref_count;
};

struct _NspMpiComm {
  /*< private >*/
  NspObject father;
  NspTypeMpiComm*type;
  /*< public >*/
  nsp_mpicomm *obj;
};

extern int nsp_type_mpicomm_id;
extern NspTypeMpiComm *nsp_type_mpicomm;

/* type instances for object */

NspTypeMpiComm *new_type_mpicomm(type_mode mode);

/* instance for MpiComm */

NspMpiComm *new_mpicomm();

/*
* Object methods redefined for mpicomm 
*/


#define NULLMPICOMM (NspMpiComm*) 0

extern NspMpiComm *nsp_mpicomm_create(char *name,MPI_Comm comm,NspTypeBase *type);

/* from MpiCommObj.c */

extern NspMpiComm *nsp_mpicomm_copy(NspMpiComm *H);
extern void nsp_mpicomm_destroy(NspMpiComm *H);
extern int nsp_mpicomm_info(NspMpiComm *H, int indent,const char *name, int rec_level);
extern int nsp_mpicomm_print(NspMpiComm *H, int indent,const char *name, int rec_level);
extern int nsp_mpicomm_latex(NspMpiComm *H, int indent,const char *name, int rec_level);
extern NspMpiComm *nsp_mpicomm_object (NspObject *O); 
extern int IsMpiCommObj (Stack stack, int i); 
extern int IsMpiComm(NspObject *O);
extern NspMpiComm *GetMpiCommCopy (Stack stack, int i); 
extern NspMpiComm *GetMpiComm (Stack stack, int i); 
extern int nsp_mpicomm_create_partial(NspMpiComm *H);
extern void nsp_mpicomm_destroy_partial(NspMpiComm *H);
extern NspMpiComm * nsp_mpicomm_copy_partial(NspMpiComm *H,NspMpiComm *self);
extern NspMpiComm * nsp_mpicomm_full_copy_partial(NspMpiComm *H,NspMpiComm *self);
extern NspMpiComm * nsp_mpicomm_full_copy(NspMpiComm *self);
extern int nsp_mpicomm_check_values(NspMpiComm *H);
extern int int_mpicomm_create(Stack stack, int rhs, int opt, int lhs); 
extern NspMpiComm *nsp_mpicomm_xdr_load_partial(XDR *xdrs, NspMpiComm *M);
extern int nsp_mpicomm_xdr_save(XDR  *xdrs, NspMpiComm *M);

#endif /* NSP_INC_MpiComm */ 

#ifdef MpiComm_Private 
static int init_mpicomm(NspMpiComm *o,NspTypeMpiComm *type);
static int nsp_mpicomm_size(NspMpiComm *Mat, int flag);
static char *nsp_mpicomm_type_as_string(void);
static char *nsp_mpicomm_type_short_string(NspObject *v);
static int nsp_mpicomm_eq(NspMpiComm *A, NspObject *B);
static int nsp_mpicomm_neq(NspMpiComm *A, NspObject *B);
static NspMpiComm *nsp_mpicomm_xdr_load(XDR *xdrs);
static AttrTab mpicomm_attrs[];
static NspMethods *mpicomm_get_methods(void);
/* static int int_mpicomm_create(Stack stack, int rhs, int opt, int lhs);*/ 
static NspMpiComm *nsp_mpicomm_create_void(char *name,NspTypeBase *type);
#endif /* MpiComm_Private */

