/* Nsp
 * Copyright (C) 2009-2013 Jean-Philippe Chancelier Enpc/Cermics
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public
 * License along with this library; if not, write to the
 * Free Software Foundation, Inc., 59 Temple Place - Suite 330,
 * Boston, MA 02111-1307, USA.
 *
 * Group object for MPI. 
 *
 * To be finished: free 
 */

#define  MpiGroup_Private 
#include "nsp/objects.h"
#include "mpigroup.h"
#include "nsp/interf.h"

/* 
 * NspMpiGroup inherits from NspObject 
 */

int nsp_type_mpigroup_id=0;
NspTypeMpiGroup *nsp_type_mpigroup=NULL;

/*
 * Type object for MpiGroup 
 * all the instance of NspTypeMpiGroup share the same id. 
 * nsp_type_mpigroup: is an instance of NspTypeMpiGroup 
 *    used for objects of NspMpiGroup type (i.e built with new_mpigroup) 
 * other instances are used for derived classes 
 */
NspTypeMpiGroup *new_type_mpigroup(type_mode mode)
{
  NspTypeMpiGroup *type= NULL;
  NspTypeObject *top;
  if (  nsp_type_mpigroup != 0 && mode == T_BASE ) 
    {
      /* initialization performed and T_BASE requested */
      return nsp_type_mpigroup;
    }
  if ((type =  malloc(sizeof(NspTypeMpiGroup))) == NULL) return NULL;
  type->interface = NULL;
  type->surtype = (NspTypeBase *) new_type_object(T_DERIVED);
  if ( type->surtype == NULL) return NULL;
  type->attrs = mpigroup_attrs ; 
  type->get_attrs = (attrs_func *) int_get_attribute;
  type->set_attrs = (attrs_func *) int_set_attribute;
  type->methods = mpigroup_get_methods; 
  type->new = (new_func *) new_mpigroup;

  
  top = NSP_TYPE_OBJECT(type->surtype);
  while ( top->surtype != NULL ) top= NSP_TYPE_OBJECT(top->surtype);
  
  /* object methods redefined for mpigroup */ 

  top->pr = (print_func *) nsp_mpigroup_print;                  
  top->dealloc = (dealloc_func *) nsp_mpigroup_destroy;
  top->copy  =  (copy_func *) nsp_mpigroup_copy;                 
  top->size  = (size_func *) nsp_mpigroup_size;                
  top->s_type =  (s_type_func *) nsp_mpigroup_type_as_string;  
  top->sh_type = (sh_type_func *) nsp_mpigroup_type_short_string;
  top->info = (info_func *) nsp_mpigroup_info ;                  
  /* top->is_true = (is_true_func  *) nsp_mpigroup_is_true; */
  /* top->loop =(loop_func *) nsp_mpigroup_loop;*/
  top->path_extract = (path_func *)  object_path_extract; 
  top->get_from_obj = (get_from_obj_func *) nsp_mpigroup_object;
  top->eq  = (eq_func *) nsp_mpigroup_eq;
  top->neq  = (eq_func *) nsp_mpigroup_neq;
  top->save  = (save_func *) nsp_mpigroup_xdr_save;
  top->load  = (load_func *) nsp_mpigroup_xdr_load;
  top->create = (create_func*) int_mpigroup_create;
  top->latex = (print_func *) nsp_mpigroup_latex;
  
  /* specific methods for mpigroup */
      
  type->init = (init_func *) init_mpigroup;

  /* 
   * MpiGroup interfaces can be added here 
   * type->interface = (NspTypeBase *) new_type_b();
   * type->interface->interface = (NspTypeBase *) new_type_C()
   * ....
   */
  if ( nsp_type_mpigroup_id == 0 ) 
    {
      /* 
       * the first time we get here we initialize the type id and
       * an instance of NspTypeMpiGroup called nsp_type_mpigroup
       */
      type->id =  nsp_type_mpigroup_id = nsp_new_type_id();
      nsp_type_mpigroup = type;
      if ( nsp_register_type(nsp_type_mpigroup) == FALSE) return NULL;
      return ( mode == T_BASE ) ? type : new_type_mpigroup(mode);
    }
  else 
    {
       type->id = nsp_type_mpigroup_id;
       return type;
    }
}

/*
 * initialize MpiGroup instances 
 * locally and by calling initializer on parent class 
 */

static int init_mpigroup(NspMpiGroup *Obj,NspTypeMpiGroup *type)
{
  /* jump the first surtype */ 
  if ( type->surtype->init(&Obj->father,type->surtype) == FAIL) return FAIL;
  Obj->type = type; 
  NSP_OBJECT(Obj)->basetype = (NspTypeBase *)type;
  /* specific */
  Obj->obj = NULL;
  return OK;
}

/*
 * new instance of MpiGroup 
 */

NspMpiGroup *new_mpigroup() 
{
  NspMpiGroup *loc; 
  /* type must exists */
  nsp_type_mpigroup = new_type_mpigroup(T_BASE);
  if ( (loc = malloc(sizeof(NspMpiGroup)))== NULLMPIGROUP) return loc;
  /* initialize object */
  if ( init_mpigroup(loc,nsp_type_mpigroup) == FAIL) return NULLMPIGROUP;
  return loc;
}

/*----------------------------------------------
 * Object method redefined for MpiGroup 
 *-----------------------------------------------*/
/*
 * size 
 */

static int nsp_mpigroup_size(NspMpiGroup *Mat, int flag)
{
  return 0;
}

/*
 * type as string 
 */

static char mpigroup_type_name[]="MpiGroup";
static char mpigroup_short_type_name[]="mpigroup";

static char *nsp_mpigroup_type_as_string(void)
{
  return(mpigroup_type_name);
}

static char *nsp_mpigroup_type_short_string(NspObject *v)
{
  return(mpigroup_short_type_name);
}

/*
 * A == B 
 */

static int nsp_mpigroup_eq(NspMpiGroup *A, NspObject *B)
{
  NspMpiGroup *loc = (NspMpiGroup *) B;
  if ( check_cast(B,nsp_type_mpigroup_id) == FALSE) return FALSE ;
  if ( A->obj == loc->obj ) return TRUE;
  if ( A->obj->group != loc->obj->group) return FALSE;
  return TRUE;
}

/*
 * A != B 
 */

static int nsp_mpigroup_neq(NspMpiGroup *A, NspObject *B)
{
  return ( nsp_mpigroup_eq(A,B) == TRUE ) ? FALSE : TRUE;
}

/*
 * save 
 */

int nsp_mpigroup_xdr_save(XDR *xdrs, NspMpiGroup *M)
{
  if (nsp_xdr_save_i(xdrs,M->type->id) == FAIL) return FAIL;
  if (nsp_xdr_save_string(xdrs, NSP_OBJECT(M)->name) == FAIL) return FAIL;
  return OK;
}

/*
 * load 
 */

NspMpiGroup  *nsp_mpigroup_xdr_load_partial(XDR *xdrs, NspMpiGroup *M)
{
  if ((M->obj = malloc(sizeof(nsp_mpigroup))) == NULL) return NULL;
 return M;
}

static NspMpiGroup  *nsp_mpigroup_xdr_load(XDR *xdrs)
{
  NspMpiGroup *M = NULL;
  static char name[NAME_MAXL];
  if (nsp_xdr_load_string(xdrs,name,NAME_MAXL) == FAIL) return NULLMPIGROUP;
  if ((M  = nsp_mpigroup_create_void(name,(NspTypeBase *) nsp_type_mpigroup))== NULLMPIGROUP) return M;
  return nsp_mpigroup_xdr_load_partial(xdrs,M);
}

/*
 * delete 
 */

void nsp_mpigroup_destroy_partial(NspMpiGroup *H)
{
  H->obj->ref_count--;
  if ( H->obj->ref_count == 0 )
    {
      /* XXXXX Pb si le groupe est NULL ou EMPTY ? 
       * MPI_Group_free(&(H->obj->group)); */
      FREE(H->obj);
   }
}

void nsp_mpigroup_destroy(NspMpiGroup *H)
{
  nsp_object_destroy_name(NSP_OBJECT(H));
  nsp_mpigroup_destroy_partial(H);
  FREE(H);
}

/*
 * info 
 */

int nsp_mpigroup_info(NspMpiGroup *M,int indent,const char *name,int rec_level)
{
  const char *pname;
  if ( M == NULLMPIGROUP) 
    {
      Sciprintf("Null Pointer MpiGroup \n");
      return TRUE;
    }
  pname = (name != NULL) ? name : NSP_OBJECT(M)->name;
  Sciprintf1(indent,"%s\t=\t\t%s\n", (pname==NULL) ? "" : pname,
             nsp_mpigroup_type_short_string(NSP_OBJECT(M)));
  return TRUE;
}

/*
 * print 
 */

int nsp_mpigroup_print(NspMpiGroup *M, int indent,const char *name, int rec_level)
{
  const char *pname = (name != NULL) ? name : NSP_OBJECT(M)->name;
  if ( M == NULLMPIGROUP) 
    {
      Sciprintf("Null Pointer MpiGroup \n");
      return TRUE;
    }
  if (user_pref.pr_as_read_syntax) 
    { 
      Sciprintf1(indent,"%s=TO_BE_DONE();\n",pname);
    } 
  else 
    { 
      if ( user_pref.pr_depth  <= rec_level -1 ) 
        {
          nsp_mpigroup_info(M,indent,pname,rec_level);
          return TRUE;
        }
      Sciprintf1(indent,"%s\t=\t\t%s (nref=%d)\n",pname, nsp_mpigroup_type_short_string(NSP_OBJECT(M)) ,M->obj->ref_count);
      Sciprintf1(indent+1,"{\n");
      /* Sciprintf1(indent+2,"group	= %s\n", ( M->obj->group == TRUE) ? "T" : "F" ); */
      Sciprintf1(indent+1,"}\n");
    }
  return TRUE;
}

/*
 * latex print 
 */

int nsp_mpigroup_latex(NspMpiGroup *M, int indent,const char *name, int rec_level)
{
  const char *pname = (name != NULL) ? name : NSP_OBJECT(M)->name;
  if ( nsp_from_texmacs() == TRUE ) Sciprintf("\002latex:\\[");
  Sciprintf1(indent,"%s\t=\t\t%s\n",pname, nsp_mpigroup_type_short_string(NSP_OBJECT(M)));
  Sciprintf1(indent+1,"{\n");
  /* Sciprintf1(indent+2,"group	= %s\n", ( M->obj->group == TRUE) ? "T" : "F" ); */
  Sciprintf1(indent+1,"}\n");
  if ( nsp_from_texmacs() == TRUE ) Sciprintf("\\]\005");
  return TRUE;
}
/*-----------------------------------------------------
 * a set of functions used when writing interfaces 
 * for MpiGroup objects 
 * Note that some of these functions could become MACROS 
 *-----------------------------------------------------*/

NspMpiGroup   *nsp_mpigroup_object(NspObject *O)
{
  /* Follow pointer */
  if ( check_cast(O,nsp_type_hobj_id) == TRUE)  O = ((NspHobj *) O)->O ;
  /* Check type */
  if ( check_cast (O,nsp_type_mpigroup_id) == TRUE ) return ((NspMpiGroup *) O);
  else 
    Scierror("Error:	Argument should be a %s\n",type_get_name(nsp_type_mpigroup));
  return NULL;
}

int IsMpiGroupObj(Stack stack, int i)
{
  return nsp_object_type(NthObj(i) , nsp_type_mpigroup_id);
}

int IsMpiGroup(NspObject *O)
{
  return nsp_object_type(O,nsp_type_mpigroup_id);
}

NspMpiGroup  *GetMpiGroupCopy(Stack stack, int i)
{
  if (  GetMpiGroup(stack,i) == NULL ) return NULL;
  return MaybeObjCopy(&NthObj(i));
}

NspMpiGroup  *GetMpiGroup(Stack stack, int i)
{
  NspMpiGroup *M;
  if (( M = nsp_mpigroup_object(NthObj(i))) == NULLMPIGROUP)
     ArgMessage(stack,i);
  return M;
}

/*-----------------------------------------------------
  * constructor 
 * if type is non NULL it is a subtype which can be used to 
 * create a NspClassB instance 
 *-----------------------------------------------------*/

static NspMpiGroup *nsp_mpigroup_create_void(char *name,NspTypeBase *type)
{
 NspMpiGroup *H  = (type == NULL) ? new_mpigroup() : type->new();
 if ( H ==  NULLMPIGROUP)
  {
   Sciprintf("No more memory\n");
   return NULLMPIGROUP;
  }
 if ( nsp_object_set_initial_name(NSP_OBJECT(H),name) == NULLSTRING) return NULLMPIGROUP;
 NSP_OBJECT(H)->ret_pos = -1 ;
 return H;
}

int nsp_mpigroup_create_partial(NspMpiGroup *H)
{
  if((H->obj = calloc(1,sizeof(nsp_mpigroup)))== NULL ) return FAIL;
  H->obj->ref_count=1;
  return OK;
}

int nsp_mpigroup_check_values(NspMpiGroup *H)
{
  return OK;
}

NspMpiGroup *nsp_mpigroup_create(char *name,  MPI_Group group,NspTypeBase *type)
{
 NspMpiGroup *H  = nsp_mpigroup_create_void(name,type);
 if ( H ==  NULLMPIGROUP) return NULLMPIGROUP;
  if ( nsp_mpigroup_create_partial(H) == FAIL) return NULLMPIGROUP;
  H->obj->group=group;
 if ( nsp_mpigroup_check_values(H) == FAIL) return NULLMPIGROUP;
 return H;
}

/*
 * copy for gobject derived class  
 */

NspMpiGroup *nsp_mpigroup_copy_partial(NspMpiGroup *H,NspMpiGroup *self)
{
  H->obj = self->obj; self->obj->ref_count++;
  return H;
}

NspMpiGroup *nsp_mpigroup_copy(NspMpiGroup *self)
{
  NspMpiGroup *H  =nsp_mpigroup_create_void(NVOID,(NspTypeBase *) nsp_type_mpigroup);
  if ( H ==  NULLMPIGROUP) return NULLMPIGROUP;
  if ( nsp_mpigroup_copy_partial(H,self)== NULL) return NULLMPIGROUP;

  return H;
}
/*
 * full copy for gobject derived class  
 */

NspMpiGroup *nsp_mpigroup_full_copy_partial(NspMpiGroup *H,NspMpiGroup *self)
{
  if ((H->obj = calloc(1,sizeof(nsp_mpigroup))) == NULL) return NULLMPIGROUP;
  H->obj->ref_count=1;
  H->obj->group=self->obj->group;
  return H;
}

NspMpiGroup *nsp_mpigroup_full_copy(NspMpiGroup *self)
{
  NspMpiGroup *H  =nsp_mpigroup_create_void(NVOID,(NspTypeBase *) nsp_type_mpigroup);
  if ( H ==  NULLMPIGROUP) return NULLMPIGROUP;
  if ( nsp_mpigroup_full_copy_partial(H,self)== NULL) return NULLMPIGROUP;
  return H;
}

/*-------------------------------------------------------------------
 * wrappers for the MpiGroup
 * i.e functions at Nsp level 
 *-------------------------------------------------------------------*/

int int_mpigroup_create(Stack stack, int rhs, int opt, int lhs)
{
  char *str ;
  NspMpiGroup *H;
  CheckStdRhs(1,1);
  /* want to be sure that type mpigroup is initialized */
  nsp_type_mpigroup = new_type_mpigroup(T_BASE);
  if(( H = nsp_mpigroup_create_void(NVOID,(NspTypeBase *) nsp_type_mpigroup)) == NULLMPIGROUP) 
    return RET_BUG;
  /* then we use optional arguments to fill attributes */
  if ( nsp_mpigroup_create_partial(H) == FAIL) return RET_BUG;
  if ((str=GetString(stack,1)) == NULL) return RET_BUG;
  if (!strcmp(str,"NULL"  )) 
    H->obj->group =MPI_GROUP_NULL  ;
  else if (!strcmp(str,"EMPTY" ))
    H->obj->group =MPI_GROUP_EMPTY ;
  else			
    {
      Scierror("Error: unable to create MPI Group %s\n",str);
      return RET_BUG;
    }
  MoveObj(stack,1,(NspObject  *) H);
  return 1;
} 

static int _wrap_diff_poo(NspMpiGroup *self,Stack stack,int rhs,int opt,int lhs)
{
  int_types T[] = {obj_check,t_end};
  int ret=0;
  NspObject *grp;
  if ( GetArgs(stack,rhs,opt,T,&nsp_type_mpigroup, &grp) == FAIL) return RET_BUG;
  /* XXX ret = diff_poo(self, grp ); */
  if ( nsp_move_double(stack,1,(double) ret)==FAIL) return RET_BUG;
  return 1;
}

static NspMethods mpigroup_methods[] = {
  {"difference",(nsp_method *) _wrap_diff_poo},
  { NULL, NULL}
};

static NspMethods *mpigroup_get_methods(void) { return mpigroup_methods;};
/*-------------------------------------------
 * Attributes
 *-------------------------------------------*/

static AttrTab mpigroup_attrs[] = {{NULL,NULL,NULL,NULL,NULL}} ;

/*-------------------------------------------
 * functions 
 *-------------------------------------------*/

int int_mpi_group_compare(Stack stack,int rhs,int opt,int lhs)
{
  int_types T[] = {obj_check,obj_check,t_end};
  int result,info;
  NspMpiGroup *grp1,*grp2;
  if ( GetArgs(stack,rhs,opt,T,&nsp_type_mpigroup, &grp1,&nsp_type_mpigroup, &grp2) == FAIL) 
    return RET_BUG;
  info= MPI_Group_compare(grp1->obj->group,grp2->obj->group, &result);
  if ( lhs >= 2 ) 
    {
      if ( nsp_move_double(stack,2,(double) result)==FAIL) return RET_BUG;
    }
  if ( nsp_move_double(stack,1,(double) info)==FAIL) return RET_BUG;
  return Max(lhs,1);
}

typedef int (mpi_group_op2)(MPI_Group GRP1,MPI_Group GRP2,MPI_Group *GRP);

static int int_mpi_group_gen(Stack stack,int rhs,int opt,int lhs, mpi_group_op2 *F)
{
  int_types T[] = {obj_check,obj_check,t_end};
  int result=0,info;
  NspMpiGroup *grp1,*grp2,*grp;
  MPI_Group GRP;
  if ( GetArgs(stack,rhs,opt,T,&nsp_type_mpigroup, &grp1,&nsp_type_mpigroup, &grp2) == FAIL) 
    return RET_BUG;
  info= (*F)(grp1->obj->group,grp2->obj->group,&GRP);
  if ( info == MPI_SUCCESS) 
    {
      grp = nsp_mpigroup_create(NVOID,GRP,NULL);
      if ( grp == NULL) return RET_BUG;
      if ( lhs >= 2 ) 
	{
	  MoveObj(stack,2,NSP_OBJECT(grp));
	}
      if ( nsp_move_double(stack,1,(double) info)==FAIL) return RET_BUG;
    }
  else 
    {
      if ( lhs >= 2 ) 
	{
	  if ( nsp_move_double(stack,2,(double) result)==FAIL) return RET_BUG;
	}
      if ( nsp_move_double(stack,1,(double) info)==FAIL) return RET_BUG;
    }
  return Max(lhs,1);
}

int int_mpi_group_difference(Stack stack,int rhs,int opt,int lhs)
{
  return int_mpi_group_gen(stack,rhs,opt,lhs, MPI_Group_difference);
}

int int_mpi_group_union(Stack stack,int rhs,int opt,int lhs)
{
  return int_mpi_group_gen(stack,rhs,opt,lhs, MPI_Group_union);
}

int int_mpi_group_intersection(Stack stack,int rhs,int opt,int lhs)
{
  return int_mpi_group_gen(stack,rhs,opt,lhs, MPI_Group_intersection);
}

typedef int (mpi_group_op)(MPI_Group GRP1,int n, int *val,MPI_Group *GRP);

static int int_mpi_group_excl_incl(Stack stack,int rhs,int opt,int lhs, mpi_group_op *F)
{
  NspMatrix *Ranks;
  int_types T[] = {obj_check, mat_int,t_end};
  int result=0,info;
  NspMpiGroup *grp1,*grp;
  MPI_Group GRP;
  if ( GetArgs(stack,rhs,opt,T,&nsp_type_mpigroup, &grp1,&Ranks) == FAIL) 
    return RET_BUG;
  /* we want group_excl not to abort 
   * XXXXXXX 
   */
  MPI_Errhandler_set(MPI_COMM_WORLD,MPI_ERRORS_RETURN);

  
  info= (*F)(grp1->obj->group,Ranks->mn,Ranks->I, &GRP);
  if ( info == MPI_SUCCESS) 
    {
      grp = nsp_mpigroup_create(NVOID,GRP,NULL);
      if ( grp == NULL) return RET_BUG;
      if ( lhs >= 2 ) 
	{
	  MoveObj(stack,2,NSP_OBJECT(grp));
	}
      if ( nsp_move_double(stack,1,(double) info)==FAIL) return RET_BUG;
    }
  else 
    {
      if ( lhs >= 2 ) 
	{
	  if ( nsp_move_double(stack,2,(double) result)==FAIL) return RET_BUG;
	}
      if ( nsp_move_double(stack,1,(double) info)==FAIL) return RET_BUG;
    }
  return Max(lhs,1);
}


int int_mpi_group_excl(Stack stack,int rhs,int opt,int lhs)
{
  return int_mpi_group_excl_incl(stack,rhs,opt,lhs, MPI_Group_excl);
}

int int_mpi_group_incl(Stack stack,int rhs,int opt,int lhs)
{
  return int_mpi_group_excl_incl(stack,rhs,opt,lhs, MPI_Group_incl);
}

typedef int (mpi_group_op_range)(MPI_Group GRP1,int n,int ranges[][3],MPI_Group *GRP);
typedef int rng[3]; 

static int int_mpi_group_range_excl_incl(Stack stack,int rhs,int opt,int lhs, mpi_group_op_range *F)
{
  NspMatrix *Ranks;
  int_types T[] = {obj_check, mat_int,t_end};
  int result=0,info;
  NspMpiGroup *grp1,*grp;
  MPI_Group GRP;
  if ( GetArgs(stack,rhs,opt,T,&nsp_type_mpigroup, &grp1,&Ranks) == FAIL) 
    return RET_BUG;
  /* we want group_excl not to abort 
   * XXXXXXX 
   */
  MPI_Errhandler_set(MPI_COMM_WORLD,MPI_ERRORS_RETURN);
  if ( Ranks->m != 3 ) 
    {
      Scierror("Erorr: range should be a 3xn matrix\n");
      return RET_BUG;
    }
  info= (*F)(grp1->obj->group,Ranks->mn/3 ,(rng*) Ranks->I, &GRP);
  if ( info == MPI_SUCCESS) 
    {
      grp = nsp_mpigroup_create(NVOID,GRP,NULL);
      if ( grp == NULL) return RET_BUG;
      if ( lhs >= 2 ) 
	{
	  MoveObj(stack,2,NSP_OBJECT(grp));
	}
      if ( nsp_move_double(stack,1,(double) info)==FAIL) return RET_BUG;
    }
  else 
    {
      if ( lhs >= 2 ) 
	{
	  if ( nsp_move_double(stack,2,(double) result)==FAIL) return RET_BUG;
	}
      if ( nsp_move_double(stack,1,(double) info)==FAIL) return RET_BUG;
    }
  return Max(lhs,1);
}


int int_mpi_group_range_excl(Stack stack,int rhs,int opt,int lhs)
{
  return int_mpi_group_range_excl_incl(stack,rhs,opt,lhs, MPI_Group_range_excl);
}

int int_mpi_group_range_incl(Stack stack,int rhs,int opt,int lhs)
{
  return int_mpi_group_range_excl_incl(stack,rhs,opt,lhs, MPI_Group_range_incl);
}

int int_mpi_group_rank(Stack stack,int rhs,int opt,int lhs)
{
  int_types T[] = {obj_check,t_end};
  int result=0,info;
  NspMpiGroup *grp1;
  if ( GetArgs(stack,rhs,opt,T,&nsp_type_mpigroup, &grp1) == FAIL) 
    return RET_BUG;
  info= MPI_Group_rank(grp1->obj->group,&result);
  if ( lhs >= 2 ) 
    {
      if ( nsp_move_double(stack,2,(double) result)==FAIL) return RET_BUG;
    }
  if ( nsp_move_double(stack,1,(double) info)==FAIL) return RET_BUG;
  return Max(lhs,1);
}

int int_mpi_group_size(Stack stack,int rhs,int opt,int lhs)
{
  int_types T[] = {obj_check,t_end};
  int result=0,info;
  NspMpiGroup *grp1;
  if ( GetArgs(stack,rhs,opt,T,&nsp_type_mpigroup, &grp1) == FAIL) 
    return RET_BUG;
  info= MPI_Group_size(grp1->obj->group,&result);
  if ( lhs >= 2 ) 
    {
      if ( nsp_move_double(stack,2,(double) result)==FAIL) return RET_BUG;
    }
  if ( nsp_move_double(stack,1,(double) info)==FAIL) return RET_BUG;
  return Max(lhs,1);
}


int int_mpi_group_translate_ranks(Stack stack,int rhs,int opt,int lhs)
{
  NspMatrix *Ranks,*Res;
  int_types T[] = {obj_check, mat_int,obj_check, t_end};
  int info;
  NspMpiGroup *grp1,*grp2;
  if ( GetArgs(stack,rhs,opt,T,&nsp_type_mpigroup, &grp1,&Ranks,&nsp_type_mpigroup, &grp2) == FAIL) 
    return RET_BUG;
  if ( (Res = nsp_matrix_create(NVOID,'r',1,Ranks->mn))== NULL) return RET_BUG;
  info = MPI_Group_translate_ranks(grp1->obj->group,Ranks->mn,Ranks->I,grp2->obj->group,Res->I);
  if ( lhs >= 2 ) 
    {
      Res->convert = 'i';
      Mat2double (Res);
      MoveObj(stack,2,NSP_OBJECT(Res));
    }
  else 
    {
      nsp_matrix_destroy(Res);
    }
  if ( nsp_move_double(stack,1,(double) info)==FAIL) return RET_BUG;
  return Max(lhs,1);
  

}


/*----------------------------------------------------
 * Interface 
 * i.e a set of function which are accessible at nsp level
 *----------------------------------------------------*/

static OpTab mpigroup_func[]={
  {"MPI_Group_compare", int_mpi_group_compare},
  {"MPI_Group_difference", int_mpi_group_difference},
  {"MPI_Group_union", int_mpi_group_union},
  {"MPI_Group_intersection", int_mpi_group_intersection},
  {"MPI_Group_excl", int_mpi_group_excl},
  {"MPI_Group_incl", int_mpi_group_incl},
  {"MPI_Group_range_excl", int_mpi_group_range_excl},
  {"MPI_Group_range_incl", int_mpi_group_range_incl},
  {"MPI_Group_rank", int_mpi_group_rank},
  {"MPI_Group_size", int_mpi_group_size},
  {"MPI_Group_translate_ranks", int_mpi_group_translate_ranks},
  { "mpigroup_create", int_mpigroup_create},
  { NULL, NULL}
};

/* call ith function in the mpigroup interface */

int mpigroup_Interf(int i, Stack stack, int rhs, int opt, int lhs)
{
  return (*(mpigroup_func[i].fonc))(stack,rhs,opt,lhs);
}

/* used to walk through the interface table 
    (for adding or removing functions) */

void mpigroup_Interf_Info(int i, char **fname, function (**f))
{
  *fname = mpigroup_func[i].name;
  *f = mpigroup_func[i].fonc;
}

