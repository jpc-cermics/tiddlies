/* -*- Mode: C -*- */
#ifndef NSP_INC_MpiGroup
#define NSP_INC_MpiGroup

/*
 * This Software is GPL (Copyright ENPC 1998-2013) 
 * Jean-Philippe Chancelier Enpc/Cermics         
 */

/* MpiGroup */

#include <mpi.h>	
#include "nsp/object.h"

/*
 * NspMpiGroup inherits from NspObject
 */

typedef struct _NspMpiGroup NspMpiGroup ;
typedef struct _NspTypeMpiGroup NspTypeMpiGroup ;


struct _NspTypeMpiGroup {
  /*< private >*/
  NSP_TYPE_OBJECT__
  /*< public >*/
  
};

typedef struct _nsp_mpigroup nsp_mpigroup;
struct _nsp_mpigroup {
  MPI_Group group;
  int ref_count;
};

struct _NspMpiGroup {
  /*< private >*/
  NspObject father;
  NspTypeMpiGroup*type;
  /*< public >*/
  nsp_mpigroup *obj;
};

extern int nsp_type_mpigroup_id;
extern NspTypeMpiGroup *nsp_type_mpigroup;

/* type instances for object */

NspTypeMpiGroup *new_type_mpigroup(type_mode mode);

/* instance for MpiGroup */

NspMpiGroup *new_mpigroup();

/*
* Object methods redefined for mpigroup 
*/


#define NULLMPIGROUP (NspMpiGroup*) 0

extern NspMpiGroup *nsp_mpigroup_create(char *name,  MPI_Group group,NspTypeBase *type);

/* from MpiGroupObj.c */

extern NspMpiGroup *nsp_mpigroup_copy(NspMpiGroup *H);
extern void nsp_mpigroup_destroy(NspMpiGroup *H);
extern int nsp_mpigroup_info(NspMpiGroup *H, int indent,const char *name, int rec_level);
extern int nsp_mpigroup_print(NspMpiGroup *H, int indent,const char *name, int rec_level);
extern int nsp_mpigroup_latex(NspMpiGroup *H, int indent,const char *name, int rec_level);
extern NspMpiGroup *nsp_mpigroup_object (NspObject *O); 
extern int IsMpiGroupObj (Stack stack, int i); 
extern int IsMpiGroup(NspObject *O);
extern NspMpiGroup *GetMpiGroupCopy (Stack stack, int i); 
extern NspMpiGroup *GetMpiGroup (Stack stack, int i); 
extern int nsp_mpigroup_create_partial(NspMpiGroup *H);
extern void nsp_mpigroup_destroy_partial(NspMpiGroup *H);
extern NspMpiGroup * nsp_mpigroup_copy_partial(NspMpiGroup *H,NspMpiGroup *self);
extern NspMpiGroup * nsp_mpigroup_full_copy_partial(NspMpiGroup *H,NspMpiGroup *self);
extern NspMpiGroup * nsp_mpigroup_full_copy(NspMpiGroup *self);
extern int nsp_mpigroup_check_values(NspMpiGroup *H);
extern int int_mpigroup_create(Stack stack, int rhs, int opt, int lhs); 
extern NspMpiGroup *nsp_mpigroup_xdr_load_partial(XDR *xdrs, NspMpiGroup *M);
extern int nsp_mpigroup_xdr_save(XDR  *xdrs, NspMpiGroup *M);

#endif /* NSP_INC_MpiGroup */ 

#ifdef MpiGroup_Private 
static int init_mpigroup(NspMpiGroup *o,NspTypeMpiGroup *type);
static int nsp_mpigroup_size(NspMpiGroup *Mat, int flag);
static char *nsp_mpigroup_type_as_string(void);
static char *nsp_mpigroup_type_short_string(NspObject *v);
static int nsp_mpigroup_eq(NspMpiGroup *A, NspObject *B);
static int nsp_mpigroup_neq(NspMpiGroup *A, NspObject *B);
static NspMpiGroup *nsp_mpigroup_xdr_load(XDR *xdrs);
static AttrTab mpigroup_attrs[];
static NspMethods *mpigroup_get_methods(void);
/* static int int_mpigroup_create(Stack stack, int rhs, int opt, int lhs);*/ 
static NspMpiGroup *nsp_mpigroup_create_void(char *name,NspTypeBase *type);
#endif /* MpiGroup_Private */

