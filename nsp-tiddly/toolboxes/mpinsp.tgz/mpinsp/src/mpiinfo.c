/* Nsp
 * Copyright (C) 2009-2013 Jean-Philippe Chancelier Enpc/Cermics
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public
 * License along with this library; if not, write to the
 * Free Software Foundation, Inc., 59 Temple Place - Suite 330,
 * Boston, MA 02111-1307, USA.
 *
 * Info object for MPI. 
 *
 * To be finished: free 
 */

#define  MpiInfo_Private 
#include "nsp/objects.h"
#include "mpiinfo.h"
#include "nsp/interf.h"

/* 
 * NspMpiInfo inherits from NspObject 
 */

int nsp_type_mpiinfo_id=0;
NspTypeMpiInfo *nsp_type_mpiinfo=NULL;

/*
 * Type object for MpiInfo 
 * all the instance of NspTypeMpiInfo share the same id. 
 * nsp_type_mpiinfo: is an instance of NspTypeMpiInfo 
 *    used for objects of NspMpiInfo type (i.e built with new_mpiinfo) 
 * other instances are used for derived classes 
 */
NspTypeMpiInfo *new_type_mpiinfo(type_mode mode)
{
  NspTypeMpiInfo *type= NULL;
  NspTypeObject *top;
  if (  nsp_type_mpiinfo != 0 && mode == T_BASE ) 
    {
      /* initialization performed and T_BASE requested */
      return nsp_type_mpiinfo;
    }
  if ((type =  malloc(sizeof(NspTypeMpiInfo))) == NULL) return NULL;
  type->interface = NULL;
  type->surtype = (NspTypeBase *) new_type_object(T_DERIVED);
  if ( type->surtype == NULL) return NULL;
  type->attrs = mpiinfo_attrs ; 
  type->get_attrs = (attrs_func *) int_get_attribute;
  type->set_attrs = (attrs_func *) int_set_attribute;
  type->methods = mpiinfo_get_methods; 
  type->new = (new_func *) new_mpiinfo;

  
  top = NSP_TYPE_OBJECT(type->surtype);
  while ( top->surtype != NULL ) top= NSP_TYPE_OBJECT(top->surtype);
  
  /* object methods redefined for mpiinfo */ 

  top->pr = (print_func *) nsp_mpiinfo_print;                  
  top->dealloc = (dealloc_func *) nsp_mpiinfo_destroy;
  top->copy  =  (copy_func *) nsp_mpiinfo_copy;                 
  top->size  = (size_func *) nsp_mpiinfo_size;                
  top->s_type =  (s_type_func *) nsp_mpiinfo_type_as_string;  
  top->sh_type = (sh_type_func *) nsp_mpiinfo_type_short_string;
  top->info = (info_func *) nsp_mpiinfo_info ;                  
  /* top->is_true = (is_true_func  *) nsp_mpiinfo_is_true; */
  /* top->loop =(loop_func *) nsp_mpiinfo_loop;*/
  top->path_extract = (path_func *)  object_path_extract; 
  top->get_from_obj = (get_from_obj_func *) nsp_mpiinfo_object;
  top->eq  = (eq_func *) nsp_mpiinfo_eq;
  top->neq  = (eq_func *) nsp_mpiinfo_neq;
  top->save  = (save_func *) nsp_mpiinfo_xdr_save;
  top->load  = (load_func *) nsp_mpiinfo_xdr_load;
  top->create = (create_func*) int_mpiinfo_create;
  top->latex = (print_func *) nsp_mpiinfo_latex;
  
  /* specific methods for mpiinfo */
      
  type->init = (init_func *) init_mpiinfo;

  /* 
   * MpiInfo interfaces can be added here 
   * type->interface = (NspTypeBase *) new_type_b();
   * type->interface->interface = (NspTypeBase *) new_type_C()
   * ....
   */
  if ( nsp_type_mpiinfo_id == 0 ) 
    {
      /* 
       * the first time we get here we initialize the type id and
       * an instance of NspTypeMpiInfo called nsp_type_mpiinfo
       */
      type->id =  nsp_type_mpiinfo_id = nsp_new_type_id();
      nsp_type_mpiinfo = type;
      if ( nsp_register_type(nsp_type_mpiinfo) == FALSE) return NULL;
      return ( mode == T_BASE ) ? type : new_type_mpiinfo(mode);
    }
  else 
    {
       type->id = nsp_type_mpiinfo_id;
       return type;
    }
}

/*
 * initialize MpiInfo instances 
 * locally and by calling initializer on parent class 
 */

static int init_mpiinfo(NspMpiInfo *Obj,NspTypeMpiInfo *type)
{
  /* jump the first surtype */ 
  if ( type->surtype->init(&Obj->father,type->surtype) == FAIL) return FAIL;
  Obj->type = type; 
  NSP_OBJECT(Obj)->basetype = (NspTypeBase *)type;
  /* specific */
  Obj->obj = NULL;
  return OK;
}

/*
 * new instance of MpiInfo 
 */

NspMpiInfo *new_mpiinfo() 
{
  NspMpiInfo *loc; 
  /* type must exists */
  nsp_type_mpiinfo = new_type_mpiinfo(T_BASE);
  if ( (loc = malloc(sizeof(NspMpiInfo)))== NULLMPIINFO) return loc;
  /* initialize object */
  if ( init_mpiinfo(loc,nsp_type_mpiinfo) == FAIL) return NULLMPIINFO;
  return loc;
}

/*----------------------------------------------
 * Object method redefined for MpiInfo 
 *-----------------------------------------------*/
/*
 * size 
 */

static int nsp_mpiinfo_size(NspMpiInfo *Mat, int flag)
{
  return 0;
}

/*
 * type as string 
 */

static char mpiinfo_type_name[]="MpiInfo";
static char mpiinfo_short_type_name[]="mpiinfo";

static char *nsp_mpiinfo_type_as_string(void)
{
  return(mpiinfo_type_name);
}

static char *nsp_mpiinfo_type_short_string(NspObject *v)
{
  return(mpiinfo_short_type_name);
}

/*
 * A == B 
 */

static int nsp_mpiinfo_eq(NspMpiInfo *A, NspObject *B)
{
  NspMpiInfo *loc = (NspMpiInfo *) B;
  if ( check_cast(B,nsp_type_mpiinfo_id) == FALSE) return FALSE ;
  if ( A->obj == loc->obj ) return TRUE;
  if ( A->obj->info != loc->obj->info) return FALSE;
  return TRUE;
}

/*
 * A != B 
 */

static int nsp_mpiinfo_neq(NspMpiInfo *A, NspObject *B)
{
  return ( nsp_mpiinfo_eq(A,B) == TRUE ) ? FALSE : TRUE;
}

/*
 * save 
 */

int nsp_mpiinfo_xdr_save(XDR *xdrs, NspMpiInfo *M)
{
  if (nsp_xdr_save_i(xdrs,M->type->id) == FAIL) return FAIL;
  if (nsp_xdr_save_string(xdrs, NSP_OBJECT(M)->name) == FAIL) return FAIL;
  return OK;
}

/*
 * load 
 */

NspMpiInfo  *nsp_mpiinfo_xdr_load_partial(XDR *xdrs, NspMpiInfo *M)
{
  if ((M->obj = malloc(sizeof(nsp_mpiinfo))) == NULL) return NULL;
 return M;
}

static NspMpiInfo  *nsp_mpiinfo_xdr_load(XDR *xdrs)
{
  NspMpiInfo *M = NULL;
  static char name[NAME_MAXL];
  if (nsp_xdr_load_string(xdrs,name,NAME_MAXL) == FAIL) return NULLMPIINFO;
  if ((M  = nsp_mpiinfo_create_void(name,(NspTypeBase *) nsp_type_mpiinfo))== NULLMPIINFO) return M;
  return nsp_mpiinfo_xdr_load_partial(xdrs,M);
}

/*
 * delete 
 */

void nsp_mpiinfo_destroy_partial(NspMpiInfo *H)
{
  H->obj->ref_count--;
  if ( H->obj->ref_count == 0 )
   {
    FREE(H->obj);
   }
}

void nsp_mpiinfo_destroy(NspMpiInfo *H)
{
  nsp_object_destroy_name(NSP_OBJECT(H));
  nsp_mpiinfo_destroy_partial(H);
  FREE(H);
}

/*
 * info 
 */

int nsp_mpiinfo_info(NspMpiInfo *M,int indent,const char *name,int rec_level)
{
  const char *pname;
  if ( M == NULLMPIINFO) 
    {
      Sciprintf("Null Pointer MpiInfo \n");
      return TRUE;
    }
  pname = (name != NULL) ? name : NSP_OBJECT(M)->name;
  Sciprintf1(indent,"%s\t=\t\t%s\n", (pname==NULL) ? "" : pname,
             nsp_mpiinfo_type_short_string(NSP_OBJECT(M)));
  return TRUE;
}

/*
 * print 
 */

int nsp_mpiinfo_print(NspMpiInfo *M, int indent,const char *name, int rec_level)
{
  const char *pname = (name != NULL) ? name : NSP_OBJECT(M)->name;
  if ( M == NULLMPIINFO) 
    {
      Sciprintf("Null Pointer MpiInfo \n");
      return TRUE;
    }
  if (user_pref.pr_as_read_syntax) 
    { 
      Sciprintf1(indent,"%s=TO_BE_DONE();\n",pname);
    } 
  else 
    { 
      if ( user_pref.pr_depth  <= rec_level -1 ) 
        {
          nsp_mpiinfo_info(M,indent,pname,rec_level);
          return TRUE;
        }
      Sciprintf1(indent,"%s\t=\t\t%s (nref=%d)\n",pname, nsp_mpiinfo_type_short_string(NSP_OBJECT(M)) ,M->obj->ref_count);
    }
  return TRUE;
}

/*
 * latex print 
 */

int nsp_mpiinfo_latex(NspMpiInfo *M, int indent,const char *name, int rec_level)
{
  const char *pname = (name != NULL) ? name : NSP_OBJECT(M)->name;
  if ( nsp_from_texmacs() == TRUE ) Sciprintf("\002latex:\\[");
  Sciprintf1(indent,"%s\t=\t\t%s\n",pname, nsp_mpiinfo_type_short_string(NSP_OBJECT(M)));
  if ( nsp_from_texmacs() == TRUE ) Sciprintf("\\]\005");
  return TRUE;
}
/*-----------------------------------------------------
 * a set of functions used when writing interfaces 
 * for MpiInfo objects 
 * Note that some of these functions could become MACROS 
 *-----------------------------------------------------*/

NspMpiInfo   *nsp_mpiinfo_object(NspObject *O)
{
  /* Follow pointer */
  if ( check_cast(O,nsp_type_hobj_id) == TRUE)  O = ((NspHobj *) O)->O ;
  /* Check type */
  if ( check_cast (O,nsp_type_mpiinfo_id) == TRUE ) return ((NspMpiInfo *) O);
  else 
    Scierror("Error:	Argument should be a %s\n",type_get_name(nsp_type_mpiinfo));
  return NULL;
}

int IsMpiInfoObj(Stack stack, int i)
{
  return nsp_object_type(NthObj(i) , nsp_type_mpiinfo_id);
}

int IsMpiInfo(NspObject *O)
{
  return nsp_object_type(O,nsp_type_mpiinfo_id);
}

NspMpiInfo  *GetMpiInfoCopy(Stack stack, int i)
{
  if (  GetMpiInfo(stack,i) == NULL ) return NULL;
  return MaybeObjCopy(&NthObj(i));
}

NspMpiInfo  *GetMpiInfo(Stack stack, int i)
{
  NspMpiInfo *M;
  if (( M = nsp_mpiinfo_object(NthObj(i))) == NULLMPIINFO)
     ArgMessage(stack,i);
  return M;
}

/*-----------------------------------------------------
  * constructor 
 * if type is non NULL it is a subtype which can be used to 
 * create a NspClassB instance 
 *-----------------------------------------------------*/

static NspMpiInfo *nsp_mpiinfo_create_void(char *name,NspTypeBase *type)
{
 NspMpiInfo *H  = (type == NULL) ? new_mpiinfo() : type->new();
 if ( H ==  NULLMPIINFO)
  {
   Sciprintf("No more memory\n");
   return NULLMPIINFO;
  }
 if ( nsp_object_set_initial_name(NSP_OBJECT(H),name) == NULLSTRING) return NULLMPIINFO;
 NSP_OBJECT(H)->ret_pos = -1 ;
 return H;
}

int nsp_mpiinfo_create_partial(NspMpiInfo *H)
{
  if((H->obj = calloc(1,sizeof(nsp_mpiinfo)))== NULL ) return FAIL;
  H->obj->ref_count=1;
  return OK;
}

int nsp_mpiinfo_check_values(NspMpiInfo *H)
{
  return OK;
}

NspMpiInfo *nsp_mpiinfo_create(char *name,MPI_Info group,NspTypeBase *type)
{
 NspMpiInfo *H  = nsp_mpiinfo_create_void(name,type);
 if ( H ==  NULLMPIINFO) return NULLMPIINFO;
  if ( nsp_mpiinfo_create_partial(H) == FAIL) return NULLMPIINFO;
  H->obj->info=group;
 if ( nsp_mpiinfo_check_values(H) == FAIL) return NULLMPIINFO;
 return H;
}

/*
 * copy for gobject derived class  
 */

NspMpiInfo *nsp_mpiinfo_copy_partial(NspMpiInfo *H,NspMpiInfo *self)
{
  H->obj = self->obj; self->obj->ref_count++;
  return H;
}

NspMpiInfo *nsp_mpiinfo_copy(NspMpiInfo *self)
{
  NspMpiInfo *H  =nsp_mpiinfo_create_void(NVOID,(NspTypeBase *) nsp_type_mpiinfo);
  if ( H ==  NULLMPIINFO) return NULLMPIINFO;
  if ( nsp_mpiinfo_copy_partial(H,self)== NULL) return NULLMPIINFO;

  return H;
}
/*
 * full copy for gobject derived class  
 */

NspMpiInfo *nsp_mpiinfo_full_copy_partial(NspMpiInfo *H,NspMpiInfo *self)
{
  if ((H->obj = calloc(1,sizeof(nsp_mpiinfo))) == NULL) return NULLMPIINFO;
  H->obj->ref_count=1;
  H->obj->info=self->obj->info;
  return H;
}

NspMpiInfo *nsp_mpiinfo_full_copy(NspMpiInfo *self)
{
  NspMpiInfo *H  =nsp_mpiinfo_create_void(NVOID,(NspTypeBase *) nsp_type_mpiinfo);
  if ( H ==  NULLMPIINFO) return NULLMPIINFO;
  if ( nsp_mpiinfo_full_copy_partial(H,self)== NULL) return NULLMPIINFO;
  return H;
}

/*-------------------------------------------------------------------
 * wrappers for the MpiInfo
 * i.e functions at Nsp level 
 *-------------------------------------------------------------------*/

int int_mpiinfo_create(Stack stack, int rhs, int opt, int lhs)
{
  char *str;
  int info;
  MPI_Info INF;
  NspMpiInfo *H;
  CheckStdRhs(0,1);
  /* want to be sure that type mpiinfo is initialized */
  nsp_type_mpiinfo = new_type_mpiinfo(T_BASE);
  if(( H = nsp_mpiinfo_create_void(NVOID,(NspTypeBase *) nsp_type_mpiinfo)) == NULLMPIINFO) return RET_BUG;
  /* then we use optional arguments to fill attributes */
  if ( nsp_mpiinfo_create_partial(H) == FAIL) return RET_BUG;
  if ( rhs == 1)
    {
      if ((str=GetString(stack,1)) == NULL) return RET_BUG;
      if ( strcmp(str,"NULL"  ) == 0) 
	{
	  H->obj->info =MPI_INFO_NULL  ;
	  MoveObj(stack,1,(NspObject  *) H);
	  return 1;      	 
	}
      Scierror("Error: unable to create MPI INFO  %s\n",str);
    }
  else 
    {
      info = MPI_Info_create(&INF);
      if ( info == MPI_SUCCESS)
	{
	  H->obj->info = INF;
	  MoveObj(stack,1,(NspObject  *) H);
	  return 1;      
	}
      Scierror("Error: %s failed\n",NspFname(stack));
    }
  return RET_BUG;
} 


static NspMethods mpiinfo_methods[] = {
  { NULL, NULL}
};

static NspMethods *mpiinfo_get_methods(void) { return mpiinfo_methods;};
/*-------------------------------------------
 * Attributes
 *-------------------------------------------*/

static AttrTab mpiinfo_attrs[] = {{NULL,NULL,NULL,NULL,NULL}} ;

/*-------------------------------------------
 * functions 
 *-------------------------------------------*/


/*----------------------------------------------------
 * Interface 
 * i.e a set of function which are accessible at nsp level
 *----------------------------------------------------*/

static OpTab mpiinfo_func[]={
  { "mpiinfo_create", int_mpiinfo_create},
  { NULL, NULL}
};

/* call ith function in the mpiinfo interface */

int mpiinfo_Interf(int i, Stack stack, int rhs, int opt, int lhs)
{
  return (*(mpiinfo_func[i].fonc))(stack,rhs,opt,lhs);
}

/* used to walk through the interface table 
    (for adding or removing functions) */

void mpiinfo_Interf_Info(int i, char **fname, function (**f))
{
  *fname = mpiinfo_func[i].name;
  *f = mpiinfo_func[i].fonc;
}

int int_mpiinfo_delete(Stack stack, int rhs, int opt, int lhs)
{
  int info;
  NspMpiInfo *inf;
  char *key;
  int_types T[] = {obj_check,string,t_end};
  CheckLhs(0,0);
  if ( GetArgs(stack,rhs,opt,T,&nsp_type_mpiinfo,&inf,&key) == FAIL) return RET_BUG;
  info = MPI_Info_delete(inf->obj->info, key);
  return 0;
}

int int_mpiinfo_dup(Stack stack, int rhs, int opt, int lhs)
{
  int info;
  MPI_Info NEWINF;
  NspMpiInfo *inf;
  int_types T[] = {obj_check,t_end};
  CheckLhs(0,1);
  if ( GetArgs(stack,rhs,opt,T,&nsp_type_mpiinfo,&inf) == FAIL) return RET_BUG;
  info = MPI_Info_dup(inf->obj->info, &NEWINF);
  if ( info == MPI_SUCCESS)
    {
      NspMpiInfo *res = nsp_mpiinfo_create(NVOID,NEWINF,NULL);
      if ( res == NULL) return RET_BUG;
      MoveObj(stack,1,NSP_OBJECT(res));
      return 1;
    }
  Scierror("Error: %s failed\n",NspFname(stack));
  return RET_BUG;
}


int int_mpiinfo_get(Stack stack, int rhs, int opt, int lhs)
{
  int info;
  int flag;
  NspMpiInfo *inf;
  char *key;
  char val[MPI_MAX_INFO_VAL];
  int_types T[] = {obj_check,string,t_end};
  CheckLhs(0,1);
  if ( GetArgs(stack,rhs,opt,T,&nsp_type_mpiinfo,&inf,&key) == FAIL) return RET_BUG;
  info = MPI_Info_get(inf->obj->info, key,256,val,&flag);
  if (info ==  MPI_SUCCESS)
    {
      if ( flag == TRUE )
	{
	  if ( nsp_move_string(stack,1,val,-1) == FAIL) return RET_BUG;
	  return 1;
	}
      else 
	{
	  Scierror("Error: key %s not found\n",key);
	  return RET_BUG;
	}
    }
  Scierror("Error: %s failed\n",NspFname(stack));
  return RET_BUG;
}

int int_mpiinfo_get_nkeys(Stack stack, int rhs, int opt, int lhs)
{
  int info;
  int nkeys;
  NspMpiInfo *inf;
  int_types T[] = {obj_check,t_end};
  CheckLhs(0,1);
  if ( GetArgs(stack,rhs,opt,T,&nsp_type_mpiinfo,&inf) == FAIL) return RET_BUG;
  info = MPI_Info_get_nkeys(inf->obj->info, &nkeys);
  if (info ==  MPI_SUCCESS)
    {
      if ( nsp_move_double(stack,1,nkeys) == FAIL) return RET_BUG;
      return 1;
    }
  Scierror("Error: %s failed\n",NspFname(stack));
  return RET_BUG;
}


int int_mpiinfo_get_nthkey(Stack stack, int rhs, int opt, int lhs)
{
  int info;
  int n;
  char key[MPI_MAX_INFO_KEY];
  NspMpiInfo *inf;
  int_types T[] = {obj_check,s_int,t_end};
  CheckLhs(0,1);
  if ( GetArgs(stack,rhs,opt,T,&nsp_type_mpiinfo,&inf,&n) == FAIL) return RET_BUG;
  info =MPI_Info_get_nthkey(inf->obj->info,n,key);
  if (info ==  MPI_SUCCESS)
    {
      if ( nsp_move_string(stack,1,key,-1) == FAIL) return RET_BUG;
      return 1;
    }
  Scierror("Error: %s failed\n",NspFname(stack));
  return RET_BUG;
}

int int_mpiinfo_get_valuelen(Stack stack, int rhs, int opt, int lhs)
{
  int info,len,flag;
  NspMpiInfo *inf;
  char *key;
  int_types T[] = {obj_check,string,t_end};
  CheckLhs(0,1);
  if ( GetArgs(stack,rhs,opt,T,&nsp_type_mpiinfo,&inf,&key) == FAIL) return RET_BUG;
  info = MPI_Info_get_valuelen(inf->obj->info, key, &len, &flag);
  if (info ==  MPI_SUCCESS)
    {
      if ( flag == TRUE )
	{
	  if ( nsp_move_double(stack,1,len) == FAIL) return RET_BUG;
	  return 1;
	}
      else 
	{
	  Scierror("Error: key %s not found\n",key);
	  return RET_BUG;
	}
    }
  Scierror("Error: %s failed\n",NspFname(stack));
  return RET_BUG;
}


int int_mpiinfo_set(Stack stack, int rhs, int opt, int lhs)
{
  int info;
  NspMpiInfo *inf;
  char *key,*val;
  int_types T[] = {obj_check,string,string,t_end};
  CheckLhs(0,1);
  if ( GetArgs(stack,rhs,opt,T,&nsp_type_mpiinfo,&inf,&key,&val) == FAIL) return RET_BUG;
  info = MPI_Info_set(inf->obj->info, key,val);
  if (info !=  MPI_SUCCESS)
    {
      Scierror("Error: %s failed\n",NspFname(stack));
      return RET_BUG;
    }
  return 0;
}
