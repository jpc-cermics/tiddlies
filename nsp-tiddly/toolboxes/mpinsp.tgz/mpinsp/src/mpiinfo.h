/* -*- Mode: C -*- */
#ifndef NSP_INC_MpiInfo
#define NSP_INC_MpiInfo

/*
 * This Software is GPL (Copyright ENPC 1998-2013) 
 * Jean-Philippe Chancelier Enpc/Cermics         
 */

/* MpiInfo */


#include <mpi.h>	
#include "nsp/object.h"

/*
 * NspMpiInfo inherits from NspObject
 */

typedef struct _NspMpiInfo NspMpiInfo ;
typedef struct _NspTypeMpiInfo NspTypeMpiInfo ;


struct _NspTypeMpiInfo {
  /*< private >*/
  NSP_TYPE_OBJECT__
  /*< public >*/
  
};

typedef struct _nsp_mpiinfo nsp_mpiinfo;
struct _nsp_mpiinfo {
  MPI_Info info;
  int ref_count;
};

struct _NspMpiInfo {
  /*< private >*/
  NspObject father;
  NspTypeMpiInfo*type;
  /*< public >*/
  nsp_mpiinfo *obj;
};

extern int nsp_type_mpiinfo_id;
extern NspTypeMpiInfo *nsp_type_mpiinfo;

/* type instances for object */

NspTypeMpiInfo *new_type_mpiinfo(type_mode mode);

/* instance for MpiInfo */

NspMpiInfo *new_mpiinfo();

/*
* Object methods redefined for mpiinfo 
*/


#define NULLMPIINFO (NspMpiInfo*) 0

extern NspMpiInfo *nsp_mpiinfo_create(char *name,MPI_Info group,NspTypeBase *type);

/* from MpiInfoObj.c */

extern NspMpiInfo *nsp_mpiinfo_copy(NspMpiInfo *H);
extern void nsp_mpiinfo_destroy(NspMpiInfo *H);
extern int nsp_mpiinfo_info(NspMpiInfo *H, int indent,const char *name, int rec_level);
extern int nsp_mpiinfo_print(NspMpiInfo *H, int indent,const char *name, int rec_level);
extern int nsp_mpiinfo_latex(NspMpiInfo *H, int indent,const char *name, int rec_level);
extern NspMpiInfo *nsp_mpiinfo_object (NspObject *O); 
extern int IsMpiInfoObj (Stack stack, int i); 
extern int IsMpiInfo(NspObject *O);
extern NspMpiInfo *GetMpiInfoCopy (Stack stack, int i); 
extern NspMpiInfo *GetMpiInfo (Stack stack, int i); 
extern int nsp_mpiinfo_create_partial(NspMpiInfo *H);
extern void nsp_mpiinfo_destroy_partial(NspMpiInfo *H);
extern NspMpiInfo * nsp_mpiinfo_copy_partial(NspMpiInfo *H,NspMpiInfo *self);
extern NspMpiInfo * nsp_mpiinfo_full_copy_partial(NspMpiInfo *H,NspMpiInfo *self);
extern NspMpiInfo * nsp_mpiinfo_full_copy(NspMpiInfo *self);
extern int nsp_mpiinfo_check_values(NspMpiInfo *H);
extern int int_mpiinfo_create(Stack stack, int rhs, int opt, int lhs); 
extern NspMpiInfo *nsp_mpiinfo_xdr_load_partial(XDR *xdrs, NspMpiInfo *M);
extern int nsp_mpiinfo_xdr_save(XDR  *xdrs, NspMpiInfo *M);

#endif /* NSP_INC_MpiInfo */ 

#ifdef MpiInfo_Private 
static int init_mpiinfo(NspMpiInfo *o,NspTypeMpiInfo *type);
static int nsp_mpiinfo_size(NspMpiInfo *Mat, int flag);
static char *nsp_mpiinfo_type_as_string(void);
static char *nsp_mpiinfo_type_short_string(NspObject *v);
static int nsp_mpiinfo_eq(NspMpiInfo *A, NspObject *B);
static int nsp_mpiinfo_neq(NspMpiInfo *A, NspObject *B);
static NspMpiInfo *nsp_mpiinfo_xdr_load(XDR *xdrs);
static AttrTab mpiinfo_attrs[];
static NspMethods *mpiinfo_get_methods(void);
/* static int int_mpiinfo_create(Stack stack, int rhs, int opt, int lhs);*/ 
static NspMpiInfo *nsp_mpiinfo_create_void(char *name,NspTypeBase *type);
#endif /* MpiInfo_Private */

