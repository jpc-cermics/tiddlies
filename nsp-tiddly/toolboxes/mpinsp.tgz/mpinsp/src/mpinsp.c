/* Nsp
 * Copyright (C) 2009-2013 Jean-Philippe Chancelier Enpc/Cermics
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public
 * License along with this library; if not, write to the
 * Free Software Foundation, Inc., 59 Temple Place - Suite 330,
 * Boston, MA 02111-1307, USA.
 *
 * Interface for MPI functions 
 */

#include <nsp/objects.h>
#include "nsp/serial.h"
#include "nsp/cells.h"
#include <nsp/interf.h>

#include "mpicomm.h"
#include "mpiinfo.h"
#include "mpigroup.h"
#include "mpireq.h"
#include "mpibuf.h"
#include "mpinsp.h"

/*
 * Initialize the MPI execution environment
 */

int int_nsp_mpi_init(Stack stack,int rhs,int opt,int lhs)
{
  int info;
  NspSMatrix *A;
  CheckRhs(0,1);
  CheckLhs(0,1);
  MPI_Finalized(&info);
  if ( info == TRUE ) 
    {
      /* should be clarified */
      Scierror("Error: cannot call MPI_Init  after MPI_Finalize\n");
      Scierror("Error: The solution is to ulink are re-link the MPI librarie\n");
      return RET_BUG;
    }
  if ( rhs== 1 )
    {
      if ((A = GetSMat(stack,1)) == NULLSMAT) return RET_BUG;
      info = MPI_Init(&A->mn,&A->S);
    }
  else 
    {
      info = MPI_Init(NULL,NULL);
    }
  if ( info != MPI_SUCCESS ) 
    {
      Scierror("Error: an attempt was made to call MPI_Init a second time\n");
      return RET_BUG;
    }
  else
    {
      MPI_Errhandler_set(MPI_COMM_WORLD,MPI_ERRORS_RETURN);
    }
  return 0;
}

int int_nsp_mpi_finalize(Stack stack,int rhs,int opt,int lhs)
{
  int info;
  CheckRhs(0,0);
  CheckLhs(0,1);
  MPI_Initialized(&info);
  if ( info == FALSE ) 
    {
      Scierror("Error: MPI is not initialized\n");
      return RET_BUG;
    }
  MPI_Finalized(&info);
  if ( info == TRUE ) 
    {
      return 0;
    }
  info = MPI_Finalize();
  switch (info )
    {
    case  MPI_ERR_INTERN:
      Scierror("Error: fatal error while calling  MPI_Finalize\n");
      return RET_BUG;
    case MPI_ERR_OTHER:
      Scierror("Error: a different thread attempts to finalize MPI\n"
	       " than the thread that initialized MPI\n");
      return RET_BUG;
    }
  return 0;
}


int int_nsp_mpi_initialized(Stack stack,int rhs,int opt,int lhs)
{
  int flag;
  CheckRhs(0,0);
  CheckLhs(0,1);
  MPI_Initialized(&flag);
  nsp_move_boolean(stack,1,(flag == 1) ? TRUE:FALSE ); 
  return 1;
}

int int_nsp_mpi_finalized(Stack stack,int rhs,int opt,int lhs)
{
  int flag;
  CheckRhs(0,0);
  CheckLhs(0,1);
  MPI_Finalized(&flag);
  nsp_move_boolean(stack,1,(flag == 1) ? TRUE:FALSE ); 
  return 1;
}

int int_nsp_mpi_Get_processor_name(Stack stack,int rhs,int opt,int lhs)
{
  char name[MPI_MAX_PROCESSOR_NAME];
  int len,info;
  CheckRhs(0,0);
  CheckLhs(0,1);
  info =  MPI_Get_processor_name(name, &len);
  if ( info == MPI_SUCCESS)
    {
      if ( nsp_move_string(stack,1,name,-1) == FAIL ) return RET_BUG;
      return 1;
    }
  Scierror("Error: %s failed\n",NspFname(stack));
  return RET_BUG;
}

int int_nsp_mpi_Get_version(Stack stack,int rhs,int opt,int lhs)
{
  int major, minor,info;
  CheckRhs(0,0);
  CheckLhs(0,2);
  info = MPI_Get_version(&major, &minor);
  if ( info == MPI_SUCCESS)
    {
      if ( lhs >= 2) 
	{
	  if ( nsp_move_double(stack,2,minor) == FAIL ) return RET_BUG;
	}
      if ( nsp_move_double(stack,1,major) == FAIL ) return RET_BUG;
      return Max(1,lhs);
    }
  Scierror("Error: %s failed\n",NspFname(stack));
  return RET_BUG;
}

int int_nsp_mpi_Wtime(Stack stack,int rhs,int opt,int lhs)
{
  CheckRhs(0,0);
  CheckLhs(0,1);
  if ( nsp_move_double(stack,1,MPI_Wtime()) == FAIL ) return RET_BUG;
  return 1;
}

int int_nsp_mpi_Wtick(Stack stack,int rhs,int opt,int lhs)
{
  CheckRhs(0,0);
  CheckLhs(0,1);
  if ( nsp_move_double(stack,1,MPI_Wtick()) == FAIL ) return RET_BUG;
  return 1;
}



int int_nsp_mpi_Send_obj(Stack stack,int rhs,int opt,int lhs)
{
  NspObject *Obj;
  int srcdst,tag,info;
  NspMpiComm *comm;
  int_types T[] = {obj,s_int,s_int,obj_check, t_end};
  if ( GetArgs(stack,rhs,opt,T,&Obj,&srcdst,&tag,&nsp_type_mpicomm,&comm) == FAIL)
    return RET_BUG;
  if ( IsSerial(Obj) == FALSE) 
    {
      Obj = nsp_object_serialize(Obj);
      if ( Obj == NULLOBJ) return RET_BUG;
    }
  /* send a serialized object */
  info = MPI_Send(((NspSerial *) Obj)->val,
		  ((NspSerial *) Obj)->nbytes, MPI_BYTE , srcdst,tag, comm->obj->comm); 
  if ( info == MPI_SUCCESS)
    {
      return 0;
    }
  Scierror("Error: %s failed\n",NspFname(stack));
  return RET_BUG;
}

int int_nsp_mpi_Recv_obj(Stack stack,int rhs,int opt,int lhs)
{
  NspSerial *M = NULL;
  MPI_Status ST;
  int src,tag,info,nbytes;
  NspMpiComm *comm;
  int_types T[] = {s_int,s_int,obj_check, t_end};
  if ( GetArgs(stack,rhs,opt,T,&src,&tag,&nsp_type_mpicomm,&comm) == FAIL)
    return RET_BUG;
  info = MPI_Probe(src,tag,comm->obj->comm,&ST);      
  if ( info != MPI_SUCCESS) return RET_BUG; 
  info = MPI_Get_elements(&ST, MPI_BYTE , &nbytes);
  if ( info != MPI_SUCCESS) return RET_BUG; 
  /* prepare a serialized object */
  if ((M = nsp_serial_create(NVOID,NULL,nbytes-strlen(nsp_serial_header)))== NULLSERIAL) 
    return RET_BUG;
  info = MPI_Recv( M->val,M->nbytes, MPI_BYTE , src,tag, comm->obj->comm,&ST); 
  if ( info == MPI_SUCCESS)
    {
      NspObject *Res ;
      /* unserialize */
      if ((Res = nsp_object_unserialize(M))==NULLOBJ) goto err;	
      nsp_serial_destroy(M);
      MoveObj(stack,1,NSP_OBJECT(Res));
      return 1;
    }
 err:
  Scierror("Error: %s failed\n",NspFname(stack));
  if ( M != NULL)  nsp_serial_destroy(M);
  return RET_BUG;
}



int int_nsp_mpi_Iprobe(Stack stack,int rhs,int opt,int lhs)
{ 
  MPI_Status ST ={0};
  int src,tag,info,flag;
  NspMpiComm *comm;
  int_types T[] = {s_int,s_int,obj_check, t_end};
  if ( GetArgs(stack,rhs,opt,T,&src,&tag,&nsp_type_mpicomm,&comm) == FAIL)
    return RET_BUG;
  info = MPI_Iprobe(src,tag,comm->obj->comm, &flag,&ST); 
  if ( info == MPI_SUCCESS)
    {
      NspHash *Res; 
      if ( flag == FALSE )
	{
	  /* we return a ST where all fields are 0 */
	  /* Scierror("Error: cannot find a matching message in %s\n",NspFname(stack)); */
	}
      Res = MPI_Stat_to_Nsphash(ST);
      if ( Res == NULL) return RET_BUG; 
      MoveObj(stack,1,NSP_OBJECT(Res));
      return 1;
    }
  Scierror("Error: %s failed\n",NspFname(stack));
  return RET_BUG;
}

int int_nsp_mpi_Probe(Stack stack,int rhs,int opt,int lhs)
{ 
  MPI_Status ST ={0};
  int src,tag,info;
  NspMpiComm *comm;
  int_types T[] = {s_int,s_int,obj_check, t_end};
  if ( GetArgs(stack,rhs,opt,T,&src,&tag,&nsp_type_mpicomm,&comm) == FAIL)
    return RET_BUG;
  info = MPI_Probe(src,tag,comm->obj->comm, &ST); 
  if ( info == MPI_SUCCESS)
    {
      NspHash *Res = MPI_Stat_to_Nsphash(ST);
      if ( Res == NULL) return RET_BUG; 
      MoveObj(stack,1,NSP_OBJECT(Res));
      return 1;
    }
  Scierror("Error: %s failed\n",NspFname(stack));
  return RET_BUG;
}

int int_nsp_mpi_Get_count(Stack stack,int rhs,int opt,int lhs)
{
 MPI_Status ST;
 int count,info;
 NspHash *H;
 CheckRhs(1,1);
 CheckLhs(0,1);
 if ((H = GetHash(stack,1)) == NULLHASH) return RET_BUG;
 if ( Nsphash_to_MPI_Stat(H,&ST) == FAIL) 
   {
     Scierror("Error: given hash table cannot be used as MPI_Status\n");
     return RET_BUG;
   }

 /* info = MPI_Get_count(&ST, (&ompi_mpi_packed), &count); */
 info = MPI_Get_count(&ST, MPI_PACKED , &count);

 if ( info == MPI_SUCCESS)
   {
     if ( nsp_move_double(stack,1,count) == FAIL ) return RET_BUG;
     return 1;
   }
 Scierror("Error: %s failed\n",NspFname(stack));
 return RET_BUG;
}

int int_nsp_mpi_Get_elements(Stack stack,int rhs,int opt,int lhs)
{
  MPI_Datatype TP;
  MPI_Status ST;
  int elems,info;
  NspHash *H;
  NspObject *Obj;
  CheckRhs(2,2);
  CheckLhs(0,1);
  if ((H = GetHash(stack,1)) == NULLHASH) return RET_BUG;
  if ( Nsphash_to_MPI_Stat(H,&ST) == FAIL) 
    {
      Scierror("Error: given hash table cannot be used as MPI_Status\n");
      return RET_BUG;
    }
  if ((Obj = nsp_get_object(stack,2)) == NULLOBJ) return RET_BUG;
  if ((TP = nsp_get_mpi_type(Obj)) == NULL) return RET_BUG;
  
  info =MPI_Get_elements(&ST, TP, &elems);
  if ( info == MPI_SUCCESS)
    {
      if ( elems == MPI_UNDEFINED ) 
	{
	  Scierror("Error: %s failed, data in status is not an exact multiple\n"
		   "  of the size of given datatype \n",NspFname(stack));
	  return RET_BUG;
	}

      if ( nsp_move_double(stack,1,elems) == FAIL ) return RET_BUG;
      return 1;
    }
  Scierror("Error: %s failed\n",NspFname(stack));
  return RET_BUG;
}


int int_nsp_mpi_Send(Stack stack,int rhs,int opt,int lhs)
{
  MPI_Datatype TYPE; 
  void* BUF; 
  int SIZ;
  NspObject *Buf;
  int srcdst,tag,info;
  NspMpiComm *comm;
  int_types T[] = {obj,s_int,s_int,obj_check, t_end};
  if ( GetArgs(stack,rhs,opt,T,&Buf,&srcdst,&tag,&nsp_type_mpicomm,&comm) == FAIL)
    return RET_BUG;
  BUF = nsp_get_mpi_buffer_from_obj(Buf, &SIZ,&TYPE); 
  if ( BUF == NULL) return RET_BUG;
  info = MPI_Send(BUF,SIZ,TYPE,srcdst,tag,comm->obj->comm);
  if ( info == MPI_SUCCESS)
    {
      return 0;
    }
  Scierror("Error: %s failed\n",NspFname(stack));
  return RET_BUG;
}

int int_nsp_mpi_Send_init(Stack stack,int rhs,int opt,int lhs)
{
  MPI_Request REQ; 
  MPI_Datatype TYPE; 
  void* BUF; 
  int SIZ;
  NspObject *Buf;
  int srcdst,tag,info;
  NspMpiComm *comm;
  int_types T[] = {obj,s_int,s_int,obj_check, t_end};
  if ( GetArgs(stack,rhs,opt,T,&Buf,&srcdst,&tag,&nsp_type_mpicomm,&comm) == FAIL)
    return RET_BUG;
  BUF = nsp_get_mpi_buffer_from_obj(Buf, &SIZ,&TYPE); 
  if ( BUF == NULL) return RET_BUG;
  info = MPI_Send_init(BUF,SIZ,TYPE,srcdst,tag,comm->obj->comm,&REQ);
  if ( info == MPI_SUCCESS)
    {
      NspMpiReq *res = nsp_mpireq_create(NVOID,REQ,NULL);
      if ( res == NULL) return RET_BUG;
      MoveObj(stack,1,NSP_OBJECT(res));
      return 1;
    }
  Scierror("Error: %s failed\n",NspFname(stack));
  return RET_BUG;
}


int int_nsp_mpi_Rsend(Stack stack,int rhs,int opt,int lhs)
{
  MPI_Datatype TYPE; 
  void* BUF; 
  int SIZ;
  NspObject *Buf;
  int srcdst,tag,info;
  NspMpiComm *comm;
  int_types T[] = {obj,s_int,s_int,obj_check, t_end};
  if ( GetArgs(stack,rhs,opt,T,&Buf,&srcdst,&tag,&nsp_type_mpicomm,&comm) == FAIL)
    return RET_BUG;
  BUF = nsp_get_mpi_buffer_from_obj(Buf, &SIZ,&TYPE); 
  if ( BUF == NULL) return RET_BUG;
  info = MPI_Rsend(BUF,SIZ,TYPE,srcdst,tag,comm->obj->comm);
  if ( info == MPI_SUCCESS)
    {
      return 0;
    }
  Scierror("Error: %s failed\n",NspFname(stack));
  return RET_BUG;
}

int int_nsp_mpi_Rsend_init(Stack stack,int rhs,int opt,int lhs)
{
  MPI_Request REQ; 
  MPI_Datatype TYPE; 
  void* BUF; 
  int SIZ;
  NspObject *Buf;
  int srcdst,tag,info;
  NspMpiComm *comm;
  int_types T[] = {obj,s_int,s_int,obj_check, t_end};
  if ( GetArgs(stack,rhs,opt,T,&Buf,&srcdst,&tag,&nsp_type_mpicomm,&comm) == FAIL)
    return RET_BUG;
  BUF = nsp_get_mpi_buffer_from_obj(Buf, &SIZ,&TYPE); 
  if ( BUF == NULL) return RET_BUG;
  info = MPI_Rsend_init(BUF,SIZ,TYPE,srcdst,tag,comm->obj->comm,&REQ);
  if ( info == MPI_SUCCESS)
    {
      NspMpiReq *res = nsp_mpireq_create(NVOID,REQ,NULL);
      if ( res == NULL) return RET_BUG;
      MoveObj(stack,1,NSP_OBJECT(res));
      return 1;
    }
  Scierror("Error: %s failed\n",NspFname(stack));
  return RET_BUG;
}



int int_nsp_mpi_Recv(Stack stack,int rhs,int opt,int lhs)
{
  MPI_Status ST;
  MPI_Datatype TYPE; 
  void* BUF; 
  int SIZ;
  NspObject *Buf;
  int srcdst,tag,info;
  NspMpiComm *comm;
  int_types T[] = {obj,s_int,s_int,obj_check, t_end};
  if ( GetArgs(stack,rhs,opt,T,&Buf,&srcdst,&tag,&nsp_type_mpicomm,&comm) == FAIL)
    return RET_BUG;
  BUF =  nsp_get_mpi_buffer_from_obj(Buf, &SIZ,&TYPE); 
  info = MPI_Recv(BUF,SIZ, TYPE, srcdst,tag,comm->obj->comm, &ST);
  if ( info == MPI_SUCCESS) 
    {
      NspHash *Res = MPI_Stat_to_Nsphash(ST);
      if ( Res == NULL) return RET_BUG; 
      MoveObj(stack,1,NSP_OBJECT(Res));
      return 1;
    }
  Scierror("Error: %s failed\n",NspFname(stack));
  return RET_BUG;
}

int int_nsp_mpi_Recv_init(Stack stack,int rhs,int opt,int lhs)
{
  MPI_Request REQ; 
  MPI_Datatype TYPE; 
  void* BUF; 
  int SIZ;
  NspObject *Buf;
  int srcdst,tag,info;
  NspMpiComm *comm;
  int_types T[] = {obj,s_int,s_int,obj_check, t_end};
  if ( GetArgs(stack,rhs,opt,T,&Buf,&srcdst,&tag,&nsp_type_mpicomm,&comm) == FAIL)
    return RET_BUG;
  BUF = nsp_get_mpi_buffer_from_obj(Buf, &SIZ,&TYPE); 
  if ( BUF == NULL) return RET_BUG;
  info = MPI_Recv_init(BUF,SIZ,TYPE,srcdst,tag,comm->obj->comm,&REQ);
  if ( info == MPI_SUCCESS)
    {
      NspMpiReq *res = nsp_mpireq_create(NVOID,REQ,NULL);
      if ( res == NULL) return RET_BUG;
      MoveObj(stack,1,NSP_OBJECT(res));
      return 1;
    }
  Scierror("Error: %s failed\n",NspFname(stack));
  return RET_BUG;
}


int int_nsp_mpi_Sendrecv(Stack stack,int rhs,int opt,int lhs)
{ 
  MPI_Status ST; 
  MPI_Datatype TYPE,RTYPE; 
  void *BUF,*RBUF; 
  int SIZ,RSIZ;
  NspObject *Buf,*Rbuf;
  int dst,stag,src,rtag,info;
  NspMpiComm *comm;
  int_types T[] = {obj,s_int,s_int,obj,s_int,s_int,obj_check, t_end};
  if ( GetArgs(stack,rhs,opt,T,&Buf,&dst,&stag,&Rbuf,&src,&rtag,&nsp_type_mpicomm,&comm)
       == FAIL)
    return RET_BUG;
  BUF = nsp_get_mpi_buffer_from_obj(Buf, &SIZ,&TYPE); 
  RBUF= nsp_get_mpi_buffer_from_obj(Rbuf,&RSIZ,&RTYPE); 
  if ( BUF == NULL) return RET_BUG;
  if ( RBUF == NULL) return RET_BUG;
  info = MPI_Sendrecv (BUF,SIZ,TYPE,dst,stag,RBUF,RSIZ,RTYPE,src,rtag,comm->obj->comm, &ST); 
  if ( info == MPI_SUCCESS)
    {
      NspHash *Res; 
      Res = MPI_Stat_to_Nsphash(ST);
      if ( Res == NULL) return RET_BUG; 
      MoveObj(stack,1,NSP_OBJECT(Res));
      return 1;
    }
  Scierror("Error: %s failed\n",NspFname(stack));
  return RET_BUG;
}

int int_nsp_mpi_Sendrecv_replace(Stack stack,int rhs,int opt,int lhs)
{ 
  MPI_Status ST; 
  NspObject *Buf,*Rbuf;
  MPI_Datatype TYPE,RTYPE; 
  void *BUF,*RBUF; 
  int SIZ, RSIZ, src,dst,rtag,stag,info; 
  NspMpiComm *comm;

  int_types T[] = {obj,s_int,s_int,obj,s_int,s_int,obj_check, t_end};
  if ( GetArgs(stack,rhs,opt,T,&Buf,&dst,&stag,&Rbuf,&src,&rtag,&nsp_type_mpicomm,&comm)
       == FAIL)
    return RET_BUG;
  BUF = nsp_get_mpi_buffer_from_obj(Buf, &SIZ,&TYPE); 
  RBUF= nsp_get_mpi_buffer_from_obj(Rbuf,&RSIZ,&RTYPE); 
  if ( BUF == NULL) return RET_BUG;
  if ( RBUF == NULL) return RET_BUG;
  info = MPI_Sendrecv_replace (BUF, SIZ, TYPE, dst,stag, src,rtag,comm->obj->comm, &ST); 
  if ( info == MPI_SUCCESS)
    {
      NspHash *Res; 
      Res = MPI_Stat_to_Nsphash(ST);
      if ( Res == NULL) return RET_BUG; 
      MoveObj(stack,1,NSP_OBJECT(Res));
      return 1;
    }
  Scierror("Error: %s failed\n",NspFname(stack));
  return RET_BUG;
}

int int_nsp_mpi_Buffer_attach(Stack stack,int rhs,int opt,int lhs)
{
  MPI_Datatype TYPE; 
  void* BUF; 
  int SIZ;
  NspObject *Buf;
  int bytes,info ;
  int_types T[] = {obj, t_end};
  if ( GetArgs(stack,rhs,opt,T,&Buf) == FAIL)
    return RET_BUG;
  BUF =  nsp_get_mpi_buffer_from_obj(Buf, &SIZ,&TYPE); 
  if ( TYPE == MPI_DOUBLE) 
    bytes = SIZ*sizeof(double);
  else if ( TYPE == MPI_INT) 
    bytes = SIZ*sizeof(int); 
  else 
    bytes = SIZ;
  info = MPI_Buffer_attach(BUF, bytes);
  if ( info == MPI_SUCCESS)
    {
      return 0;
    }
  Scierror("Error: %s failed\n",NspFname(stack));
  return RET_BUG;
}

int int_nsp_mpi_Buffer_detach(Stack stack,int rhs,int opt,int lhs)
{
  int n,info;
  void *ptr=NULL;
  CheckRhs(0,0);
  CheckLhs(0,1);
  info = MPI_Buffer_detach(&ptr,&n);
  if ( info == MPI_SUCCESS)
    {
      return 0;
    }
  Scierror("Error: %s failed\n",NspFname(stack));
  return RET_BUG;
}


int int_nsp_mpi_Bsend(Stack stack,int rhs,int opt,int lhs)
{ 
  MPI_Datatype TYPE; 
  void* BUF; 
  int SIZ;
  NspObject *Buf;
  int srcdst,tag,info;
  NspMpiComm *comm;
  int_types T[] = {obj,s_int,s_int,obj_check, t_end};
  if ( GetArgs(stack,rhs,opt,T,&Buf,&srcdst,&tag,&nsp_type_mpicomm,&comm) == FAIL)
    return RET_BUG;
  BUF =  nsp_get_mpi_buffer_from_obj(Buf, &SIZ,&TYPE); 
  info = MPI_Bsend(BUF,SIZ, TYPE, srcdst,tag,comm->obj->comm); 
  if ( info == MPI_SUCCESS)
    {
      return 0;
    }
  Scierror("Error: %s failed\n",NspFname(stack));
  return RET_BUG;
}

int int_nsp_mpi_Bsend_init(Stack stack,int rhs,int opt,int lhs)
{ 
  MPI_Request REQ;
  MPI_Datatype TYPE; 
  void* BUF; 
  int SIZ;
  NspObject *Buf;
  int srcdst,tag,info;
  NspMpiComm *comm;
  int_types T[] = {obj,s_int,s_int,obj_check, t_end};
  if ( GetArgs(stack,rhs,opt,T,&Buf,&srcdst,&tag,&nsp_type_mpicomm,&comm) == FAIL)
    return RET_BUG;
  BUF =  nsp_get_mpi_buffer_from_obj(Buf, &SIZ,&TYPE); 
  info = MPI_Bsend_init(BUF,SIZ, TYPE, srcdst,tag,comm->obj->comm,&REQ); 
  if ( info == MPI_SUCCESS)
    {
      NspMpiReq *res = nsp_mpireq_create(NVOID,REQ,NULL);
      if ( res == NULL) return RET_BUG;
      MoveObj(stack,1,NSP_OBJECT(res));
      return 1;
    }
  Scierror("Error: %s failed\n",NspFname(stack));
  return RET_BUG;
}

int int_nsp_mpi_Ibsend(Stack stack,int rhs,int opt,int lhs)
{ 
  MPI_Request REQ;
  MPI_Datatype TYPE; 
  void* BUF; 
  int SIZ;
  NspObject *Buf;
  int srcdst,tag,info;
  NspMpiComm *comm;
  int_types T[] = {obj,s_int,s_int,obj_check, t_end};
  if ( GetArgs(stack,rhs,opt,T,&Buf,&srcdst,&tag,&nsp_type_mpicomm,&comm) == FAIL)
    return RET_BUG;
  BUF =  nsp_get_mpi_buffer_from_obj(Buf, &SIZ,&TYPE); 
  info = MPI_Ibsend(BUF,SIZ, TYPE, srcdst,tag,comm->obj->comm,&REQ); 
  if ( info == MPI_SUCCESS)
    {
      NspMpiReq *res = nsp_mpireq_create(NVOID,REQ,NULL);
      if ( res == NULL) return RET_BUG;
      MoveObj(stack,1,NSP_OBJECT(res));
      return 1;
    }
  Scierror("Error: %s failed\n",NspFname(stack));
  return RET_BUG;

}

int int_nsp_mpi_Irsend(Stack stack,int rhs,int opt,int lhs)
{
  MPI_Request REQ;
  MPI_Datatype TYPE; 
  void* BUF; 
  int SIZ;
  NspObject *Buf;
  int srcdst,tag,info;
  NspMpiComm *comm;
  int_types T[] = {obj,s_int,s_int,obj_check, t_end};
  if ( GetArgs(stack,rhs,opt,T,&Buf,&srcdst,&tag,&nsp_type_mpicomm,&comm) == FAIL)
    return RET_BUG;
  BUF =  nsp_get_mpi_buffer_from_obj(Buf, &SIZ,&TYPE); 
  info = MPI_Irsend(BUF,SIZ, TYPE, srcdst,tag,comm->obj->comm,&REQ); 
  if ( info == MPI_SUCCESS)
    {
      NspMpiReq *res = nsp_mpireq_create(NVOID,REQ,NULL);
      if ( res == NULL) return RET_BUG;
      MoveObj(stack,1,NSP_OBJECT(res));
      return 1;
    }
  Scierror("Error: %s failed\n",NspFname(stack));
  return RET_BUG;

}

int int_nsp_mpi_Isend(Stack stack,int rhs,int opt,int lhs)
{
  MPI_Request REQ;
  MPI_Datatype TYPE; 
  void* BUF; 
  int SIZ;
  NspObject *Buf;
  int srcdst,tag,info;
  NspMpiComm *comm;
  int_types T[] = {obj,s_int,s_int,obj_check, t_end};
  if ( GetArgs(stack,rhs,opt,T,&Buf,&srcdst,&tag,&nsp_type_mpicomm,&comm) == FAIL)
    return RET_BUG;
  BUF =  nsp_get_mpi_buffer_from_obj(Buf, &SIZ,&TYPE); 
  info = MPI_Isend(BUF,SIZ, TYPE, srcdst,tag,comm->obj->comm,&REQ); 
  if ( info == MPI_SUCCESS)
    {
      NspMpiReq *res = nsp_mpireq_create(NVOID,REQ,NULL);
      if ( res == NULL) return RET_BUG;
      MoveObj(stack,1,NSP_OBJECT(res));
      return 1;
    }
  Scierror("Error: %s failed\n",NspFname(stack));
  return RET_BUG;

}

 int int_nsp_mpi_Issend(Stack stack,int rhs,int opt,int lhs)
{
  MPI_Request REQ;
  MPI_Datatype TYPE; 
  void* BUF; 
  int SIZ;
  NspObject *Buf;
  int srcdst,tag,info;
  NspMpiComm *comm;
  int_types T[] = {obj,s_int,s_int,obj_check, t_end};
  if ( GetArgs(stack,rhs,opt,T,&Buf,&srcdst,&tag,&nsp_type_mpicomm,&comm) == FAIL)
    return RET_BUG;
  BUF =  nsp_get_mpi_buffer_from_obj(Buf, &SIZ,&TYPE); 
  info = MPI_Issend(BUF,SIZ, TYPE, srcdst,tag,comm->obj->comm,&REQ); 
  if ( info == MPI_SUCCESS)
    {
      NspMpiReq *res = nsp_mpireq_create(NVOID,REQ,NULL);
      if ( res == NULL) return RET_BUG;
      MoveObj(stack,1,NSP_OBJECT(res));
      return 1;
    }
  Scierror("Error: %s failed\n",NspFname(stack));
  return RET_BUG;

}

int int_nsp_mpi_Ssend(Stack stack,int rhs,int opt,int lhs)
{
  MPI_Datatype TYPE; 
  void* BUF; 
  int SIZ;
  NspObject *Buf;
  int srcdst,tag,info;
  NspMpiComm *comm;
  int_types T[] = {obj,s_int,s_int,obj_check, t_end};
  if ( GetArgs(stack,rhs,opt,T,&Buf,&srcdst,&tag,&nsp_type_mpicomm,&comm) == FAIL)
    return RET_BUG;
  BUF =  nsp_get_mpi_buffer_from_obj(Buf, &SIZ,&TYPE); 
  info = MPI_Ssend(BUF,SIZ, TYPE, srcdst,tag,comm->obj->comm);
  if ( info == MPI_SUCCESS)
    {
      return 0;
    }
  Scierror("Error: %s failed\n",NspFname(stack));
  return RET_BUG;

}

 int int_nsp_mpi_Ssend_init(Stack stack,int rhs,int opt,int lhs)
{
  MPI_Request REQ;
  MPI_Datatype TYPE; 
  void* BUF; 
  int SIZ;
  NspObject *Buf;
  int srcdst,tag,info;
  NspMpiComm *comm;
  int_types T[] = {obj,s_int,s_int,obj_check, t_end};
  if ( GetArgs(stack,rhs,opt,T,&Buf,&srcdst,&tag,&nsp_type_mpicomm,&comm) == FAIL)
    return RET_BUG;
  BUF =  nsp_get_mpi_buffer_from_obj(Buf, &SIZ,&TYPE); 
  info = MPI_Ssend_init(BUF,SIZ, TYPE, srcdst,tag,comm->obj->comm,&REQ); 
  if ( info == MPI_SUCCESS)
    {
      NspMpiReq *res = nsp_mpireq_create(NVOID,REQ,NULL);
      if ( res == NULL) return RET_BUG;
      MoveObj(stack,1,NSP_OBJECT(res));
      return 1;
    }
  Scierror("Error: %s failed\n",NspFname(stack));
  return RET_BUG;

}

int int_nsp_mpi_Irecv(Stack stack,int rhs,int opt,int lhs)
{
  MPI_Request REQ;
  MPI_Datatype TYPE; 
  void* BUF; 
  int SIZ;
  NspObject *Buf;
  int srcdst,tag,info;
  NspMpiComm *comm;
  int_types T[] = {obj,s_int,s_int,obj_check, t_end};
  if ( GetArgs(stack,rhs,opt,T,&Buf,&srcdst,&tag,&nsp_type_mpicomm,&comm) == FAIL)
    return RET_BUG;
  BUF =  nsp_get_mpi_buffer_from_obj(Buf, &SIZ,&TYPE); 
  info = MPI_Irecv(BUF,SIZ, TYPE, srcdst,tag,comm->obj->comm, &REQ);
  if ( info == MPI_SUCCESS) 
    {
      NspMpiReq *res = nsp_mpireq_create(NVOID,REQ,NULL);
      if ( res == NULL) return RET_BUG;
      MoveObj(stack,1,NSP_OBJECT(res));
      return 1;
    }
  Scierror("Error: %s failed\n",NspFname(stack));
  return RET_BUG;
}


int int_nsp_mpi_Reduce(Stack stack,int rhs,int opt,int lhs)
{
  int info,rank,size;
  char *op=NULL;
  NspObject *Sbuf, *Rbuf;
  MPI_Op Op;
  void*SBUF; int Scnt; MPI_Datatype STYPE;
  void*RBUF; int Rcnt; MPI_Datatype RTYPE;
  int root; 
  NspMpiComm *comm;
  int_types T[] = {obj,obj,string,s_int, obj_check, t_end};
  if ( GetArgs(stack,rhs,opt,T,&Sbuf,&Rbuf,&op,&root,&nsp_type_mpicomm,&comm) == FAIL)
    return RET_BUG;
  SBUF =  nsp_get_mpi_buffer_from_obj(Sbuf, &Scnt,&STYPE); 
  RBUF =  nsp_get_mpi_buffer_from_obj(Rbuf, &Rcnt,&RTYPE); 
  if ( nsp_check_mpi_op(stack,op,&Op) == FAIL) return RET_BUG;
  MPI_Comm_rank(comm->obj->comm, &rank);
  MPI_Comm_size(comm->obj->comm, &size);
  if ( rank == root ) 
    {
      if ( Scnt != Rcnt || STYPE != RTYPE ) 
	{
	  Scierror("Error: first and second arguments of %s should have same size and type\n",
		   NspFname(stack));
	  return RET_BUG;
	}
    }
  info = MPI_Reduce(SBUF,RBUF,Scnt,STYPE, Op, root,comm->obj->comm);
  if ( info == MPI_SUCCESS) 
    {
      return 0;
    }
  Scierror("Error: %s failed\n",NspFname(stack));
  return RET_BUG;
}

int int_nsp_mpi_Reduce_scatter(Stack stack,int rhs,int opt,int lhs)
{
  int info;
  char *op=NULL;
  NspObject *Sbuf, *Rbuf;
  NspMatrix *Rcnts;
  MPI_Op Op;
  void*SBUF; int Scnt; MPI_Datatype STYPE;
  void*RBUF; int Rcnt; MPI_Datatype RTYPE;
  int root,count,i; 
  NspMpiComm *comm;
  int_types T[] = {obj,obj,mat_int,string,obj_check, t_end};
  if ( GetArgs(stack,rhs,opt,T,&Sbuf,&Rbuf,&Rcnts,&op,&root,&nsp_type_mpicomm,&comm) == FAIL)
    return RET_BUG;
  SBUF =  nsp_get_mpi_buffer_from_obj(Sbuf, &Scnt,&STYPE); 
  RBUF =  nsp_get_mpi_buffer_from_obj(Rbuf, &Rcnt,&RTYPE); 
  if ( nsp_check_mpi_op(stack,op,&Op) == FAIL) return RET_BUG;
  /*  compute the sum of Rcnts : check that it is equal to  Scnt and Rcnt 
   */
  count = 0; for ( i =0 ; i < Rcnts->mn ; i++) count += Rcnts->I[i];
  if ( Scnt != Rcnt || STYPE != RTYPE ) 
    {
      Scierror("Error: first and second arguments of %s should have same size and type\n"
	       "\tand have a size compatible with third argument\n",
	       NspFname(stack));
      return RET_BUG;
    }
  /* Check that count is equal to the number of processors XXXXX 
   *
   */
  info = MPI_Reduce_scatter(SBUF,RBUF,Rcnts->I,STYPE, Op, comm->obj->comm);
  if ( info == MPI_SUCCESS) 
    {
      return 0;
    }
  Scierror("Error: %s failed\n",NspFname(stack));
  return RET_BUG;
}

int int_nsp_mpi_Allreduce(Stack stack,int rhs,int opt,int lhs)
{
  int info;
  char *op=NULL;
  NspObject *Sbuf, *Rbuf;
  MPI_Op Op;
  void*SBUF; int Scnt; MPI_Datatype STYPE;
  void*RBUF; int Rcnt; MPI_Datatype RTYPE;
  NspMpiComm *comm;
  int_types T[] = {obj,obj,string,obj_check, t_end};
  if ( GetArgs(stack,rhs,opt,T,&Sbuf,&Rbuf,&op,&nsp_type_mpicomm,&comm) == FAIL)
    return RET_BUG;
  SBUF =  nsp_get_mpi_buffer_from_obj(Sbuf, &Scnt,&STYPE); 
  RBUF =  nsp_get_mpi_buffer_from_obj(Rbuf, &Rcnt,&RTYPE); 
  if ( nsp_check_mpi_op(stack,op,&Op) == FAIL) return RET_BUG;
  if ( Scnt != Rcnt || STYPE != RTYPE ) 
    {
      Scierror("Error: first and second arguments of %s should have same size and type\n",
	       NspFname(stack));
      return RET_BUG;
    }
  info = MPI_Allreduce(SBUF,RBUF,Scnt,STYPE,Op,comm->obj->comm);
  if ( info == MPI_SUCCESS) 
    {
      return 0;
    }
  Scierror("Error: %s failed\n",NspFname(stack));
  return RET_BUG;
}


int int_nsp_mpi_Gather(Stack stack,int rhs,int opt,int lhs)
{
  int info;
  NspObject *Sbuf, *Rbuf;
  void*SBUF; int Scnt; MPI_Datatype STYPE;
  void*RBUF; int Rcnt; MPI_Datatype RTYPE;
  int root,rank;
  NspMpiComm *comm;
  int_types T[] = {obj,obj,s_int, obj_check, t_end};
  if ( GetArgs(stack,rhs,opt,T,&Sbuf,&Rbuf,&root,&nsp_type_mpicomm,&comm) == FAIL)
    return RET_BUG;
  SBUF =  nsp_get_mpi_buffer_from_obj(Sbuf, &Scnt,&STYPE); 
  RBUF =  nsp_get_mpi_buffer_from_obj(Rbuf, &Rcnt,&RTYPE); 
  MPI_Comm_rank(comm->obj->comm, &rank);
  if ( rank == root ) 
    {
      int size; 
      MPI_Comm_size(comm->obj->comm,&size);
      if ( Rcnt != size *Scnt )
	{
	  Scierror("Error: size of recieve buffer should be %d*%s\n",size,Scnt);
	  return RET_BUG;
	}
    }
  info = MPI_Gather(SBUF,Scnt,STYPE, RBUF,Scnt,RTYPE, root,comm->obj->comm);
  if ( info == MPI_SUCCESS) 
    {
      return 0;
    }
  Scierror("Error: %s failed\n",NspFname(stack));
  return RET_BUG;
}

int int_nsp_mpi_Allgather(Stack stack,int rhs,int opt,int lhs)
{
  int info,size;
  NspObject *Sbuf, *Rbuf;
  void*SBUF; int Scnt; MPI_Datatype STYPE;
  void*RBUF; int Rcnt; MPI_Datatype RTYPE;
  NspMpiComm *comm;
  int_types T[] = {obj,obj,obj_check, t_end};
  CheckLhs(0,1);
  if ( GetArgs(stack,rhs,opt,T,&Sbuf,&Rbuf,&nsp_type_mpicomm,&comm) == FAIL)
    return RET_BUG;
  SBUF =  nsp_get_mpi_buffer_from_obj(Sbuf, &Scnt,&STYPE); 
  RBUF =  nsp_get_mpi_buffer_from_obj(Rbuf, &Rcnt,&RTYPE); 
  MPI_Comm_size(comm->obj->comm,&size);
  if ( Rcnt != size *Scnt )
    {
      Scierror("Error: size of recieve buffer should be %d*%s\n",size,Scnt);
      return RET_BUG;
    }
  info = MPI_Allgather(SBUF,Scnt,STYPE, RBUF,Scnt,RTYPE,comm->obj->comm);
  if ( info == MPI_SUCCESS) 
    {
      return 0;
    }
  Scierror("Error: %s failed\n",NspFname(stack));
  return RET_BUG;
}

int int_nsp_mpi_Gatherv(Stack stack,int rhs,int opt,int lhs)
{
  NspMatrix *Recvcounts,*Displs;
  int info;
  NspObject *Sbuf, *Rbuf;
  void*SBUF; int Scnt; MPI_Datatype STYPE;
  void*RBUF; int Rcnt; MPI_Datatype RTYPE;
  int root; 
  NspMpiComm *comm;
  int_types T[] = {obj,obj,mat_int,mat_int, s_int, obj_check, t_end};
  if ( GetArgs(stack,rhs,opt,T,&Sbuf,&Rbuf,&Recvcounts,&Displs,&root,&nsp_type_mpicomm,&comm) == FAIL)
    return RET_BUG;
  SBUF =  nsp_get_mpi_buffer_from_obj(Sbuf, &Scnt,&STYPE); 
  RBUF =  nsp_get_mpi_buffer_from_obj(Rbuf, &Rcnt,&RTYPE); 
  /* 
   *XXXX : should check that RBUF,Recvcounts->I,Displs->I,
   * are compatibles 
   *
   */
  info = MPI_Gatherv(SBUF,Scnt,STYPE, RBUF,Recvcounts->I,Displs->I,RTYPE, root,comm->obj->comm);
  if ( info == MPI_SUCCESS) 
    {
      return 0;
    }
  Scierror("Error: %s failed\n",NspFname(stack));
  return RET_BUG;
}

int int_nsp_mpi_Allgatherv(Stack stack,int rhs,int opt,int lhs)
{
  NspMatrix *Recvcounts,*Displs;
  int info;
  NspObject *Sbuf, *Rbuf;
  void*SBUF; int Scnt; MPI_Datatype STYPE;
  void*RBUF; int Rcnt; MPI_Datatype RTYPE;
  int root=0;  /* root should be in the arg list */
  NspMpiComm *comm;
  int_types T[] = {obj,obj,mat_int,mat_int, obj_check, t_end};
  if ( GetArgs(stack,rhs,opt,T,&Sbuf,&Rbuf,&Recvcounts,&Displs,&nsp_type_mpicomm,&comm) == FAIL)
    return RET_BUG;
  SBUF =  nsp_get_mpi_buffer_from_obj(Sbuf, &Scnt,&STYPE); 
  RBUF =  nsp_get_mpi_buffer_from_obj(Rbuf, &Rcnt,&RTYPE); 
  /* 
   *XXXX : should check that RBUF,Recvcounts->I,Displs->I,
   * are compatibles 
   *
   */
  info = MPI_Gatherv(SBUF,Scnt,STYPE, RBUF,Recvcounts->I,Displs->I,RTYPE, root,comm->obj->comm);
  if ( info == MPI_SUCCESS) 
    {
      return 0;
    }
  Scierror("Error: %s failed\n",NspFname(stack));
  return RET_BUG;
}


int int_nsp_mpi_Barrier(Stack stack, int rhs, int opt, int lhs)
{
  int info;
  NspMpiComm *comm;
  int_types T[] = {obj_check, t_end};
  if ( GetArgs(stack,rhs,opt,T,&nsp_type_mpicomm,&comm) == FAIL)
    return RET_BUG;
  info = MPI_Barrier(comm->obj->comm);
  if ( info == MPI_SUCCESS)
    {
      return 0;
    }
  Scierror("Error: %s failed\n",NspFname(stack));
  return RET_BUG;
}


int int_nsp_mpi_Bcast(Stack stack, int rhs, int opt, int lhs)
{
  MPI_Datatype TYPE; 
  void* BUF; 
  int SIZ,root, info;
  NspObject *Buf;
  NspMpiComm *comm;
  int_types T[] = {obj,s_int,obj_check, t_end};
  if ( GetArgs(stack,rhs,opt,T,&Buf,&root,&nsp_type_mpicomm,&comm) == FAIL)
    return RET_BUG;
  BUF = nsp_get_mpi_buffer_from_obj(Buf, &SIZ,&TYPE); 
  if ( BUF == NULL) return RET_BUG;
  info = MPI_Bcast(BUF,SIZ,TYPE,root,comm->obj->comm);
  if ( info == MPI_SUCCESS)
    {
      return 0;
    }
  Scierror("Error: %s failed\n",NspFname(stack));
  return RET_BUG;
}

/*
 * MPI_Scatterv(A,[1 2 3],[0 3 5],R,0,NEWORLD) 
 */

int int_nsp_mpi_Scatterv(Stack stack, int rhs, int opt, int lhs)
{
  int size,rank; 
  NspMatrix *index,*pos;
  int info;
  NspObject *Sbuf, *Rbuf;
  void*SBUF; int Scnt; MPI_Datatype STYPE;
  void*RBUF; int Rcnt; MPI_Datatype RTYPE;
  int root; 
  NspMpiComm *comm;
  int_types T[] = {obj,mat_int,mat_int,obj,s_int, obj_check, t_end};
  if ( GetArgs(stack,rhs,opt,T,&Sbuf,&index,&pos,&Rbuf,&root,&nsp_type_mpicomm,&comm) == FAIL)
    return RET_BUG;
  SBUF =  nsp_get_mpi_buffer_from_obj(Sbuf, &Scnt,&STYPE); 
  RBUF =  nsp_get_mpi_buffer_from_obj(Rbuf, &Rcnt,&RTYPE); 
  MPI_Comm_rank(comm->obj->comm, &rank);
  if ( rank == root ) 
    {
      int i;
      MPI_Comm_size(comm->obj->comm,&size);
      if ( index->mn != size || pos->mn != size )
	{
	  Scierror("Error: second and third arguments of %s should be of length %d\n",
		   NspFname(stack),size);
	  return RET_BUG;
	}
      for ( i = 0 ; i < size ; i++) 
	{
	  if ( index->I[i] + pos->I[i] > Scnt) 
	    {
	      Scierror("Error: the elements you are trying to send to process %d are out of range\n",
		       i);
	       return RET_BUG;
	    }
	}
      if ( index->I[root] > Rcnt) 
	{
	  Scierror("Error: the receive buffer is too small for receiving %d elements\n",
		   index->I[root]);
	  return RET_BUG;
	}
    }
  info = MPI_Scatterv(SBUF,index->I,pos->I,STYPE, RBUF,Rcnt,RTYPE, root,comm->obj->comm);
  if ( info == MPI_SUCCESS) 
    {
      return 0;
    }
  Scierror("Error: %s failed\n",NspFname(stack));
  return RET_BUG;
}

 /* envoit des blocks de taille Rcnt a chaque element de Comm
  * La taille de Snd n'est importante que sur root 
  * Il faut bien sur que la taille de Snd soit conforme 
  * a la taille de Rcnt* nbre de procs i.e >= 
  */

int int_nsp_mpi_Scatter(Stack stack, int rhs, int opt, int lhs)
{
  int info;
  NspObject *Sbuf, *Rbuf;
  void*SBUF; int Scnt; MPI_Datatype STYPE;
  void*RBUF; int Rcnt; MPI_Datatype RTYPE;
  int root; 
  NspMpiComm *comm;
  int_types T[] = {obj,obj,s_int, obj_check, t_end};
  if ( GetArgs(stack,rhs,opt,T,&Sbuf,&Rbuf,&root,&nsp_type_mpicomm,&comm) == FAIL)
    return RET_BUG;
  SBUF =  nsp_get_mpi_buffer_from_obj(Sbuf, &Scnt,&STYPE); 
  RBUF =  nsp_get_mpi_buffer_from_obj(Rbuf, &Rcnt,&RTYPE); 
  Scnt = Rcnt;
  info = MPI_Scatter(SBUF,Scnt,STYPE, RBUF,Rcnt,RTYPE, root,comm->obj->comm);
  /* XXXXX */
  if ( info == MPI_SUCCESS) 
    {
      return 0;
    }
  Scierror("Error: %s failed\n",NspFname(stack));
  return RET_BUG;
}

/*
 * Deletes communicator attribute value associated with a key (comm,kv)
 */

int int_nsp_mpi_Attr_delete(Stack stack, int rhs, int opt, int lhs)
{
  int info,kv;
  NspMpiComm *comm;
  int_types T[] = {obj_check,s_int, t_end};
  if ( GetArgs(stack,rhs,opt,T,&nsp_type_mpicomm,&comm,&kv) == FAIL)
    return RET_BUG;
  info = MPI_Attr_delete(comm->obj->comm,kv);
  if ( info == MPI_SUCCESS) 
    {
      return 0;
    }
  Scierror("Error: %s failed\n",NspFname(stack));
  return RET_BUG;
}

/*
 * Retrieves communicator attribute value by key (comm,kv)
 */


int int_nsp_mpi_Attr_get (Stack stack, int rhs, int opt, int lhs)
{
  int info,kv,flag;
  NspMpiComm *comm;
  int_types T[] = {obj_check,s_int, t_end};
  if ( GetArgs(stack,rhs,opt,T,&nsp_type_mpicomm,&comm,&kv) == FAIL)
    return RET_BUG;
  if ( kv <= MPI_WIN_DISP_UNIT ) 
    {
      int pred;
      info = MPI_Attr_get(comm->obj->comm,kv,&pred,&flag);
      if ( info == MPI_SUCCESS) 
	{
	  if ( flag == FALSE )
	    {
	      Scierror("Error: key %d does not exists\n",kv);
	      return RET_BUG;
	    }
	  if ( nsp_move_double(stack,1,pred) == FAIL ) return RET_BUG;
	  return 1;
	}
    }
  else 
    {
      NspObject *attr;
      info = MPI_Attr_get(comm->obj->comm,kv,&attr,&flag);
      if ( info == MPI_SUCCESS) 
	{
	  if ( flag == FALSE )
	    {
	      Scierror("Error: key %d does not exists\n",kv);
	      return RET_BUG;
	    }
	  if ( (attr = nsp_object_copy(attr))== NULLOBJ) 
	    return RET_BUG;
	  MoveObj(stack,1,attr);
	  return 0;
	}
    }
  Scierror("Error: %s failed\n",NspFname(stack));
  return RET_BUG;
}


/*
 * Stores a communicator attribute value associated with a key (comm,kv)
 * This is maybe not so usefull. We can attach a Nsp object to 
 * a Nspcomm if needed. XXX 
 */


int int_nsp_mpi_Attr_put(Stack stack, int rhs, int opt, int lhs)
{
  NspObject *attr;
  int info,kv;
  NspMpiComm *comm;
  int_types T[] = {obj_check,s_int, objcopy, t_end};
  if ( GetArgs(stack,rhs,opt,T,&nsp_type_mpicomm,&comm,&kv,&attr) == FAIL)
    return RET_BUG;
  /* 
   * Not that the attached nsp object is 
   * duplicated 
   * This routine should check that kv is a proper 
   * Attribute indice
   */
  info = MPI_Attr_put(comm->obj->comm,kv,&attr);
  if ( info == MPI_SUCCESS) 
    {
      return 0;
    }
  Scierror("Error: %s failed\n",NspFname(stack));
  return RET_BUG;
}




int int_nsp_mpi_Waitall(Stack stack, int rhs, int opt, int lhs)
{ 
  NspObject *Obj;
  int n,info;
  MPI_Status *stats = NULL; 
  MPI_Request *reqs=NULL;
  CheckRhs(1,1);
  CheckLhs(0,1);
  if ((Obj = nsp_get_object(stack,1)) == NULL) return RET_BUG;
  if ((reqs = nsp_mpi_check_requests(Obj))== NULL) return RET_BUG;
  n = ((NspCells *) Obj)->mn;
  if ((stats = calloc(n,sizeof(MPI_Status))) ==NULL) goto err;
  info = MPI_Waitall(n, reqs, stats); 
  nsp_mpi_update_requests((NspCells *) Obj,reqs);
  FREE(reqs);
  if ( info == MPI_SUCCESS)
    {
      NspCells *Res; 
      if ((Res=nsp_mpi_create_stat_cells(NVOID,n,stats))== NULL) 
	goto err; 
      MoveObj(stack,1,NSP_OBJECT(Res));
      FREE(stats);
      return Max(lhs,1);
    }
 err: 
  Scierror("Error: %s failed\n",NspFname(stack));
  FREE(stats);
  return RET_BUG;
}

int int_nsp_mpi_Waitany(Stack stack, int rhs, int opt, int lhs)
{ 
  NspObject *Obj;
  MPI_Status ST; 
  int n,idx,info;
  MPI_Request *reqs=NULL;
  CheckRhs(1,1);
  CheckLhs(0,2);
  if ((Obj = nsp_get_object(stack,1)) == NULL) return RET_BUG;
  if ((reqs = nsp_mpi_check_requests(Obj))== NULL) return RET_BUG;
  n = ((NspCells *) Obj)->mn;
  info = MPI_Waitany(n, reqs,  &idx, &ST); 
  nsp_mpi_update_requests((NspCells *) Obj,reqs);
  FREE(reqs);
  if ( info == MPI_SUCCESS)
    {
      NspHash *Res; 
      if ( lhs >= 2 ) 
	{
	  Res = MPI_Stat_to_Nsphash(ST);
	  if ( Res == NULL) goto err;
	  MoveObj(stack,2,NSP_OBJECT(Res));
	}
      if ( nsp_move_double(stack,1,idx) ==FAIL) return RET_BUG;
      return Max(lhs,1);
    }
 err: 
  Scierror("Error: %s failed\n",NspFname(stack));
  return RET_BUG;
}


int int_nsp_mpi_Wait(Stack stack, int rhs, int opt, int lhs)
{ 
  MPI_Status ST ={MPI_ANY_SOURCE,MPI_ANY_TAG,0,0};
  int info;
  NspMpiReq  *req;
  CheckRhs(1,1);
  CheckLhs(0,1);
  if ((req = GetMpiReq(stack,1))== NULL) return RET_BUG;
  info = MPI_Wait(&req->obj->req, &ST); 
  if ( info == MPI_SUCCESS)
    {
      NspHash *Res; 
      Res = MPI_Stat_to_Nsphash(ST);
      if ( Res == NULL) goto err;
      MoveObj(stack,1,NSP_OBJECT(Res));
    }
 err: 
  Scierror("Error: %s failed\n",NspFname(stack));
  return RET_BUG;
}

int int_nsp_mpi_Waitsome(Stack stack, int rhs, int opt, int lhs)
{
  NspMatrix *Idx=NULL;
  NspObject *Obj;
  int n,info,outcount;
  MPI_Status *stats = NULL; 
  MPI_Request *reqs=NULL;
  CheckRhs(1,1);
  CheckLhs(0,2);
  if ((Obj = nsp_get_object(stack,1)) == NULL) return RET_BUG;
  if ((reqs = nsp_mpi_check_requests(Obj))== NULL) return RET_BUG;
  n = ((NspCells *) Obj)->mn;
  if ((stats = calloc(n,sizeof(MPI_Status))) ==NULL) goto err;
  if ( (Idx = nsp_matrix_create(NVOID,'r',n,1))== NULL) goto err;
  info = MPI_Waitsome(n, reqs, &outcount, Idx->I, stats);
  nsp_mpi_update_requests((NspCells *) Obj,reqs);
  FREE(reqs);
  if ( info == MPI_SUCCESS)
    {
      NspCells *Res; 
      if ( lhs >= 2 )
	{
	  if ((Res=nsp_mpi_create_stat_cells(NVOID,outcount,stats))== NULL) 
	    goto err; 
	  MoveObj(stack,2,NSP_OBJECT(Res));
	}
      FREE(reqs);
      FREE(stats);
      Idx->convert = 'i';
      Mat2double (Idx);
      if (nsp_matrix_resize (Idx, Max(outcount,0),1) == FAIL) goto err;
      MoveObj(stack,1,NSP_OBJECT(Idx));
      return Max(lhs,1);
    }
 err: 
  Scierror("Error: %s failed\n",NspFname(stack));
  if ( Idx != NULL) nsp_matrix_destroy(Idx);
  FREE(stats);
  return RET_BUG;
}


int int_nsp_mpi_Startall(Stack stack, int rhs, int opt, int lhs)
{
  NspObject *Obj;
  int n,info;
  MPI_Request *reqs=NULL;
  CheckRhs(1,1);
  CheckLhs(0,1);
  if ((Obj = nsp_get_object(stack,1)) == NULL) return RET_BUG;
  if ((reqs = nsp_mpi_check_requests(Obj))== NULL) return RET_BUG;
  n = ((NspCells *) Obj)->mn;
  info = MPI_Startall(n, reqs ) ;
  nsp_mpi_update_requests((NspCells *) Obj,reqs);
  FREE(reqs);
  if ( info == MPI_SUCCESS)
    {
      return 0;
    }
  Scierror("Error: %s failed\n",NspFname(stack));
  return RET_BUG;
}


int int_nsp_mpi_Start(Stack stack, int rhs, int opt, int lhs)
{ 
  int info;
  NspMpiReq  *req;
  CheckRhs(1,1);
  CheckLhs(0,1);
  if ((req = GetMpiReq(stack,1))== NULL) return RET_BUG;
  info = MPI_Start(&req->obj->req) ;
  if ( info == MPI_SUCCESS)
    {
      return 0;
    }
  Scierror("Error: %s failed\n",NspFname(stack));
  return RET_BUG;
}


int int_nsp_mpi_Testall(Stack stack, int rhs, int opt, int lhs)
{ 
  NspObject *Obj;
  int info;
  int n,flag;
  MPI_Status *stats = NULL; 
  MPI_Request *reqs=NULL;
  CheckRhs(1,1);
  CheckLhs(0,rhs);
  if ((Obj = nsp_get_object(stack,1)) == NULL) return RET_BUG;
  if ((reqs = nsp_mpi_check_requests(Obj))== NULL) return RET_BUG;
  n = ((NspCells *) Obj)->mn;
  if ((stats = calloc(n,sizeof(MPI_Status))) ==NULL) goto err;
  info = MPI_Testall(n, reqs,&flag, stats); 
  nsp_mpi_update_requests((NspCells *) Obj,reqs);
  FREE(reqs);
  if ( info == MPI_SUCCESS ) 
    {
      NspCells *Res;
      if ( flag == FALSE ) 
	{
	  int i;
	  for ( i = 0; i < n ;i++)
	    {
	      stats[i].MPI_SOURCE  = MPI_ANY_SOURCE;
	      stats[i].MPI_TAG = MPI_ANY_TAG;
	    }
	}
      if ((Res=nsp_mpi_create_stat_cells(NVOID,n,stats))== NULL) 
	goto err; 
      MoveObj(stack,1,NSP_OBJECT(Res));
      FREE(stats);
      return Max(lhs,1);
    }
 err: 
  Scierror("Error: %s failed\n",NspFname(stack));
  FREE(stats);
  return RET_BUG;
}

int int_nsp_mpi_Testany(Stack stack, int rhs, int opt, int lhs)
{ 
  NspObject *Obj;
  MPI_Status ST ={MPI_ANY_SOURCE,MPI_ANY_TAG,0,0};
  int n,info, idx=-1, flag;
  MPI_Request *reqs=NULL;
  CheckRhs(1,1);
  CheckLhs(0,2);
  if ((Obj = nsp_get_object(stack,1)) == NULL) return RET_BUG;
  if ((reqs = nsp_mpi_check_requests(Obj))== NULL) return RET_BUG;
  n = ((NspCells *) Obj)->mn;
  info = MPI_Testany(n, reqs,  &idx,&flag, &ST); 
  nsp_mpi_update_requests((NspCells *) Obj,reqs);
  FREE(reqs);
  if ( info == MPI_SUCCESS ) 
    {
      NspHash *Res; 
      if ( lhs >= 2 ) 
	{
	  Res = MPI_Stat_to_Nsphash(ST);
	  if ( Res == NULL) goto err;
	  MoveObj(stack,2,NSP_OBJECT(Res));
	}
      if ( nsp_move_double(stack,1,idx) ==FAIL) return RET_BUG;
      return Max(lhs,1);
    }
 err: 
  Scierror("Error: %s failed\n",NspFname(stack));
  return RET_BUG;
}

int int_nsp_mpi_Test(Stack stack, int rhs, int opt, int lhs)
{
  MPI_Status ST ={MPI_ANY_SOURCE,MPI_ANY_TAG,0,0};
  int info;
  NspMpiReq  *req;
  int flag;
  CheckRhs(1,1);
  CheckLhs(0,1);
  if ((req = GetMpiReq(stack,1))== NULL) return RET_BUG;
  info = MPI_Test(&req->obj->req,&flag,&ST);
  if ( info == MPI_SUCCESS && flag == TRUE )
    {
      NspHash *Res; 
      Res = MPI_Stat_to_Nsphash(ST);
      if ( Res == NULL) goto err;
      MoveObj(stack,1,NSP_OBJECT(Res));
      return 1;
    }
 err: 
  Scierror("Error: %s failed\n",NspFname(stack));
  return RET_BUG;
}



int int_nsp_mpi_Test_cancelled(Stack stack, int rhs, int opt, int lhs)
{
  NspHash *H;
  int info;
  int flag; 
  MPI_Status ST ={MPI_ANY_SOURCE,MPI_ANY_TAG,0,0};
  CheckRhs(1,1);
  CheckLhs(0,1);
  if ((H = GetHash(stack,1)) == NULLHASH) return RET_BUG;
  if ( Nsphash_to_MPI_Stat(H,&ST) == FAIL) 
    {
      Scierror("Error: given hash table cannot be used as MPI_Status\n");
      return RET_BUG;
    }
  info = MPI_Test_cancelled(&ST, &flag);
  if ( info == MPI_SUCCESS && flag == TRUE ) 
   {
      NspHash *Res = MPI_Stat_to_Nsphash(ST);
      if ( Res == NULL) return RET_BUG; 
      MoveObj(stack,1,NSP_OBJECT(Res));
      return 1;
    }
  Scierror("Error: %s failed\n",NspFname(stack));
  return RET_BUG;
}

int int_nsp_mpi_Testsome(Stack stack, int rhs, int opt, int lhs)
{ 
  NspMatrix *Idx= NULL;
  NspObject *Obj;
  int n,info, outcount;
  MPI_Status *stats = NULL; 
  MPI_Request *reqs=NULL;
  CheckRhs(1,1);
  CheckLhs(0,2);
  if ((Obj = nsp_get_object(stack,1)) == NULL) return RET_BUG;
  if ((reqs = nsp_mpi_check_requests(Obj))== NULL) return RET_BUG;
  n = ((NspCells *) Obj)->mn;
  if ((stats = calloc(n,sizeof(MPI_Status))) ==NULL) goto err;
  if ( (Idx = nsp_matrix_create(NVOID,'r',n,1))== NULL) goto err;
  info = MPI_Testsome(n, reqs, &outcount, Idx->I, stats);
  nsp_mpi_update_requests((NspCells *) Obj,reqs);
  FREE(reqs);
  if ( info == MPI_SUCCESS)
    {
      NspCells *Res; 
      if ( lhs >= 2 )
	{
	  if ((Res=nsp_mpi_create_stat_cells(NVOID,outcount,stats))== NULL) 
	    goto err; 
	  MoveObj(stack,2,NSP_OBJECT(Res));
	}
      FREE(stats);
      Idx->convert = 'i';
      Mat2double (Idx);
      if (nsp_matrix_resize (Idx, Max(outcount,0),1) == FAIL) goto err;
      MoveObj(stack,1,NSP_OBJECT(Idx));
      return Max(lhs,1);
    }
 err: 
  Scierror("Error: %s failed\n",NspFname(stack));
  FREE(stats);
  if ( Idx != NULL) nsp_matrix_destroy(Idx);
  return RET_BUG;
}

int int_nsp_mpi_Abort(Stack stack, int rhs, int opt, int lhs)
{
  int errcode,info;
  NspMpiComm *comm;
  int_types T[] = {obj_check,s_int, t_end};
  if ( GetArgs(stack,rhs,opt,T,&nsp_type_mpicomm,&comm,&errcode) == FAIL)
    return RET_BUG;
  info = MPI_Abort(comm->obj->comm, errcode);
  if ( info == MPI_SUCCESS) 
    {
      return 0;
    }
  Scierror("Error: %s failed\n",NspFname(stack));
  return RET_BUG;
}

int int_nsp_mpi_Cancel(Stack stack, int rhs, int opt, int lhs)
{ 
  int info;
  NspMpiReq  *req;
  int_types T[] = {obj_check, t_end};
  if ( GetArgs(stack,rhs,opt,T,&nsp_type_mpireq,&req) == FAIL)
    return RET_BUG;
  info = MPI_Cancel(&req->obj->req);
  if ( info == MPI_SUCCESS) 
    {
      return 0;
    }
  Scierror("Error: %s failed\n",NspFname(stack));
  return RET_BUG;
}


int int_nsp_mpi_Scan(Stack stack, int rhs, int opt, int lhs)
{
  int info;
  char *op=NULL;
  NspObject *Sbuf, *Rbuf;
  MPI_Op Op;
  void*SBUF; int Scnt; MPI_Datatype STYPE;
  void*RBUF; int Rcnt; MPI_Datatype RTYPE;
  NspMpiComm *comm;
  int_types T[] = {obj,obj,string, obj_check, t_end};
  if ( GetArgs(stack,rhs,opt,T,&Sbuf,&Rbuf,&op,&nsp_type_mpicomm,&comm) == FAIL)
    return RET_BUG;
  SBUF =  nsp_get_mpi_buffer_from_obj(Sbuf, &Scnt,&STYPE); 
  RBUF =  nsp_get_mpi_buffer_from_obj(Rbuf, &Rcnt,&RTYPE); 
  if ( nsp_check_mpi_op(stack,op,&Op) == FAIL) return RET_BUG;
  if ( Scnt != Rcnt || STYPE != RTYPE ) 
    {
      Scierror("Error: first and second arguments of %s should have same size and type\n",
	       NspFname(stack));
      return RET_BUG;
    }
  info = MPI_Scan(SBUF,RBUF,Scnt,STYPE, Op,comm->obj->comm);
  if ( info == MPI_SUCCESS) 
    {
      return 0;
    }
  Scierror("Error: %s failed\n",NspFname(stack));
  return RET_BUG;
}


int int_nsp_mpi_Alltoall(Stack stack, int rhs, int opt, int lhs)
{
  int size,n, info;
  NspObject *Sbuf, *Rbuf;
  void*SBUF; int Scnt; MPI_Datatype STYPE;
  void*RBUF; int Rcnt; MPI_Datatype RTYPE;
  NspMpiComm *comm;
  int_types T[] = {obj,obj,s_int, obj_check, t_end};
  if ( GetArgs(stack,rhs,opt,T,&Sbuf,&Rbuf,&Rcnt,&nsp_type_mpicomm,&comm) == FAIL)
    return RET_BUG;
  SBUF =  nsp_get_mpi_buffer_from_obj(Sbuf, &Scnt,&STYPE); 
  RBUF =  nsp_get_mpi_buffer_from_obj(Rbuf, &Rcnt,&RTYPE); 
  MPI_Comm_size(comm->obj->comm,&size);
  if ( Rcnt != Scnt ) 
    {
      Scierror("Error: the receive and send buffer should be of the same size\n");
      return RET_BUG;
    }
  if ((Scnt % size) != 0)
    {
      Scierror("Error: the length of send buffer should be a multiple of %s\n",
	       size);
      return RET_BUG;
    }
  n = Scnt/size;
  info = MPI_Alltoall(SBUF,n,STYPE,RBUF,n,RTYPE,comm->obj->comm);
  if ( info == MPI_SUCCESS) 
    {
      return 0;
    }
  Scierror("Error: %s failed\n",NspFname(stack));
  return RET_BUG;
}

int int_nsp_mpi_Alltoallv(Stack stack, int rhs, int opt, int lhs)
{
  NspMatrix *Scnts,*Rcnts,*Sdisps,*Rdisps;
  int info;
  NspObject *Sbuf, *Rbuf;
  void*SBUF; int Scnt; MPI_Datatype STYPE;
  void*RBUF; int Rcnt; MPI_Datatype RTYPE;
  int root; 
  NspMpiComm *comm;
  int_types T[] = {obj,mat_int,mat_int,obj, mat_int,mat_int, obj_check, t_end};
  if ( GetArgs(stack,rhs,opt,T,&Sbuf,&Scnts,&Sdisps,&Rbuf,&root,&Rcnts,&Rdisps,&nsp_type_mpicomm,&comm) == FAIL)
    return RET_BUG;
  SBUF =  nsp_get_mpi_buffer_from_obj(Sbuf, &Scnt,&STYPE); 
  RBUF =  nsp_get_mpi_buffer_from_obj(Rbuf, &Rcnt,&RTYPE); 
  
  info =MPI_Alltoallv(SBUF,Scnts->I,Sdisps->I,STYPE, RBUF,Rcnts->I,Rdisps->I,RTYPE, comm->obj->comm);
  if ( info == MPI_SUCCESS) 
    {
      return 0;
    }
  Scierror("Error: %s failed\n",NspFname(stack));
  return RET_BUG;
}

int int_nsp_mpi_Error_string(Stack stack, int rhs, int opt, int lhs)
{
  char str[MPI_MAX_ERROR_STRING];
  int info,errcode,len;
  int_types T[] = {s_int,  t_end};
  if ( GetArgs(stack,rhs,opt,T,&errcode) == FAIL)
    return RET_BUG;
  info = MPI_Error_string(errcode, str, &len);
  if ( info == MPI_SUCCESS)
    {
      if ( nsp_move_string(stack,1,str,len) == FAIL ) return RET_BUG;
      return 1;
    }
  Scierror("Error: %s failed\n",NspFname(stack));
  return RET_BUG;
}

int int_nsp_mpi_Error_class(Stack stack, int rhs, int opt, int lhs)
{
  int info,errcode,class;
  int_types T[] = {s_int,  t_end};
  if ( GetArgs(stack,rhs,opt,T,&errcode) == FAIL)
    return RET_BUG;
  info = MPI_Error_class(errcode, &class);
  if ( info == MPI_SUCCESS)
    {
      if ( nsp_move_double(stack,1,class) ==FAIL) return RET_BUG;
      return Max(lhs,1);
    }
  Scierror("Error: %s failed\n",NspFname(stack));
  return RET_BUG;
}



int int_nsp_mpi_Dims_create(Stack stack,int rhs,int opt,int lhs)
{
  NspMatrix *dims;
  int info,nnodes, ndims;
  int_types T[] = {s_int,s_int, t_end};
  if ( GetArgs(stack,rhs,opt,T,&nnodes,&ndims) == FAIL)
    return RET_BUG;
  if ( (dims = nsp_matrix_create(NVOID,'r',ndims,1))== NULL) return RET_BUG;
  info = MPI_Dims_create(nnodes, ndims, dims->I);
  if ( info == MPI_SUCCESS) 
    {
      dims->convert = 'i';
      Mat2double (dims);
      MoveObj(stack,1,NSP_OBJECT(dims));
      return 1;
    }
  nsp_matrix_destroy(dims);
  Scierror("Error: %s failed\n",NspFname(stack));
  return RET_BUG;
}

/*
 * Establish a server port for client MPI connections
 */

int int_nsp_mpi_Open_port(Stack stack,int rhs,int opt,int lhs)
{
  int info;
  char   port[MPI_MAX_PORT_NAME];
  NspMpiInfo *inf;
  int_types T[] = {obj_check,t_end};
  CheckLhs(0,1);
  if ( GetArgs(stack,rhs,opt,T,&nsp_type_mpiinfo,&inf) == FAIL) return RET_BUG;
  info =MPI_Open_port(inf->obj->info,port);
  if ( info == MPI_SUCCESS)
    {
      if ( nsp_move_string(stack,1,port,-1) == FAIL ) return RET_BUG;
      return 1;
    }
  Scierror("Error: %s failed\n",NspFname(stack));
  return RET_BUG;
}



/*
 * Utilities to facilitate life in previous functions 
 */

/* Creates a NspHash table filled with 
 * stats informations. We could create a NspMpiStat 
 * object. 
 */

NspHash *MPI_Stat_to_Nsphash( MPI_Status stats)
{
  int *STptr = (int*) &stats,  i;
  NspHash *H;
  if(( H = nsp_hash_create(NVOID,4)) == NULLHASH) return  NULLHASH;
  for ( i = 0 ; i < 4 ; i++)
    {
      double val = STptr[i];
      NspMatrix *M= nsp_matrix_create_from_array(STAT_FNAME[i],1,1,&val,NULL);
      if ( M == NULLMAT) return  NULLHASH;
      if (nsp_hash_enter(H,NSP_OBJECT(M)) == FAIL) return  NULLHASH;
    }
  return H;
} 

/* fills a MPI_Status whith the contents of a NspHash table 
 * If the requested fields are not present FAIL is returned 
 */

int Nsphash_to_MPI_Stat(NspHash *H, MPI_Status *stats)
{
  int *STptr = (int*) stats,  i;
  for ( i = 0 ; i < 4 ; i++)
    {
      NspObject *Obj;
      int rep= nsp_hash_find(H,STAT_FNAME[i],&Obj);
      if ( rep == FAIL) return FAIL;
      if ( IsMat(Obj) && ((NspMatrix *) Obj)->rc_type == 'r' && ((NspMatrix *) Obj)->mn == 1)
	{
	  STptr[i] =(int) ((NspMatrix *) Obj)->R[0];
	}
      else 
	{
	  return FAIL;
	}
    }
  return OK;
} 


/* utility: returns a cell array of stats 
 */

NspCells *nsp_mpi_create_stat_cells(const char *name,int count,MPI_Status *stats)
{
  NspCells *Loc;
  int i=0;
  count = Max(count,0);
  /* initial mxn matrix with unallocated elements **/
  if ( ( Loc =nsp_cells_create("ce",count,1)) == NULLCELLS) return(NULLCELLS);
  /* allocate elements and store copies of elements **/
  for ( i = 0 ; i < count ; i++ )
    {
      Loc->objs[i]=(NspObject *) MPI_Stat_to_Nsphash(stats[i]);
      if (Loc->objs[i]  == NULL) goto err;
    }
  return(Loc);
 err: 
  return NULLCELLS;
}

/* returns the MPI Datatype which is associated to 
 * a NspObject when send/recv operations are used.
 */

MPI_Datatype nsp_get_mpi_type(NspObject *Obj ) 
{
  if (IsMat(Obj)) 
    {
      return MPI_DOUBLE;
    }
  else if ( IsSMat(Obj))
    {
      return MPI_BYTE;
    }
  else if ( IsBMat(Obj) )
    {
      return MPI_INT;
    }
  else 
    {
      Scierror("Error: no MPI Type for this object\n");
      return NULL;
    }
}

/* Get proper information from a NspObject for send/recv 
 * buffer 
 */


void *nsp_get_mpi_buffer_from_obj(NspObject *Obj,int *SIZ, MPI_Datatype * TYPE)
{
  if (IsMat(Obj)) 
    {
      NspMatrix *M= (NspMatrix *) Obj;
      Mat2double(M);
      *SIZ = M->mn *((M->rc_type == 'r') ? 1 :2 );
      *TYPE =  MPI_DOUBLE;
      return M->R;
    }
  else if ( IsSMat(Obj))
    {
      NspSMatrix *M= (NspSMatrix *) Obj;
      if ( M->mn == 1 ) 
	{
	  *SIZ = strlen(M->S[0])+1;
	  *TYPE =  MPI_BYTE;
	  return M->S[0];
	}
      else 
	{
	  Scierror("Error: Cannot make a buffer from argument\n"); 
	  return NULL;
	}
    }
  else if ( IsBMat(Obj) )
    {
      NspBMatrix *M= (NspBMatrix *) Obj;
      *SIZ = M->mn;
      *TYPE =  MPI_INT;
      return M->B;
    }
  else if ( IsMpiBuf(Obj))
    {
      NspMpiBuf *B = (NspMpiBuf *) Obj;
      *SIZ = B->nbytes;
      *TYPE =  MPI_PACKED;
      return B->val;
    }
  else if ( IsSerial(Obj))
    {
      NspSerial *S = (NspSerial *) Obj;
      *SIZ = S->nbytes;
      *TYPE = MPI_PACKED;
      return S->val;
    }

  Scierror("Error: Cannot send this type of object\n");
  return NULL;
}

/* checks that the string op is a proper MPI_Op
 *
 */


int nsp_check_mpi_op(Stack stack,char *op,MPI_Op *Op)
{
  int rep;
  char *ops[]={ "MAX", "MIN",  "SUM",  "PROD",  "LAND",  "BAND",  "LOR",  "BOR",  "LXOR",  "BXOR",  "MAXLOC",
		"MINLOC", "REPLACE", NULL};
  MPI_Op mpi_ops[]={  MPI_MAX, MPI_MIN, MPI_SUM, MPI_PROD, MPI_LAND, MPI_BAND, MPI_LOR, 
		      MPI_BOR, MPI_LXOR, MPI_BXOR, MPI_MAXLOC, MPI_MINLOC};
  rep = is_string_in_array(op, ops ,1);
  if ( rep < 0 ) 
    {
      string_not_in_array(stack,op, ops ,"argument");
      return FAIL;
    }
  *Op = mpi_ops[rep];
  return OK;
}

/* Check that the given cells is a cells of requests 
 *
 */


MPI_Request *nsp_mpi_check_requests(NspObject *Obj)
{
  NspCells *C =   (NspCells *) Obj;
  int i;
  MPI_Request *reqs=NULL;
  if ( ! IsCells(Obj)) return NULL;
  if ((reqs = calloc(C->mn, sizeof(MPI_Request)))==NULL) return NULL;
  for ( i = 0 ; i < C->mn ; i++ )
    {
      if ( C->objs[i] == NULL) goto err;
      if ( ! IsMpiReq(C->objs[i])) goto err;
      reqs[i] = ((NspMpiReq *) C->objs[i])->obj->req;
    }
  return reqs;
 err: 
  FREE(reqs);
  Scierror("Error: given argument is not a cell of mpi requests\n");
  return NULL;
}

void nsp_mpi_update_requests(NspCells *C,MPI_Request *reqs)
{
  int i;
  for ( i = 0 ; i < C->mn ; i++ )
    {
      ((NspMpiReq *) C->objs[i])->obj->req = reqs[i];
    }
}


