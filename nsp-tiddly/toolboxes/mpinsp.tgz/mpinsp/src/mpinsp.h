/* -*- Mode: C -*- */
#ifndef NSP_INC_MpiNsp
#define NSP_INC_MpiNsp

/*
 * This Software is GPL (Copyright ENPC 1998-2013) 
 * Jean-Philippe Chancelier Enpc/Cermics         
 */

#define       STATNFIELDS 4
static const char *STAT_FNAME[]={"src","tag","err","len"};
extern NspHash *MPI_Stat_to_Nsphash( MPI_Status stats);
extern int Nsphash_to_MPI_Stat(NspHash *H, MPI_Status *stats);
extern NspCells *nsp_mpi_create_stat_cells(const char *name,int count,MPI_Status *stats);
extern MPI_Datatype nsp_get_mpi_type(NspObject *Obj ) ;
extern void *nsp_get_mpi_buffer_from_obj(NspObject *Obj,int *SIZ, MPI_Datatype * TYPE);
extern int nsp_check_mpi_op(Stack stack,char *op,MPI_Op *Op);
extern void nsp_mpi_update_requests(NspCells *C,MPI_Request *reqs);
extern MPI_Request *nsp_mpi_check_requests(NspObject *Obj);


#endif 
