/* Nsp
 * Copyright (C) 2009-2013 Jean-Philippe Chancelier Enpc/Cermics
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public
 * License along with this library; if not, write to the
 * Free Software Foundation, Inc., 59 Temple Place - Suite 330,
 * Boston, MA 02111-1307, USA.
 *
 * Packing and Unpacking objects 
 * To be done: lists/sparse 
 * When inside nsp this is not that much useful since we can 
 * send/recv serialized objects and mostly all objects can be 
 * serialiazed. 
 */

#include <nsp/objects.h>
#include <nsp/cells.h>
#include <nsp/spcolmatrix.h>
#include <nsp/sprowmatrix.h>
#include <nsp/serial.h>
#include <nsp/interf.h>

#include "mpicomm.h"
#include "mpiinfo.h"
#include "mpigroup.h"
#include "mpibuf.h"

extern void *nsp_get_mpibuf_from_obj(NspObject *Obj,int *SIZ, MPI_Datatype * TYPE);

static int unpack_class(NspObject **Obj,MPI_Comm COM,void *BUF,int SIZ,int *IDX,int flag);
static int pack_class(NspObject *Obj,MPI_Comm COM,void *BUF,int SIZ,int *IDX);
static int size_class(NspObject *Obj,MPI_Comm COM,int *size);


static int pack_serial(NspObject *Obj,MPI_Comm COM,void *BUF,int SIZ,int *IDX)
{
  NspSerial *M =  (NspSerial *) Obj;
  int info;	
  if((info=MPI_Pack(&M->nbytes,1,MPI_INT, BUF,SIZ,IDX, COM))) return(info);
  if((info=MPI_Pack(M->val,M->nbytes,MPI_CHAR, BUF,SIZ,IDX, COM))) return(info);
  return(MPI_SUCCESS);		
}

static int size_serial(NspObject *Obj,MPI_Comm COM,int *size)
{
  NspSerial *M =  (NspSerial *) Obj;
  int info,sz;							
  if((info=MPI_Pack_size(1,MPI_INT, COM,&sz))) return(info);
  *size += sz;
  if((info=MPI_Pack_size(M->nbytes,MPI_CHAR, COM,&sz))) return(info);
  *size += sz;
  return(MPI_SUCCESS);		
}

static int unpack_serial(NspObject **Obj,char *name,MPI_Comm COM,void *BUF,int SIZ,int *IDX)
{
  NspSerial *M;
  int info,nbytes;
  if ((info=MPI_Unpack(BUF,SIZ,IDX,&nbytes,1,MPI_INT, COM))) return(info);
  if ((M = nsp_serial_create(name,NULL,nbytes-strlen(nsp_serial_header)))== NULLSERIAL) 
    return MPI_ERR_ARG; /* XXXX */ 
  if ((info=MPI_Unpack(BUF,SIZ,IDX,M->val,M->nbytes,MPI_CHAR, COM))) return(info);
  *Obj = NSP_OBJECT(M);
  return(MPI_SUCCESS);
}

/* NspCells 
 */

static int pack_cells(NspObject *Obj,MPI_Comm COM,void *BUF,int SIZ,int *IDX)
{
  NspCells *C = (NspCells *) Obj;
  int i, info, ok=OK,fail=FAIL;
  if((info=MPI_Pack(&C->m,1,MPI_INT, BUF,SIZ,IDX, COM))) return(info);
  if((info=MPI_Pack(&C->n,1,MPI_INT, BUF,SIZ,IDX, COM))) return(info);
  for( i=0; i< C->mn ; i++)
    {	
      if (C->objs[i]   == NULLOBJ)
	{
	  if((info=MPI_Pack(&fail,1,MPI_INT, BUF,SIZ,IDX, COM))) return(info); 
	}
      else
	{ 
	  if((info=MPI_Pack(&ok,1,MPI_INT, BUF,SIZ,IDX, COM))) return(info); 
	  if((info=pack_class(C->objs[i],COM,BUF,SIZ,IDX))) return(info); 
	}
    }
  return(MPI_SUCCESS);
}

static int size_cells(NspObject *Obj,MPI_Comm COM,int *size)
{
  NspCells *C = (NspCells *) Obj;
  int i, info, sz;
  if((info=MPI_Pack_size(1,MPI_INT, COM,&sz))) return(info);
  *size += sz;
  if((info=MPI_Pack_size(1,MPI_INT, COM,&sz))) return(info);
  *size += sz;
  for( i=0; i< C->mn ; i++)
    {	
      if (C->objs[i]   == NULLOBJ)
	{
	  if((info=MPI_Pack_size(1,MPI_INT, COM,&sz))) return(info); 
	  *size += sz;
	}
      else
	{ 
	  if((info=MPI_Pack_size(1,MPI_INT,  COM,&sz))) return(info); 
	  *size += sz;
	  if((info=size_class(C->objs[i],COM,size))) return(info); 
	}
    }
  return(MPI_SUCCESS);
}


static int unpack_cells(NspObject **Obj,char *name,MPI_Comm COM,void *BUF,int SIZ,int *IDX)
{
  NspCells *C = (NspCells *) Obj;
  int i,m,n, info;
  if ((info=MPI_Unpack(BUF,SIZ,IDX,&m,1,MPI_INT, COM))) return(info);
  if ((info=MPI_Unpack(BUF,SIZ,IDX,&n,1,MPI_INT, COM))) return(info);
  if ((C =nsp_cells_create(name,m,n)) == NULLCELLS) return MPI_ERR_ARG; /* XXXX */ 
  /* allocate elements and store copies of A elements **/
  for ( i = 0 ; i < m*n ; i++ )
    {
      NspObject *Elt;
      int tag;
      if ((info=MPI_Unpack(BUF,SIZ,IDX,&tag,1,MPI_INT, COM))) return(info);
      C->objs[i]= NULL;
      if ( tag == OK)
	{
	  if ((info= unpack_class(&Elt,COM,BUF,SIZ,IDX,TRUE) )) return(info);
	  C->objs[i]= Elt;
	}
    }
  *Obj = NSP_OBJECT(C);
  return(MPI_SUCCESS);
}

/* NspHash 
 */

static int pack_hash(NspObject *Obj,MPI_Comm COM,void *BUF,int SIZ,int *IDX)
{
  NspHash *H = (NspHash *) Obj;
  int  i=0, info;	
  if((info=MPI_Pack(&H->hsize,1,MPI_INT, BUF,SIZ,IDX, COM))) return(info);
  if((info=MPI_Pack(&H->filled,1,MPI_INT, BUF,SIZ,IDX, COM))) return(info);
  for ( i =0 ; i <= H->hsize ; i++) 
    {
      Hash_Entry *loc = ((Hash_Entry *) H->htable) + i;
      if ( loc->used && loc->data != NULLOBJ )
	{
	  if ((info = pack_class(loc->data,COM,BUF,SIZ,IDX))) return info;
	}
    }
  return(MPI_SUCCESS);
}

static int size_hash(NspObject *Obj,MPI_Comm COM,int *size)
{
  NspHash *H = (NspHash *) Obj;
  int  i=0, info, sz;
  if((info=MPI_Pack_size(1,MPI_INT, COM,&sz))) return(info);
  *size += sz;
  if((info=MPI_Pack_size(1,MPI_INT, COM,&sz))) return(info);
  *size += sz;
  for ( i =0 ; i <= H->hsize ; i++) 
    {
      Hash_Entry *loc = ((Hash_Entry *) H->htable) + i;
      if ( loc->used && loc->data != NULLOBJ )
	{
	  if ((info = size_class(loc->data,COM,size))) return info;
	}
    }
  return(MPI_SUCCESS);
}

static int unpack_hash(NspObject **Obj,char *name,MPI_Comm COM,void *BUF,int SIZ,int *IDX)
{
  NspHash *M = (NspHash *) Obj;
  int i,hsize,filled, info;
  if ((info=MPI_Unpack(BUF,SIZ,IDX,&hsize,1,MPI_INT, COM))) return(info);
  if ((info=MPI_Unpack(BUF,SIZ,IDX,&filled,1,MPI_INT, COM))) return(info);
  if ((M =nsp_hash_create(name,hsize)) == NULLHASH) return MPI_ERR_ARG; /* XXXX */ 
  /* allocate elements and store copies of A elements **/
  for ( i = 0 ; i < filled ; i++ )
    {
      NspObject *Elt;
      if ((info= unpack_class(&Elt,COM,BUF,SIZ,IDX,TRUE) )) return(info);
      if (nsp_hash_enter(M,Elt)== FAIL) return MPI_ERR_ARG;/* XXXX */ 
    }
  *Obj = NSP_OBJECT(M);
  return(MPI_SUCCESS);
}

/* NspBMatrix
 */

static int pack_bmat(NspObject *Obj,MPI_Comm COM,void *BUF,int SIZ,int *IDX)
{
  NspBMatrix *B =  (NspBMatrix *) Obj;
  int    info;							
  if((info=MPI_Pack(&B->m,1,MPI_INT, BUF,SIZ,IDX, COM))) return(info);
  if((info=MPI_Pack(&B->n,1,MPI_INT, BUF,SIZ,IDX, COM))) return(info);
  if((info=MPI_Pack(B->B,B->mn,MPI_INT,BUF,SIZ,IDX,COM)))return(info);	
  return(MPI_SUCCESS);							
}

static int size_bmat(NspObject *Obj,MPI_Comm COM,int *size)
{
  NspBMatrix *B =  (NspBMatrix *) Obj;
  int info,sz;							
  if((info=MPI_Pack_size(1,MPI_INT, COM,&sz))) return(info);
  *size += sz;
  if((info=MPI_Pack_size(1,MPI_INT, COM,&sz ))) return(info);
  *size += sz;
  if((info=MPI_Pack_size(B->mn,MPI_INT,COM,&sz)))return(info);	
  *size += sz;
  return(MPI_SUCCESS);							
}

static int unpack_bmat(NspObject **Obj,char *name,MPI_Comm COM,void *BUF,int SIZ,int *IDX)
{
  NspBMatrix *M;
  int m,n,info;
  if ((info=MPI_Unpack(BUF,SIZ,IDX,&m,1,MPI_INT, COM))) return(info);
  if ((info=MPI_Unpack(BUF,SIZ,IDX,&n,1,MPI_INT, COM))) return(info);
  if ((M=nsp_bmatrix_create(name,m,n)) == NULLBMAT) return MPI_ERR_ARG; /* XXXX */
  if ((info=MPI_Unpack(BUF,SIZ,IDX,M->B,M->mn,MPI_INT, COM))) return(info);
  *Obj = NSP_OBJECT(M);
  return(MPI_SUCCESS);
}


static int pack_mat(NspObject *Obj,MPI_Comm COM,void *BUF,int SIZ,int *IDX)
{
  NspMatrix *M =  (NspMatrix *) Obj;
  int   n, info;	
  Mat2double(M);
  if((info=MPI_Pack(&M->m,1,MPI_INT, BUF,SIZ,IDX, COM))) return(info);
  if((info=MPI_Pack(&M->n,1,MPI_INT, BUF,SIZ,IDX, COM))) return(info);
  if((info=MPI_Pack(&M->rc_type,1,MPI_CHAR, BUF,SIZ,IDX, COM))) return(info);
  n = ( M->rc_type == 'r') ? M->mn : 2*M->mn;
  if((info=MPI_Pack(M->R,n,MPI_DOUBLE,BUF,SIZ,IDX,COM)))return(info);	
  return(MPI_SUCCESS);		
}

static int size_mat(NspObject *Obj,MPI_Comm COM,int *size)
{
  NspMatrix *M =  (NspMatrix *) Obj;
  int   n, info,sz;							
  if((info=MPI_Pack_size(1,MPI_INT, COM,&sz))) return(info);
  *size += sz;
  if((info=MPI_Pack_size(1,MPI_INT, COM,&sz))) return(info);
  *size += sz;
  if((info=MPI_Pack_size(1,MPI_CHAR, COM,&sz))) return(info);
  *size += sz;
  n = ( M->rc_type == 'r') ? M->mn : 2*M->mn;
  if((info=MPI_Pack_size(n,MPI_DOUBLE,COM,&sz)))return(info);	
  *size += sz;
  return(MPI_SUCCESS);		
}

static int unpack_mat(NspObject **Obj,char *name,MPI_Comm COM,void *BUF,int SIZ,int *IDX)
{
  NspMatrix *M;
  int m,n,info;
  char type;
  if ((info=MPI_Unpack(BUF,SIZ,IDX,&m,1,MPI_INT, COM))) return(info);
  if ((info=MPI_Unpack(BUF,SIZ,IDX,&n,1,MPI_INT, COM))) return(info);
  if ((info=MPI_Unpack(BUF,SIZ,IDX,&type,1,MPI_CHAR, COM))) return(info);
  if ((M=nsp_matrix_create(name,type,m,n)) == NULLMAT) return MPI_ERR_ARG; /* XXXX */
  n = ( M->rc_type == 'r') ? M->mn : 2*M->mn;
  if ((info=MPI_Unpack(BUF,SIZ,IDX,M->R,n,MPI_DOUBLE, COM))) return(info);
  *Obj = NSP_OBJECT(M);
  return(MPI_SUCCESS);
}

static int pack_smat(NspObject *Obj,MPI_Comm COM,void *BUF,int SIZ,int *IDX)
{
  NspSMatrix *M =  (NspSMatrix *) Obj;
  int   n,i, info;			/* and then a nelm*elmsize block */
  if((info=MPI_Pack(&M->m,1,MPI_INT, BUF,SIZ,IDX, COM))) return(info);
  if((info=MPI_Pack(&M->n,1,MPI_INT, BUF,SIZ,IDX, COM))) return(info);
  for ( i = 0 ; i < M->mn ; i++) 
    {
      n = strlen(M->S[i]);
      if((info=MPI_Pack(&n,1,MPI_INT, BUF,SIZ,IDX, COM))) return(info);
      if((info=MPI_Pack(M->S[i],n,MPI_CHAR,BUF,SIZ,IDX, COM))) return(info);
    }
  return(MPI_SUCCESS);
}

static int size_smat(NspObject *Obj,MPI_Comm COM,int *size)
{
  NspSMatrix *M =  (NspSMatrix *) Obj;
  int   n,i, info,sz;	
  if((info=MPI_Pack_size(1,MPI_INT, COM,&sz))) return(info);
  *size += sz;
  if((info=MPI_Pack_size(1,MPI_INT, COM,&sz))) return(info);
  *size += sz;
  for ( i = 0 ; i < M->mn ; i++) 
    {
      n = strlen(M->S[i]);
      if((info=MPI_Pack_size(1,MPI_INT, COM,&sz))) return(info);
      *size += sz;
      if((info=MPI_Pack_size(n,MPI_CHAR, COM,&sz))) return(info);
      *size += sz;
    }
  return(MPI_SUCCESS);
}

static int unpack_smat(NspObject **Obj,char *name,MPI_Comm COM,void *BUF,int SIZ,int *IDX)
{
  NspSMatrix *M;
  int m,n,info,i;
  if ((info=MPI_Unpack(BUF,SIZ,IDX,&m,1,MPI_INT, COM))) return(info);
  if ((info=MPI_Unpack(BUF,SIZ,IDX,&n,1,MPI_INT, COM))) return(info);
  if ((M=nsp_smatrix_create(name,m,n,NULL,0)) == NULLSMAT) return MPI_ERR_ARG; /* XXXX */
  for ( i = 0 ; i < M->mn ; i++) 
    {
      int len;
      if ((info=MPI_Unpack(BUF,SIZ,IDX,&len,1,MPI_INT, COM))) return(info);
      if ((M->S[i] =new_nsp_string_n(len)) == (nsp_string) 0) return MPI_ERR_ARG; /* XXXX */
      if ((info=MPI_Unpack(BUF,SIZ,IDX,M->S[i],len,MPI_CHAR, COM))) return(info);
      M->S[i][len]='\0';
    }
  *Obj = NSP_OBJECT(M);
  return(MPI_SUCCESS);
}

static int pack_class(NspObject *Obj,MPI_Comm COM,void *BUF,int SIZ,int *IDX)
{
  char *name;
  int class,i, info;
  const char *vname;
  class = Obj->basetype->id;
  if((info=MPI_Pack(&class,1, MPI_INT, BUF,SIZ,IDX, COM))) return(info);
  vname = nsp_object_get_name(Obj);
  if ((name =nsp_string_copy(vname)) == (nsp_string) 0)  goto err;
  i = strlen(vname);
  if ((info=MPI_Pack(   &i,1, MPI_INT, BUF,SIZ,IDX, COM))) return(info);
  if ((info=MPI_Pack(name,i, MPI_CHAR,BUF,SIZ,IDX, COM))) return(info);
  if ( class ==  nsp_type_bmatrix_id )   return(pack_bmat(Obj,COM,BUF,SIZ,IDX));
  else if ( class ==  nsp_type_cells_id ) return(pack_cells(Obj,COM,BUF,SIZ,IDX));
  else if ( class ==  nsp_type_hash_id )return(pack_hash(Obj,COM,BUF,SIZ,IDX));
  else if ( class ==  nsp_type_list_id ) goto err;
  else if ( class ==  nsp_type_matrix_id ) return(pack_mat(Obj,COM,BUF,SIZ,IDX));
  else if ( class ==  nsp_type_serial_id ) return(pack_serial(Obj,COM,BUF,SIZ,IDX));
  else if ( class ==  nsp_type_smatrix_id )return(pack_smat(Obj,COM,BUF,SIZ,IDX));
  else if ( class ==  nsp_type_spcolmatrix_id ) goto err;
  else if ( class ==  nsp_type_sprowmatrix_id ) goto err;
 err: 
  Scierror("Error: packing not implemented for type %s\n"
	   "\tyou should first serialize object\n",  Obj->type->s_type());  
#ifdef MPI_ERR_TYPENOTSUP
    return(MPI_ERR_TYPENOTSUP);
#else 
    return(MPI_ERR_TYPE);
#endif
}

static int size_class(NspObject *Obj,MPI_Comm COM,int *size)
{
  int class;
  const char *vname;
  int  i,sz, info;
  class = Obj->basetype->id;
  if((info=MPI_Pack_size(1, MPI_INT, COM,&sz))) return(info);
  *size += sz;  
  vname = nsp_object_get_name(Obj);
  i = strlen(vname);
  if ((info=MPI_Pack_size( 1, MPI_INT, COM,&sz))) return(info);
  *size += sz;
  if ((info=MPI_Pack_size(i, MPI_CHAR, COM,&sz))) return(info);
  *size += sz;
  if ( class ==  nsp_type_bmatrix_id )   return(size_bmat(Obj,COM,size));
  else if ( class ==  nsp_type_cells_id ) return(size_cells(Obj,COM,size));
  else if ( class ==  nsp_type_hash_id )return(size_hash(Obj,COM,size));
  else if ( class ==  nsp_type_list_id ) goto err;
  else if ( class ==  nsp_type_matrix_id ) return(size_mat(Obj,COM,size));
  else if ( class ==  nsp_type_serial_id ) return(size_serial(Obj,COM,size));
  else if ( class ==  nsp_type_smatrix_id )return(size_smat(Obj,COM,size));
  else if ( class ==  nsp_type_spcolmatrix_id ) goto err;
  else if ( class ==  nsp_type_sprowmatrix_id ) goto err;
  /* add a zero at the end for unpacking detection */
 err: 
  Scierror("Error: packing not implemented for type %s\n"
	   "\tyou should first serialize object\n",  Obj->type->s_type());  
#ifdef MPI_ERR_TYPENOTSUP
    return(MPI_ERR_TYPENOTSUP);
#else 
    return(MPI_ERR_TYPE);
#endif
}


#define mxMAXNAM 512

static int unpack_class(NspObject **Obj,MPI_Comm COM,void *BUF,int SIZ,int *IDX,int flag)
{
  int class;
  char pname[mxMAXNAM+1];	/* Ok, ok, pname-dims should be dynamic */
  int  info, i;

  while (1) 
    {
      if((info=MPI_Unpack(BUF,SIZ,IDX,&class,1,MPI_INT, COM))) return(info);
      if (class == 0 ) return MPI_SUCCESS;
      if((info=MPI_Unpack(BUF,SIZ,IDX,    &i,1,MPI_INT, COM))) return(info);
      if((info=MPI_Unpack(BUF,SIZ,IDX, pname,i,MPI_CHAR,COM))) return(info);
      pname[i]='\0';
      if ( class ==  nsp_type_bmatrix_id ) 
	{
	  info = unpack_bmat(Obj,pname,COM,BUF,SIZ,IDX);
	  if ( info ) return info ;
	}
      else if ( class ==  nsp_type_cells_id )
	{
	  info = unpack_cells(Obj,pname,COM,BUF,SIZ,IDX);
	  if ( info ) return info ;
	}
      else if ( class ==  nsp_type_hash_id )
	{
	  info = unpack_hash(Obj,pname,COM,BUF,SIZ,IDX);
	  if ( info ) return info ;
	}
      else if ( class ==  nsp_type_list_id ) goto err;
      else if ( class ==  nsp_type_matrix_id ) 
	{
	  info = unpack_mat(Obj,pname,COM,BUF,SIZ,IDX);
	  if ( info ) return info ;
	}
      else if ( class ==  nsp_type_serial_id ) 
	{
	  info = unpack_serial(Obj,pname,COM,BUF,SIZ,IDX);
	  if ( info ) return info ;
	}
      else if ( class ==  nsp_type_smatrix_id ) 
	{
	  info = unpack_smat(Obj,pname,COM,BUF,SIZ,IDX);
	  if ( info ) return info ;
	}
      else if ( class ==  nsp_type_spcolmatrix_id ) goto err;
      else if ( class ==  nsp_type_sprowmatrix_id ) goto err;
      if ( flag == TRUE ) return MPI_SUCCESS;
    }
 err: 
#ifdef MPI_ERR_TYPENOTSUP
    return(MPI_ERR_TYPENOTSUP);
#else 
    return(MPI_ERR_TYPE);
#endif
}


int int_nsp_mpi_Unpack(Stack stack, int rhs, int opt, int lhs)
{
  int info,pos=0;
  NspMpiComm *comm;
  NspMpiBuf *buf;
  NspObject *Obj;
  int_types T[] = { obj_check,  obj_check, t_end};
  if ( GetArgs(stack,rhs,opt,T,&nsp_type_mpibuf,&buf,&nsp_type_mpicomm,&comm) == FAIL)
    return RET_BUG;
  info  = unpack_class(&Obj,comm->obj->comm,buf->val,buf->nbytes,&pos,TRUE);
  if ( info == MPI_SUCCESS) 
    {
      MoveObj(stack,1,Obj);
      return 1;
    }
  Scierror("Error: %s failed\n",NspFname(stack));
  return RET_BUG;
}


int int_nsp_mpi_Pack_size(Stack stack, int rhs, int opt, int lhs)
{
  int info,size=0;
  NspMpiComm *comm;
  NspObject *Obj;
  int_types T[] = { obj,  obj_check, t_end};
  CheckLhs(0,1);
  if ( GetArgs(stack,rhs,opt,T,&Obj,&nsp_type_mpicomm,&comm) == FAIL)
    return RET_BUG;
  info  = size_class(Obj,comm->obj->comm,&size);
  if ( info == MPI_SUCCESS) 
    {
      if ( nsp_move_double(stack,1,size) == FAIL ) return RET_BUG;
      return 1;
    }
  Scierror("Error: %s failed\n",NspFname(stack));
  return RET_BUG;
}


int int_nsp_mpi_Pack(Stack stack, int rhs, int opt, int lhs)
{
  NspMpiBuf *M = NULL;
  int size=0,info; /* take care that size must be 0 before call */
  NspObject *Obj;
  NspMpiComm *comm;
  CheckRhs(2,2);
  CheckLhs(0,1);
  if ((Obj = nsp_get_object(stack,1))== NULLOBJ) return RET_BUG;
  if ((comm = GetMpiComm(stack,2))== NULL) return RET_BUG;
  info  = size_class(Obj,comm->obj->comm,&size);
  if ( info != MPI_SUCCESS) goto err;
  if ((M = nsp_mpibuf_create(NVOID,NULL,size))== NULLMPIBUF)
    return RET_BUG;
  info  = pack_class(Obj,comm->obj->comm,M->val,M->nbytes,&M->pos);
  if ( info == MPI_SUCCESS) 
    {
      MoveObj(stack,1,NSP_OBJECT(M));
      return 1;
    }
 err:
  Scierror("Error: %s failed\n",NspFname(stack));
  return RET_BUG;
}

