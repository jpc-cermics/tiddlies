/* Nsp
 * Copyright (C) 2009-2013 Jean-Philippe Chancelier Enpc/Cermics
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public
 * License along with this library; if not, write to the
 * Free Software Foundation, Inc., 59 Temple Place - Suite 330,
 * Boston, MA 02111-1307, USA.
 *
 * MpiReq objects used to store MPI_Request.
 *
 * To be finished: free 
 */

#define  MpiReq_Private 
#include "nsp/objects.h"
#include "nsp/interf.h"
#include "mpicomm.h"
#include "mpiinfo.h"
#include "mpigroup.h"
#include "mpireq.h"


/* 
 * NspMpiReq inherits from NspObject 
 */

int nsp_type_mpireq_id=0;
NspTypeMpiReq *nsp_type_mpireq=NULL;

/*
 * Type object for MpiReq 
 * all the instance of NspTypeMpiReq share the same id. 
 * nsp_type_mpireq: is an instance of NspTypeMpiReq 
 *    used for objects of NspMpiReq type (i.e built with new_mpireq) 
 * other instances are used for derived classes 
 */
NspTypeMpiReq *new_type_mpireq(type_mode mode)
{
  NspTypeMpiReq *type= NULL;
  NspTypeObject *top;
  if (  nsp_type_mpireq != 0 && mode == T_BASE ) 
    {
      /* initialization performed and T_BASE requested */
      return nsp_type_mpireq;
    }
  if ((type =  malloc(sizeof(NspTypeMpiReq))) == NULL) return NULL;
  type->interface = NULL;
  type->surtype = (NspTypeBase *) new_type_object(T_DERIVED);
  if ( type->surtype == NULL) return NULL;
  type->attrs = mpireq_attrs ; 
  type->get_attrs = (attrs_func *) int_get_attribute;
  type->set_attrs = (attrs_func *) int_set_attribute;
  type->methods = mpireq_get_methods; 
  type->new = (new_func *) new_mpireq;

  
  top = NSP_TYPE_OBJECT(type->surtype);
  while ( top->surtype != NULL ) top= NSP_TYPE_OBJECT(top->surtype);
  
  /* object methods redefined for mpireq */ 

  top->pr = (print_func *) nsp_mpireq_print;                  
  top->dealloc = (dealloc_func *) nsp_mpireq_destroy;
  top->copy  =  (copy_func *) nsp_mpireq_copy;                 
  top->size  = (size_func *) nsp_mpireq_size;                
  top->s_type =  (s_type_func *) nsp_mpireq_type_as_string;  
  top->sh_type = (sh_type_func *) nsp_mpireq_type_short_string;
  top->info = (info_func *) nsp_mpireq_info ;                  
  /* top->is_true = (is_true_func  *) nsp_mpireq_is_true; */
  /* top->loop =(loop_func *) nsp_mpireq_loop;*/
  top->path_extract = (path_func *)  object_path_extract; 
  top->get_from_obj = (get_from_obj_func *) nsp_mpireq_object;
  top->eq  = (eq_func *) nsp_mpireq_eq;
  top->neq  = (eq_func *) nsp_mpireq_neq;
  top->save  = (save_func *) nsp_mpireq_xdr_save;
  top->load  = (load_func *) nsp_mpireq_xdr_load;
  top->create = (create_func*) int_mpireq_create;
  top->latex = (print_func *) nsp_mpireq_latex;
  
  /* specific methods for mpireq */
      
  type->init = (init_func *) init_mpireq;

  /* 
   * MpiReq interfaces can be added here 
   * type->interface = (NspTypeBase *) new_type_b();
   * type->interface->interface = (NspTypeBase *) new_type_C()
   * ....
   */
  if ( nsp_type_mpireq_id == 0 ) 
    {
      /* 
       * the first time we get here we initialize the type id and
       * an instance of NspTypeMpiReq called nsp_type_mpireq
       */
      type->id =  nsp_type_mpireq_id = nsp_new_type_id();
      nsp_type_mpireq = type;
      if ( nsp_register_type(nsp_type_mpireq) == FALSE) return NULL;
      return ( mode == T_BASE ) ? type : new_type_mpireq(mode);
    }
  else 
    {
       type->id = nsp_type_mpireq_id;
       return type;
    }
}

/*
 * initialize MpiReq instances 
 * locally and by calling initializer on parent class 
 */

static int init_mpireq(NspMpiReq *Obj,NspTypeMpiReq *type)
{
  /* jump the first surtype */ 
  if ( type->surtype->init(&Obj->father,type->surtype) == FAIL) return FAIL;
  Obj->type = type; 
  NSP_OBJECT(Obj)->basetype = (NspTypeBase *)type;
  /* specific */
  Obj->obj = NULL;
  return OK;
}

/*
 * new instance of MpiReq 
 */

NspMpiReq *new_mpireq() 
{
  NspMpiReq *loc; 
  /* type must exists */
  nsp_type_mpireq = new_type_mpireq(T_BASE);
  if ( (loc = malloc(sizeof(NspMpiReq)))== NULLMPIREQ) return loc;
  /* initialize object */
  if ( init_mpireq(loc,nsp_type_mpireq) == FAIL) return NULLMPIREQ;
  return loc;
}

/*----------------------------------------------
 * Object method redefined for MpiReq 
 *-----------------------------------------------*/
/*
 * size 
 */

static int nsp_mpireq_size(NspMpiReq *Mat, int flag)
{
  return 0;
}

/*
 * type as string 
 */

static char mpireq_type_name[]="MpiReq";
static char mpireq_short_type_name[]="mpireq";

static char *nsp_mpireq_type_as_string(void)
{
  return(mpireq_type_name);
}

static char *nsp_mpireq_type_short_string(NspObject *v)
{
  return(mpireq_short_type_name);
}

/*
 * A == B 
 */

static int nsp_mpireq_eq(NspMpiReq *A, NspObject *B)
{
  NspMpiReq *loc = (NspMpiReq *) B;
  if ( check_cast(B,nsp_type_mpireq_id) == FALSE) return FALSE ;
  if ( A->obj == loc->obj ) return TRUE;
  if ( A->obj->req != loc->obj->req) return FALSE;
  return TRUE;
}

/*
 * A != B 
 */

static int nsp_mpireq_neq(NspMpiReq *A, NspObject *B)
{
  return ( nsp_mpireq_eq(A,B) == TRUE ) ? FALSE : TRUE;
}

/*
 * save 
 */

int nsp_mpireq_xdr_save(XDR *xdrs, NspMpiReq *M)
{
  if (nsp_xdr_save_i(xdrs,M->type->id) == FAIL) return FAIL;
  if (nsp_xdr_save_string(xdrs, NSP_OBJECT(M)->name) == FAIL) return FAIL;
  return OK;
}

/*
 * load 
 */

NspMpiReq  *nsp_mpireq_xdr_load_partial(XDR *xdrs, NspMpiReq *M)
{
  if ((M->obj = malloc(sizeof(nsp_mpireq))) == NULL) return NULL;
 return M;
}

static NspMpiReq  *nsp_mpireq_xdr_load(XDR *xdrs)
{
  NspMpiReq *M = NULL;
  static char name[NAME_MAXL];
  if (nsp_xdr_load_string(xdrs,name,NAME_MAXL) == FAIL) return NULLMPIREQ;
  if ((M  = nsp_mpireq_create_void(name,(NspTypeBase *) nsp_type_mpireq))== NULLMPIREQ) return M;
  return nsp_mpireq_xdr_load_partial(xdrs,M);
}

/*
 * delete 
 */

void nsp_mpireq_destroy_partial(NspMpiReq *H)
{
  H->obj->ref_count--;
  if ( H->obj->ref_count == 0 )
   {
     if ( H->obj->req != MPI_REQUEST_NULL )
       MPI_Request_free(&(H->obj->req));
     FREE(H->obj);
   }
}

void nsp_mpireq_destroy(NspMpiReq *H)
{
  nsp_object_destroy_name(NSP_OBJECT(H));
  nsp_mpireq_destroy_partial(H);
  FREE(H);
}

/*
 * info 
 */

int nsp_mpireq_info(NspMpiReq *M,int indent,const char *name,int rec_level)
{
  const char *pname;
  if ( M == NULLMPIREQ) 
    {
      Sciprintf("Null Pointer MpiReq \n");
      return TRUE;
    }
  pname = (name != NULL) ? name : NSP_OBJECT(M)->name;
  Sciprintf1(indent,"%s\t=\t\t%s\n", (pname==NULL) ? "" : pname,
             nsp_mpireq_type_short_string(NSP_OBJECT(M)));
  return TRUE;
}

/*
 * print 
 */

int nsp_mpireq_print(NspMpiReq *M, int indent,const char *name, int rec_level)
{
  const char *pname = (name != NULL) ? name : NSP_OBJECT(M)->name;
  if ( M == NULLMPIREQ) 
    {
      Sciprintf("Null Pointer MpiReq \n");
      return TRUE;
    }
  if (user_pref.pr_as_read_syntax) 
    { 
      Sciprintf1(indent,"%s=TO_BE_DONE();\n",pname);
    } 
  else 
    { 
      if ( user_pref.pr_depth  <= rec_level -1 ) 
        {
          nsp_mpireq_info(M,indent,pname,rec_level);
          return TRUE;
        }
      Sciprintf1(indent,"%s\t=\t\t%s (nref=%d)\n",pname, nsp_mpireq_type_short_string(NSP_OBJECT(M)) ,M->obj->ref_count);
    }
  return TRUE;
}

/*
 * latex print 
 */

int nsp_mpireq_latex(NspMpiReq *M, int indent,const char *name, int rec_level)
{
  const char *pname = (name != NULL) ? name : NSP_OBJECT(M)->name;
  if ( nsp_from_texmacs() == TRUE ) Sciprintf("\002latex:\\[");
  Sciprintf1(indent,"%s\t=\t\t%s\n",pname, nsp_mpireq_type_short_string(NSP_OBJECT(M)));
  if ( nsp_from_texmacs() == TRUE ) Sciprintf("\\]\005");
  return TRUE;
}
/*-----------------------------------------------------
 * a set of functions used when writing interfaces 
 * for MpiReq objects 
 * Note that some of these functions could become MACROS 
 *-----------------------------------------------------*/

NspMpiReq   *nsp_mpireq_object(NspObject *O)
{
  /* Follow pointer */
  if ( check_cast(O,nsp_type_hobj_id) == TRUE)  O = ((NspHobj *) O)->O ;
  /* Check type */
  if ( check_cast (O,nsp_type_mpireq_id) == TRUE ) return ((NspMpiReq *) O);
  else 
    Scierror("Error:	Argument should be a %s\n",type_get_name(nsp_type_mpireq));
  return NULL;
}

int IsMpiReqObj(Stack stack, int i)
{
  return nsp_object_type(NthObj(i) , nsp_type_mpireq_id);
}

int IsMpiReq(NspObject *O)
{
  return nsp_object_type(O,nsp_type_mpireq_id);
}

NspMpiReq  *GetMpiReqCopy(Stack stack, int i)
{
  if (  GetMpiReq(stack,i) == NULL ) return NULL;
  return MaybeObjCopy(&NthObj(i));
}

NspMpiReq  *GetMpiReq(Stack stack, int i)
{
  NspMpiReq *M;
  if (( M = nsp_mpireq_object(NthObj(i))) == NULLMPIREQ)
     ArgMessage(stack,i);
  return M;
}

/*-----------------------------------------------------
  * constructor 
 * if type is non NULL it is a subtype which can be used to 
 * create a NspClassB instance 
 *-----------------------------------------------------*/

static NspMpiReq *nsp_mpireq_create_void(char *name,NspTypeBase *type)
{
 NspMpiReq *H  = (type == NULL) ? new_mpireq() : type->new();
 if ( H ==  NULLMPIREQ)
  {
   Sciprintf("No more memory\n");
   return NULLMPIREQ;
  }
 if ( nsp_object_set_initial_name(NSP_OBJECT(H),name) == NULLSTRING) return NULLMPIREQ;
 NSP_OBJECT(H)->ret_pos = -1 ;
 return H;
}

int nsp_mpireq_create_partial(NspMpiReq *H)
{
  if((H->obj = calloc(1,sizeof(nsp_mpireq)))== NULL ) return FAIL;
  H->obj->ref_count=1;
  return OK;
}

int nsp_mpireq_check_values(NspMpiReq *H)
{
  return OK;
}

NspMpiReq *nsp_mpireq_create(char *name,MPI_Request req,NspTypeBase *type)
{
 NspMpiReq *H  = nsp_mpireq_create_void(name,type);
 if ( H ==  NULLMPIREQ) return NULLMPIREQ;
  if ( nsp_mpireq_create_partial(H) == FAIL) return NULLMPIREQ;
  H->obj->req=req;
 if ( nsp_mpireq_check_values(H) == FAIL) return NULLMPIREQ;
 return H;
}

/*
 * copy for gobject derived class  
 */

NspMpiReq *nsp_mpireq_copy_partial(NspMpiReq *H,NspMpiReq *self)
{
  H->obj = self->obj; self->obj->ref_count++;
  return H;
}

NspMpiReq *nsp_mpireq_copy(NspMpiReq *self)
{
  NspMpiReq *H  =nsp_mpireq_create_void(NVOID,(NspTypeBase *) nsp_type_mpireq);
  if ( H ==  NULLMPIREQ) return NULLMPIREQ;
  if ( nsp_mpireq_copy_partial(H,self)== NULL) return NULLMPIREQ;

  return H;
}
/*
 * full copy for gobject derived class  
 */

NspMpiReq *nsp_mpireq_full_copy_partial(NspMpiReq *H,NspMpiReq *self)
{
  if ((H->obj = calloc(1,sizeof(nsp_mpireq))) == NULL) return NULLMPIREQ;
  H->obj->ref_count=1;
  H->obj->req=self->obj->req;
  return H;
}

NspMpiReq *nsp_mpireq_full_copy(NspMpiReq *self)
{
  NspMpiReq *H  =nsp_mpireq_create_void(NVOID,(NspTypeBase *) nsp_type_mpireq);
  if ( H ==  NULLMPIREQ) return NULLMPIREQ;
  if ( nsp_mpireq_full_copy_partial(H,self)== NULL) return NULLMPIREQ;
  return H;
}

/*-------------------------------------------------------------------
 * wrappers for the MpiReq
 * i.e functions at Nsp level 
 *-------------------------------------------------------------------*/

int int_mpireq_create(Stack stack, int rhs, int opt, int lhs)
{
  char *str ;
  NspMpiReq *H;
  CheckStdRhs(1,1);
  /* want to be sure that type mpireq is initialized */
  nsp_type_mpireq = new_type_mpireq(T_BASE);
  if(( H = nsp_mpireq_create_void(NVOID,(NspTypeBase *) nsp_type_mpireq)) == NULLMPIREQ) return RET_BUG;
  /* then we use optional arguments to fill attributes */
  if ( nsp_mpireq_create_partial(H) == FAIL) return RET_BUG;
  if ((str=GetString(stack,1)) == NULL) return RET_BUG;
  if (!strcmp(str,"NULL"  )) 
    H->obj->req =MPI_REQUEST_NULL  ;
  else			
    {
      Scierror("Error: unable to create MPI Group %s\n",str);
      return RET_BUG;
    }
  MoveObj(stack,1,(NspObject  *) H);
  return 1;
} 



static NspMethods mpireq_methods[] = {
  { NULL, NULL}
};

static NspMethods *mpireq_get_methods(void) { return mpireq_methods;};
/*-------------------------------------------
 * Attributes
 *-------------------------------------------*/

static AttrTab mpireq_attrs[] = {{NULL,NULL,NULL,NULL,NULL}} ;

/*-------------------------------------------
 * functions 
 *-------------------------------------------*/

/*----------------------------------------------------
 * Interface 
 * i.e a set of function which are accessible at nsp level
 *----------------------------------------------------*/

static OpTab mpireq_func[]={
  { "mpireq_create", int_mpireq_create},
  { NULL, NULL}
};

/* call ith function in the mpireq interface */

int mpireq_Interf(int i, Stack stack, int rhs, int opt, int lhs)
{
  return (*(mpireq_func[i].fonc))(stack,rhs,opt,lhs);
}

/* used to walk through the interface table 
    (for adding or removing functions) */

void mpireq_Interf_Info(int i, char **fname, function (**f))
{
  *fname = mpireq_func[i].name;
  *f = mpireq_func[i].fonc;
}
