/* -*- Mode: C -*- */
#ifndef NSP_INC_MpiReq
#define NSP_INC_MpiReq

/*
 * This Software is GPL (Copyright ENPC 1998-2013) 
 * Jean-Philippe Chancelier Enpc/Cermics         
 */

/* MpiReq */

#include "nsp/object.h"

/*
 * NspMpiReq inherits from NspObject
 */

typedef struct _NspMpiReq NspMpiReq ;
typedef struct _NspTypeMpiReq NspTypeMpiReq ;


struct _NspTypeMpiReq {
  /*< private >*/
  NSP_TYPE_OBJECT__
  /*< public >*/
  
};

typedef struct _nsp_mpireq nsp_mpireq;
struct _nsp_mpireq {
  MPI_Request req;
  int ref_count;
};

struct _NspMpiReq {
  /*< private >*/
  NspObject father;
  NspTypeMpiReq*type;
  /*< public >*/
  nsp_mpireq *obj;
};

extern int nsp_type_mpireq_id;
extern NspTypeMpiReq *nsp_type_mpireq;

/* type instances for object */

NspTypeMpiReq *new_type_mpireq(type_mode mode);

/* instance for MpiReq */

NspMpiReq *new_mpireq();

/*
* Object methods redefined for mpireq 
*/


#define NULLMPIREQ (NspMpiReq*) 0

extern NspMpiReq *nsp_mpireq_create(char *name,MPI_Request req,NspTypeBase *type);

/* from MpiReqObj.c */

extern NspMpiReq *nsp_mpireq_copy(NspMpiReq *H);
extern void nsp_mpireq_destroy(NspMpiReq *H);
extern int nsp_mpireq_info(NspMpiReq *H, int indent,const char *name, int rec_level);
extern int nsp_mpireq_print(NspMpiReq *H, int indent,const char *name, int rec_level);
extern int nsp_mpireq_latex(NspMpiReq *H, int indent,const char *name, int rec_level);
extern NspMpiReq *nsp_mpireq_object (NspObject *O); 
extern int IsMpiReqObj (Stack stack, int i); 
extern int IsMpiReq(NspObject *O);
extern NspMpiReq *GetMpiReqCopy (Stack stack, int i); 
extern NspMpiReq *GetMpiReq (Stack stack, int i); 
extern int nsp_mpireq_create_partial(NspMpiReq *H);
extern void nsp_mpireq_destroy_partial(NspMpiReq *H);
extern NspMpiReq * nsp_mpireq_copy_partial(NspMpiReq *H,NspMpiReq *self);
extern NspMpiReq * nsp_mpireq_full_copy_partial(NspMpiReq *H,NspMpiReq *self);
extern NspMpiReq * nsp_mpireq_full_copy(NspMpiReq *self);
extern int nsp_mpireq_check_values(NspMpiReq *H);
extern int int_mpireq_create(Stack stack, int rhs, int opt, int lhs); 
extern NspMpiReq *nsp_mpireq_xdr_load_partial(XDR *xdrs, NspMpiReq *M);
extern int nsp_mpireq_xdr_save(XDR  *xdrs, NspMpiReq *M);

#endif /* NSP_INC_MpiReq */ 

#ifdef MpiReq_Private 
static int init_mpireq(NspMpiReq *o,NspTypeMpiReq *type);
static int nsp_mpireq_size(NspMpiReq *Mat, int flag);
static char *nsp_mpireq_type_as_string(void);
static char *nsp_mpireq_type_short_string(NspObject *v);
static int nsp_mpireq_eq(NspMpiReq *A, NspObject *B);
static int nsp_mpireq_neq(NspMpiReq *A, NspObject *B);
static NspMpiReq *nsp_mpireq_xdr_load(XDR *xdrs);
static AttrTab mpireq_attrs[];
static NspMethods *mpireq_get_methods(void);
/* static int int_mpireq_create(Stack stack, int rhs, int opt, int lhs);*/ 
static NspMpiReq *nsp_mpireq_create_void(char *name,NspTypeBase *type);
#endif /* MpiReq_Private */

