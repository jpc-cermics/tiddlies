// Copyright (C) 2000-08 Javier Fern�ndez Baldomero <jfernand@ugr.es> 
// This program is free software
// myPi:	Classic PI computation by numeric integration of arctan'(x) in [0..1]
//
//  N	[1E7]	//subdivisions of the [0, 1] interval
//  mod	['s']	communication modality:  (s)end (r)educe
//
//  printed results struct contains
//	pi	estimated pi value
//	err	error
//	time	from argument xmit to pi computed
//
// Examples:
//
// This file can be run through 
// mpirun -c 2 /usr/local/src/nsp2/bin/nsp -f tests/myPi.sce -e "if SLV then MPI_Finalize();quit;end"

exec('src/loader.sce')

N=1E7 
mod = 'r';

results.pi   =0;
results.err  =0;
results.time =0;

// PARALLEL // initialization, include MPI_Init time in measurement
tic(); //

if ~MPI_Initialized() then   MPI_Init();end 
MPI_COMM_WORLD=mpicomm_create('WORLD');
[rank] =	MPI_Comm_rank (MPI_COMM_WORLD);	
[size] =	MPI_Comm_size (MPI_COMM_WORLD);

SLV = (rank <> 0) //
MST = ~ SLV;	  // 

// PARALLEL // computation (depends on rank/size)
////////////////////////	// vectorized code, equivalent to
width=1/N; lsum=0;		// for i=rnk:siz:N-1
i=rank:size:N-1;		//   x=(i+0.5)*width;
x=(i+0.5)*width;		//   lsum=lsum+4/(1+x^2);
lsum=sum(4./(1+x.^2));	// end
// mem-bound, N=1E7 => size(i)=8E7/siz (80MB!!!)

// PARALLEL // reduction and finish
select mod
 case 's',			TAG=7;	// Any tag would do
  if SLV				// All slaves send result back
    MPI_Send(lsum,0,TAG,MPI_COMM_WORLD);
  else				// Here at master
    Sum =lsum;			// save local result
    for slv=1:size-1			// collect in any order
      MPI_Recv(lsum,-1,TAG,MPI_COMM_WORLD);
      Sum = Sum+lsum;			// and accumulate
    end				// order: slv or MPI_ANY_SOURCE
  end
 case 'r',		Sum=0;		// reduction master = rank 0 @ WORLD
  MPI_Reduce(lsum,Sum, 'SUM',  0,MPI_COMM_WORLD);
end

MPI_Finalize();

if MST
  Sum      = Sum/N ; 			// better at end: don't loose resolution
  results.time = toc();  // but only at master after PI computed
  results.err  = Sum- %pi;
  results.pi   = Sum 
  // FINAL CHECK //
  if abs(results.err)>5E-10
    print('pretty nice pi value! go fix it');
  else
    print('value is ok ! see results;\n");
  end
else
  quit
end


