// MPI automatic test for nsp 
// assumes that the toolbox is already loaded
// ---------------------------
// exec('tests/loader.sce')

N=2;
NEWORLD=NSP_spawn(N,%t);

// Now we have two children waiting on tag 7 for commands and tag 8 for
// data 

A=int(10*rand(N+1,N+1,'n'));

for i=1:N
  MPI_Send_Obj("rank=MPI_Comm_rank(NEWORLD);",i,7,NEWORLD);
  MPI_Send_Obj(A,i,8,NEWORLD);
  MPI_Send_Obj("A=data;MPI_Reduce(A(rank+1,:),[],''MIN'',0,NEWORLD);",i,7,NEWORLD);
end

// now run the reduce operation on root.

R=0*ones(1,3);
MPI_Reduce(A(1,:),R,'MIN',0,NEWORLD);     

if R<>min(A,'r') then pause;end 

//MPI_Finalize();

