// macros. 

add_lib('macros',compile=%t);



