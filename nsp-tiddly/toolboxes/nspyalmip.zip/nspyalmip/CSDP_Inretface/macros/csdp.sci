//
// [x,y,z,info]=csdp(At,b,c,K,pars)
//
// Uses CSDP to solve a problem in SeDuMi format.
//
// Input:
//        At, b, c, K      SDP problem in SeDuMi format.
//        pars             CSDP parameters (optional parameter.)
//
// Output:
//
//        x, y, z          solution.
//        info             CSDP return code.
//                         info=100 indicates a failure in the MATLAB
//                         interface, such as inability to write to 
//                         a temporary file.
//
// Note: This interface makes use of temporary files with names given by the
// tempname function.  This will fail if there is no working temporary
// directory or there isn't enough space available in this directory.  
//
// Note: This code writes its own param.csdp file in the current working
// directory.  Any param.csdp file already in the directory will be deleted.
//
// Note: It is assumed that csdp is the search path made available through
// the "system" or "dos" command.  Typically, having the csdp executable in
// current working directory will work, although some paranoid system
// administrators keep . out of the path.  In that case, you'll need to
// install csdp in one of the directories that is in the search path.
// A simple test is to run csdp from a command line prompt.  
//
function [x,y,z,info]=csdp(At,b,c,K,pars)
//
// First, put a dummy pars in place if no argument was given.  Also
// set pars.printlevel if not given.
//

if (nargin<5) then
  pars.printlevel=1;
else
  if (isfield(pars,'printlevel'))
    pars.printlevel=pars.printlevel;
  else
    pars.printlevel=1;
  end
end
//
// Write out the param.csdp file.
//
err = 0; //FIXME!!!
fid=fopen('param.csdp',mode='w');
if (err ~= 0) then
  if (pars.printlevel ~= 0) 
    fprintf('Could not open param.csdp\n');
  end
  info=100;
  return 
end


//
// Now, go through the parameters.
//

if (isfield(pars,'axtol')) then
  fprintf(fid,'axtol= %e\n',pars.axtol);
else
  fprintf(fid,'axtol=%e\n',1.0e-8);
end


if (isfield(pars,'atytol')) then
  fprintf(fid,'atytol= %e\n',pars.atytol);
else
  fprintf(fid,'atytol=%e\n',1.0e-8);
end

if (isfield(pars,'objtol')) then
  fprintf(fid,'objtol= %e\n',pars.objtol);
else
  fprintf(fid,'objtol=%e\n',1.0e-8);
end

if (isfield(pars,'pinftol')) then
  fprintf(fid,'pinftol= %e\n',pars.pinftol);
else
  fprintf(fid,'pinftol=%e\n',1.0e8);
end

if (isfield(pars,'dinftol')) then
  fprintf(fid,'dinftol= %e\n',pars.dinftol);
else
  fprintf(fid,'dinftol=%e\n',1.0e8);
end

if (isfield(pars,'maxiter')) then
  fprintf(fid,'maxiter= %d\n',pars.maxiter);
else
  fprintf(fid,'maxiter=%d\n',100);
end
if (isfield(pars,'minstepfrac')) then
  fprintf(fid,'minstepfrac= %e\n',pars.minstepfrac);
else
  fprintf(fid,'minstepfrac=%e\n',0.90);
end

if (isfield(pars,'maxstepfrac')) then
  fprintf(fid,'maxstepfrac= %e\n',pars.maxstepfrac);
else
  fprintf(fid,'maxstepfrac=%e\n',0.97);
end

if (isfield(pars,'minstepp')) then
  fprintf(fid,'minstepp= %e\n',pars.minstepp);
else
  fprintf(fid,'minstepp=%e\n',1.0e-8);
end

if (isfield(pars,'minstepd')) then
  fprintf(fid,'minstepd= %e\n',pars.minstepd);
else
  fprintf(fid,'minstepd=%e\n',1.0e-8);
end

if (isfield(pars,'usexzgap')) then
  fprintf(fid,'usexzgap= %d\n',pars.usexzgap);
else
  fprintf(fid,'usexzgap=%d\n',1);
end

if (isfield(pars,'tweakgap')) then
  fprintf(fid,'tweakgap= %d\n',pars.tweakgap);
else
  fprintf(fid,'tweakgap=%d\n',0);
end

if (isfield(pars,'affine')) then
  fprintf(fid,'affine= %d\n',pars.affine);
else
  fprintf(fid,'affine=%d\n',0);
end

if (isfield(pars,'printlevel')) then
  fprintf(fid,'printlevel= %d\n',pars.printlevel);
else
  fprintf(fid,'printlevel=%d\n',1);
end

if (isfield(pars,'perturbobj')) then
  fprintf(fid,'printlevel= %d\n',pars.perturbobj);
else
  fprintf(fid,'printlevel=%d\n',1);
end

if (isfield(pars,'fastmode')) then
  fprintf(fid,'printlevel= %d\n',pars.fastmode);
else
  fprintf(fid,'printlevel=%d\n',0);
end


//
// close the parameter file.
//
fid.close[];
//
// Write the problem out.
//


chdir(getcwd());
fname='tp592620';
file("delete",strcat([fname, '.dat-s']));
file("delete",strcat([fname, '.sol']));

ret=writesdpa(strcat([fname, '.dat-s']),At,b,c,K,pars);
if (ret==1) then
  info=100;
  x=[];
  y=[];
  z=[];
  return
end
//
// Solve the problem.
//

if (%win32) then
   rep=system(strcat(['cmd /C',' ','csdp ', fname, '.dat-s', ' ', fname '.sol']));
else
  if (pars.printlevel ~=0) then
    rep=system(strcat(['time ','csdp ', fname, '.dat-s', ' ' ,fname '.sol']));
  else
    rep=system(strcat(['csdp ', fname, '.dat-s', ' ', fname, '.sol']));
  end
end

if pars.printlevel then
  print(rep);
end
//
// Read back the solution.
//

[x,y,z]=readsol(strcat([fname, '.sol']),K,length(b));
//
// Delete the temporary files, including param.csdp if we wrote one!
//
file("delete",strcat([fname, '.dat-s']));
file("delete",strcat([fname, '.sol']));
file("delete",'param.csdp');
info=rep;
endfunction
