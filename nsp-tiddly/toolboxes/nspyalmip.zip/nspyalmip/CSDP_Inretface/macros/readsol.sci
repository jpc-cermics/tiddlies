//
// [x,y,z]=readsol(fname,K,m)
//
//   fname     File name to read solution from.
//   K         structure of the matrices.
//   m         size of y vector.
// 
// Modified 7/15/04, for greater MATLAB acceleration.
//
function [x,y,z]=readsol(fname,K,m)
//
//  First, eliminate special cases that we don't handle.
//
//
//  Check for any quadratic cone constraints.
//
if isfield(K,'q') then
  if ((~isempty(K.q)) & (K.q ~= 0)) then
    fprintf('quadratic cone constraints are not supported.\n');
    return
  end
end 
//
//  Check for any rotated cone constraints.
//
if isfield(K,'r') then
  if ((~isempty(K.r)) & (K.r ~= 0)) then
    fprintf('rotated cone constraints are not supported.\n');
    x=[];
    y=[];
    z=[];
    return
  end
end 
//
// Check for any free variables.
//
if isfield(K,'f') then
  if ((~isempty(K.f)) & (K.f ~= 0)) then
    fprintf('Free variables are not supported.\n');
    x=[];
    y=[];
    z=[];
    return
  end
end 
//
// Figure out the structure of the LP and SDP blocks.
//
if (isfield(K,'l')) then
  if (K.l > 0) then
    nlin=K.l;
  else
    K.l=0;
    nlin=0;
  end
else
  K.l=0;
  nlin=0;
end
//
// Patched on 10/23/03 to handle all kinds of stupid ways of indicating
// no SDP block.
//
if (isfield(K,'s')) then
  if (length(K.s) > 1) then
    nsdpblocks=length(K.s);
  else
    if (length(K.s)==1) then
      if (K.s==0) then
        nsdpblocks=0;
        K.s=[];
      else
        nsdpblocks=1;
      end
    else
      nsdpblocks=0;
      K.s=[]; 
    end
  end
else
  K.s=[];
  nsdpblocks=0;
end

//
// First, where everything is in the vector.
//
// vecsdpbase(i)=point in vector at which SDP block i starts.
// v(1..nlin)         LP variables.
//
base=nlin+1;
for i=1:length(K.s)
  vecsdpbase(i)=base;
  base=base+(K.s(i))^2;
end

//
// Second, where everything is in the matrix.
//
// matsdpbase(i)=   index of upper left corner of SDP block i.
// matlpbase        index of start of LP block.
//
base=1;
for i=1:length(K.s)
  matsdpbase(i)=base;
  base=base+K.s(i);
end 
matlpbase=base;
//
// Setup an array containing blocksizes. blocksize(i) is used as a faster
// synonym for K.s(i) in what follows.  This is because MATLAB doesn't
// accelerate statements involving fields.  
//
if (nsdpblocks >= 1) then
  blocksizes=zeros(nsdpblocks,1);
  for i=1:nsdpblocks
    blocksizes(i)=K.s(i);
  end
end
//
//  Open up the file.
//
err = 0; //FIXME!!!
fid=fopen(fname,mode='r');
if (err ~= 0) then
  printf('file does not exist!\n');
  x=[];
  y=[];
  z=[];
  return
end
//
// Read y.
//
y=fscanf(m,fid,'%le');
//
// Read the remaining entries.
//
[v_1,v_2,v_3,v_4,v_5]=fscanf(-1,fid,'%d %d %d %d %le');
A=[v_1,v_2,v_3,v_4,v_5];
colnum=size(A);
A=A';
count = colnum(1)*colnum(2);
count=count/5;


//
// Allocate storage for x and z.
//
if ((length(K.s) > 1) | (length(K.s)==1 & (K.s>0))) then
  veclength=vecsdpbase(length(K.s))+K.s(nsdpblocks)^2-1;
else
  veclength=nlin;
end
//
// Allocate space for x and z.  We could use sparse vectors here, but 
// the dense vector is vastly faster.
//
x=zeros(veclength,1);
z=zeros(veclength,1);
//
// now, loop through the entries and put them into x and z.
//
for i=1:count
  if (A(1,i)==1) then
//
// A z entry.
//    
    blk=A(2,i);
    indexi=A(3,i);
    indexj=A(4,i);
    ent=A(5,i);

    if (blk==nsdpblocks+1) then
      z(indexi)=ent;
    else
//
// In one of the SDP blocks.
//      
//      [blk, indexi, indexj, K.s(blk)]

      z(vecsdpbase(blk)+indexi+(indexj-1)*blocksizes(blk)-1)=ent;
      z(vecsdpbase(blk)+indexj+(indexi-1)*blocksizes(blk)-1)=ent;
    end
  else
//
// An x entry.
//    
    blk=A(2,i);
    indexi=A(3,i);
    indexj=A(4,i);
    ent=A(5,i);

    if (blk==nsdpblocks+1) then
      x(indexi)=ent;
    else
//
// In one of the SDP blocks.
//      
      x(vecsdpbase(blk)+indexi+(indexj-1)*blocksizes(blk)-1)=ent;
      x(vecsdpbase(blk)+indexj+(indexi-1)*blocksizes(blk)-1)=ent;
    end
  end
end
//
// Correction for the difference between CSDP and SeDuMi primal/dual pair.
//
y=-y;
//
// close the file.  
//
fid.close[];
endfunction
