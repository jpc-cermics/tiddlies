clear ploty
clear beta_vec
A = [0,1,0 ; -4.2,-1.5,4.2	; 0.77,0,-0.77]
 
B = [0;-7.4;0]

C = [1,0,0; 0,1,0]

[U,S,V] = svd(C)

stop_crit = 1e-4;

Q = eye(3,3)
X = eye(3,3)
R = eye(1,1)

spec(A)

p=8;
g = [1 0.5 1 1 1 1 1 1]; // noise intensity
A_i=list();
A_i(1) = [0,1,0 ; -7.1,-1.9,7.1	; 1,0,-1		];
A_i(2) = [0,1,0 ; -78,-4.1,78		; 2.8,0,-2.8	];
A_i(3) = [0,1,0 ; -4,-1.4,4		; 0.62,0,-0.62	];
A_i(4) = [0,1,0 ; -116,-2.36,116	; 2.3,0,-2.3	];
A_i(5) = [0,1,0 ; -7.9,-1.1,7.9	; 0.56,0,-0.56	];
A_i(6) = [0,1,0 ; -55,-0.66,55	; 0.84,0,-0.84	];
A_i(7) = [0,1,0 ; -14.5,-0.43,14.5; 0.33,0,-0.33	];
A_i(8) = [0,1,0 ; -18,-0.31,18	; 0.34,0,-0.34	];

B_i=list();
B_i(1) = [0;-12.7;0];
B_i(2) = [0;-57;0];
B_i(3) = [0;-7.5;0];
B_i(4) = [0;-42;0];
B_i(5) = [0;-13.8;0];
B_i(6) = [0;-22.5;0];
B_i(7) = [0;-8.6;0];
B_i(8) = [0;-10;0];

//for i=1:p
//   A_i(i) = eye(7);
//   B_i(i) = eye(7,2);
//end

P = sdpvar(3);
Y = sdpvar(3);

sum1 = g(1)*A_i(1)'*P*A_i(1);
sum2 = g(1)*B_i(1)'*P*B_i(1);
sum3 = g(1)*B_i(1)'*P*A_i(1);
sum4 = g(1)*A_i(1)'*P*B_i(1);

for i=2:p
    sum1 = sum1 + g(i)*A_i(i)'*P*A_i(i);
    sum2 = sum2 + g(i)*B_i(i)'*P*B_i(i);
    sum3 = sum3 + g(i)*B_i(i)'*P*A_i(i);
    sum4 = sum4 + g(i)*A_i(i)'*P*B_i(i);
end

F = set([A'*P*A+sum1+Q sum4+A'*P*B;B'*P*A+sum3 B'*P*B+sum2+R]>=0)+set(P>0);
solvesdp(F,-trace(P));

K0 = inv(B'*double(P)*B+double(sum2)+R)*(B'*double(P)*A+double(sum3))
//K0 = 100*eye(2,7)

result = K0*V;
K = K0;

iteration = 0;

while norm(result(:,2),'fro') >= stop_crit

sum_1 = g(1)*(A_i(1)-B_i(1)*K)*Y*(A_i(1)-B_i(1)*K)';
sum_2 = g(1)*(A_i(1)-B_i(1)*K)'*P*(A_i(1)-B_i(1)*K);

for i=2:p
    sum_1 = sum_1 + g(i)*(A_i(i)-B_i(i)*K)*Y*(A_i(i)-B_i(i)*K)';
    sum_2 = sum_2 + g(i)*(A_i(i)-B_i(i)*K)'*P*(A_i(i)-B_i(i)*K);
end

F=set(Y>0)+set((A-B*K)*Y*(A-B*K)'+X+sum_1 == 0);
solvesdp(F);

RES=set((A-B*K)'*P*(A-B*K)+sum_2+K'*R*K+Q==0)+set(P>0);
solvesdp(RES);

V2 = V(:,2);
tmp=size(V2*inv(V2'*inv( double(Y) )*V2)*V2'*inv(double(Y)));
I = eye(tmp(1),tmp(2));
dK = inv(R+B'*double(P)*B+double(sum2))*B'*double(P)*A*( I-V2*inv(V2'*inv( double(Y) )*V2)*V2'*inv(double(Y)) ) - K;

// calculate beta1
beta1_sum1 = g(1)*(-B_i(1)*dK)*double(Y)*(-B_i(1)*dK)';
beta1_sum2 = g(1)*(A_i(1)-B_i(1)*dK)*double(Y)*(-B_i(1)*dK)';

for i=2:p
 beta1_sum1 = beta1_sum1+g(i)*(-B_i(i)*dK)*double(Y)*(-B_i(i)*dK)';
 beta1_sum2 = beta1_sum2+g(i)*(A_i(i)-B_i(i)*dK)*double(Y)*(-B_i(i)*dK)';
end


a = norm(X^(-1/2)*((-B*dK)*double(Y)*(-B*dK)'+beta1_sum1)*X^(-1/2),'fro');
b = norm(X^(-1/2)*((A-B*K)*double(Y)*(-B*dK)'+beta1_sum2)*X^(-1/2),'fro');

roots_beta1 =  roots([a 2*b -1]);
tmp = roots_beta1(1);
// finding positive root
disp(tmp)
if tmp>0 then
    positive_root1 = roots_beta1(1); 
else
    positive_root1 = roots_beta1(2); 
end

// calculate beta2
beta2_sum1 = g(1)*(-B_i(1)*dK)'*double(P)*(-B_i(1)*dK);
beta2_sum2 = g(1)*(A_i(1)-B_i(1)*dK)'*double(P)*(-B_i(1)*dK);

for i=2:p
 beta1_sum1 = beta1_sum1+g(i)*(-B_i(i)*dK)'*double(P)*(-B_i(i)*dK);
 beta1_sum2 = beta1_sum2+g(i)*(A_i(i)-B_i(i)*dK)'*double(P)*(-B_i(i)*dK);
end


a = norm((K'*R*K+Q)^(-1/2)*((-B*dK)'*double(P)*(-B*dK)+beta1_sum1)*(K'*R*K+Q)^(-1/2),'fro');
b = norm((K'*R*K+Q)^(-1/2)*((A-B*K)'*double(P)*(-B*dK)+beta1_sum2)*(K'*R*K+Q)^(-1/2),'fro');

roots_beta2 = roots([a 2*b -1]);

// finding positive root
if (roots_beta2(1)>0)
    positive_root2 = roots_beta2(1); 
else
    positive_root2 = roots_beta2(2); 
end

min([positive_root1/2 positive_root2/2 1.9])
K = K + min([positive_root1 positive_root2 1.9])*dK;

result = K*V;
iteration = iteration + 1;

ploty(iteration) = norm(result(:,2),'fro');
beta_vec(iteration) = min([positive_root1 positive_root2 1.9]);
norm(result(:,2),'fro')
end

norm(result(:,2))

plot(ploty)
title('Norm');
figure

plot(beta_vec)
title('Beta');
