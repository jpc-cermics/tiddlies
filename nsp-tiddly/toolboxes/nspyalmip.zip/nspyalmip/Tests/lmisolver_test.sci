clc
format('v',10)
//Find diagonal matrix X (i.e. X=diag(diag(X), p=1) such that
//A1'*X+X*A1+Q1 < 0, A2'*X+X*A2+Q2 < 0 (q=2) and trace(X) is maximized 
n=6;
A1 =[ -1.2810    0.1793    0.0194    0.9304    0.0920    0.7012;
   -0.4530   -0.5653    0.3310    0.8462    0.6539    0.9103;
    0.1789   -0.1165   -1.4654    0.5269    0.4160    0.7622;
         0         0         0   -1.4465   -0.4923   -0.0825;
         0         0         0    0.0297   -1.1166    0.1868;
         0         0         0    0.1711   -0.4332   -0.9110]
         
disp('lmisolver throught the YALMIP interface');

x1 = sdpvar(n,n);

F=set('A1''*x1+x1*A1 < 0')+set(x1>0);
//F=F+set('A2''*x1+x1*A2+Q2 < 0')+set(x1>0);
solvesdp(F,[],sdpsettings('solver','sdpa'));

X=double(x1)
spec(X)
c = double(-trace(x1));
Z=list(); 
Z(1) = spec( A1'*X+X*A1)
//Z(2) = spec( A2'*X+X*A2)
