clc; 
opts = sdpsettings('solver','csdp','verbose',0,'warning',1);
opts.sedumi.eps = 1e-7;
disp(' ');

A=list();
B=list();
B0=list();
C=list();
D=list();
D0=list();

A(1)=[0.9819 196.3746; -9.0634*(1e-5) 0.9819];
B(1)=[-0.0906;-4.5317*(1e-4)];
B0(1)=(1e-3)*[4.1831; 0.0209];
C(1)=[0.9819 196.3746];
D(1)=-0.0906;
D0(1)=0.7734;

A(2)=[0.9769 195.3837; -1.1541*(1e-4) 0.9769];
B(2)=(1e-3)*[-6.0741; -0.0304];
B0(2)=(1e-4)*[3.5878; 0.0179];
C(2)=[0.9769 195.3837];
D(2)=-6.0741*(1e-3);
D0(2)=0.9848;

A(3)=[0.9363 187.2554; -3.1861*(1e-4) 0.9363];
B(3)=[-0.3186; -1.5931*(1e-3)];
B0(3)=[0.0542; 2.7106*(1e-4)];
C(3)=[0.9363 187.2554];
D(3)=-0.3186;
D0(3)=0.2035;

A(4)=[0.7403 148.0638; -1.2984*(1e-3) 0.7403];
B(4)=[-0.0683; -3.4169*(1e-4)];
B0(4)=[0.0599; 2.9963*(1e-4)];
C(4)=[0.7403 148.0638];
D(4)=-0.0683;
D0(4)=0.8292;

for i=1:4
 gama(i)=sqrt(4);
end

M=eye(2,2);
R=1;
Q=1;

W1=sdpvar(2,2);
W2=sdpvar(1,1);

sys11=0;
sys12=0;
sys21=0;
sys22=0;

for i=1:4
 sys11=sys11 + gama(i)^2*(A(i)'*W1*A(i)+C(i)'*W2*C(i));
 sys12=sys12 + gama(i)^2*(A(i)'*W1*B(i)+C(i)'*W2*D(i));
 sys21=sys21 + gama(i)^2*(B(i)'*W1*A(i)+D(i)'*W2*C(i));
 sys22=sys22 + gama(i)^2*(B(i)'*W1*B(i)+D(i)'*W2*D(i));
end

sys11=sys11-W1+M;
sys22=sys22+R;


sys211=0;
sys212=0;
sys221=0;
sys222=0;

for i=1:4
 sys211=sys211 + gama(i)^2*(B0(i)'*W1*B0(i)+D0(i)'*W2*D0(i));
 sys212=sys212 + gama(i)^2*(B0(i)'*W1*B(i)+D0(i)'*W2*D(i));
 sys221=sys221 + gama(i)^2*(B(i)'*W1*B0(i)+D(i)'*W2*D0(i));
 sys222=sys222 + gama(i)^2*(B(i)'*W1*B(i)+D(i)'*W2*D(i));
end

sys211=sys211-W2+Q;
sys222=sys222+R;

ct1=set('W1>0')+set('W2>0');
ct1=ct1+set('[sys11 sys12; sys21 sys22]>=0');
ct1=ct1+set('[sys211 sys212; sys221 sys222]>=0')

solvesdp(ct1,-trace(W1+W2),opts)

Double(W1)
Double(W2)

spec(double([sys11 sys12; sys21 sys22]))
spec(double([sys211 sys212; sys221 sys222]))
