clc;
disp(' Quadprog with scilab interface');

//Find x in R^6 such that:
//C1*x = b1 (3 equality constraints i.e me=3)
C1= [1,-1,1,0,3,1;
    -1,0,-3,-4,5,6;
     2,5,3,0,1,0];
b1=[1;2;3];
//C2*x <= b2 (2 inequality constraints)
C2=[0,1,0,1,2,-1;
    -1,0,2,1,1,0];
b2=[-1;2.5];
//with  x between ci and cs:
ci=[-1000;-10000;0;-1000;-1000;-1000];cs=[10000;100;1.5;100;100;1000];
//and minimize 0.5*x'*Q*x + p'*x with
p=[1;2;3;4;5;6]; Q=eye(6,6);
//No initial point is given;
C=[C1;C2] ; //
b=[b1;b2] ;  //
me=3;
[x,lagr,f]=quapro(Q,p,C,b,ci,cs,me)
//Only linear constraints (1 to 4) are active (lagr(1:6)=0):
[x,lagr,f]=quapro(Q,p,C,b,[],[],me)   //Same result as above



disp('YALMIP scilab interface (with quadprog solver)');

x1=sdpvar(6,1);
F1=set('C1*x1==b1');
F1=F1+set('C2*x1<=b2')+set('ci<=x1<=cs');

solvesdp(F1,0.5*x1'*Q*x1+p'*x1,sdpsettings('solver','quadprog'))

disp('');
f = double(0.5*x1'*Q*x1+p'*x1)
x = double(x1)
clear x1
clear F1
