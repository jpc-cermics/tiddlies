//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Iterative algorithm YALMIP/SeDuMi version

clc;
opts = sdpsettings('solver','csdp','verbose',0,'warning',1);
//opts.sedumi.eps = 1e-10;
disp(' ');

////////////////////////////////////////////////////////////// CONTROL SYSTEM MODEL  ////////////////////////////////////////////////////////////// 

n = 3;          // problem size
nu = 9;         // number of switching modes
ni = 1;         // number of input signals
no = 2;         // number of output signals
dt = 0.02;      // discretization period
//P A R A M E T E R S
mu=10;
spect=[-6 -10 -10];
//spec = [-5 -50+i -50-i];
//spec= [-5 -5+5i -5-5i];
A0=list();
// nominal matrices A
A0(1) = [0,1,0 ; -4.2,-1.5,4.2	; 0.77,0,-0.77	];
A0(2) = [0,1,0 ; -7.1,-1.9,7.1	; 1,0,-1		];
A0(3) = [0,1,0 ; -78,-4.1,78		; 2.8,0,-2.8	];
A0(4) = [0,1,0 ; -4,-1.4,4		; 0.62,0,-0.62	];
A0(5) = [0,1,0 ; -116,-2.36,116	; 2.3,0,-2.3	];
A0(6) = [0,1,0 ; -7.9,-1.1,7.9	; 0.56,0,-0.56	];
A0(7) = [0,1,0 ; -55,-0.66,55	; 0.84,0,-0.84	];
A0(8) = [0,1,0 ; -14.5,-0.43,14.5; 0.33,0,-0.33	];
A0(9) = [0,1,0 ; -18,-0.31,18	; 0.34,0,-0.34	];

B0=list();
// nominal matrices B
B0(1) = [0;-7.4;0];
B0(2) = [0;-12.7;0];
B0(3) = [0;-57;0];
B0(4) = [0;-7.5;0];
B0(5) = [0;-42;0];
B0(6) = [0;-13.8;0];
B0(7) = [0;-22.5;0];
B0(8) = [0;-8.6;0];
B0(9) = [0;-10;0];


// matrix C
C = [1,0,0; 0,1,0];
//singular value decomposition
[U,S,V] = svd(C);
  V2 = V(:,no+1:n);



EI=list();
EK=list();
// projection matrices EI and EK
for i = 1:nu,
	EI(i) = pinv(C) * C;	
	EK(i) = eye(n,n) - EI(i);	
end;

// weight matrices Qi and Ri
Q=list();
R=list();
for i = 1:nu,
    Q(i) = weight(A0(i),B0(i),spect);
    R(i) = 1;
end;
A=list();
B=list();
// matrices  A, B, C for discrete model
for i = 1:nu,
    [A(i) B(i) Q(i) R(i)] = cont2disc(A0(i),B0(i),Q(i),R(i),dt);
end;

//-----------------------------------------------------------------------------------
////////////////////////////////////////////////// OUTPUT FEEDBACK CONTROL SYNTHESIS //////////////////////////////////////////////// 
//-----------------------------------------------------------------------------------

quiz = set([]);

E=list();
F=list();
EC=list();
SV=list();

H = sdpvar(n,n);
L = sdpvar(ni,n);


for i = 1:nu,
    RR = R(i) + B(i)'*H*B(i);
    G=set(H > 0)+ set(0 < [
        A(i)'*H*A(i) - H + (1+mu)*Q(i), A(i)'*H*B(i);
        B(i)'*H*A(i)              , RR;
    ])+ set(0 <[
        mu*Q(i),    L';
        L,     R(i);
    ])+set((B(i)'*H*A(i) + L)*V2==0);
 minimize = - trace(H); 
// check feasibility
G= solvesdp(G, minimize, opts);
if (G.problem), disp('Infeasible to find Hi'); return; end;
disp('Found feasible solutions Hi > 0');
	HD = double(H);
 E(i)=spec(HD);
        disp(sprintf('\tE%d = %s',i,sprintf('%g ',E(i))));
		LD = double(L);
            SV(i) = (B(i)'*HD*A(i) +LD)*V2;
			F(i) = inv(R(i) + B(i)'*HD*B(i))*(B(i)'*HD*A(i) + LD)*pinv(C);
        EC(i)=abs(spec(A(i)-B(i)*F(i)*C));
        disp(sprintf('\tEC%d = %s',i,sprintf('%g ',EC(i))));
        disp(sprintf('\tSV%d = %s',i,sprintf('%g ',SV(i))));
        disp(sprintf('\tF%d = %s',i,sprintf('%g ',F(i))));
        disp(sprintf('\tL%d = %s',i,sprintf('%g ',LD)));
        disp(sprintf('\tH%d = %s',i,sprintf('%g ',HD))); 
        //figure
        //dstep(A(i)-B(i)*F(i)*C, B(i)*F(i)*C,[1 0 0],0,1);
        //grid on;
   	//grid minor;
end;



//-----------------------------------------------------------------------------------
//////////////////////////////////////////////////// OUTPUT DATA ////////////////////////////////////////////////////// 
//-----------------------------------------------------------------------------------




	

