clc; 
opts = sdpsettings('solver','csdp','verbose',1,'warning',1);
opts.sedumi.eps = 1e-9;
disp(' ');

nu=9;
 n=3;
 r=2;
 m=1;
 A=list();
A(1) = [0,1,0 ; -4.2,-1.5,4.2	; 0.77,0,-0.77	];
A(2) = [0,1,0 ; -7.1,-1.9,7.1	; 1,0,-1		];
A(3) = [0,1,0 ; -78,-4.1,78		; 2.8,0,-2.8	];
A(4) = [0,1,0 ; -4,-1.4,4		; 0.62,0,-0.62	];
A(5) = [0,1,0 ; -116,-2.36,116	; 2.3,0,-2.3	];
A(6) = [0,1,0 ; -7.9,-1.1,7.9	; 0.56,0,-0.56	];
A(7) = [0,1,0 ; -55,-0.66,55	; 0.84,0,-0.84	];
A(8) = [0,1,0 ; -14.5,-0.43,14.5; 0.33,0,-0.33	];
A(9) = [0,1,0 ; -18,-0.31,18	; 0.34,0,-0.34	];

B=list();
B(1) = [0;-7.4;0];
B(2) = [0;-12.7;0];
B(3) = [0;-57;0];
B(4) = [0;-7.5;0];
B(5) = [0;-42;0];
B(6) = [0;-13.8;0];
B(7) = [0;-22.5;0];
B(8) = [0;-8.6;0];
B(9) = [0;-10;0];

C = [1,0,0; 0,1,0];
[U,S,V] = svd(C);
 
  V2 = V(:,r+1:n);
mu = 0.5;
// Q and R
//POLY = [-15 -15 -15];
POLY = [-15 -10+5*%i -10-5*%i];
//POLY = [-5 -5+5i -5-5i];
P = sdpvar(3);
L = sdpvar(1,3);
//G=sdpvar(1,2);
G=[-200, -20];
Q=list();
R=list();
for i=1:nu,
    Q(i) = weight(A(1),B(1),POLY);
    R(i) = 100;

S=set([A(i)'*P+P*A(i)+mu*Q(i)+Q(i),P*B(i);B(i)'*P,R(i)]>0)+set(P>0)+set((B(i)'*P+L)*V2==0)+set([mu*Q(i),L';L,R(i)]>0)+set(B(i)'*P-G*C==0);
minimize=-trace(P);
solvesdp(S,minimize,opts);
K=inv(R(i))*(B(i)'*double(P)+double(L))
F=K*pinv(C)
L1=double(L)
//G1=double(G)
AC=list();
BC=list();
SV=(B(i)'*double(P)+double(L))*V2
AC(i)=A(i)-B(i)*F*C;
eigAC=spec(AC(i))
BC(i)=B(i)*F*C;
end
//for i = 1:nu,
//   	    step(AC(i), BC(i),[1 0 0],0,1);
//  	    hold on;
//   	end;
//   	grid on;
//   	grid minor;
//end
