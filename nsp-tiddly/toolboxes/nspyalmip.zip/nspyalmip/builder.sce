libname='sedumilib'

// generate Path.incl file 
// -----------------------

ilib_path_incl()

// macros 
//--------

add_lib('macros',compile=%t);

// compile shared library in src.
// ------------------------------

if c_link('libyalmip') then
  printf('please do not rebuild a shared library while it is linked\n')
  printf('use ulink to unlink first\n');
else 
  printf('building shared library\n')
  chdir('c-code');
  // we need to chdir to execute a builder.
  ok=exec('builder.sce',errcatch=%t);
  if ~ok then 
    x_message('Compilation of source file failed\n");
  end
  chdir("../");
end 







