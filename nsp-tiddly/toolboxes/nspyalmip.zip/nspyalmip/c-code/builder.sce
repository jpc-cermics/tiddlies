// This is the builder.sce 
// must be run from this directory 

// [1] generate Path.incl 

ilib_path_incl()

// [3] the part devoted to shared lib generation 

ilib_name  = 'libyalmip' 		// interface library name 

// objects files (but do not give mexfiles here)

files = ['sdpvar.o','lmi.o','constraint.o'];

// other libs needed for linking (must be shared library names)

libs  = [];

// table of (scilab_name,interface-name or mexfile-name, type) 

table = [ 'sdpvar_create','int_sdpvar_create','csci',
	  'lmi_create','int_lmi_create','csci',
	  'constraint_create','int_constraint_create','csci']

cflags="-I./"; // add the local nsp directory 
ldflags="";

// do not modify below 
// ----------------------------------------------
ilib_build(ilib_name,table,files,libs,cflags=cflags,ldflags=ldflags)

