/* -*- Mode: C -*- */

/* This file is generated, please do not edit */
/* Nsp
 * Copyright (C) 1998-2009 Jean-Philippe Chancelier Enpc/Cermics
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public
 * License along with this library; if not, write to the
 * Free Software Foundation, Inc., 59 Temple Place - Suite 330,
 * Boston, MA 02111-1307, USA.
 */





#line 21 "codegen/constraint.override"

#line 30 "constraint.c"

/* ----------- NspConstraint ----------- */


#define  NspConstraint_Private 
#include <nsp/objects.h>
#include <nsp/constraint.h>
#include <nsp/interf.h>

/* 
 * NspConstraint inherits from Object 
 */

int nsp_type_constraint_id=0;
NspTypeConstraint *nsp_type_constraint=NULL;

/*
 * Type object for NspConstraint 
 * all the instance of NspTypeConstraint share the same id. 
 * nsp_type_constraint: is an instance of NspTypeConstraint 
 *    used for objects of NspConstraint type (i.e built with new_constraint) 
 * other instances are used for derived classes 
 */
NspTypeConstraint *new_type_constraint(type_mode mode)
{
  NspTypeConstraint *type= NULL;
  NspTypeObject *top;
  if (  nsp_type_constraint != 0 && mode == T_BASE )
    {
      /* initialization performed and T_BASE requested */
      return nsp_type_constraint;
    }
  if (( type =  malloc(sizeof(NspTypeConstraint))) == NULL) return NULL;
  type->interface = NULL;
  type->surtype = (NspTypeBase *) new_type_object(T_DERIVED);
  if ( type->surtype == NULL) return NULL;
  type->attrs = constraint_attrs;
  type->get_attrs = (attrs_func *) int_get_attribute;
  type->set_attrs = (attrs_func *) int_set_attribute;
  type->methods = constraint_get_methods;
  type->new = (new_func *) new_constraint;


  top = NSP_TYPE_OBJECT(type->surtype);
  while ( top->surtype != NULL ) top= NSP_TYPE_OBJECT(top->surtype);

  /* object methods redefined for constraint */ 

  top->pr = (print_func *) nsp_constraint_print;
  top->dealloc = (dealloc_func *) nsp_constraint_destroy;
  top->copy  =  (copy_func *) nsp_constraint_copy;
  top->size  = (size_func *) nsp_constraint_size;
  top->s_type =  (s_type_func *) nsp_constraint_type_as_string;
  top->sh_type = (sh_type_func *) nsp_constraint_type_short_string;
  top->info = (info_func *) nsp_constraint_info;
  /* top->is_true = (is_true_func  *) nsp_constraint_is_true; */
  /* top->loop =(loop_func *) nsp_constraint_loop;*/
  top->path_extract = (path_func *)  object_path_extract;
  top->get_from_obj = (get_from_obj_func *) nsp_constraint_object;
  top->eq  = (eq_func *) nsp_constraint_eq;
  top->neq  = (eq_func *) nsp_constraint_neq;
  top->save  = (save_func *) nsp_constraint_xdr_save;
  top->load  = (load_func *) nsp_constraint_xdr_load;
  top->create = (create_func*) int_constraint_create;
  top->latex = (print_func *) nsp_constraint_latex;
  top->full_copy = (copy_func *) nsp_constraint_full_copy;

  /* specific methods for constraint */

  type->init = (init_func *) init_constraint;

  /* 
   * NspConstraint interfaces can be added here 
   * type->interface = (NspTypeBase *) new_type_b();
   * type->interface->interface = (NspTypeBase *) new_type_C()
   * ....
   */
  if ( nsp_type_constraint_id == 0 ) 
    {
      /* 
       * the first time we get here we initialize the type id and
       * an instance of NspTypeConstraint called nsp_type_constraint
       */
      type->id =  nsp_type_constraint_id = nsp_new_type_id();
      nsp_type_constraint = type;
      if ( nsp_register_type(nsp_type_constraint) == FALSE) return NULL;
      return ( mode == T_BASE ) ? type : new_type_constraint(mode);
    }
  else 
    {
      type->id = nsp_type_constraint_id;
      return type;
    }
}

/*
 * initialize NspConstraint instances 
 * locally and by calling initializer on parent class 
 */

static int init_constraint(NspConstraint *Obj,NspTypeConstraint *type)
{
  /* initialize the surtype */ 
  if ( type->surtype->init(&Obj->father,type->surtype) == FAIL) return FAIL;
  Obj->type = type;
  NSP_OBJECT(Obj)->basetype = (NspTypeBase *)type;
  /* specific */
  Obj->List = NULLLIST;
  Obj->Evaluated = NULLLIST;
  Obj->strict = NULLMAT;
  return OK;
}

/*
 * new instance of NspConstraint 
 */

NspConstraint *new_constraint() 
{
  NspConstraint *loc;
  /* type must exists */
  nsp_type_constraint = new_type_constraint(T_BASE);
  if ( (loc = malloc(sizeof(NspConstraint)))== NULLCONSTRAINT) return loc;
  /* initialize object */
  if ( init_constraint(loc,nsp_type_constraint) == FAIL) return NULLCONSTRAINT;
  return loc;
}

/*----------------------------------------------
 * Object method redefined for NspConstraint 
 *-----------------------------------------------*/
/*
 * size 
 */

static int nsp_constraint_size(NspConstraint *Mat, int flag)
{
  return 0;
}

/*
 * type as string 
 */

static char constraint_type_name[]="Constraint";
static char constraint_short_type_name[]="constraint";

static char *nsp_constraint_type_as_string(void)
{
  return(constraint_type_name);
}

static char *nsp_constraint_type_short_string(NspObject *v)
{
  return(constraint_short_type_name);
}

/*
 * A == B 
 */

static int nsp_constraint_eq(NspConstraint *A, NspObject *B)
{
  NspConstraint *loc = (NspConstraint *) B;
  if ( check_cast(B,nsp_type_constraint_id) == FALSE) return FALSE ;
  if ( NSP_OBJECT(A->List)->type->eq(A->List,loc->List) == FALSE ) return FALSE;
  if ( NSP_OBJECT(A->Evaluated)->type->eq(A->Evaluated,loc->Evaluated) == FALSE ) return FALSE;
  if ( NSP_OBJECT(A->strict)->type->eq(A->strict,loc->strict) == FALSE ) return FALSE;
  return TRUE;
}

/*
 * A != B 
 */

static int nsp_constraint_neq(NspConstraint *A, NspObject *B)
{
  return ( nsp_constraint_eq(A,B) == TRUE ) ? FALSE : TRUE;
}

/*
 * save 
 */

int nsp_constraint_xdr_save(XDR *xdrs, NspConstraint *M)
{
  /* if (nsp_xdr_save_id(xdrs,NSP_OBJECT(M)) == FAIL) return FAIL;*/
  /* if (nsp_xdr_save_i(xdrs,M->type->id) == FAIL) return FAIL; */ 
  if (nsp_xdr_save_i(xdrs,nsp_dynamic_id) == FAIL) return FAIL;
  if (nsp_xdr_save_string(xdrs,type_get_name(nsp_type_constraint)) == FAIL) return FAIL;
  if (nsp_xdr_save_string(xdrs, NSP_OBJECT(M)->name) == FAIL) return FAIL;
  if (nsp_object_xdr_save(xdrs,NSP_OBJECT(M->List)) == FAIL) return FAIL;
  if (nsp_object_xdr_save(xdrs,NSP_OBJECT(M->Evaluated)) == FAIL) return FAIL;
  if (nsp_object_xdr_save(xdrs,NSP_OBJECT(M->strict)) == FAIL) return FAIL;
  return OK;
}

/*
 * load 
 */

NspConstraint  *nsp_constraint_xdr_load_partial(XDR *xdrs, NspConstraint *M)
{
  if ((M->List =(NspList *) nsp_object_xdr_load(xdrs))== NULLLIST) return NULL;
  if ((M->Evaluated =(NspList *) nsp_object_xdr_load(xdrs))== NULLLIST) return NULL;
  if ((M->strict =(NspMatrix *) nsp_object_xdr_load(xdrs))== NULLMAT) return NULL;
 return M;
}

static NspConstraint  *nsp_constraint_xdr_load(XDR *xdrs)
{
  NspConstraint *H = NULL;
  char name[NAME_MAXL];
  if (nsp_xdr_load_string(xdrs,name,NAME_MAXL) == FAIL) return NULLCONSTRAINT;
  if ((H  = nsp_constraint_create_void(name,(NspTypeBase *) nsp_type_constraint))== NULLCONSTRAINT) return H;
  if ( nsp_constraint_create_partial(H) == FAIL) return NULLCONSTRAINT;
  if ((H  = nsp_constraint_xdr_load_partial(xdrs,H))== NULLCONSTRAINT) return H;
  if ( nsp_constraint_check_values(H) == FAIL) return NULLCONSTRAINT;
#line 37 "codegen/constraint.override"
  /* verbatim in create/load/full_copy interface use NULL for returned value */
#line 251 "constraint.c"
  return H;
}

/*
 * delete 
 */

void nsp_constraint_destroy_partial(NspConstraint *H)
{
#line 40 "codegen/constraint.override"
  /* verbatim in destroy */
#line 263 "constraint.c"
  if ( H->List != NULL ) 
    nsp_list_destroy(H->List);
  if ( H->Evaluated != NULL ) 
    nsp_list_destroy(H->Evaluated);
  if ( H->strict != NULL ) 
    nsp_matrix_destroy(H->strict);
}

void nsp_constraint_destroy(NspConstraint *H)
{
  nsp_object_destroy_name(NSP_OBJECT(H));
  nsp_constraint_destroy_partial(H);
  FREE(H);
}

/*
 * info 
 */

int nsp_constraint_info(NspConstraint *M,int indent,const char *name,int rec_level)
{
  const char *pname;
  if ( M == NULLCONSTRAINT) 
    {
      Sciprintf("Null Pointer NspConstraint \n");
      return TRUE;
    }
  pname = (name != NULL) ? name : NSP_OBJECT(M)->name;
  Sciprintf1(indent,"%s\t=\t\t%s\n", (pname==NULL) ? "" : pname,
             nsp_constraint_type_short_string(NSP_OBJECT(M)));
  return TRUE;
}

/*
 * print 
 */

int nsp_constraint_print(NspConstraint *M, int indent,const char *name, int rec_level)
{
  const char *pname = (name != NULL) ? name : NSP_OBJECT(M)->name;
  if ( M == NULLCONSTRAINT) 
    {
      Sciprintf("Null Pointer NspConstraint \n");
      return TRUE;
    }
  if (user_pref.pr_as_read_syntax) 
    { 
      Sciprintf1(indent,"%s=TO_BE_DONE();\n",pname);
    } 
  else 
    { 
      if ( user_pref.pr_depth  <= rec_level -1 ) 
        {
          nsp_constraint_info(M,indent,pname,rec_level);
          return TRUE;
        }
      Sciprintf1(indent,"%s\t=\t\t%s \n",pname, nsp_constraint_type_short_string(NSP_OBJECT(M)) );
      Sciprintf1(indent+1,"{\n");
  if ( M->List != NULL)
    { if ( nsp_object_print(NSP_OBJECT(M->List),indent+2,"List",rec_level+1)== FALSE ) return FALSE ;
    }
  if ( M->Evaluated != NULL)
    { if ( nsp_object_print(NSP_OBJECT(M->Evaluated),indent+2,"Evaluated",rec_level+1)== FALSE ) return FALSE ;
    }
  if ( M->strict != NULL)
    { if ( nsp_object_print(NSP_OBJECT(M->strict),indent+2,"strict",rec_level+1)== FALSE ) return FALSE ;
    }
      Sciprintf1(indent+1,"}\n");
    }
  return TRUE;
}

/*
 * latex print 
 */

int nsp_constraint_latex(NspConstraint *M, int indent,const char *name, int rec_level)
{
  const char *pname = (name != NULL) ? name : NSP_OBJECT(M)->name;
  if ( nsp_from_texmacs() == TRUE ) Sciprintf("\002latex:\\[");
  Sciprintf1(indent,"%s\t=\t\t%s\n",pname, nsp_constraint_type_short_string(NSP_OBJECT(M)));
  Sciprintf1(indent+1,"{\n");
  if ( M->List != NULL)
    { if ( nsp_object_latex(NSP_OBJECT(M->List),indent+2,"List",rec_level+1)== FALSE ) return FALSE ;
    }
  if ( M->Evaluated != NULL)
    { if ( nsp_object_latex(NSP_OBJECT(M->Evaluated),indent+2,"Evaluated",rec_level+1)== FALSE ) return FALSE ;
    }
  if ( M->strict != NULL)
    { if ( nsp_object_latex(NSP_OBJECT(M->strict),indent+2,"strict",rec_level+1)== FALSE ) return FALSE ;
    }
  Sciprintf1(indent+1,"}\n");
  if ( nsp_from_texmacs() == TRUE ) Sciprintf("\\]\005");
  return TRUE;
}
/*-----------------------------------------------------
 * a set of functions used when writing interfaces 
 * for NspConstraint objects 
 * Note that some of these functions could become MACROS
 *-----------------------------------------------------*/

NspConstraint   *nsp_constraint_object(NspObject *O)
{
  /* Follow pointer */
  if ( check_cast(O,nsp_type_hobj_id) == TRUE)  O = ((NspHobj *) O)->O ;
  /* Check type */
  if ( check_cast (O,nsp_type_constraint_id) == TRUE ) return ((NspConstraint *) O);
  else 
    Scierror("Error:	Argument should be a %s\n",type_get_name(nsp_type_constraint));
  return NULL;
}

int IsConstraintObj(Stack stack, int i)
{
  return nsp_object_type(NthObj(i),nsp_type_constraint_id);
}

int IsConstraint(NspObject *O)
{
  return nsp_object_type(O,nsp_type_constraint_id);
}

NspConstraint  *GetConstraintCopy(Stack stack, int i)
{
  if (  GetConstraint(stack,i) == NULL ) return NULL;
  return MaybeObjCopy(&NthObj(i));
}

NspConstraint  *GetConstraint(Stack stack, int i)
{
  NspConstraint *M;
  if (( M = nsp_constraint_object(NthObj(i))) == NULLCONSTRAINT)
     ArgMessage(stack,i);
  return M;
}

/*-----------------------------------------------------
 * constructor 
 * if type is non NULL it is a subtype which can be used to 
 * create a NspConstraint instance 
 *-----------------------------------------------------*/

static NspConstraint *nsp_constraint_create_void(char *name,NspTypeBase *type)
{
 NspConstraint *H  = (type == NULL) ? new_constraint() : type->new();
 if ( H ==  NULLCONSTRAINT)
  {
   Sciprintf("No more memory\n");
   return NULLCONSTRAINT;
  }
 if ( nsp_object_set_initial_name(NSP_OBJECT(H),name) == NULLSTRING) return NULLCONSTRAINT;
 NSP_OBJECT(H)->ret_pos = -1 ;
 return H;
}

int nsp_constraint_create_partial(NspConstraint *H)
{
  return OK;
}

int nsp_constraint_check_values(NspConstraint *H)
{
  if ( H->List == NULLLIST) 
    {
     if (( H->List = nsp_list_create("List")) == NULLLIST)
       return FAIL;
    }
  if ( H->Evaluated == NULLLIST) 
    {
     if (( H->Evaluated = nsp_list_create("Evaluated")) == NULLLIST)
       return FAIL;
    }
  if ( H->strict == NULLMAT) 
    {
       if (( H->strict = nsp_matrix_create("strict",'r',0,0)) == NULLMAT)
       return FAIL;

    }
  return OK;
}

NspConstraint *nsp_constraint_create(char *name,NspList* List,NspList* Evaluated,NspMatrix* strict,NspTypeBase *type)
{
  NspConstraint *H  = nsp_constraint_create_void(name,type);
  if ( H ==  NULLCONSTRAINT) return NULLCONSTRAINT;
  H->List= List;
  H->Evaluated= Evaluated;
  H->strict= strict;
  if ( nsp_constraint_check_values(H) == FAIL) return NULLCONSTRAINT;
#line 37 "codegen/constraint.override"
  /* verbatim in create/load/full_copy interface use NULL for returned value */
#line 455 "constraint.c"
  return H;
}


NspConstraint *nsp_constraint_create_default(char *name)
{
 NspConstraint *H  = nsp_constraint_create_void(name,NULL);
 if ( H ==  NULLCONSTRAINT) return NULLCONSTRAINT;
 if ( nsp_constraint_check_values(H) == FAIL) return NULLCONSTRAINT;
 return H;
}

/*
 * copy for gobject derived class  
 */

NspConstraint *nsp_constraint_copy_partial(NspConstraint *H,NspConstraint *self)
{
  if ( self->List == NULL )
    { H->List = NULL;}
  else
    {
      if ((H->List = (NspList *) nsp_object_copy_and_name("List",NSP_OBJECT(self->List))) == NULLLIST) return NULL;
    }
  if ( self->Evaluated == NULL )
    { H->Evaluated = NULL;}
  else
    {
      if ((H->Evaluated = (NspList *) nsp_object_copy_and_name("Evaluated",NSP_OBJECT(self->Evaluated))) == NULLLIST) return NULL;
    }
  if ( self->strict == NULL )
    { H->strict = NULL;}
  else
    {
      if ((H->strict = (NspMatrix *) nsp_object_copy_and_name("strict",NSP_OBJECT(self->strict))) == NULLMAT) return NULL;
    }
  return H;
}

NspConstraint *nsp_constraint_copy(NspConstraint *self)
{
  NspConstraint *H  =nsp_constraint_create_void(NVOID,(NspTypeBase *) nsp_type_constraint);
  if ( H ==  NULLCONSTRAINT) return NULLCONSTRAINT;
  if ( nsp_constraint_copy_partial(H,self)== NULL) return NULLCONSTRAINT;

  return H;
}
/*
 * full copy for gobject derived class
 */

NspConstraint *nsp_constraint_full_copy_partial(NspConstraint *H,NspConstraint *self)
{
  if ( self->List == NULL )
    { H->List = NULL;}
  else
    {
      if ((H->List = (NspList *) nsp_object_full_copy_and_name("List",NSP_OBJECT(self->List))) == NULLLIST) return NULL;
    }
  if ( self->Evaluated == NULL )
    { H->Evaluated = NULL;}
  else
    {
      if ((H->Evaluated = (NspList *) nsp_object_full_copy_and_name("Evaluated",NSP_OBJECT(self->Evaluated))) == NULLLIST) return NULL;
    }
  if ( self->strict == NULL )
    { H->strict = NULL;}
  else
    {
      if ((H->strict = (NspMatrix *) nsp_object_full_copy_and_name("strict",NSP_OBJECT(self->strict))) == NULLMAT) return NULL;
    }
  return H;
}

NspConstraint *nsp_constraint_full_copy(NspConstraint *self)
{
  NspConstraint *H  =nsp_constraint_create_void(NVOID,(NspTypeBase *) nsp_type_constraint);
  if ( H ==  NULLCONSTRAINT) return NULLCONSTRAINT;
  if ( nsp_constraint_full_copy_partial(H,self)== NULL) return NULLCONSTRAINT;

#line 37 "codegen/constraint.override"
  /* verbatim in create/load/full_copy interface use NULL for returned value */
#line 538 "constraint.c"
  return H;
}

/*-------------------------------------------------------------------
 * wrappers for the NspConstraint
 * i.e functions at Nsp level 
 *-------------------------------------------------------------------*/

int int_constraint_create(Stack stack, int rhs, int opt, int lhs)
{
  NspConstraint *H;
  CheckStdRhs(0,0);
  /* want to be sure that type constraint is initialized */
  nsp_type_constraint = new_type_constraint(T_BASE);
  if(( H = nsp_constraint_create_void(NVOID,(NspTypeBase *) nsp_type_constraint)) == NULLCONSTRAINT) return RET_BUG;
  /* then we use optional arguments to fill attributes */
  if ( int_create_with_attributes((NspObject  *) H,stack,rhs,opt,lhs) == RET_BUG)  return RET_BUG;
 if ( nsp_constraint_check_values(H) == FAIL) return RET_BUG;
#line 37 "codegen/constraint.override"
  /* verbatim in create/load/full_copy interface use RET_BUG for returned value */
#line 559 "constraint.c"
  MoveObj(stack,1,(NspObject  *) H);
  return 1;
} 

/*-------------------------------------------
 * Methods
 *-------------------------------------------*/
static NspMethods *constraint_get_methods(void) { return NULL;};
/*-------------------------------------------
 * Attributes
 *-------------------------------------------*/

static NspObject *_wrap_constraint_get_List(void *self,const char *attr)
{
  NspList *ret;

  ret = ((NspConstraint *) self)->List;
  return (NspObject *) ret;
}

static NspObject *_wrap_constraint_get_obj_List(void *self,const char *attr, int *copy)
{
  NspList *ret;

  *copy = FALSE;
  ret = ((NspList*) ((NspConstraint *) self)->List);
  return (NspObject *) ret;
}

static int _wrap_constraint_set_List(void *self,const char *attr, NspObject *O)
{
  NspList *List;

  if ( ! IsList(O) ) return FAIL;
  if ((List = (NspList *) nsp_object_copy_and_name(attr,O)) == NULLLIST) return FAIL;
  if (((NspConstraint *) self)->List != NULL ) 
    nsp_list_destroy(((NspConstraint *) self)->List);
  ((NspConstraint *) self)->List= List;
  return OK;
}

static NspObject *_wrap_constraint_get_Evaluated(void *self,const char *attr)
{
  NspList *ret;

  ret = ((NspConstraint *) self)->Evaluated;
  return (NspObject *) ret;
}

static NspObject *_wrap_constraint_get_obj_Evaluated(void *self,const char *attr, int *copy)
{
  NspList *ret;

  *copy = FALSE;
  ret = ((NspList*) ((NspConstraint *) self)->Evaluated);
  return (NspObject *) ret;
}

static int _wrap_constraint_set_Evaluated(void *self,const char *attr, NspObject *O)
{
  NspList *Evaluated;

  if ( ! IsList(O) ) return FAIL;
  if ((Evaluated = (NspList *) nsp_object_copy_and_name(attr,O)) == NULLLIST) return FAIL;
  if (((NspConstraint *) self)->Evaluated != NULL ) 
    nsp_list_destroy(((NspConstraint *) self)->Evaluated);
  ((NspConstraint *) self)->Evaluated= Evaluated;
  return OK;
}

static NspObject *_wrap_constraint_get_strict(void *self,const char *attr)
{
  NspMatrix *ret;

  ret = ((NspConstraint *) self)->strict;
  return (NspObject *) ret;
}

static NspObject *_wrap_constraint_get_obj_strict(void *self,const char *attr, int *copy)
{
  NspMatrix *ret;

  *copy = FALSE;
  ret = ((NspMatrix*) ((NspConstraint *) self)->strict);
  return (NspObject *) ret;
}

static int _wrap_constraint_set_strict(void *self,const char *attr, NspObject *O)
{
  NspMatrix *strict;

  if ( ! IsMat(O) ) return FAIL;
  if ((strict = (NspMatrix *) nsp_object_copy_and_name(attr,O)) == NULLMAT) return FAIL;
  if (((NspConstraint *) self)->strict != NULL ) 
    nsp_matrix_destroy(((NspConstraint *) self)->strict);
  ((NspConstraint *) self)->strict= strict;
  return OK;
}

static AttrTab constraint_attrs[] = {
  { "List", (attr_get_function *)_wrap_constraint_get_List, (attr_set_function *)_wrap_constraint_set_List,(attr_get_object_function *)_wrap_constraint_get_obj_List, (attr_set_object_function *)int_set_object_failed },
  { "Evaluated", (attr_get_function *)_wrap_constraint_get_Evaluated, (attr_set_function *)_wrap_constraint_set_Evaluated,(attr_get_object_function *)_wrap_constraint_get_obj_Evaluated, (attr_set_object_function *)int_set_object_failed },
  { "strict", (attr_get_function *)_wrap_constraint_get_strict, (attr_set_function *)_wrap_constraint_set_strict,(attr_get_object_function *)_wrap_constraint_get_obj_strict, (attr_set_object_function *)int_set_object_failed },
  { NULL,NULL,NULL,NULL,NULL },
};


/*-------------------------------------------
 * functions 
 *-------------------------------------------*/
/*----------------------------------------------------
 * Interface 
 * i.e a set of function which are accessible at nsp level
 *----------------------------------------------------*/

static OpTab Constraint_func[]={
  { "constraint_create", int_constraint_create},
  { NULL, NULL}
};

/* call ith function in the Constraint interface */

int Constraint_Interf(int i, Stack stack, int rhs, int opt, int lhs)
{
  return (*(Constraint_func[i].fonc))(stack,rhs,opt,lhs);
}

/* used to walk through the interface table 
    (for adding or removing functions) */

void Constraint_Interf_Info(int i, char **fname, function (**f))
{
  *fname = Constraint_func[i].name;
  *f = Constraint_func[i].fonc;
}

#line 696 "constraint.c"
