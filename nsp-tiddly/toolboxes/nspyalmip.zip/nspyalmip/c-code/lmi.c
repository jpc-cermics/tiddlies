/* -*- Mode: C -*- */

/* This file is generated, please do not edit */
/* Nsp
 * Copyright (C) 1998-2009 Jean-Philippe Chancelier Enpc/Cermics
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public
 * License along with this library; if not, write to the
 * Free Software Foundation, Inc., 59 Temple Place - Suite 330,
 * Boston, MA 02111-1307, USA.
 */





#line 22 "codegen/lmi.override"

#line 30 "lmi.c"

/* ----------- NspLmi ----------- */


#define  NspLmi_Private 
#include <nsp/objects.h>
#include <nsp/lmi.h>
#include <nsp/interf.h>

/* 
 * NspLmi inherits from Object 
 */

int nsp_type_lmi_id=0;
NspTypeLmi *nsp_type_lmi=NULL;

/*
 * Type object for NspLmi 
 * all the instance of NspTypeLmi share the same id. 
 * nsp_type_lmi: is an instance of NspTypeLmi 
 *    used for objects of NspLmi type (i.e built with new_lmi) 
 * other instances are used for derived classes 
 */
NspTypeLmi *new_type_lmi(type_mode mode)
{
  NspTypeLmi *type= NULL;
  NspTypeObject *top;
  if (  nsp_type_lmi != 0 && mode == T_BASE )
    {
      /* initialization performed and T_BASE requested */
      return nsp_type_lmi;
    }
  if (( type =  malloc(sizeof(NspTypeLmi))) == NULL) return NULL;
  type->interface = NULL;
  type->surtype = (NspTypeBase *) new_type_object(T_DERIVED);
  if ( type->surtype == NULL) return NULL;
  type->attrs = lmi_attrs;
  type->get_attrs = (attrs_func *) int_get_attribute;
  type->set_attrs = (attrs_func *) int_set_attribute;
  type->methods = lmi_get_methods;
  type->new = (new_func *) new_lmi;


  top = NSP_TYPE_OBJECT(type->surtype);
  while ( top->surtype != NULL ) top= NSP_TYPE_OBJECT(top->surtype);

  /* object methods redefined for lmi */ 

  top->pr = (print_func *) nsp_lmi_print;
  top->dealloc = (dealloc_func *) nsp_lmi_destroy;
  top->copy  =  (copy_func *) nsp_lmi_copy;
  top->size  = (size_func *) nsp_lmi_size;
  top->s_type =  (s_type_func *) nsp_lmi_type_as_string;
  top->sh_type = (sh_type_func *) nsp_lmi_type_short_string;
  top->info = (info_func *) nsp_lmi_info;
  /* top->is_true = (is_true_func  *) nsp_lmi_is_true; */
  /* top->loop =(loop_func *) nsp_lmi_loop;*/
  top->path_extract = (path_func *)  object_path_extract;
  top->get_from_obj = (get_from_obj_func *) nsp_lmi_object;
  top->eq  = (eq_func *) nsp_lmi_eq;
  top->neq  = (eq_func *) nsp_lmi_neq;
  top->save  = (save_func *) nsp_lmi_xdr_save;
  top->load  = (load_func *) nsp_lmi_xdr_load;
  top->create = (create_func*) int_lmi_create;
  top->latex = (print_func *) nsp_lmi_latex;
  top->full_copy = (copy_func *) nsp_lmi_full_copy;

  /* specific methods for lmi */

  type->init = (init_func *) init_lmi;

  /* 
   * NspLmi interfaces can be added here 
   * type->interface = (NspTypeBase *) new_type_b();
   * type->interface->interface = (NspTypeBase *) new_type_C()
   * ....
   */
  if ( nsp_type_lmi_id == 0 ) 
    {
      /* 
       * the first time we get here we initialize the type id and
       * an instance of NspTypeLmi called nsp_type_lmi
       */
      type->id =  nsp_type_lmi_id = nsp_new_type_id();
      nsp_type_lmi = type;
      if ( nsp_register_type(nsp_type_lmi) == FALSE) return NULL;
      return ( mode == T_BASE ) ? type : new_type_lmi(mode);
    }
  else 
    {
      type->id = nsp_type_lmi_id;
      return type;
    }
}

/*
 * initialize NspLmi instances 
 * locally and by calling initializer on parent class 
 */

static int init_lmi(NspLmi *Obj,NspTypeLmi *type)
{
  /* initialize the surtype */ 
  if ( type->surtype->init(&Obj->father,type->surtype) == FAIL) return FAIL;
  Obj->type = type;
  NSP_OBJECT(Obj)->basetype = (NspTypeBase *)type;
  /* specific */
  Obj->clauses = NULLCELLS;
  Obj->savedata = NULLLIST;
  return OK;
}

/*
 * new instance of NspLmi 
 */

NspLmi *new_lmi() 
{
  NspLmi *loc;
  /* type must exists */
  nsp_type_lmi = new_type_lmi(T_BASE);
  if ( (loc = malloc(sizeof(NspLmi)))== NULLLMI) return loc;
  /* initialize object */
  if ( init_lmi(loc,nsp_type_lmi) == FAIL) return NULLLMI;
  return loc;
}

/*----------------------------------------------
 * Object method redefined for NspLmi 
 *-----------------------------------------------*/
/*
 * size 
 */

static int nsp_lmi_size(NspLmi *Mat, int flag)
{
  return 0;
}

/*
 * type as string 
 */

static char lmi_type_name[]="Lmi";
static char lmi_short_type_name[]="lmi";

static char *nsp_lmi_type_as_string(void)
{
  return(lmi_type_name);
}

static char *nsp_lmi_type_short_string(NspObject *v)
{
  return(lmi_short_type_name);
}

/*
 * A == B 
 */

static int nsp_lmi_eq(NspLmi *A, NspObject *B)
{
  NspLmi *loc = (NspLmi *) B;
  if ( check_cast(B,nsp_type_lmi_id) == FALSE) return FALSE ;
  if ( NSP_OBJECT(A->clauses)->type->eq(A->clauses,loc->clauses) == FALSE ) return FALSE;
  if ( NSP_OBJECT(A->savedata)->type->eq(A->savedata,loc->savedata) == FALSE ) return FALSE;
  return TRUE;
}

/*
 * A != B 
 */

static int nsp_lmi_neq(NspLmi *A, NspObject *B)
{
  return ( nsp_lmi_eq(A,B) == TRUE ) ? FALSE : TRUE;
}

/*
 * save 
 */

int nsp_lmi_xdr_save(XDR *xdrs, NspLmi *M)
{
  /* if (nsp_xdr_save_id(xdrs,NSP_OBJECT(M)) == FAIL) return FAIL;*/
  /* if (nsp_xdr_save_i(xdrs,M->type->id) == FAIL) return FAIL; */ 
  if (nsp_xdr_save_i(xdrs,nsp_dynamic_id) == FAIL) return FAIL;
  if (nsp_xdr_save_string(xdrs,type_get_name(nsp_type_lmi)) == FAIL) return FAIL;
  if (nsp_xdr_save_string(xdrs, NSP_OBJECT(M)->name) == FAIL) return FAIL;
  if (nsp_object_xdr_save(xdrs,NSP_OBJECT(M->clauses)) == FAIL) return FAIL;
  if (nsp_object_xdr_save(xdrs,NSP_OBJECT(M->savedata)) == FAIL) return FAIL;
  return OK;
}

/*
 * load 
 */

NspLmi  *nsp_lmi_xdr_load_partial(XDR *xdrs, NspLmi *M)
{
  if ((M->clauses =(NspCells *) nsp_object_xdr_load(xdrs))== NULLCELLS) return NULL;
  if ((M->savedata =(NspList *) nsp_object_xdr_load(xdrs))== NULLLIST) return NULL;
 return M;
}

static NspLmi  *nsp_lmi_xdr_load(XDR *xdrs)
{
  NspLmi *H = NULL;
  char name[NAME_MAXL];
  if (nsp_xdr_load_string(xdrs,name,NAME_MAXL) == FAIL) return NULLLMI;
  if ((H  = nsp_lmi_create_void(name,(NspTypeBase *) nsp_type_lmi))== NULLLMI) return H;
  if ( nsp_lmi_create_partial(H) == FAIL) return NULLLMI;
  if ((H  = nsp_lmi_xdr_load_partial(xdrs,H))== NULLLMI) return H;
  if ( nsp_lmi_check_values(H) == FAIL) return NULLLMI;
#line 38 "codegen/lmi.override"
  /* verbatim in create/load/full_copy interface use NULL for returned value */
#line 247 "lmi.c"
  return H;
}

/*
 * delete 
 */

void nsp_lmi_destroy_partial(NspLmi *H)
{
#line 41 "codegen/lmi.override"
  /* verbatim in destroy */
#line 259 "lmi.c"
  if ( H->clauses != NULL ) 
    nsp_cells_destroy(H->clauses);
  if ( H->savedata != NULL ) 
    nsp_list_destroy(H->savedata);
}

void nsp_lmi_destroy(NspLmi *H)
{
  nsp_object_destroy_name(NSP_OBJECT(H));
  nsp_lmi_destroy_partial(H);
  FREE(H);
}

/*
 * info 
 */

int nsp_lmi_info(NspLmi *M,int indent,const char *name,int rec_level)
{
  const char *pname;
  if ( M == NULLLMI) 
    {
      Sciprintf("Null Pointer NspLmi \n");
      return TRUE;
    }
  pname = (name != NULL) ? name : NSP_OBJECT(M)->name;
  Sciprintf1(indent,"%s\t=\t\t%s\n", (pname==NULL) ? "" : pname,
             nsp_lmi_type_short_string(NSP_OBJECT(M)));
  return TRUE;
}

/*
 * print 
 */

int nsp_lmi_print(NspLmi *M, int indent,const char *name, int rec_level)
{
  const char *pname = (name != NULL) ? name : NSP_OBJECT(M)->name;
  if ( M == NULLLMI) 
    {
      Sciprintf("Null Pointer NspLmi \n");
      return TRUE;
    }
  if (user_pref.pr_as_read_syntax) 
    { 
      Sciprintf1(indent,"%s=TO_BE_DONE();\n",pname);
    } 
  else 
    { 
      if ( user_pref.pr_depth  <= rec_level -1 ) 
        {
          nsp_lmi_info(M,indent,pname,rec_level);
          return TRUE;
        }
      Sciprintf1(indent,"%s\t=\t\t%s \n",pname, nsp_lmi_type_short_string(NSP_OBJECT(M)) );
      Sciprintf1(indent+1,"{\n");
  if ( M->clauses != NULL)
    { if ( nsp_object_print(NSP_OBJECT(M->clauses),indent+2,"clauses",rec_level+1)== FALSE ) return FALSE ;
    }
  if ( M->savedata != NULL)
    { if ( nsp_object_print(NSP_OBJECT(M->savedata),indent+2,"savedata",rec_level+1)== FALSE ) return FALSE ;
    }
      Sciprintf1(indent+1,"}\n");
    }
  return TRUE;
}

/*
 * latex print 
 */

int nsp_lmi_latex(NspLmi *M, int indent,const char *name, int rec_level)
{
  const char *pname = (name != NULL) ? name : NSP_OBJECT(M)->name;
  if ( nsp_from_texmacs() == TRUE ) Sciprintf("\002latex:\\[");
  Sciprintf1(indent,"%s\t=\t\t%s\n",pname, nsp_lmi_type_short_string(NSP_OBJECT(M)));
  Sciprintf1(indent+1,"{\n");
  if ( M->clauses != NULL)
    { if ( nsp_object_latex(NSP_OBJECT(M->clauses),indent+2,"clauses",rec_level+1)== FALSE ) return FALSE ;
    }
  if ( M->savedata != NULL)
    { if ( nsp_object_latex(NSP_OBJECT(M->savedata),indent+2,"savedata",rec_level+1)== FALSE ) return FALSE ;
    }
  Sciprintf1(indent+1,"}\n");
  if ( nsp_from_texmacs() == TRUE ) Sciprintf("\\]\005");
  return TRUE;
}
/*-----------------------------------------------------
 * a set of functions used when writing interfaces 
 * for NspLmi objects 
 * Note that some of these functions could become MACROS
 *-----------------------------------------------------*/

NspLmi   *nsp_lmi_object(NspObject *O)
{
  /* Follow pointer */
  if ( check_cast(O,nsp_type_hobj_id) == TRUE)  O = ((NspHobj *) O)->O ;
  /* Check type */
  if ( check_cast (O,nsp_type_lmi_id) == TRUE ) return ((NspLmi *) O);
  else 
    Scierror("Error:	Argument should be a %s\n",type_get_name(nsp_type_lmi));
  return NULL;
}

int IsLmiObj(Stack stack, int i)
{
  return nsp_object_type(NthObj(i),nsp_type_lmi_id);
}

int IsLmi(NspObject *O)
{
  return nsp_object_type(O,nsp_type_lmi_id);
}

NspLmi  *GetLmiCopy(Stack stack, int i)
{
  if (  GetLmi(stack,i) == NULL ) return NULL;
  return MaybeObjCopy(&NthObj(i));
}

NspLmi  *GetLmi(Stack stack, int i)
{
  NspLmi *M;
  if (( M = nsp_lmi_object(NthObj(i))) == NULLLMI)
     ArgMessage(stack,i);
  return M;
}

/*-----------------------------------------------------
 * constructor 
 * if type is non NULL it is a subtype which can be used to 
 * create a NspLmi instance 
 *-----------------------------------------------------*/

static NspLmi *nsp_lmi_create_void(char *name,NspTypeBase *type)
{
 NspLmi *H  = (type == NULL) ? new_lmi() : type->new();
 if ( H ==  NULLLMI)
  {
   Sciprintf("No more memory\n");
   return NULLLMI;
  }
 if ( nsp_object_set_initial_name(NSP_OBJECT(H),name) == NULLSTRING) return NULLLMI;
 NSP_OBJECT(H)->ret_pos = -1 ;
 return H;
}

int nsp_lmi_create_partial(NspLmi *H)
{
  return OK;
}

int nsp_lmi_check_values(NspLmi *H)
{
  if ( H->clauses == NULLCELLS) 
    {
     if (( H->clauses = nsp_cells_create("clauses",0,0) ) == NULLCELLS)
       return FAIL;
    }
  if ( H->savedata == NULLLIST) 
    {
     if (( H->savedata = nsp_list_create("savedata")) == NULLLIST)
       return FAIL;
    }
  return OK;
}

NspLmi *nsp_lmi_create(char *name,NspCells* clauses,NspList* savedata,NspTypeBase *type)
{
  NspLmi *H  = nsp_lmi_create_void(name,type);
  if ( H ==  NULLLMI) return NULLLMI;
  H->clauses= clauses;
  H->savedata= savedata;
  if ( nsp_lmi_check_values(H) == FAIL) return NULLLMI;
#line 38 "codegen/lmi.override"
  /* verbatim in create/load/full_copy interface use NULL for returned value */
#line 436 "lmi.c"
  return H;
}


NspLmi *nsp_lmi_create_default(char *name)
{
 NspLmi *H  = nsp_lmi_create_void(name,NULL);
 if ( H ==  NULLLMI) return NULLLMI;
 if ( nsp_lmi_check_values(H) == FAIL) return NULLLMI;
 return H;
}

/*
 * copy for gobject derived class  
 */

NspLmi *nsp_lmi_copy_partial(NspLmi *H,NspLmi *self)
{
  if ( self->clauses == NULL )
    { H->clauses = NULL;}
  else
    {
      if ((H->clauses = (NspCells *) nsp_object_copy_and_name("clauses",NSP_OBJECT(self->clauses))) == NULLCELLS) return NULL;
    }
  if ( self->savedata == NULL )
    { H->savedata = NULL;}
  else
    {
      if ((H->savedata = (NspList *) nsp_object_copy_and_name("savedata",NSP_OBJECT(self->savedata))) == NULLLIST) return NULL;
    }
  return H;
}

NspLmi *nsp_lmi_copy(NspLmi *self)
{
  NspLmi *H  =nsp_lmi_create_void(NVOID,(NspTypeBase *) nsp_type_lmi);
  if ( H ==  NULLLMI) return NULLLMI;
  if ( nsp_lmi_copy_partial(H,self)== NULL) return NULLLMI;

  return H;
}
/*
 * full copy for gobject derived class
 */

NspLmi *nsp_lmi_full_copy_partial(NspLmi *H,NspLmi *self)
{
  if ( self->clauses == NULL )
    { H->clauses = NULL;}
  else
    {
      if ((H->clauses = (NspCells *) nsp_object_full_copy_and_name("clauses",NSP_OBJECT(self->clauses))) == NULLCELLS) return NULL;
    }
  if ( self->savedata == NULL )
    { H->savedata = NULL;}
  else
    {
      if ((H->savedata = (NspList *) nsp_object_full_copy_and_name("savedata",NSP_OBJECT(self->savedata))) == NULLLIST) return NULL;
    }
  return H;
}

NspLmi *nsp_lmi_full_copy(NspLmi *self)
{
  NspLmi *H  =nsp_lmi_create_void(NVOID,(NspTypeBase *) nsp_type_lmi);
  if ( H ==  NULLLMI) return NULLLMI;
  if ( nsp_lmi_full_copy_partial(H,self)== NULL) return NULLLMI;

#line 38 "codegen/lmi.override"
  /* verbatim in create/load/full_copy interface use NULL for returned value */
#line 507 "lmi.c"
  return H;
}

/*-------------------------------------------------------------------
 * wrappers for the NspLmi
 * i.e functions at Nsp level 
 *-------------------------------------------------------------------*/

int int_lmi_create(Stack stack, int rhs, int opt, int lhs)
{
  NspLmi *H;
  CheckStdRhs(0,0);
  /* want to be sure that type lmi is initialized */
  nsp_type_lmi = new_type_lmi(T_BASE);
  if(( H = nsp_lmi_create_void(NVOID,(NspTypeBase *) nsp_type_lmi)) == NULLLMI) return RET_BUG;
  /* then we use optional arguments to fill attributes */
  if ( int_create_with_attributes((NspObject  *) H,stack,rhs,opt,lhs) == RET_BUG)  return RET_BUG;
 if ( nsp_lmi_check_values(H) == FAIL) return RET_BUG;
#line 38 "codegen/lmi.override"
  /* verbatim in create/load/full_copy interface use RET_BUG for returned value */
#line 528 "lmi.c"
  MoveObj(stack,1,(NspObject  *) H);
  return 1;
} 

/*-------------------------------------------
 * Methods
 *-------------------------------------------*/
static NspMethods *lmi_get_methods(void) { return NULL;};
/*-------------------------------------------
 * Attributes
 *-------------------------------------------*/

static NspObject *_wrap_lmi_get_clauses(void *self,const char *attr)
{
  NspCells *ret;

  ret = ((NspLmi *) self)->clauses;
  return (NspObject *) ret;
}

static NspObject *_wrap_lmi_get_obj_clauses(void *self,const char *attr, int *copy)
{
  NspCells *ret;

  *copy = FALSE;
  ret = ((NspCells*) ((NspLmi *) self)->clauses);
  return (NspObject *) ret;
}

static int _wrap_lmi_set_clauses(void *self,const char *attr, NspObject *O)
{
  NspCells *clauses;

  if ( ! IsCells(O) ) return FAIL;
  if ((clauses = (NspCells *) nsp_object_copy_and_name(attr,O)) == NULLCELLS) return FAIL;
  if (((NspLmi *) self)->clauses != NULL ) 
    nsp_cells_destroy(((NspLmi *) self)->clauses);
  ((NspLmi *) self)->clauses= clauses;
  return OK;
}

static NspObject *_wrap_lmi_get_savedata(void *self,const char *attr)
{
  NspList *ret;

  ret = ((NspLmi *) self)->savedata;
  return (NspObject *) ret;
}

static NspObject *_wrap_lmi_get_obj_savedata(void *self,const char *attr, int *copy)
{
  NspList *ret;

  *copy = FALSE;
  ret = ((NspList*) ((NspLmi *) self)->savedata);
  return (NspObject *) ret;
}

static int _wrap_lmi_set_savedata(void *self,const char *attr, NspObject *O)
{
  NspList *savedata;

  if ( ! IsList(O) ) return FAIL;
  if ((savedata = (NspList *) nsp_object_copy_and_name(attr,O)) == NULLLIST) return FAIL;
  if (((NspLmi *) self)->savedata != NULL ) 
    nsp_list_destroy(((NspLmi *) self)->savedata);
  ((NspLmi *) self)->savedata= savedata;
  return OK;
}

static AttrTab lmi_attrs[] = {
  { "clauses", (attr_get_function *)_wrap_lmi_get_clauses, (attr_set_function *)_wrap_lmi_set_clauses,(attr_get_object_function *)_wrap_lmi_get_obj_clauses, (attr_set_object_function *)int_set_object_failed },
  { "savedata", (attr_get_function *)_wrap_lmi_get_savedata, (attr_set_function *)_wrap_lmi_set_savedata,(attr_get_object_function *)_wrap_lmi_get_obj_savedata, (attr_set_object_function *)int_set_object_failed },
  { NULL,NULL,NULL,NULL,NULL },
};


/*-------------------------------------------
 * functions 
 *-------------------------------------------*/
/*----------------------------------------------------
 * Interface 
 * i.e a set of function which are accessible at nsp level
 *----------------------------------------------------*/

static OpTab Lmi_func[]={
  { "lmi_create", int_lmi_create},
  { NULL, NULL}
};

/* call ith function in the Lmi interface */

int Lmi_Interf(int i, Stack stack, int rhs, int opt, int lhs)
{
  return (*(Lmi_func[i].fonc))(stack,rhs,opt,lhs);
}

/* used to walk through the interface table 
    (for adding or removing functions) */

void Lmi_Interf_Info(int i, char **fname, function (**f))
{
  *fname = Lmi_func[i].name;
  *f = Lmi_func[i].fonc;
}

#line 635 "lmi.c"
