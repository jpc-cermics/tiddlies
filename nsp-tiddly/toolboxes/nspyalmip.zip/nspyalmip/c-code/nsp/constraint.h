/* -*- Mode: C -*- */
#ifndef NSP_INC_NspConstraint
#define NSP_INC_NspConstraint

/*
 * Copyright (C) 1998-2010 Jean-Philippe Chancelier Enpc/Cermics
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public
 * License along with this library; if not, write to the
 * Free Software Foundation, Inc., 59 Temple Place - Suite 330,
 * Boston, MA 02111-1307, USA.
 */

#line 4 "codegen/constraint.override"

#line 27 "./constraint.h"
/* NspConstraint */

#include <nsp/object.h>

/*
 * NspConstraint inherits from Object
 */

typedef struct _NspConstraint NspConstraint ;
typedef struct _NspTypeConstraint NspTypeConstraint ;

#line 39 "./constraint.h"

struct _NspTypeConstraint {
  /*< private >*/
  NSP_TYPE_OBJECT__
  /*< public >*/
 
#line 46 "./constraint.h"
};

struct _NspConstraint {
  /*< private >*/
  NspObject father;
  NspTypeConstraint*type;
  /*< public >*/
    NspList* List;
  NspList* Evaluated;
  NspMatrix* strict;
};

extern int nsp_type_constraint_id;
extern NspTypeConstraint *nsp_type_constraint;

/* type instances for object */

NspTypeConstraint *new_type_constraint(type_mode mode);

/* instance for NspConstraint */

NspConstraint *new_constraint();

/*
 * Object methods redefined for constraint 
 */


#define NULLCONSTRAINT (NspConstraint*) 0

extern NspConstraint *nsp_constraint_create(char *name,NspList* List,NspList* Evaluated,NspMatrix* strict,NspTypeBase *type);
extern NspConstraint *nsp_constraint_create_default(char *name);

/* from NspConstraintObj.c */

extern NspConstraint *nsp_constraint_copy(NspConstraint *H);
extern void nsp_constraint_destroy(NspConstraint *H);
extern int nsp_constraint_info(NspConstraint *H, int indent,const char *name, int rec_level);
extern int nsp_constraint_print(NspConstraint *H, int indent,const char *name, int rec_level);
extern int nsp_constraint_latex(NspConstraint *H, int indent,const char *name, int rec_level);
extern NspConstraint *nsp_constraint_object (NspObject *O);
extern int IsConstraintObj (Stack stack, int i);
extern int IsConstraint(NspObject *O);
extern NspConstraint *GetConstraintCopy (Stack stack, int i);
extern NspConstraint *GetConstraint (Stack stack, int i);
extern int nsp_constraint_create_partial(NspConstraint *H);
extern void nsp_constraint_destroy_partial(NspConstraint *H);
extern NspConstraint * nsp_constraint_copy_partial(NspConstraint *H,NspConstraint *self);
extern NspConstraint * nsp_constraint_full_copy_partial(NspConstraint *H,NspConstraint *self);
extern NspConstraint * nsp_constraint_full_copy(NspConstraint *self);
extern int nsp_constraint_check_values(NspConstraint *H);
extern int int_constraint_create(Stack stack, int rhs, int opt, int lhs);
extern NspConstraint *nsp_constraint_xdr_load_partial(XDR *xdrs, NspConstraint *M);
extern int nsp_constraint_xdr_save(XDR  *xdrs, NspConstraint *M);

#line 7 "codegen/constraint.override"

/* inserted at the end of public part of include file
 * of classa.h
 */

#line 108 "./constraint.h"
#endif /* NSP_INC_NspConstraint */ 

#ifdef NspConstraint_Private 
static int init_constraint(NspConstraint *o,NspTypeConstraint *type);
static int nsp_constraint_size(NspConstraint *Mat, int flag);
static char *nsp_constraint_type_as_string(void);
static char *nsp_constraint_type_short_string(NspObject *v);
static int nsp_constraint_eq(NspConstraint *A, NspObject *B);
static int nsp_constraint_neq(NspConstraint *A, NspObject *B);
static NspConstraint *nsp_constraint_xdr_load(XDR *xdrs);
static AttrTab constraint_attrs[];
static NspMethods *constraint_get_methods(void);
/* static int int_constraint_create(Stack stack, int rhs, int opt, int lhs);*/ 
static NspConstraint *nsp_constraint_create_void(char *name,NspTypeBase *type);
#line 14 "codegen/constraint.override"

/* inserted in the private part of include file
 * of classa.h
 */

#line 129 "./constraint.h"
#endif /* NspConstraint_Private */

