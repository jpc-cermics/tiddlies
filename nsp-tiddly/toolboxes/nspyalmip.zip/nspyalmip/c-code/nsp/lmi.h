/* -*- Mode: C -*- */
#ifndef NSP_INC_NspLmi
#define NSP_INC_NspLmi

/*
 * Copyright (C) 1998-2010 Jean-Philippe Chancelier Enpc/Cermics
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public
 * License along with this library; if not, write to the
 * Free Software Foundation, Inc., 59 Temple Place - Suite 330,
 * Boston, MA 02111-1307, USA.
 */

#line 4 "codegen/lmi.override"
#include <nsp/cells.h> 

#line 28 "./lmi.h"
/* NspLmi */

#include <nsp/object.h>

/*
 * NspLmi inherits from Object
 */

typedef struct _NspLmi NspLmi ;
typedef struct _NspTypeLmi NspTypeLmi ;

#line 40 "./lmi.h"

struct _NspTypeLmi {
  /*< private >*/
  NSP_TYPE_OBJECT__
  /*< public >*/
 
#line 47 "./lmi.h"
};

struct _NspLmi {
  /*< private >*/
  NspObject father;
  NspTypeLmi*type;
  /*< public >*/
    NspCells* clauses;
  NspList* savedata;
};

extern int nsp_type_lmi_id;
extern NspTypeLmi *nsp_type_lmi;

/* type instances for object */

NspTypeLmi *new_type_lmi(type_mode mode);

/* instance for NspLmi */

NspLmi *new_lmi();

/*
 * Object methods redefined for lmi 
 */


#define NULLLMI (NspLmi*) 0

extern NspLmi *nsp_lmi_create(char *name,NspCells* clauses,NspList* savedata,NspTypeBase *type);
extern NspLmi *nsp_lmi_create_default(char *name);

/* from NspLmiObj.c */

extern NspLmi *nsp_lmi_copy(NspLmi *H);
extern void nsp_lmi_destroy(NspLmi *H);
extern int nsp_lmi_info(NspLmi *H, int indent,const char *name, int rec_level);
extern int nsp_lmi_print(NspLmi *H, int indent,const char *name, int rec_level);
extern int nsp_lmi_latex(NspLmi *H, int indent,const char *name, int rec_level);
extern NspLmi *nsp_lmi_object (NspObject *O);
extern int IsLmiObj (Stack stack, int i);
extern int IsLmi(NspObject *O);
extern NspLmi *GetLmiCopy (Stack stack, int i);
extern NspLmi *GetLmi (Stack stack, int i);
extern int nsp_lmi_create_partial(NspLmi *H);
extern void nsp_lmi_destroy_partial(NspLmi *H);
extern NspLmi * nsp_lmi_copy_partial(NspLmi *H,NspLmi *self);
extern NspLmi * nsp_lmi_full_copy_partial(NspLmi *H,NspLmi *self);
extern NspLmi * nsp_lmi_full_copy(NspLmi *self);
extern int nsp_lmi_check_values(NspLmi *H);
extern int int_lmi_create(Stack stack, int rhs, int opt, int lhs);
extern NspLmi *nsp_lmi_xdr_load_partial(XDR *xdrs, NspLmi *M);
extern int nsp_lmi_xdr_save(XDR  *xdrs, NspLmi *M);

#line 8 "codegen/lmi.override"

/* inserted at the end of public part of include file
 * of classa.h
 */

#line 108 "./lmi.h"
#endif /* NSP_INC_NspLmi */ 

#ifdef NspLmi_Private 
static int init_lmi(NspLmi *o,NspTypeLmi *type);
static int nsp_lmi_size(NspLmi *Mat, int flag);
static char *nsp_lmi_type_as_string(void);
static char *nsp_lmi_type_short_string(NspObject *v);
static int nsp_lmi_eq(NspLmi *A, NspObject *B);
static int nsp_lmi_neq(NspLmi *A, NspObject *B);
static NspLmi *nsp_lmi_xdr_load(XDR *xdrs);
static AttrTab lmi_attrs[];
static NspMethods *lmi_get_methods(void);
/* static int int_lmi_create(Stack stack, int rhs, int opt, int lhs);*/ 
static NspLmi *nsp_lmi_create_void(char *name,NspTypeBase *type);
#line 15 "codegen/lmi.override"

/* inserted in the private part of include file
 * of classa.h
 */

#line 129 "./lmi.h"
#endif /* NspLmi_Private */

