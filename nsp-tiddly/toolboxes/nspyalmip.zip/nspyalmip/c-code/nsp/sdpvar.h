/* -*- Mode: C -*- */
#ifndef NSP_INC_NspSdpvar
#define NSP_INC_NspSdpvar

/*
 * Copyright (C) 1998-2010 Jean-Philippe Chancelier Enpc/Cermics
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public
 * License along with this library; if not, write to the
 * Free Software Foundation, Inc., 59 Temple Place - Suite 330,
 * Boston, MA 02111-1307, USA.
 */

#line 4 "codegen/sdpvar.override"
#include <nsp/spcolmatrix.h>

#line 28 "./sdpvar.h"
/* NspSdpvar */

#include <nsp/object.h>

/*
 * NspSdpvar inherits from Object
 */

typedef struct _NspSdpvar NspSdpvar ;
typedef struct _NspTypeSdpvar NspTypeSdpvar ;

#line 40 "./sdpvar.h"

struct _NspTypeSdpvar {
  /*< private >*/
  NSP_TYPE_OBJECT__
  /*< public >*/
 
#line 47 "./sdpvar.h"
};

struct _NspSdpvar {
  /*< private >*/
  NspObject father;
  NspTypeSdpvar*type;
  /*< public >*/
    NspSpColMatrix* basis;
  NspMatrix* lmi_variables;
  int n;
  int m;
  int typeflag;
  NspList* savedata;
  NspList* extra;
};

extern int nsp_type_sdpvar_id;
extern NspTypeSdpvar *nsp_type_sdpvar;

/* type instances for object */

NspTypeSdpvar *new_type_sdpvar(type_mode mode);

/* instance for NspSdpvar */

NspSdpvar *new_sdpvar();

/*
 * Object methods redefined for sdpvar 
 */


#define NULLSDPVAR (NspSdpvar*) 0

extern NspSdpvar *nsp_sdpvar_create(char *name,NspSpColMatrix* basis,NspMatrix* lmi_variables,int n,int m,int typeflag,NspList* savedata,NspList* extra,NspTypeBase *type);
extern NspSdpvar *nsp_sdpvar_create_default(char *name);

/* from NspSdpvarObj.c */

extern NspSdpvar *nsp_sdpvar_copy(NspSdpvar *H);
extern void nsp_sdpvar_destroy(NspSdpvar *H);
extern int nsp_sdpvar_info(NspSdpvar *H, int indent,const char *name, int rec_level);
extern int nsp_sdpvar_print(NspSdpvar *H, int indent,const char *name, int rec_level);
extern int nsp_sdpvar_latex(NspSdpvar *H, int indent,const char *name, int rec_level);
extern NspSdpvar *nsp_sdpvar_object (NspObject *O);
extern int IsSdpvarObj (Stack stack, int i);
extern int IsSdpvar(NspObject *O);
extern NspSdpvar *GetSdpvarCopy (Stack stack, int i);
extern NspSdpvar *GetSdpvar (Stack stack, int i);
extern int nsp_sdpvar_create_partial(NspSdpvar *H);
extern void nsp_sdpvar_destroy_partial(NspSdpvar *H);
extern NspSdpvar * nsp_sdpvar_copy_partial(NspSdpvar *H,NspSdpvar *self);
extern NspSdpvar * nsp_sdpvar_full_copy_partial(NspSdpvar *H,NspSdpvar *self);
extern NspSdpvar * nsp_sdpvar_full_copy(NspSdpvar *self);
extern int nsp_sdpvar_check_values(NspSdpvar *H);
extern int int_sdpvar_create(Stack stack, int rhs, int opt, int lhs);
extern NspSdpvar *nsp_sdpvar_xdr_load_partial(XDR *xdrs, NspSdpvar *M);
extern int nsp_sdpvar_xdr_save(XDR  *xdrs, NspSdpvar *M);

#line 8 "codegen/sdpvar.override"

/* inserted at the end of public part of include file
 * of classa.h
 */

#line 113 "./sdpvar.h"
#endif /* NSP_INC_NspSdpvar */ 

#ifdef NspSdpvar_Private 
static int init_sdpvar(NspSdpvar *o,NspTypeSdpvar *type);
static int nsp_sdpvar_size(NspSdpvar *Mat, int flag);
static char *nsp_sdpvar_type_as_string(void);
static char *nsp_sdpvar_type_short_string(NspObject *v);
static int nsp_sdpvar_eq(NspSdpvar *A, NspObject *B);
static int nsp_sdpvar_neq(NspSdpvar *A, NspObject *B);
static NspSdpvar *nsp_sdpvar_xdr_load(XDR *xdrs);
static AttrTab sdpvar_attrs[];
static NspMethods *sdpvar_get_methods(void);
/* static int int_sdpvar_create(Stack stack, int rhs, int opt, int lhs);*/ 
static NspSdpvar *nsp_sdpvar_create_void(char *name,NspTypeBase *type);
#line 15 "codegen/sdpvar.override"

/* inserted in the private part of include file
 * of classa.h
 */

#line 134 "./sdpvar.h"
#endif /* NspSdpvar_Private */

