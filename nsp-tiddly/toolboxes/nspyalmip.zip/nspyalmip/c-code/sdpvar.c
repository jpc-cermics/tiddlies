/* -*- Mode: C -*- */

/* This file is generated, please do not edit */
/* Nsp
 * Copyright (C) 1998-2009 Jean-Philippe Chancelier Enpc/Cermics
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public
 * License along with this library; if not, write to the
 * Free Software Foundation, Inc., 59 Temple Place - Suite 330,
 * Boston, MA 02111-1307, USA.
 */





#line 22 "codegen/sdpvar.override"

#line 30 "sdpvar.c"

/* ----------- NspSdpvar ----------- */


#define  NspSdpvar_Private 
#include <nsp/objects.h>
#include <nsp/sdpvar.h>
#include <nsp/interf.h>

/* 
 * NspSdpvar inherits from Object 
 */

int nsp_type_sdpvar_id=0;
NspTypeSdpvar *nsp_type_sdpvar=NULL;

/*
 * Type object for NspSdpvar 
 * all the instance of NspTypeSdpvar share the same id. 
 * nsp_type_sdpvar: is an instance of NspTypeSdpvar 
 *    used for objects of NspSdpvar type (i.e built with new_sdpvar) 
 * other instances are used for derived classes 
 */
NspTypeSdpvar *new_type_sdpvar(type_mode mode)
{
  NspTypeSdpvar *type= NULL;
  NspTypeObject *top;
  if (  nsp_type_sdpvar != 0 && mode == T_BASE )
    {
      /* initialization performed and T_BASE requested */
      return nsp_type_sdpvar;
    }
  if (( type =  malloc(sizeof(NspTypeSdpvar))) == NULL) return NULL;
  type->interface = NULL;
  type->surtype = (NspTypeBase *) new_type_object(T_DERIVED);
  if ( type->surtype == NULL) return NULL;
  type->attrs = sdpvar_attrs;
  type->get_attrs = (attrs_func *) int_get_attribute;
  type->set_attrs = (attrs_func *) int_set_attribute;
  type->methods = sdpvar_get_methods;
  type->new = (new_func *) new_sdpvar;


  top = NSP_TYPE_OBJECT(type->surtype);
  while ( top->surtype != NULL ) top= NSP_TYPE_OBJECT(top->surtype);

  /* object methods redefined for sdpvar */ 

  top->pr = (print_func *) nsp_sdpvar_print;
  top->dealloc = (dealloc_func *) nsp_sdpvar_destroy;
  top->copy  =  (copy_func *) nsp_sdpvar_copy;
  top->size  = (size_func *) nsp_sdpvar_size;
  top->s_type =  (s_type_func *) nsp_sdpvar_type_as_string;
  top->sh_type = (sh_type_func *) nsp_sdpvar_type_short_string;
  top->info = (info_func *) nsp_sdpvar_info;
  /* top->is_true = (is_true_func  *) nsp_sdpvar_is_true; */
  /* top->loop =(loop_func *) nsp_sdpvar_loop;*/
  top->path_extract = (path_func *)  object_path_extract;
  top->get_from_obj = (get_from_obj_func *) nsp_sdpvar_object;
  top->eq  = (eq_func *) nsp_sdpvar_eq;
  top->neq  = (eq_func *) nsp_sdpvar_neq;
  top->save  = (save_func *) nsp_sdpvar_xdr_save;
  top->load  = (load_func *) nsp_sdpvar_xdr_load;
  top->create = (create_func*) int_sdpvar_create;
  top->latex = (print_func *) nsp_sdpvar_latex;
  top->full_copy = (copy_func *) nsp_sdpvar_full_copy;

  /* specific methods for sdpvar */

  type->init = (init_func *) init_sdpvar;

  /* 
   * NspSdpvar interfaces can be added here 
   * type->interface = (NspTypeBase *) new_type_b();
   * type->interface->interface = (NspTypeBase *) new_type_C()
   * ....
   */
  if ( nsp_type_sdpvar_id == 0 ) 
    {
      /* 
       * the first time we get here we initialize the type id and
       * an instance of NspTypeSdpvar called nsp_type_sdpvar
       */
      type->id =  nsp_type_sdpvar_id = nsp_new_type_id();
      nsp_type_sdpvar = type;
      if ( nsp_register_type(nsp_type_sdpvar) == FALSE) return NULL;
      return ( mode == T_BASE ) ? type : new_type_sdpvar(mode);
    }
  else 
    {
      type->id = nsp_type_sdpvar_id;
      return type;
    }
}

/*
 * initialize NspSdpvar instances 
 * locally and by calling initializer on parent class 
 */

static int init_sdpvar(NspSdpvar *Obj,NspTypeSdpvar *type)
{
  /* initialize the surtype */ 
  if ( type->surtype->init(&Obj->father,type->surtype) == FAIL) return FAIL;
  Obj->type = type;
  NSP_OBJECT(Obj)->basetype = (NspTypeBase *)type;
  /* specific */
  Obj->basis = NULLSPCOLMAT;
  Obj->lmi_variables = NULLMAT;
  Obj->n = 0;
  Obj->m = 0;
  Obj->typeflag = 0;
  Obj->savedata = NULLLIST;
  Obj->extra = NULLLIST;
  return OK;
}

/*
 * new instance of NspSdpvar 
 */

NspSdpvar *new_sdpvar() 
{
  NspSdpvar *loc;
  /* type must exists */
  nsp_type_sdpvar = new_type_sdpvar(T_BASE);
  if ( (loc = malloc(sizeof(NspSdpvar)))== NULLSDPVAR) return loc;
  /* initialize object */
  if ( init_sdpvar(loc,nsp_type_sdpvar) == FAIL) return NULLSDPVAR;
  return loc;
}

/*----------------------------------------------
 * Object method redefined for NspSdpvar 
 *-----------------------------------------------*/
/*
 * size 
 */

static int nsp_sdpvar_size(NspSdpvar *Mat, int flag)
{
  return 0;
}

/*
 * type as string 
 */

static char sdpvar_type_name[]="Sdpvar";
static char sdpvar_short_type_name[]="sdpvar";

static char *nsp_sdpvar_type_as_string(void)
{
  return(sdpvar_type_name);
}

static char *nsp_sdpvar_type_short_string(NspObject *v)
{
  return(sdpvar_short_type_name);
}

/*
 * A == B 
 */

static int nsp_sdpvar_eq(NspSdpvar *A, NspObject *B)
{
  NspSdpvar *loc = (NspSdpvar *) B;
  if ( check_cast(B,nsp_type_sdpvar_id) == FALSE) return FALSE ;
  if ( NSP_OBJECT(A->basis)->type->eq(A->basis,loc->basis) == FALSE ) return FALSE;
  if ( NSP_OBJECT(A->lmi_variables)->type->eq(A->lmi_variables,loc->lmi_variables) == FALSE ) return FALSE;
  if ( A->n != loc->n) return FALSE;
  if ( A->m != loc->m) return FALSE;
  if ( A->typeflag != loc->typeflag) return FALSE;
  if ( NSP_OBJECT(A->savedata)->type->eq(A->savedata,loc->savedata) == FALSE ) return FALSE;
  if ( NSP_OBJECT(A->extra)->type->eq(A->extra,loc->extra) == FALSE ) return FALSE;
  return TRUE;
}

/*
 * A != B 
 */

static int nsp_sdpvar_neq(NspSdpvar *A, NspObject *B)
{
  return ( nsp_sdpvar_eq(A,B) == TRUE ) ? FALSE : TRUE;
}

/*
 * save 
 */

int nsp_sdpvar_xdr_save(XDR *xdrs, NspSdpvar *M)
{
  /* if (nsp_xdr_save_id(xdrs,NSP_OBJECT(M)) == FAIL) return FAIL;*/
  /* if (nsp_xdr_save_i(xdrs,M->type->id) == FAIL) return FAIL; */ 
  if (nsp_xdr_save_i(xdrs,nsp_dynamic_id) == FAIL) return FAIL;
  if (nsp_xdr_save_string(xdrs,type_get_name(nsp_type_sdpvar)) == FAIL) return FAIL;
  if (nsp_xdr_save_string(xdrs, NSP_OBJECT(M)->name) == FAIL) return FAIL;
  if (nsp_object_xdr_save(xdrs,NSP_OBJECT(M->basis)) == FAIL) return FAIL;
  if (nsp_object_xdr_save(xdrs,NSP_OBJECT(M->lmi_variables)) == FAIL) return FAIL;
  if (nsp_xdr_save_i(xdrs, M->n) == FAIL) return FAIL;
  if (nsp_xdr_save_i(xdrs, M->m) == FAIL) return FAIL;
  if (nsp_xdr_save_i(xdrs, M->typeflag) == FAIL) return FAIL;
  if (nsp_object_xdr_save(xdrs,NSP_OBJECT(M->savedata)) == FAIL) return FAIL;
  if (nsp_object_xdr_save(xdrs,NSP_OBJECT(M->extra)) == FAIL) return FAIL;
  return OK;
}

/*
 * load 
 */

NspSdpvar  *nsp_sdpvar_xdr_load_partial(XDR *xdrs, NspSdpvar *M)
{
  if ((M->basis =(NspSpColMatrix *) nsp_object_xdr_load(xdrs))== NULLSPCOLMAT) return NULL;
  if ((M->lmi_variables =(NspMatrix *) nsp_object_xdr_load(xdrs))== NULLMAT) return NULL;
  if (nsp_xdr_load_i(xdrs, &M->n) == FAIL) return NULL;
  if (nsp_xdr_load_i(xdrs, &M->m) == FAIL) return NULL;
  if (nsp_xdr_load_i(xdrs, &M->typeflag) == FAIL) return NULL;
  if ((M->savedata =(NspList *) nsp_object_xdr_load(xdrs))== NULLLIST) return NULL;
  if ((M->extra =(NspList *) nsp_object_xdr_load(xdrs))== NULLLIST) return NULL;
 return M;
}

static NspSdpvar  *nsp_sdpvar_xdr_load(XDR *xdrs)
{
  NspSdpvar *H = NULL;
  char name[NAME_MAXL];
  if (nsp_xdr_load_string(xdrs,name,NAME_MAXL) == FAIL) return NULLSDPVAR;
  if ((H  = nsp_sdpvar_create_void(name,(NspTypeBase *) nsp_type_sdpvar))== NULLSDPVAR) return H;
  if ( nsp_sdpvar_create_partial(H) == FAIL) return NULLSDPVAR;
  if ((H  = nsp_sdpvar_xdr_load_partial(xdrs,H))== NULLSDPVAR) return H;
  if ( nsp_sdpvar_check_values(H) == FAIL) return NULLSDPVAR;
#line 38 "codegen/sdpvar.override"
  /* verbatim in create/load/full_copy interface use NULL for returned value */
#line 267 "sdpvar.c"
  return H;
}

/*
 * delete 
 */

void nsp_sdpvar_destroy_partial(NspSdpvar *H)
{
#line 41 "codegen/sdpvar.override"
  /* verbatim in destroy */
#line 279 "sdpvar.c"
  if ( H->basis != NULL ) 
    nsp_spcolmatrix_destroy(H->basis);
  if ( H->lmi_variables != NULL ) 
    nsp_matrix_destroy(H->lmi_variables);
  if ( H->savedata != NULL ) 
    nsp_list_destroy(H->savedata);
  if ( H->extra != NULL ) 
    nsp_list_destroy(H->extra);
}

void nsp_sdpvar_destroy(NspSdpvar *H)
{
  nsp_object_destroy_name(NSP_OBJECT(H));
  nsp_sdpvar_destroy_partial(H);
  FREE(H);
}

/*
 * info 
 */

int nsp_sdpvar_info(NspSdpvar *M,int indent,const char *name,int rec_level)
{
  const char *pname;
  if ( M == NULLSDPVAR) 
    {
      Sciprintf("Null Pointer NspSdpvar \n");
      return TRUE;
    }
  pname = (name != NULL) ? name : NSP_OBJECT(M)->name;
  Sciprintf1(indent,"%s\t=\t\t%s\n", (pname==NULL) ? "" : pname,
             nsp_sdpvar_type_short_string(NSP_OBJECT(M)));
  return TRUE;
}

/*
 * print 
 */

int nsp_sdpvar_print(NspSdpvar *M, int indent,const char *name, int rec_level)
{
  const char *pname = (name != NULL) ? name : NSP_OBJECT(M)->name;
  if ( M == NULLSDPVAR) 
    {
      Sciprintf("Null Pointer NspSdpvar \n");
      return TRUE;
    }
  if (user_pref.pr_as_read_syntax) 
    { 
      Sciprintf1(indent,"%s=TO_BE_DONE();\n",pname);
    } 
  else 
    { 
      if ( user_pref.pr_depth  <= rec_level -1 ) 
        {
          nsp_sdpvar_info(M,indent,pname,rec_level);
          return TRUE;
        }
      Sciprintf1(indent,"%s\t=\t\t%s \n",pname, nsp_sdpvar_type_short_string(NSP_OBJECT(M)) );
      Sciprintf1(indent+1,"{\n");
  if ( M->basis != NULL)
    { if ( nsp_object_print(NSP_OBJECT(M->basis),indent+2,"basis",rec_level+1)== FALSE ) return FALSE ;
    }
  if ( M->lmi_variables != NULL)
    { if ( nsp_object_print(NSP_OBJECT(M->lmi_variables),indent+2,"lmi_variables",rec_level+1)== FALSE ) return FALSE ;
    }
  Sciprintf1(indent+2,"n=%d\n",M->n);
  Sciprintf1(indent+2,"m=%d\n",M->m);
  Sciprintf1(indent+2,"typeflag=%d\n",M->typeflag);
  if ( M->savedata != NULL)
    { if ( nsp_object_print(NSP_OBJECT(M->savedata),indent+2,"savedata",rec_level+1)== FALSE ) return FALSE ;
    }
  if ( M->extra != NULL)
    { if ( nsp_object_print(NSP_OBJECT(M->extra),indent+2,"extra",rec_level+1)== FALSE ) return FALSE ;
    }
      Sciprintf1(indent+1,"}\n");
    }
  return TRUE;
}

/*
 * latex print 
 */

int nsp_sdpvar_latex(NspSdpvar *M, int indent,const char *name, int rec_level)
{
  const char *pname = (name != NULL) ? name : NSP_OBJECT(M)->name;
  if ( nsp_from_texmacs() == TRUE ) Sciprintf("\002latex:\\[");
  Sciprintf1(indent,"%s\t=\t\t%s\n",pname, nsp_sdpvar_type_short_string(NSP_OBJECT(M)));
  Sciprintf1(indent+1,"{\n");
  if ( M->basis != NULL)
    { if ( nsp_object_latex(NSP_OBJECT(M->basis),indent+2,"basis",rec_level+1)== FALSE ) return FALSE ;
    }
  if ( M->lmi_variables != NULL)
    { if ( nsp_object_latex(NSP_OBJECT(M->lmi_variables),indent+2,"lmi_variables",rec_level+1)== FALSE ) return FALSE ;
    }
  Sciprintf1(indent+2,"n=%d\n",M->n);
  Sciprintf1(indent+2,"m=%d\n",M->m);
  Sciprintf1(indent+2,"typeflag=%d\n",M->typeflag);
  if ( M->savedata != NULL)
    { if ( nsp_object_latex(NSP_OBJECT(M->savedata),indent+2,"savedata",rec_level+1)== FALSE ) return FALSE ;
    }
  if ( M->extra != NULL)
    { if ( nsp_object_latex(NSP_OBJECT(M->extra),indent+2,"extra",rec_level+1)== FALSE ) return FALSE ;
    }
  Sciprintf1(indent+1,"}\n");
  if ( nsp_from_texmacs() == TRUE ) Sciprintf("\\]\005");
  return TRUE;
}
/*-----------------------------------------------------
 * a set of functions used when writing interfaces 
 * for NspSdpvar objects 
 * Note that some of these functions could become MACROS
 *-----------------------------------------------------*/

NspSdpvar   *nsp_sdpvar_object(NspObject *O)
{
  /* Follow pointer */
  if ( check_cast(O,nsp_type_hobj_id) == TRUE)  O = ((NspHobj *) O)->O ;
  /* Check type */
  if ( check_cast (O,nsp_type_sdpvar_id) == TRUE ) return ((NspSdpvar *) O);
  else 
    Scierror("Error:	Argument should be a %s\n",type_get_name(nsp_type_sdpvar));
  return NULL;
}

int IsSdpvarObj(Stack stack, int i)
{
  return nsp_object_type(NthObj(i),nsp_type_sdpvar_id);
}

int IsSdpvar(NspObject *O)
{
  return nsp_object_type(O,nsp_type_sdpvar_id);
}

NspSdpvar  *GetSdpvarCopy(Stack stack, int i)
{
  if (  GetSdpvar(stack,i) == NULL ) return NULL;
  return MaybeObjCopy(&NthObj(i));
}

NspSdpvar  *GetSdpvar(Stack stack, int i)
{
  NspSdpvar *M;
  if (( M = nsp_sdpvar_object(NthObj(i))) == NULLSDPVAR)
     ArgMessage(stack,i);
  return M;
}

/*-----------------------------------------------------
 * constructor 
 * if type is non NULL it is a subtype which can be used to 
 * create a NspSdpvar instance 
 *-----------------------------------------------------*/

static NspSdpvar *nsp_sdpvar_create_void(char *name,NspTypeBase *type)
{
 NspSdpvar *H  = (type == NULL) ? new_sdpvar() : type->new();
 if ( H ==  NULLSDPVAR)
  {
   Sciprintf("No more memory\n");
   return NULLSDPVAR;
  }
 if ( nsp_object_set_initial_name(NSP_OBJECT(H),name) == NULLSTRING) return NULLSDPVAR;
 NSP_OBJECT(H)->ret_pos = -1 ;
 return H;
}

int nsp_sdpvar_create_partial(NspSdpvar *H)
{
  return OK;
}

int nsp_sdpvar_check_values(NspSdpvar *H)
{
  if ( H->basis == NULLSPCOLMAT) 
    {
     if (( H->basis = nsp_spcolmatrix_create("basis",'r',0,0) ) == NULLSPCOLMAT)
       return FAIL;
    }
  if ( H->lmi_variables == NULLMAT) 
    {
       if (( H->lmi_variables = nsp_matrix_create("lmi_variables",'r',0,0)) == NULLMAT)
       return FAIL;

    }
  if ( H->savedata == NULLLIST) 
    {
     if (( H->savedata = nsp_list_create("savedata")) == NULLLIST)
       return FAIL;
    }
  if ( H->extra == NULLLIST) 
    {
     if (( H->extra = nsp_list_create("extra")) == NULLLIST)
       return FAIL;
    }
  return OK;
}

NspSdpvar *nsp_sdpvar_create(char *name,NspSpColMatrix* basis,NspMatrix* lmi_variables,int n,int m,int typeflag,NspList* savedata,NspList* extra,NspTypeBase *type)
{
  NspSdpvar *H  = nsp_sdpvar_create_void(name,type);
  if ( H ==  NULLSDPVAR) return NULLSDPVAR;
  H->basis= basis;
  H->lmi_variables= lmi_variables;
  H->n=n;
  H->m=m;
  H->typeflag=typeflag;
  H->savedata= savedata;
  H->extra= extra;
  if ( nsp_sdpvar_check_values(H) == FAIL) return NULLSDPVAR;
#line 38 "codegen/sdpvar.override"
  /* verbatim in create/load/full_copy interface use NULL for returned value */
#line 494 "sdpvar.c"
  return H;
}


NspSdpvar *nsp_sdpvar_create_default(char *name)
{
 NspSdpvar *H  = nsp_sdpvar_create_void(name,NULL);
 if ( H ==  NULLSDPVAR) return NULLSDPVAR;
 if ( nsp_sdpvar_check_values(H) == FAIL) return NULLSDPVAR;
 return H;
}

/*
 * copy for gobject derived class  
 */

NspSdpvar *nsp_sdpvar_copy_partial(NspSdpvar *H,NspSdpvar *self)
{
  if ( self->basis == NULL )
    { H->basis = NULL;}
  else
    {
      if ((H->basis = (NspSpColMatrix *) nsp_object_copy_and_name("basis",NSP_OBJECT(self->basis))) == NULLSPCOLMAT) return NULL;
    }
  if ( self->lmi_variables == NULL )
    { H->lmi_variables = NULL;}
  else
    {
      if ((H->lmi_variables = (NspMatrix *) nsp_object_copy_and_name("lmi_variables",NSP_OBJECT(self->lmi_variables))) == NULLMAT) return NULL;
    }
  H->n=self->n;
  H->m=self->m;
  H->typeflag=self->typeflag;
  if ( self->savedata == NULL )
    { H->savedata = NULL;}
  else
    {
      if ((H->savedata = (NspList *) nsp_object_copy_and_name("savedata",NSP_OBJECT(self->savedata))) == NULLLIST) return NULL;
    }
  if ( self->extra == NULL )
    { H->extra = NULL;}
  else
    {
      if ((H->extra = (NspList *) nsp_object_copy_and_name("extra",NSP_OBJECT(self->extra))) == NULLLIST) return NULL;
    }
  return H;
}

NspSdpvar *nsp_sdpvar_copy(NspSdpvar *self)
{
  NspSdpvar *H  =nsp_sdpvar_create_void(NVOID,(NspTypeBase *) nsp_type_sdpvar);
  if ( H ==  NULLSDPVAR) return NULLSDPVAR;
  if ( nsp_sdpvar_copy_partial(H,self)== NULL) return NULLSDPVAR;

  return H;
}
/*
 * full copy for gobject derived class
 */

NspSdpvar *nsp_sdpvar_full_copy_partial(NspSdpvar *H,NspSdpvar *self)
{
  if ( self->basis == NULL )
    { H->basis = NULL;}
  else
    {
      if ((H->basis = (NspSpColMatrix *) nsp_object_full_copy_and_name("basis",NSP_OBJECT(self->basis))) == NULLSPCOLMAT) return NULL;
    }
  if ( self->lmi_variables == NULL )
    { H->lmi_variables = NULL;}
  else
    {
      if ((H->lmi_variables = (NspMatrix *) nsp_object_full_copy_and_name("lmi_variables",NSP_OBJECT(self->lmi_variables))) == NULLMAT) return NULL;
    }
  H->n=self->n;
  H->m=self->m;
  H->typeflag=self->typeflag;
  if ( self->savedata == NULL )
    { H->savedata = NULL;}
  else
    {
      if ((H->savedata = (NspList *) nsp_object_full_copy_and_name("savedata",NSP_OBJECT(self->savedata))) == NULLLIST) return NULL;
    }
  if ( self->extra == NULL )
    { H->extra = NULL;}
  else
    {
      if ((H->extra = (NspList *) nsp_object_full_copy_and_name("extra",NSP_OBJECT(self->extra))) == NULLLIST) return NULL;
    }
  return H;
}

NspSdpvar *nsp_sdpvar_full_copy(NspSdpvar *self)
{
  NspSdpvar *H  =nsp_sdpvar_create_void(NVOID,(NspTypeBase *) nsp_type_sdpvar);
  if ( H ==  NULLSDPVAR) return NULLSDPVAR;
  if ( nsp_sdpvar_full_copy_partial(H,self)== NULL) return NULLSDPVAR;

#line 38 "codegen/sdpvar.override"
  /* verbatim in create/load/full_copy interface use NULL for returned value */
#line 595 "sdpvar.c"
  return H;
}

/*-------------------------------------------------------------------
 * wrappers for the NspSdpvar
 * i.e functions at Nsp level 
 *-------------------------------------------------------------------*/

int int_sdpvar_create(Stack stack, int rhs, int opt, int lhs)
{
  NspSdpvar *H;
  CheckStdRhs(0,0);
  /* want to be sure that type sdpvar is initialized */
  nsp_type_sdpvar = new_type_sdpvar(T_BASE);
  if(( H = nsp_sdpvar_create_void(NVOID,(NspTypeBase *) nsp_type_sdpvar)) == NULLSDPVAR) return RET_BUG;
  /* then we use optional arguments to fill attributes */
  if ( int_create_with_attributes((NspObject  *) H,stack,rhs,opt,lhs) == RET_BUG)  return RET_BUG;
 if ( nsp_sdpvar_check_values(H) == FAIL) return RET_BUG;
#line 38 "codegen/sdpvar.override"
  /* verbatim in create/load/full_copy interface use RET_BUG for returned value */
#line 616 "sdpvar.c"
  MoveObj(stack,1,(NspObject  *) H);
  return 1;
} 

/*-------------------------------------------
 * Methods
 *-------------------------------------------*/
static NspMethods *sdpvar_get_methods(void) { return NULL;};
/*-------------------------------------------
 * Attributes
 *-------------------------------------------*/

static NspObject *_wrap_sdpvar_get_basis(void *self,const char *attr)
{
  NspSpColMatrix *ret;

  ret = ((NspSdpvar *) self)->basis;
  return (NspObject *) ret;
}

static NspObject *_wrap_sdpvar_get_obj_basis(void *self,const char *attr, int *copy)
{
  NspSpColMatrix *ret;

  *copy = FALSE;
  ret = ((NspSpColMatrix*) ((NspSdpvar *) self)->basis);
  return (NspObject *) ret;
}

static int _wrap_sdpvar_set_basis(void *self,const char *attr, NspObject *O)
{
  NspSpColMatrix *basis;

  if ( ! IsSpColMat(O) ) return FAIL;
  if ((basis = (NspSpColMatrix *) nsp_object_copy_and_name(attr,O)) == NULLSPCOLMAT) return FAIL;
  if (((NspSdpvar *) self)->basis != NULL ) 
    nsp_spcolmatrix_destroy(((NspSdpvar *) self)->basis);
  ((NspSdpvar *) self)->basis= basis;
  return OK;
}

static NspObject *_wrap_sdpvar_get_lmi_variables(void *self,const char *attr)
{
  NspMatrix *ret;

  ret = ((NspSdpvar *) self)->lmi_variables;
  return (NspObject *) ret;
}

static NspObject *_wrap_sdpvar_get_obj_lmi_variables(void *self,const char *attr, int *copy)
{
  NspMatrix *ret;

  *copy = FALSE;
  ret = ((NspMatrix*) ((NspSdpvar *) self)->lmi_variables);
  return (NspObject *) ret;
}

static int _wrap_sdpvar_set_lmi_variables(void *self,const char *attr, NspObject *O)
{
  NspMatrix *lmi_variables;

  if ( ! IsMat(O) ) return FAIL;
  if ((lmi_variables = (NspMatrix *) nsp_object_copy_and_name(attr,O)) == NULLMAT) return FAIL;
  if (((NspSdpvar *) self)->lmi_variables != NULL ) 
    nsp_matrix_destroy(((NspSdpvar *) self)->lmi_variables);
  ((NspSdpvar *) self)->lmi_variables= lmi_variables;
  return OK;
}

static NspObject *_wrap_sdpvar_get_n(void *self,const char *attr)
{
  int ret;

  ret = ((NspSdpvar *) self)->n;
  return nsp_new_double_obj((double) ret);
}

static int _wrap_sdpvar_set_n(void *self,const char *attr, NspObject *O)
{
  int n;

  if ( IntScalar(O,&n) == FAIL) return FAIL;
  ((NspSdpvar *) self)->n= n;
  return OK;
}

static NspObject *_wrap_sdpvar_get_m(void *self,const char *attr)
{
  int ret;

  ret = ((NspSdpvar *) self)->m;
  return nsp_new_double_obj((double) ret);
}

static int _wrap_sdpvar_set_m(void *self,const char *attr, NspObject *O)
{
  int m;

  if ( IntScalar(O,&m) == FAIL) return FAIL;
  ((NspSdpvar *) self)->m= m;
  return OK;
}

static NspObject *_wrap_sdpvar_get_typeflag(void *self,const char *attr)
{
  int ret;

  ret = ((NspSdpvar *) self)->typeflag;
  return nsp_new_double_obj((double) ret);
}

static int _wrap_sdpvar_set_typeflag(void *self,const char *attr, NspObject *O)
{
  int typeflag;

  if ( IntScalar(O,&typeflag) == FAIL) return FAIL;
  ((NspSdpvar *) self)->typeflag= typeflag;
  return OK;
}

static NspObject *_wrap_sdpvar_get_savedata(void *self,const char *attr)
{
  NspList *ret;

  ret = ((NspSdpvar *) self)->savedata;
  return (NspObject *) ret;
}

static NspObject *_wrap_sdpvar_get_obj_savedata(void *self,const char *attr, int *copy)
{
  NspList *ret;

  *copy = FALSE;
  ret = ((NspList*) ((NspSdpvar *) self)->savedata);
  return (NspObject *) ret;
}

static int _wrap_sdpvar_set_savedata(void *self,const char *attr, NspObject *O)
{
  NspList *savedata;

  if ( ! IsList(O) ) return FAIL;
  if ((savedata = (NspList *) nsp_object_copy_and_name(attr,O)) == NULLLIST) return FAIL;
  if (((NspSdpvar *) self)->savedata != NULL ) 
    nsp_list_destroy(((NspSdpvar *) self)->savedata);
  ((NspSdpvar *) self)->savedata= savedata;
  return OK;
}

static NspObject *_wrap_sdpvar_get_extra(void *self,const char *attr)
{
  NspList *ret;

  ret = ((NspSdpvar *) self)->extra;
  return (NspObject *) ret;
}

static NspObject *_wrap_sdpvar_get_obj_extra(void *self,const char *attr, int *copy)
{
  NspList *ret;

  *copy = FALSE;
  ret = ((NspList*) ((NspSdpvar *) self)->extra);
  return (NspObject *) ret;
}

static int _wrap_sdpvar_set_extra(void *self,const char *attr, NspObject *O)
{
  NspList *extra;

  if ( ! IsList(O) ) return FAIL;
  if ((extra = (NspList *) nsp_object_copy_and_name(attr,O)) == NULLLIST) return FAIL;
  if (((NspSdpvar *) self)->extra != NULL ) 
    nsp_list_destroy(((NspSdpvar *) self)->extra);
  ((NspSdpvar *) self)->extra= extra;
  return OK;
}

static AttrTab sdpvar_attrs[] = {
  { "basis", (attr_get_function *)_wrap_sdpvar_get_basis, (attr_set_function *)_wrap_sdpvar_set_basis,(attr_get_object_function *)_wrap_sdpvar_get_obj_basis, (attr_set_object_function *)int_set_object_failed },
  { "lmi_variables", (attr_get_function *)_wrap_sdpvar_get_lmi_variables, (attr_set_function *)_wrap_sdpvar_set_lmi_variables,(attr_get_object_function *)_wrap_sdpvar_get_obj_lmi_variables, (attr_set_object_function *)int_set_object_failed },
  { "n", (attr_get_function *)_wrap_sdpvar_get_n, (attr_set_function *)_wrap_sdpvar_set_n,(attr_get_object_function *)int_get_object_failed, (attr_set_object_function *)int_set_object_failed },
  { "m", (attr_get_function *)_wrap_sdpvar_get_m, (attr_set_function *)_wrap_sdpvar_set_m,(attr_get_object_function *)int_get_object_failed, (attr_set_object_function *)int_set_object_failed },
  { "typeflag", (attr_get_function *)_wrap_sdpvar_get_typeflag, (attr_set_function *)_wrap_sdpvar_set_typeflag,(attr_get_object_function *)int_get_object_failed, (attr_set_object_function *)int_set_object_failed },
  { "savedata", (attr_get_function *)_wrap_sdpvar_get_savedata, (attr_set_function *)_wrap_sdpvar_set_savedata,(attr_get_object_function *)_wrap_sdpvar_get_obj_savedata, (attr_set_object_function *)int_set_object_failed },
  { "extra", (attr_get_function *)_wrap_sdpvar_get_extra, (attr_set_function *)_wrap_sdpvar_set_extra,(attr_get_object_function *)_wrap_sdpvar_get_obj_extra, (attr_set_object_function *)int_set_object_failed },
  { NULL,NULL,NULL,NULL,NULL },
};


/*-------------------------------------------
 * functions 
 *-------------------------------------------*/
/*----------------------------------------------------
 * Interface 
 * i.e a set of function which are accessible at nsp level
 *----------------------------------------------------*/

static OpTab Sdpvar_func[]={
  { "sdpvar_create", int_sdpvar_create},
  { NULL, NULL}
};

/* call ith function in the Sdpvar interface */

int Sdpvar_Interf(int i, Stack stack, int rhs, int opt, int lhs)
{
  return (*(Sdpvar_func[i].fonc))(stack,rhs,opt,lhs);
}

/* used to walk through the interface table 
    (for adding or removing functions) */

void Sdpvar_Interf_Info(int i, char **fname, function (**f))
{
  *fname = Sdpvar_func[i].name;
  *f = Sdpvar_func[i].fonc;
}

#line 837 "sdpvar.c"
