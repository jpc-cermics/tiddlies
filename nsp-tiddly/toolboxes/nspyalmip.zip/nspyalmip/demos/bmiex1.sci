mode(1)
clc
// This example shows how to solve a simple BMI using PENBMI
//
// The problem is to find a feedback u = Lx so that the 
// L2 gain from w to y is minimized, for the system
//
// x' = Ax+Bu+Gw
// y  = Cx
//
// This can be formulated as the BMI
//
// min t
// s.t                                 P > 0
//     [(A+BL)P+P(A+BL)+C'C PG; G'P -tI] < 0
//
input('');
clc

// Generate a system
//P = ss(tf(1,[1 1 1 1]));
s=poly(0,"s");
P=syslin('c',1,1+s+s^2+s^3);
Sys=tf2ss(P);


A = Sys.a;
B = Sys.b;
G = Sys.b;
C = Sys.c;
input('');

// Define decision variables
P = sdpvar(3,3);
L = sdpvar(1,3);
t = sdpvar(1,1);
input('');

// A reasonble initial guess is valuable
Q=eye(3,3);R=1;
Big=sysdiag(Q,R);
[w,wp]=fullrf(Big);C1=wp(:,1:3);D12=wp(:,4:$);   

sl=syslin('c',A,B,C1,D12); 
[L0,P0]=lqr(sl);
setsdpvar(P,P0);
setsdpvar(L,-L0);
setsdpvar(t,100);
input('');
clc

// Define the BMI
F = sdp_set('[(A+B*L)''*P+P*(A+B*L)+C''*C P*G;G''*P -t]<0') + sdp_set('P>0');
input('');

// Solve, using the initial guess on P, L and t
solvesdp(F,t,sdpsettings('solver','lmisolver','usex0',1))
Double(L)
input('');
mode(0)
