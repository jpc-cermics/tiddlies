clc
mode(1)

//to clear all variables properly need to execute next two instructions in pair
yalmip('clear')
exec(YALMIP_PATH+'\yalmipclear.sci')
//*********************************************************
//
// Modeling and solving KYP problems
//
//*********************************************************
//
// This example requires the KYPD-solver.
//
// We will show how we can use the dedicated
// KYPD solver to solve a L2-gain analysis problem.
//
// minimize t
//  s.t [A'P+PA+C'C PB;B'P -t] < 0
//                           P > 0
// 
input('');

// Define a random stable system
n = 30;
A = rand(n,n,'normal');
A = A - max(real(spec(A)))*eye(n,n)*1.5;
B = rand(n,1,'normal');
C = rand(1,n,'normal');
input('');

// YALMIP variables
t = sdpvar(1,1);
P = sdpvar(n,n);
input('');

// KYP constraint 
// NOTE : Do not add the constraint P>0
// if you want to use the KYPD solver)
F = sdp_set(kyp(A,B,P,blkdiag(C'*C,-t)) < 0)
input('');

// Solve using dedicated solver
sol1 = solvesdp(F,t,sdpsettings('solver','kypd'));
input('');

// Solve using SeDuMi (or any other standard SDP solver)
sol2 = solvesdp(F,t,sdpsettings('solver','csdp'));
input('');

// Compare solution time (this can be a bit mis-leadinhg due to memory caching etc...)
// KYPD should typically be a lot faster than the straight-forward solution
disp(sol1.solvertime/sol2.solvertime)

input('');
mode(0)
