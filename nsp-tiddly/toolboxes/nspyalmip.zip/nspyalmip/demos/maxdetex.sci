clc
mode(1)
//*********************************************************
//
// Determinant maximization problem
//
//*********************************************************
//
// YALMIP can be used to model determinant maximization 
// problems, and solve these problems using any SDP solver 
// (i.e., the dedicated solver MAXDET is not needed)
input('');
clc
// Consider the discrete-time system x(k+1)=Ax(k+1)+Bu(k), u = -Lx
A = [1 0;0.4 1];
B = [0.4;0.08]; 
L = [1.9034 1.1501];

// We want to find the largest possible invariant ellipsoid x'(Y^-1)x < 1
// for which a control constraint |u|<1 is satisfied
// This can be formulated as a determinant maximization problem
input(''); // Strike enter to continue. 

// Define the symmetric matrix Y
Y = sdpvar(2,2);
input(''); // Strike enter to continue. 

// Define LMI for invariance and constraint satisfaction
F = sdp_set( [Y Y*(A-B*L)';(A-B*L)*Y Y] > 0);
F = F + sdp_set(L*Y*L' <1);
input(''); // Strike enter to continue. 

// Y should be positive definite and we which
// to maximize det(Y) (typically written as minimize -log det(Y))
solution = solvesdp(F,-logdet(Y));
input(''); // Strike enter to continue. 

// Get result
Y = Double(Y)
input(''); // Strike enter to continue.
mode(0)
