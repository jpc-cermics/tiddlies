clc
mode(1)

// YALMIP supports mixed integer (LP/QP/SOCP/SDP) programming.
// If no specialized MIP solver is installed, such as GLPK,
// an internal branch-and bound scheme is applied, using the installed
// solvers for solving the node problems.
//
// Notice that this is a very rudimentary branch-and-bound solver, so
// for performance and anything but small academic examples, a dedicated 
// integer solver is required.
//
// Type help bnb to obtain inforamtion about the solver.
//
// Let us test the internal solver on MILP, MIQP, MISOCPP and MISDPP

input('');
yalmip('clear')
exec(YALMIP_PATH+'\yalmipclear.sci')
clc

// We are given a noisy Toeplitz matrix P, and the goal is to find an 
// integer Toeplitz matrix Z minimizing sum_i sum_j |Pij-Zij| 
//
// Obviously, this is a MILP problem.
//
input(''); // Strike any key to continue. 

// Create a noisy Toeplitz matrix
n = 5;
P = toeplitz(rand(n,1,'normal')*100)+rand(n,n,'normal')*5
input(''); // Strike any key to continue. 

// Define an integer Toeplitz matrix
Z = intvar(n,n,'toeplitz');
input(''); // Strike any key to continue. 

// Introduce a variable to deal with the absolute values
// note : P is not symmetric so constraints are automatically
// interpreted as element-wise.
t = sdpvar(n,n,'full');
F = sdp_set(-t < P-Z < t);
input(''); // Strike any key to continue. 

// Solve (using the internal branch-and-bound solver
// Turn on display in branching, but turn off display in 
// the local LP-solver
solvesdp(F,sum(sum(t)),sdpsettings('solver','csdp','verbose',2));
input(''); // Strike any key to continue. 

// Check the result
disp(P)
Double(Z)
input('');

clc
// As an alternative, let us solve the corrsponding MIQP
// problem where we minimize sum_i sum_j |Pij-Zij|^2
input('');

// Define the residuals
e = P(:)-Z(:)
// and optimize
solvesdp([],e'*e,sdpsettings('solver','csdp','verbose',2));
input(''); // Strike any key to continue. 

// Check the result
disp(P)
Double(Z)
input('');


clc
// Finally, let us do things the hard way, and formulate
// the problem a mixed integer second order cone problem!
input('');

// Define the residuals
e = P(:)-Z(:)
// and a bound
t = sdpvar(1,1);
// and optimize the bound t subject to ||e||<t
solvesdp(sdp_set(cone(e,t)),t,sdpsettings('solver','csdp','verbose',2));
input(''); // Strike any key to continue. 

// Check the result
Double(P)
Double(Z)
input('');


clc
// ...or why not a plain stupid implementation using
// mixed integer semi-definite programming!
input('');

// A Shur complement gives a LMI
F = sdp_set([t e';e eye(max(size(e)),max(size(e)))]>0);
solvesdp(F,t,sdpsettings('solver','bnb','verbose',2));
input(''); // Strike any key to continue. 

// Check the result
disp(P)
Double(Z)
input('');
mode(0)


