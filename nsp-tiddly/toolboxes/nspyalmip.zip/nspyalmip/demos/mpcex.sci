clc
mode(1)
clc
mode(1)
//*********************************************************
//
// Model predictive control example
//
//*********************************************************
//
// In this example, we solve quadratic problems using
// semidefinite programming, second order cone programming
// and quadratic programming.

// MPC settings
N = 5;
input(''); // Strike enter to continue. 

// Create numerics for a discretized double integrator
A = [2 -1;1 0];
B = [1;0];
C = [0.5 0.5];

[H,S] = create_CHS(A,B,C,N)
input(''); // Strike enter to continue. 

// Initial state
x = [2;0];

// Define free variables
t = sdpvar(1,1);
U = sdpvar(N,1);   
input(''); // Strike enter to continue. 

// Define the prediction vector
Y = H*x+S*U; 
input(''); // Strike enter to continue. 

// Control constraints 
F = sdp_set(-1 < U < 1);

// Terminal constraint
F = F+sdp_set(-1 < Y(N) < 1);  
input(''); // Strike enter to continue. 

// Our goal is to minimize the quadratic function Y'*Y+U'*U
//
// Performance constraint written as an SDP using Schur complement
// (very inefficient way to solve a QP...)
F = F+sdp_set([t Y' U';Y eye(N,N) zeros(N,N);U zeros(N,N) eye(N,N)]>0)
input(''); // Strike enter to continue. 

// Solve
sol = solvesdp(F,t);
input(''); // Strike enter to continue. 

// Look at solution
disp(Double(U)) 
disp(Double(Y(N))) 
input(''); // Strike enter to continue. 
clc
// More efficient implementation using SOCP... (if SOCP solver available)
F =  sdp_set(-1 < U < 1) + sdp_set(-1 < Y(N) < 1) + sdp_set(cone([Y;U],t));
sol = solvesdp(F,t);
input(''); // Strike enter to continue. 
clc

// Even more efficient implementation if QP solver is available
F =  sdp_set(-1 < U < 1) + sdp_set(-1 < Y(N) < 1);
sol = solvesdp(F,Y'*Y+U'*U);
input(''); // Strike enter to continue. 


mode(0)
