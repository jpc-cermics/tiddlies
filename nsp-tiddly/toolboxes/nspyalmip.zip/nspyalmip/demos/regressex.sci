clc
mode(1)
yalmip('clear')
exec(YALMIP_PATH+'\yalmipclear.sci')

// This examle will show how to define LP and QP problems
//
// We will use YALMIP to formulate couple of regression problems 
// (linear L_1, L_2 and L_inf regression)
//
input('Strike enter to continue.'); 

// To begin with, we generate data according to a noisy linear regression
// 
// y(t) = x'(t)*a+e(t), t=0,0.01,...,2*pi

a = [1 2 3 4 5 6];
t = (0:0.02:2*%pi)';
x = [sin(t) sin(2*t) sin(3*t) sin(4*t) sin(5*t) sin(6*t)];
y = x*a'+(-4+8*rand(size(x,1),1));
input('Strike enter to continue...');   
plot(y)
input('Strike enter to continue...');   

// We now want to estimate the parameter a, given y, and we will 
// try 3 different approaches; L_1, L_2 and L_inf. 
//
// We start by defining the decision variable

a_hat = sdpvar(1,6);
input('Strike enter to continue...');   

// By using a_hat and the regressor x, we can define the residuals

residuals = y-x*a_hat';
input('Strike enter to continue...');   

// To solve the L_1 problem, we define a variable that will work
// as a bound on |y-x'*a|
bound = sdpvar(size(residuals,1),1);
input('Strike enter to continue...');   

// Express that bound is absolute value of the residuals (usinhg a double-sided constraint)
F = sdp_set(-bound < residuals < bound);
input('Strike enter to continue...');   
disp(F)
// Minimize sum of bound
// NOTE, This takes time if you only have linprog installed
solvesdp(F,sum(bound));
// Optimal L_1 estimate
a_L1 = Double(a_hat)
input('Strike enter to continue...');   


clc

// The L_2 solution is easily obtained from a QP
// (note the nonlinear objetive function. More about
//  this in demo #11)
solvesdp([],residuals'*residuals,sdpsettings('solver','csdp'));
a_L2 = double(a_hat)
input('Strike enter to continue...');   

// Finally, let us minimize the L_inf norm. This corresponds to
// minimizing the largest (absolute value) residual
// We introduce a scalar bound on the largest value
bound = sdpvar(1,1);
F = sdp_set(-bound < residuals < bound);
input('Strike enter to continue...');   

// Solve by minimizing the bound
solvesdp(F,bound);
a_Linf = Double(a_hat)
input('Strike enter to continue...');   

plot([y x*a' x*a_L1' x*a_L2' x*a_Linf'])
legend('Measured','True','L1','L2','Linf')

mode(0)










