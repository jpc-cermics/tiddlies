clc
mode(1)

//*********************************************************
//
// //Second order cone programming
//
//*********************************************************
// 
// The problem is to find the point in the intersection of
// two circles which is closest to the origin
input(''); // Strike enter to continue. 

// The two circles are centered at a and b with radius 1,
// and the point we are looking for will be denoted x
a = [0;1];
b = [1;1];
x = sdpvar(2,1);
input(''); // Strike enter to continue. 

// The point lies in both circles
F = sdp_set('||x-a||<1')+sdp_set('||x-b||<1');
input('');

// An alternative way to define the SOCPs is 
F = sdp_set(cone(x-a,1))+sdp_set(cone(x-b,1));
input('');


// The distance to the origin is limited
// by a constant t
t = sdpvar(1,1);
F = F+sdp_set('||x||<t');
input(''); // Strike enter to continue. 


// And we wish to minimize the distance
sol = solvesdp(F,t);
input(''); // Strike enter to continue. 

// Optimal point
Double(x)

// Distance from origin
Double(t)

// Which of-course equals ||x||
norm(Double(x))

input(''); // Strike enter to continue. 
mode(0)
