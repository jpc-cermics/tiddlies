clc
mode(1)
//*********************************************************
//
// Lyapunov analysis using semidefinite programming
//
//*********************************************************

// Create a stable matrix
A = [-1 2;0 -2];
input(''); // Strike enter to continue. 

// Create symmetric matrix (full syntax)
P = sdpvar(2,2,'symmetric'); 
input(''); // Strike enter to continue. 

// Add SETs for stability
F = sdp_set('P>eye(2,2)') + sdp_set('A''*P+P''*A<0')
input(''); // Strike enter to continue. 

// Find feasible solution, minimize trace(P)
solution = solvesdp(F,sdp_trace(P));
input(''); // Strike enter to continue. 

// Extract numerical solution
P_feasible = Double(P);

// Check solution
disp(spec(P_feasible))
disp(spec(A'*P_feasible+P_feasible'*A))
input(''); // Strike enter to continue. 

// Checking the constraints can also be done wit
checkset(F)

input(''); // Strike enter to continue. 
mode(0)
