libname  = 'libyalmip' 	
libtitle='NSPYALMIP';

// macros. 

add_lib('macros',compile=%t);

// loader for src 

exec('c-code/loader.sce');

printf(libtitle+' loaded\n');

// path to here 
mpinsp_path = get_current_exec_dir()

