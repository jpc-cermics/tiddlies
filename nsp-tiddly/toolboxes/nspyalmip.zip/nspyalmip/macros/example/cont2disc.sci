function [ad,bd,Qd,Rd,Nd] = cont2disc(a,b,q,r,nn,Ts)
//see help on LQRD

nargin=argn(2);
ni = nargin

// no such checking functions in scilab. comment it!!!
//error(nargchk(5,6,nargin));
//[msg,a,b] = abcdchk(a,b); error(msg);

Nx = size(a,1); 
Nu = size(b,2);
// Set Ts and NN properly
if ni==5 then
   Ts = nn;
   nn = zeros(Nx,Nu);
end

// Check dimensions and symmetry

//if or(size(r,'c')~=Nu),
//   error('The R matrix must be square with as many columns as B.')
//elseif ~isequal(size(nn,nn),[Nx Nu]),
//   error('The B and N matrices must be the same size.')
//elseif norm(q'-q,1) > 100*%eps*norm(q,1),
//   warning('Q is not symmetric and has been replaced by (Q+Q'')/2).')
//elseif norm(r'-r,1) > 100*%eps*norm(r,1),
//   warning('R is not symmetric and has been replaced by (R+R'')/2).')
//end

// Enforce symmetry and check positivity
q = (q+q')/2;
r = (r+r')/2;
vr = real(spec(r));
vqnr = real(spec([q nn;nn' r]));
if min(vr)<=0,
   error('The R matrix must be positive definite.')
elseif min(vqnr)<-1e2*%eps*max(0,max(vqnr)),
   warning('The matrix [Q N;N'' R] should be positive semi-definite.')
end

// Determine discrete equivalent of continuous cost function 
// along with Ad,Bd matrices of discretized system
n = Nx+Nu;
Za = zeros(Nx,Nx); Zb = zeros(Nx,Nu); Zu = zeros(Nu,Nu);
M = [ -a' Zb   q  nn
      -b' Zu  nn'  r
      Za  Zb   a   b
      Zb' Zu  Zb' Zu];
phi = expm(M*Ts);
phi12 = phi(1:n,n+1:2*n);
phi22 = phi(n+1:2*n,n+1:2*n);
QQ = phi22'*phi12;
QQ = (QQ+QQ')/2;        // Make sure QQ is symmetric
Qd = QQ(1:Nx,1:Nx);
Rd = QQ(Nx+1:n,Nx+1:n);
Nd = QQ(1:Nx,Nx+1:n);
ad = phi22(1:Nx,1:Nx);
bd = phi22(1:Nx,Nx+1:n);
endfunction
