function q = weight(a,b,p)
s = size(a);
n = s(1);
c = eye(s);
d = zeros(size(b));
q = zeros(s);
p = m2p(p).coeffs; 

//create poly from matrix
p1 = m2p([0 1]);
p2 = det(p1*eye(s(1),s(2))-a)
f = p2.coeffs{1};

f = f(2:n+1);
m = f;
for ii = 1:n-1,
	c = [ f(ii+1:n) zeros(1,ii) ];
	m = [m;c];
end;

//Form a controlability matrix
gg = contr(a,b(:,1));
g=[];
for ii =0:gg-1,
  g = cat(2,g,(a^ii)*b(:,1));
end

if rcond(g) < %eps
	error('System must be controllable from first input.');
end;
T = g*m;
a = inv(T)*a*T;

for k = 1:n,
  q(k,k)=0;
	if k<=floor((n+1)./2)
		for ii = 1:2*k-1,
			q(k,k) = q(k,k) + (p(ii)*p(2*k-ii)-a(n,ii)*a(n,2*k-ii))*(-1)^(k+ii);
		end;
	else
		for ii = 1:2*k-1,
			t = 2*k-ii;
			if (ii <= n) & (t <= n)
				q(k,k) = q(k,k) + (p(ii)*p(t)-a(n,ii)*a(n,t))*(-1)^(k+ii);
			end;
		end;
		q(k,k) = q(k,k) + 2*(-1)^(n+k-1)*(p(2*k-n-1)+a(n,2*k-n-1));
	end;
end;
q = inv(T')*q*inv(T);

endfunction
