function [interfacedata,recoverdata,solver,diagnostic,F] = compileinterfacedata(F,G,P,h,options,findallsolvers)

global CACHED_SOLVERS;
diagnostic = [];
interfacedata = [];
recoverdata = [];
solver = [];
// ******************************************
// EXTRACT LOW-RANK DESCRIPTION
// ******************************************
lowrankdetails = getlrdata(F);
if ~isempty(lowrankdetails) then
    F = F(~is(F,'lowrank'));
end

// ******************************************
// PERTURB STRICT INEQULAITIES?
// ******************************************
if (type(options.shift,'string') == 'Sdpvar') | (options.shift~=0) then
    F = shift(F,options.shift);
end

// ******************************************
// ADD RADIUS CONSTRAINT?
// ******************************************
if (type(options.radius,'string') == 'Sdpvar') | ~isinf(options.radius) then
    x = recover(unique(union(depends(h),depends(F))));
    if length(x)>1 then
        F = F + set(cone(x,options.radius));
    else
        F = F + set(-options.radius < x < options.radius);
    end
end

// ******************************************
// CONVERT LOGIC CONSTRAINTS
// ******************************************
[F,changed] = convertlogics(F);

if changed then
    options.saveduals = 0; // We cannot calculate duals since we changed the problem
end
// // ******************************************
// // UNCERTAIN VARIABLES
// // ******************************************
// [F,changed] = robustify(F);
// if changed
//     options.saveduals = 0; // We cannot calculate duals since we changed the problem
// end

// ******************************************
// CONVERT CONVEX QUADRATIC CONSTRAINTS
// ******************************************

if (options.convertconvexquad > 0) && ~(options.solver=='bmibnb') && options.relax == 0 then
    [F,socp_changed] = convertquadratics(F);
    if socp_changed then// changed holds the number of QC -> SOCC conversions
        options.saveduals = 0; // We cannot calculate duals since we changed the problem
    end
else
    socp_changed = 0;
end

// ******************************************
// LOOK FOR AVAILABLE SOLVERS
// ******************************************

if (options.cachesolvers==0) | isempty(CACHED_SOLVERS) then
    solvers = getavailablesolvers(findallsolvers);
    CACHED_SOLVERS = solvers;
else
    solvers = CACHED_SOLVERS;
end

// ******************************************
// NO SOLVER AVAILABLE
// ******************************************
diagnostic = hash_create(10);

if isempty(solvers) then
    diagnostic.solvertime = 0;
    if isempty(options.solver) then
        diagnostic.info = yalmiperror(-2,'YALMIP');
        diagnostic.problem = -2;        
    else
        diagnostic.info = yalmiperror(-3,'YALMIP');
        diagnostic.problem = -3;        
    end
    if (options.Warning > 0) && isempty(strindex(diagnostic.info,'No problems detected')) then
        printf("%s\n",sprintf(strcat(['Warning: ', diagnostic.info])));
    end
    return
end

// CHEAT FOR QC
if socp_changed>0 & length(find(is(F,'socc')))==socp_changed then
    socp_are_really_qc = 1;
else
    socp_are_really_qc = 0;
end
   
// ******************************************
// TRY TO SELECT SUITABLE SOLVER
// ******************************************

[ProblemString,integer_variables,binary_variables,parametric_variables,quad_info]  = catsdp(F,G,h,options.relax);

// Relax ?
if options.relax then
    ProblemString = strsubst(ProblemString,'DI','');
    ProblemString = strsubst(ProblemString,'DB','');
    ProblemString = strsubst(ProblemString,'DP','');
    ProblemString = strsubst(ProblemString,'OQ','');
end

[solver,problem] = selectsolver(options,ProblemString,solvers,socp_are_really_qc);
if isempty(solver)    then
    diagnostic.solvertime = 0;
    if problem == -4 then
        diagnostic.info = yalmiperror(problem,convstr(options.solver,"u"));
    else
        diagnostic.info = yalmiperror(problem,'YALMIP');
    end
    diagnostic.problem = problem;   
    
    if (options.Warning) then
        printf("%s\n",strcat(['Warning: ', diagnostic.info]));
    end
    return
end
 solver = solver{1,1};

if length(solver.version)>0 then
    solver.tag = strcat([solver.tag, '-', solver.version]);
end

// *****************************************
// DID WE SELECT THE INTERNAL BNB SOLVER
// IN THAT CASE, SELECT LOCAL SOLVER
// (UNLESS ALREADY SPECIFIED IN OPTIONS.BNB)
// *****************************************
localsolver.qc = 0;
if solver.tag=='bnb' then
    temp_options = options;
    temp_options.solver = options.bnb.solver;
    localsolver = selectsolver(temp_options,strsubst(strsubst(ProblemString,'DI',''),'DB',''),solvers,socp_are_really_qc);
    if isempty(localsolver) | localsolver.tag=='bnb' then       
        diagnostic.solvertime = 0;
        diagnostic.info = yalmiperror(-2,'YALMIP');
        diagnostic.problem = -2;
        return
    end
    solver.subcall = localsolver.Call;
end

// *****************************************
// DID WE SELECT THE INTERNAL BMIBNB SOLVER
// IN THAT CASE, SELECT UPPER/LOWER SOLVERs
// (UNLESS ALREADY SPECIFIED IN OPTIONS)
// *****************************************
if solver.tag=='bmibnb' then
    temp_options = options;
    temp_options.solver = options.bmibnb.lowersolver;
   // if ~isempty(binary_variables)        
        binary_variables2 = binary_variables;
        ProblemString = strsubst(ProblemString,'DB','');
        binary_variables = [];     
        // end
          
    if isempty(strindex(ProblemString,'CS')) then
        localsolver = selectsolver(temp_options,strsubst(ProblemString,'CB','CE'),solvers);
    else
        localsolver = selectsolver(temp_options,strsubst(ProblemString,'CB','CS'),solvers);
    end    
    if isempty(localsolver) | localsolver.tag=='bmibnb' then        
        diagnostic.solvertime = 0;
        diagnostic.info = yalmiperror(-2,'YALMIP');
        diagnostic.problem = -2;
        return
    end
    solver.lowercall = localsolver.Call;
    
    temp_options = options;
    temp_options.solver = options.bmibnb.uppersolver;
    localsolver = selectsolver(temp_options,ProblemString,solvers);
    if isempty(localsolver) | localsolver.tag == 'bmibnb' then        
        diagnostic.solvertime = 0;
        diagnostic.info = yalmiperror(-2,'YALMIP');
        diagnostic.problem = -2;
        return
    end
    solver.uppercall = localsolver.Call;    
    
    temp_options = options;
    temp_options.solver = options.bmibnb.lpsolver;
    localsolver = selectsolver(temp_options,strsubst(strsubst(strsubst(ProblemString,'CB','CE'),'CS','CE'),'OQ',''),solvers);
    if isempty(localsolver) | localsolver.tag == 'bmibnb' then        
        diagnostic.solvertime = 0;
        diagnostic.info = yalmiperror(-2,'YALMIP');
        diagnostic.problem = -2;
        return
    end
    solver.lpcall = localsolver.Call;    
    
    binary_variables = binary_variables2;
    
end

// *****************************************
// DID WE SELECT THE INTERNAL MP SOLVER
// IN THAT CASE, SELECT LOCAL SOLVER
// (UNLESS ALREADY SPECIFIED IN OPTIONS.BNB)
// *****************************************
localsolver.qc = 0;
if solver.tag == 'mpcvx' then
    temp_options = options;
    temp_options.solver = options.mpcvx.solver;
    temp = strsubst(strsubst(ProblemString,'DI',''),'DB','');
    temp = strsubst(ProblemString,'MP','');
    localsolver = selectsolver(temp_options,temp,solvers,socp_are_really_qc);
    if isempty(localsolver) | localsolver.tag == 'mpcvx' then        
        diagnostic.solvertime = 0;
        diagnostic.info = yalmiperror(-2,'YALMIP');
        diagnostic.problem = -2;
        return
    end
    solver.subcall = localsolver.Call;
end


showprogress(strcat(['Solver chosen : ', solver.tag]),options.showprogress);

// ******************************************
// CONVERT TO STANDARD PROBlEMS
// ******************************************
if ~isempty(P) & solver.maxdet==0 then
    t = sdpvar(1,1);
    F = F + detset(t,P);
    if isempty(h) then
    h = -t;
    else
        h = h-t;
    end
end

if ~isempty(binary_variables) & (solver.binary==0) then
    x_bin = recover(binary_variables);
    F = F + lmi(x_bin<1)+lmi(x_bin>0);
    integer_variables = union(binary_variables,integer_variables);
    binary_variables = [];
end

if  (options.relax == 0 && ~isempty(quad_info) && solver.qp==0) || (~isempty(quad_info) && solver.tag == 'bnb' && localsolver.qp==0) then
   t = sdpvar(1,1);
   x = quad_info.x;
   R = quad_info.R;
   c = quad_info.c;
   f = quad_info.f;
   F = F + lmi(cone([2*R*x;1-(t-c'*x-full(f))],1+t-c'*x-full(f)));
   h = t;
   quad_info = [];
end

if solver.rotsocp == 0 then
    [F,changed] = convertlorentz(F);
    if changed
        options.saveduals = 0; // We cannot calculate duals since we change the problem
    end
end

// Whoa, horrible tests to find out when to convert SOCP to SDP
// This should not be done if :
//   1. Problem is actually a QCQP and solver supports this
//   2. Problem is integer, local solver supports SOCC
//   3. Solver supports SOCC

if ~((solver.qc == 1) && socp_are_really_qc > 0) then
    if ~(solver.tag=='bnb' & socp_are_really_qc > 0 & localsolver.qc==1 ) then
        if ((solver.socp == 0) || (solver.tag=='bnb' && localsolver.socp==0)) then
            [F,changed] = convertsocp(F);
            if changed then
                options.saveduals = 0; // We cannot calculate duals since we change the problem
            end
        end
    end
end

if ((solver.Complex==0) && ~(strindex(ProblemString,'DX')==[])) || ((solver.tag=='bnb' && localsolver.Complex==0) && ~(strindex(ProblemString,'DX')==[])) then
    showprogress('Converting to real constraints',options.showprogress)
    F = imag2reallmi(F);
    options.saveduals = 0; // We cannot calculate duals since we change the problem
end

// **********************************************
// CREATE OBJECTIVE FUNCTION c'*x+x'*Q*x
// **********************************************
showprogress('Processing objective h(x)',options.showprogress);
try
    [c,Q,f,onlyfeasible]=createobjective(h,G,options,quad_info);
catch
    error("Can''t create objective function")
end

// **********************************************
// Convert {F(x),G(x)} to internal formats 
// **********************************************
showprogress('Processing F(x)',options.showprogress);

[F_struc,K,KCut] = lmi2sedumistruct(F);


K.m = max(size(sdpvar(G)));


// **********************************************
// SOME HORRIBLE CODE TO DETERMINE USED VARIABLES
// **********************************************
// Which sdpvar variables are actually in the problem
tmp = F_struc(:,2:$);
tmp_=[%f];
for i = 1:size(tmp,'c')
tmp_(i)=or(full(tmp(:,i)) ~= 0);
end

used_variables_LMI = find(tmp_);
used_variables_obj = find(or(c' ~= 0,dim=1) | or(full(Q) ~= 0,dim=1));
used_variables = unique1D([used_variables_LMI used_variables_obj]);

// The problem is that linear terms might be missing
monomtable = full(yalmip('monomtable'));

if options.relax then
    monomtable = [];
    nonlinearvariables = [];
else
    monomtable=full(monomtable);
    nonlinearvariables = find(~(sum(monomtable~=0,dim=2)==1 & sum(monomtable,dim=2)==1));
    monomtable = sparse(monomtable);
end
linearvariables = setdiff(used_variables,nonlinearvariables);

ismemb=ismember(nonlinearvariables,used_variables);

if or(ismemb ~= 0) then
needednonlinear = nonlinearvariables(ismemb);
else
needednonlinear=[];
end

linearinnonlinear = find(or(full(monomtable(needednonlinear,:)) ~= 0,dim=1));

missinglinear = setdiff(linearinnonlinear(:),linearvariables);

used_variables = unique(gsort([used_variables(:);missinglinear(:)],'g','i')');

// Check for unbounded variables
if %f then//isempty(sqrList) WHY did I remove these
    unbounded_variables = setdiff(used_variables_obj,used_variables_LMI);
    if ~isempty(unbounded_variables)
        // Remove unbounded variable from problem
        used_variables = setdiff(used_variables,unbounded_variables);
    end
end

// ****************************************
// REMOVE UNNECESSARY VARIABLES FROM PROBLEM
// ****************************************

if length(used_variables)<sdpvar('nvars') then
    c = c(used_variables);
    Q = Q(:,used_variables);Q = Q(used_variables,:);
    if ~isempty(F_struc) then
        F_struc = sparse(F_struc(:,[1 1+used_variables]));
    end
end

// ****************************************
// Map variables and constraints in low-rank definition to local stuff
// ****************************************
if ~isempty(lowrankdetails) then
    // Identifiers of the SDP constraints
    lmiid = getlmiid(F);
    //lmiid = find(ismember(lmiid(is(F,'sdp'),);
    for i = 1:length(lowrankdetails)
        lowrankdetails(i).id = find(ismember(lmiid,lowrankdetails(i).id));
        if ~isempty(lowrankdetails(i).variables) then
            lowrankdetails(i).variables = find(ismember(used_variables,lowrankdetails(i).variables));
        end
    end
end

// ****************************************
// SPECIAL VARIABLES
// ****************************************
if options.relax then
    nonlins = [];
end

if options.relax then
    integer_variables = [];
    binary_variables  = [];
else
    if (integer_variables ~= []) then
      integer_variables = find(ismember(used_variables,integer_variables));
    end
    if (binary_variables ~=[]) then
      binary_variables  = find(ismember(used_variables,binary_variables));
    end
end
if (parametric_variables~=[]) then
parametric_variables  = find(ismember(used_variables,parametric_variables));
end

if (K.f>0)  then
    // If user explicitely says remove, or user yas nothing but slverdefinitions does
    // FIX : CHECK FOR NONLINEARS
    if ((options.removeequalities==1) & isempty(intersect(used_variables,nonlinearvariables))) | ((options.removeequalities==0) & (solver.equalities==-1)) then
        showprogress('Solving equalities',options.showprogress);   
        [x_equ,H,A_equ,b_equ] = solveequalities(F_struc,K);
        // Exit if no consistent solution exist
        if (norm(A_equ*x_equ-b_equ)>10) then//sqrt(eps)*size(A_equ,2))            
            diagnostic.solvertime = 0;
            diagnostic.info = yalmiperror(1,'YALMIP');
            diagnostic.problem = 0;
            solution = diagnostic;
            solution.variables = used_variables(:);
            solution.optvar = x_equ;
            // And we are done! Save the result
            sdpvar('setSolution',solution);
            return
        end
        // We dont need the rows for equalities anymore
        F_struc = F_struc(K.f+1:length(F_struc),:);
        K.f = 0;
        Fold = F;
        [nlmi neq]=size(F);
        F = lmi;
        for i = 1:nlmi+neq
            if ~is(Fold(i),'equality') then
                F = F + Fold(i);
            end
        end
        
        // No variables left!
        if size(H,2)==0 then           
            diagnostic.solvertime = 0;
            diagnostic.info = yalmiperror(0,'YALMIP');
            diagnostic.problem = 0;
            solution = diagnostic;
            solution.variables = used_variables(:);
            solution.optvar = x_equ;
            // And we are done! Save the result
            // Note, no dual is saved        
            sdpvar('setSolution',solution);
            p = checkset(F);
            if or(p<1e-5) then
                diagnostic.info = yalmiperror(1,'YALMIP');
                diagnostic.problem = 1;
            end
            return
        end
        showprogress('Converting problem to new basis',options.showprogress)
        // objective in new basis
        c = H'*c;
        Q = H'*Q*H;
        // LMI in new basis
        F_struc = [F_struc*[1;x_equ] F_struc(:,2:size(F_struc,'c'))*H];    
    else
        // Solver does not support equality constraints
        // and they hould be removed using double-sided
        // or user just want to remove them
         if (solver.equalities==0 | options.removeequalities==2) then
            // Add equalities
            F_struc = [-F_struc(1:1:K.f,:);F_struc];
            K.l = K.l+K.f*2;
            // Keep this in mind...
            K.fold = K.f;   
            K.f = 0;
        end
        // For simpliciy we introduce a dummy coordinate change
        x_equ = 0;
        H     = 1;
    end
else
    x_equ = 0;
    H     = 1;
end    


// **************************************************
// INITIAL SOLUTION
// **************************************************
x0 = [];
if options.usex0 then
    x0_used = Double(recover(used_variables));
    x0 = zeros(sdpvar('nvars'),1);
    x0(used_variables)  = x0_used(:);   
    x0(isnan(x0))=0;
end

if ~isempty(x0) then
    // Get a coordinate in the reduced space
    x0 = H\(x0(used_variables)-x_equ);
end

solveroutput = [];


// Monomial table for nonlinear variables
// FIX : Why here!!! mt handled above also
mt = yalmip('monomtable');
if size(mt,1)>size(mt,2) then
    mt(size(mt,1),size(mt,1)) = 0;
end
// In local variables
mt = mt(used_variables,used_variables);
if options.relax then
    mt = eye(length(used_variables),length(used_variables));
end

// ********************************
// GENERAL DATA EXCANGE WITH SOLVER
// ********************************
interfacedata=hash_create(16);

interfacedata.F_struc = F_struc;
interfacedata.c = c;
interfacedata.Q = Q;
interfacedata.f = f;
interfacedata.K = K;
interfacedata.KCut = KCut;
interfacedata.integer_variables = integer_variables;
interfacedata.binary_variables  = binary_variables;
interfacedata.parametric_variables  = parametric_variables;
interfacedata.options = options;
interfacedata.monomtable = mt;
interfacedata.x0 = x0;
interfacedata.solver = solver;
interfacedata.lb = [];
interfacedata.ub = [];
interfacedata.lowrankdetails = lowrankdetails;

// ********************************
// GENERAL DATA EXCANGE SOLUTION
// ********************************
recoverdata=hash_create(3);

recoverdata.H = H;
recoverdata.x_equ = x_equ;
recoverdata.used_variables = used_variables;
endfunction
