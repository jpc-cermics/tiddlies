function F = and_constraint_constraint(X,Y)
// Internal class for constraint list

// Author Johan L�fberg
// $Id: and.sci,v 1.2 2010-07-09 18:00:31 solovyev Exp $
tmp = getfield(1,X);

if tmp(1)=='sdpvar' then
    X = true(X);
end

if tmp(1)=='constraint' then
    X = cnt_set(X);
end

tmp = getfield(1,Y);

if tmp(1)=='sdpvar' then
    Y = true(Y);
end

if tmp(1)=='constraint' then
    Y = cnt_set(Y);
end

F = X & Y;
endfunction
