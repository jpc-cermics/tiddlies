function F = constraint(X,quantifier,Y)
// Internal class for constraint list

// Author Johan L�fberg
// $Id: constraint.sci,v 1.2 2010-07-09 18:00:31 solovyev Exp $


// Try to evaluate
if (quantifier == '>') | (quantifier == '>=') then
    Z = X - Y;
elseif (quantifier == '<') | (quantifier == '<=')
    Z = Y - X;
else
    error('Quantifier not supported')
end

F.List=list(X,quantifier,Y);
F.Evaluated = list(Z);

if (quantifier == '>') | (quantifier == '<') then
    F.strict = 1;
elseif (quantifier == '<=') | (quantifier == '>=') then
    F.strict = 0;
else
    error('Quantifier not supported')
end

F=constraint_create(List=F.List,Evaluated=F.Evaluated,strict=F.strict);
endfunction
	
