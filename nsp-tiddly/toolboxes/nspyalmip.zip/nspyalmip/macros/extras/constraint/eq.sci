function F = %constraint_o_constraint(X,Y)
// Internal class for constraint lists

// Author Johan L�fberg
// $Id: eq.sci,v 1.1 2010-05-26 07:33:10 solovyev Exp $

//superiorto('sdpvar');
//superiorto('double');

error('Equalities can not be used in double-sided constraints')
endfunction

function F = %constraint_o_s(X,Y)
// Internal class for constraint lists

// Author Johan L�fberg
// $Id: eq.sci,v 1.1 2010-05-26 07:33:10 solovyev Exp $

//superiorto('sdpvar');
//superiorto('double');

error('Equalities can not be used in double-sided constraints')
endfunction

function F = %s_o_constraint(X,Y)
// Internal class for constraint lists

// Author Johan L�fberg
// $Id: eq.sci,v 1.1 2010-05-26 07:33:10 solovyev Exp $

//superiorto('sdpvar');
//superiorto('double');

error('Equalities can not be used in double-sided constraints')
endfunction
