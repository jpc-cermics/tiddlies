function F = %constrai_4_s(X,Y)
// Internal class for constraint lists

// Author Johan L�fberg
// $Id: ge.sci,v 1.1 2010-05-26 07:33:10 solovyev Exp $

//superiorto('sdpvar');
//superiorto('double');

try
        // (z > w) > y
        Z = X.List($) - Y;
        F = X;
        F.List($ +1) = '>';
        F.List($ +1) = Y;
        F.Evaluated($+1) = Z;
        F.strict($+1) = 0;
catch
    error(lasterror);
end
endfunction

function F = %s_4_constrai(X,Y)
try
        Z = X - Y.List(1);
        F = Y;
        F.List=cell(1,3);
        F.List.entries(1) = X;
        F.List.entries(2) ='>';
        F.List.entries(3) =F.List(:);
        F.Evaluated = cell(1,2);
        F.Evaluated(1)=Z;
        F.Evaluated(2)=F.Evaluated(:);
        F.strict = [1 F.strict];        
catch
    error(lasterror);
end
endfunction
