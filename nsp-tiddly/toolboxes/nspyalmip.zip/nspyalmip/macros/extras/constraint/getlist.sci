function [F,strict] = getlist(X)
// Internal class for constraint lists

// Author Johan L�fberg
// $Id: getlist.sci,v 1.1 2010-05-26 07:33:10 solovyev Exp $

//superiorto('sdpvar');
//superiorto('double');

F = X.Evaluated;
strict = X.strict;
endfunction
