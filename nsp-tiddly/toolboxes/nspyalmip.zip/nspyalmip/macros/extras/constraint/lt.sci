function F = %constrai_1_s(X,Y)
// Internal class for constraint lists

// Author Johan L�fberg
// $Id: lt.sci,v 1.1 2010-05-26 07:33:10 solovyev Exp $

//superiorto('sdpvar');
//superiorto('double');

// Try to evaluate
try
        // (z > w) < y
        tmp_= length(X.List);
        Z = Y - X.List(tmp_);
        F = X;
        F.List(tmp_+1) = '<';
        F.List(tmp_+1) = Y;
        tmp_=length(F.Evaluated);
        F.Evaluated(tmp_+1) = Z;
        tmp_=length(F.strict);
        F.strict(tmp_+1) = 0;
catch
    error(string(lasterror));
end
endfunction

function F = %constrai_1_sdpvar(X,Y)
// Internal class for constraint lists

// Author Johan L�fberg
// $Id: lt.sci,v 1.1 2010-05-26 07:33:10 solovyev Exp $

//superiorto('sdpvar');
//superiorto('double');

// Try to evaluate
try
        // (z > w) < y
        tmp_= length(X.List);
        Z = Y - X.List(tmp_);
        F = X;
        F.List(tmp_+1) = '<';
        F.List(tmp_+1) = Y;
        tmp_=length(F.Evaluated);
        F.Evaluated(tmp_+1) = Z;
        tmp_=length(F.strict);
        F.strict(tmp_+1) = 0;
catch
    error(string(lasterror));
end
endfunction

function F = %s_1_constrai(X,Y)
try
        // x < (w > y)
        Z = Y.List(1) - X;
        F = Y;
        F.List = cell(1,3);
        F.List.entries(1)=list(X);
        F.List.entries(2)=list('<');
        F.List.entries(3)=list(F.List(:));
        F.Evaluated=cell(1,2);
        F.Evaluated.entries(1) = list(Z);
        F.Evaluated.entries(2)=list(F.Evaluated(:));
        F.strict = [1 F.strict];       
catch
    error(string(lasterror));
end
endfunction

function F = %sdpvar_1_constrai(X,Y)
try
        // x < (w > y)
        Z = Y.List(1) - X;
        F = Y;
        F.List = cell(1,3);
        F.List.entries(1)=list(X);
        F.List.entries(2)=list('<');
        F.List.entries(3)=list(F.List(:));
        F.Evaluated=cell(1,2);
        F.Evaluated.entries(1) = list(Z);
        F.Evaluated.entries(2)=list(F.Evaluated(:));
        F.strict = [1 F.strict];       
catch
    error(string(lasterror));
end
endfunction




