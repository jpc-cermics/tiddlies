  function X = %constraint_not(X)
// Internal class for constraint list

// Author Johan L�fberg
// $Id: not.sci,v 1.1 2010-05-26 07:33:10 solovyev Exp $

//superiorto('sdpvar');
//superiorto('double');

// Try to evaluate

select X.List.entries(2)
    case '<' then
        X.List.entries(2) = '>';
    case '>' then
        X.List.entries(2) = '<';
    else
        error
end

X.Evaluated.entries(1) = -X.Evaluated.entries(1);
endfunction
