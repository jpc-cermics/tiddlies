function F = %constrai_or(X,Y)
// Internal class for constraint list

// Author Johan L�fberg
// $Id: or.sci,v 1.1 2010-05-26 07:33:10 solovyev Exp $
tmp=getfield(1,X);
if tmp(1)=='sdpvar' then
    X = logic(X);
end
if tmp(1)=='constraint' then
    X = logic(X);
end

tmp=getfield(1,Y);

if tmp(1)=='sdpvar' then
    Y = logic(Y);
end
if tmp(1)=='constraint' then
    Y = logic(Y);
end

F = or(X,Y);
endfunction
