function F = sdpvar_constraint(X)
// Internal class for constraint list

// Author Johan L�fberg
// $Id: sdpvar.sci,v 1.2 2010-07-09 18:00:31 solovyev Exp $

F = X.Evaluated(1);
endfunction
