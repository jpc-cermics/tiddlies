function [Fconv,no_changed] = convertquadratics(F)
//CONVERTQUADRATICS Internal function to extract quadratic constraints

// Author Johan L�fberg
// $Id: convertquadratics.sci,v 1.1 2010-07-18 19:44:15 solovyev Exp $

// ******************************
// LINEAR?
// ******************************

//[nlmi,neq]=size(F);
//itslinear    = 1;
//itssigmonial = 0;
itslinear = islinear(F);
if itslinear then
    Fconv = F;
    no_changed = 0;
    return
end

itssigmonial = issigmonial(F);
if itssigmonial then
    Fconv = F;
    no_changed = 0;
    return
end
// 
// for i = 1:1:nlmi+neq
//     if ~itslinear//is(F(i),'linear')
//         //itslinear = 0;
//         if is(F(i),'sigmonial')
//             itssigmonial = 1;
//         end            
//     end
// end
// 
// if itslinear | itssigmonial
//     Fconv = F;
//     no_changed = 0;
//     return
// end

Fconv = lmi();
no_changed = 0;
for i = 1:1:size(F,1)
    if is(F(i),'element-wise') && ~is(F(i),'linear') && ~is(F(i),'sigmonial') then
        // f-c'*x-x'*Q*x>0 
        [Q,c,f,x,info] = quaddecomp(sdpvar(F(i)));
        //        [G,info]=nonlineartocone(getconstraint(F(i)));
        if info==0 then
            // Yes, quadratic, but convex?
            // Change sign definitions
            Q = -Q;
            c = -c;
            f = -f;
            // Semi-definite case when only part of x in Q
            // Occurs, e.g, in constraints like y'*Q*y < t
            used = find(or(Q));Qred=Q(:,used);Qred = Qred(used,:);xred = x(used);
            [R,p]=chol(Qred);
            if p==0 then
                // Write as second order cone
                d = -c'*x-f;
                Fconv=Fconv + lmi(cone([2*R*xred;1-d],1+d));
                no_changed = no_changed + 1;
            else
                Fconv = Fconv + F(i);    
            end
        else
            Fconv = Fconv + F(i);
        end
    else
           Fconv = Fconv + F(i);
    end
end
endfunction
