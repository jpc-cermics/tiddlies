function [c,Q,f,onlyfeasible] = createobjective(h,G,options,quad_info)
//CREATEOBJECTIVE Internal function to extract data related to objective function

// Author Johan L�fberg
// $Id: createobjective.sci,v 1.1 2010-07-18 19:44:15 solovyev Exp $


onlyfeasible = 0;
nvars = sdpvar('nvars'); 
if type(h,'string') ~= "Sdpvar" & isempty(h) then
    c=zeros(nvars,1);
    Q = spalloc(nvars,nvars,0);
    f = 0;
    if isempty(G) then
        onlyfeasible = 1;
    end
else  
    [n,m]=size(h);
    if n*m>1 then
        error('Scalar expression to minimize please.');
    else
        // Should check quadratic!!
        if options.relax == 0 & ~isempty(quad_info) then
            Qh = quad_info.Q;
            ch = quad_info.c;
            f = quad_info.f;
            xvar = quad_info.x;
            lmi_variables = getvariables(xvar);
//             [Qh,ch,f,xvar,info]=quaddecomp(h);
            c = zeros(nvars,1);
            Q = spalloc(nvars,nvars,0); 
            for i=1:length(lmi_variables)
                c(lmi_variables(i))=ch(i);
            end
            if nnz(Qh)>0 then
                // This has to be sped up... 
                for i = 1:length(lmi_variables)
                    for j = 1:length(lmi_variables)
                        Q(lmi_variables(i),lmi_variables(j))=Qh(i,j);
                    end
                end
            end
        else
            // A relaxed problem should not calculate quadratic
            // decomposistion, fix!
            c=cell(nvars,1);
            for ii=1:nvars
              c{ii,1}=0;
            end
            
            lmi_variables = getvariables(h);
            for i=1:length(lmi_variables)
                c{lmi_variables(i),1}=full(getbasematrix(h,lmi_variables(i)));
            end  
            c=ce2m(c);
            Q = spalloc(nvars,nvars,0); 
            f = 0;
        end
    end
end
endfunction
