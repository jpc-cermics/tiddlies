function p = depends(x)
//DEPENDS Returns indicies to variables used in an SDPVAR object
//
// i = depends(x)
//
// Input
//    x : SDPVAR object
// Output
//    i : DOUBLE

// Author Johan L�fberg 
// $Id: depends.sci,v 1.1 2010-07-18 19:44:15 solovyev Exp $  

p=[];
endfunction
