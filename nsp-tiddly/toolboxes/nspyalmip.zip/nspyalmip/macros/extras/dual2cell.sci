function X = dual2cell(dual_vec,K)
//DUAL2CELL Internal function for organizing dual data 

// Author Johan L�fberg
// $Id: dual2cell.sci,v 1.1 2010-07-18 19:44:15 solovyev Exp $

row = 1;

X.f = dual_vec(row:row+K.f-1);
row = row + K.f;

X.l = dual_vec(row:row+K.l-1);

row = row + K.l;

X.q=list();

for k = 1:length(K.q)
    X.q(k) = dual_vec(row:row+K.q(k)-1);
    row = row + K.q(k);
end

X.r=list();
for k = 1:length(K.r)
    X.r(k) = dual_vec(row:row+K.r(k)-1);
    row = row + K.r(k);
end

X.s=list();
for k = 1:length(K.s)
    X.s(k) = mat(dual_vec(row:row+K.s(k)^2-1));
    row = row + K.s(k)^2;
end
endfunction

function Y = mat(X)
n = sqrt(length(X));
Y = matrix(X,n,n);

endfunction

