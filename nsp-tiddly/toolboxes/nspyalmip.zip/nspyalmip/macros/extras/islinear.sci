function p = islinear(X)

 TMP=type(X,'string');

 select TMP
 case 'Lmi'
    p=islinear(X);
 case 'Sdpvar'
    p=islinear(X);
 else
    p=(1==1);
 end
endfunction
