function ret = ismember(x,p)

ret=[];


if type(p,'string') == 'Sdpvar' || ~is(p,type(x)) then
 for i=1:length(x(:))
  ret(i)=0;
 end
 return
end


a = x(:);
b = p(:);

 for i=1:length(a)
  ret(i) = 0;
  for j=1:length(b)
     if a(i) == b(j) then
       ret(i)= 1;
       break;
     end
  end
 end

endfunction
