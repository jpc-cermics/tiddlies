function res = justify(txt,align)

if (align=='l') then
    l_txt=m2s([]);
    [m,n]=size(txt);
    for i=1:n
      col= txt(:,i);
      len= max(length(col))*ones(m,1);
      res = [l_txt, sprintf('%-*s',len,col)];
    end 
elseif (align == 'r') then
    r_txt=m2s([]);
    [m,n]=size(txt);
    for i=1:n
      col= txt(:,i);
      len= max(length(col))*ones(m,1);
      res = [r_txt, sprintf('%*s',len,col)];
    end 
else
   res = txt;
end

endfunction
