function [catstring,integer_variables,binary_variables,parametric_variables,quad_info] = catsdp_lmi(F,G,h,relax)
//catsdp          Internal function: tries to determine the type of
//optimization problem

// Author Johan L�fberg 
// $Id: catsdp.sci,v 1.1 2010-07-18 19:44:35 solovyev Exp $

// Constraints
//
// Eigenvalue       (CV) 
// Semidefinite     (CS)
// Sec. ord. cone   (CC)
// Element-wise     (CE)
// KYP              (CK)
// Bilinear         (CB)
// Polynomial       (CP)
// Convex quadratic (CQ) 
//
// Objective functions
//
// MAXDET           (OM)
// Convex quadratic (OQ)
// Non-convex quad. (NQ) 
// Polynomial       (OP) 
//
// Datatypes
//
// Complex          (DX)
// Integer          (DI)
// Binary           (DB)
// Multi-parametric (MP)


counter = size(F.clauses,1);

Ftype = zeros(counter,1);

real_data = %t;
int_data  = %f;
bin_data  = %f;
par_data  = %f;
poly_constraint = %f;
bilin_constraint = %f;
sigm_constraint = %f;
integer_variables = [];
binary_variables = [];
parametric_variables = [];
kyp_prob  = %f;

integer_variables = yalmip('intvariables');
binary_variables = yalmip('binvariables');
for i = 1:counter
    if F.clauses{i,1}.Type==7 then
        integer_variables = union(integer_variables,getvariables(F.clauses(i,1).entries.data));
    elseif F.clauses{i,1}.Type==8 then
        binary_variables = union(binary_variables,getvariables(F.clauses(i,1).entries.data));
    elseif F.clauses{i,1}.Type==13 then
        parametric_variables = union(parametric_variables,getvariables(F.clauses(i,1).entries.data));
    end   
end

monomtable = full(yalmip('monomtable'));
// nlv = yalmip('nonlinearvariables')';
// if isempty(nlv) | ~any(ismembc(getvariables(F),nlv(1,:)))
//     no_nonlinear_inF = 1;
//     //      temp = (sum(abs(monomtable),2)==1) & (any(monomtable==1,2));
//     temp = (sum(abs(monomtable),2)==1) & (any(monomtable==1,2));
//     linear_variables = find(temp);
//     nonlinear_variables = find(~temp);
//     sigmonial_variables = find(any(0>monomtable,2) | any(monomtable-fix(monomtable),2));
// 
// else
//     no_nonlinear_inF = 0;
//     //      temp = (sum(abs(monomtable),2)==1) & (any(monomtable==1,2));
//     //      linear_variables = find(temp);
//     //      nonlinear_variables = find(~temp);
//     //      sigmonial_variables = find(any(0>monomtable,2) | any(monomtable-fix(monomtable),2));
//     temp = (sum(abs(monomtable),2)==1) & (any(monomtable==1,2));
//     linear_variables = find(temp);
//     nonlinear_variables = find(~temp);
//     sigmonial_variables = find(any(0>monomtable,2) | any(monomtable-fix(monomtable),2));
// end

temp = (sum(abs(monomtable),dim=2)==1) & (or(monomtable==1,dim=2));
linear_variables = find(temp);
nonlinear_variables = find(~temp);
sigmonial_variables = find(or(0>monomtable,dim=2) | or(monomtable-fix(monomtable)>0,dim=2));

discrete_data = ~isempty(integer_variables) | ~isempty(binary_variables);
allvars = getvariables(F);
nononlinear = isempty(find(ismember(nonlinear_variables,allvars)));
for i = 1:counter
    Ftype(i) = F.clauses{i,1}.Type;
    real_data = real_data && isreal(F.clauses{i,1}.data); //Complex
    if discrete_data then
        int_data = int_data | or(ismember(getvariables(F.clauses{i,1}.data),integer_variables));
        bin_data = bin_data | or(ismember(getvariables(F.clauses{i,1}.data),binary_variables));
        par_data = par_data | or(ismember(getvariables(F.clauses{i,1}.data),parametric_variables));
    end
    if ~nononlinear then//no_nonlinear_inF
        vars = getvariables(F.clauses{i,1}.data);
       // if ~isempty(nonlinear_variables)
            //FIX : Verify logic on ismembc
            //usednonlins = find(ismember(nonlinear_variables,vars));
            usednonlins = find(ismember(nonlinear_variables,vars));
            if ~isempty(usednonlins) then
                usedsigmonials = find(ismember(sigmonial_variables,vars));
                if ~isempty(usedsigmonials) then
                    sigm_constraint = 1;
                    poly_constraint = 1;
                else
                    deg = degree(F.clauses(i,1).entries.data);
                    bilin_constraint = bilin_constraint | (deg==2);
                    poly_constraint = poly_constraint | (deg>2);
                end
            end
       // end
    end
end

if relax then
    int_data  = 0;
    bin_data  = 0;
    poly_constraint = 0;
    bilin_constraint = 0;
    sigm_constraint = 0;
    integer_variables = [];
    binary_variables = [];
end
    
any_LMI  = find(Ftype==1);
any_ELM  = find(Ftype==2);
any_EQU  = find(Ftype==3);
any_SOCC = find(Ftype==4);
any_ROTL = find(Ftype==5);
any_KYP  = find(Ftype==9);

// **************************************************
// Element-wise, 2-cone, semidefinite, KYP constraint
// **************************************************
catstring = '';
if ~isempty(any_ELM) then
    catstring = strcat(['CE', catstring]);
end

if (~isempty(any_SOCC)) | (~isempty(any_ROTL)) then
    catstring = strcat(['CC', catstring]);
end

if ~isempty(any_LMI) then
    catstring = strcat(['CS', catstring]);
end

if ~isempty(any_KYP) then
    catstring = strcat(['CK', catstring]);
end

// *******************************************
// Complex, integer, boolen variables
// *******************************************
if ~(real_data) then
    catstring = strcat([catstring, 'DX']); 
end

d_x = depends(h);
int_obj = (~isempty(h) & or(ismember(d_x,yalmip('intvariables'))>0));
bin_obj = (~isempty(h) & or(ismember(d_x,yalmip('binvariables'))>0));
if (int_data ) | int_obj then
    catstring = strcat([catstring, 'DI']);
end;

if bin_data | bin_obj then
    catstring = strcat([catstring, 'DB']);
end;

if ~(int_data | bin_data | int_obj | bin_obj) then
    integer_variables = [];
    binary_variables = [];
end

if par_data  then
    catstring = strcat([catstring, 'MP']);
end

// *******************************************
// Bilinear, Polynomial, Sigmonial constraints
// *******************************************
if poly_constraint  && sigm_constraint then
    catstring = strcat([catstring, 'CP']);
end;

if bilin_constraint && sigm_constraint then
    catstring = strcat([catstring, 'CB']);
end

if sigm_constraint  then
    catstring = strcat([catstring, 'CG']);
end

// *******************************************
// Objective function
// *******************************************
if ~isempty(G) then
    catstring = strcat(['OM', catstring]);
end

quad_info = [];
if (~isempty(h)) && ~is(h,'linear') && relax==0 then

//     if no_nonlinear_inF
//         temp = (sum(abs(monomtable),2)==1) & (any(monomtable==1,2));
//         linear_variables = find(temp);
//         nonlinear_variables = find(~temp);
//         sigmonial_variables = find(any(0>monomtable,dim=2) | any(monomtable-fix(monomtable)>0,dim=2));
//     end
    
    if or(ismember(getvariables(h),sigmonial_variables)) then
        catstring = strcat(['OG', catstring]);           
    else
        [Q,c,f,x,info] = quaddecomp(h);
        if info==0 then
            p=bool2s(and(spec(Q)>0));
            if p~=0 then
                if min(spec(Q))>=-1e-10 then
                    p=0;
                    [U,S,V]=svd(Q);
                    i = find(diag(S)>1e-10);
                    R = sqrt(S(1:max(i),1:max(i)))*V(:,1:max(i))';
                end
            end
            if p==0 then
                //R=chol(Q);
                catstring = strcat(['OQ', catstring]);
            else
                catstring = strcat(['NQ', catstring]);
            end
            quad_info.Q = Q;
            quad_info.c = c;
            quad_info.f = f;
            quad_info.x = list();
            quad_info.x = x;
            quad_info.R = R;
            quad_info.p = p;
        else
            //  error
            catstring = strcat(['OP', catstring]);   
        end
    end
end
endfunction
