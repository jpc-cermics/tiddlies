function [pres,dres] = checkset_lmi(F)
// checklmi(F)  Displays/calculates constraint residuals on set-object F
//
// [pres,dres] = checkset(F) 
//
// pres : Primal constraint residuals
// dres : Dual constraint residuals
// 
// If no output argument is supplied, tabulated results are displayed
//
// Primal constraint residuals are calculated as:
//
//  Semidefinite constraint F(x)>0 : min(eig(F))
//  Element-wise constraint F(x)>0 : min(min(F))
//  Equality constraint F==0       : -max(max(abs(F)))
//  Second order cone t>||x||      : t-||x||
//  Integrality constraint on x    : max(abs(x-round(x)))
//  Sum-of-square constraint       : Largest coefficient in polynomial p-v'*v
//
// Dual constraints are evaluated similarily.
//
//    See also   SET, SOLVESDP, SOLVESOS, SOSD, DUAL

// Author Johan L�fberg 
// $Id: checkset.sci,v 1.1 2010-07-25 19:22:21 solovyev Exp $   

// Check if solution avaliable
pres=[];
dres=[];
currsol = evstr('sdpvar(''getSolution'')');
if isempty(currsol) then
    printf('No solution available.')
    return
end

nlmi = size(F.clauses,1);
spaces = ['                                    '];
if (nlmi == 0)  then
    printf('empty LMI')
    return
end

lmiinfo=list();
lmiinfo(1) = 'LMI';
lmiinfo(2) = 'Element-wise';
lmiinfo(3) = 'Equality constraint';
lmiinfo(4) = 'Second order cone constraint';
lmiinfo(5) = 'Rotated Lorentz constraint';
lmiinfo(7) = 'Integer constraint';
lmiinfo(8) = 'Binary constraint';
lmiinfo(9) = 'KYP constraint';
lmiinfo(10) = 'Eigenvalue constraint';
lmiinfo(11) = 'SOS constraint';

header = ['ID','Constraint','Type','Primal residual','Dual residual','Compl. slack','Tag'];

if nargout==0 then
printf(' ');
end
for j = 1:nlmi
    F0 = double(F.clauses{j,1}.data);
    if (F.clauses{j,1}.Type~=11) & or(isnan(F0(:)))
        res(j,1) = %nan;
    else
        select F.clauses{j,1}.Type
            case 1
                res(j,1) = min(spec(F0));
            case 9
                res(j,1) = min(spec(F0));
            case 2                
                res(j,1) = min(min(F0));
            case 3
                res(j,1) = -max(max(abs(F0)));                
            case 4
                res(j,1) = F0(1)-norm(F0(2:$));
            case 5
                res(j,1) = 2*F0(1)*F0(2)-norm(F0(3:$))^2;
            case 7
                res(j,1) = max(max(abs(F0-round(F0))));
            case 8
                res(j,1) = max(max(abs(F0-round(F0))));
            case 11
                p = F.clauses(j,1).entries.data;
                [v,ParVar] = sosd(subsref(F,struct('type','()','subs',list(list(j)) )));
                if ~isempty(ParVar) then
                    ParVar = recover(ParVar);
                    p = replace(p,ParVar,double(ParVar));
                end
                if isempty(v) then
                    res(j,1)=%nan;
                else
                    h = p-v'*v;
                    res(j,1) = max(max(abs(getbase(h))));
                end
             else
                 res(j,1) = %nan;
        end
    end
    
    // Get the internal index
        LMIid = F.clauses{j,1}.LMIid;
        dual  = yalmip('dual',LMIid);
        if isempty(dual) | or(isnan(dual))      then   
            resdual(j,1) = %nan;
        else
            select F.clauses{j,1}.Type
            case 1
                resdual(j,1) = min(spec(dual));
            case 9
                resdual(j,1) = min(spec(dual));
            case 2                
                resdual(j,1) = min(min(dual));
            case 3
                resdual(j,1) = -max(max(abs(dual)));                
            case 4
                resdual(j,1) = dual(1)-norm(dual(2:$));
            case 5
                resdual(j,1) = 2*dual(1)*dual(2)-norm(dual(3:$))^2;
            case 7
                resdual(j,1) = %nan;            
            else
                gap = %nan;                 
            end            
        end
        if isempty(dual) | or(isnan(dual)) |  or(isnan(F0)) then
            gap = %nan;
        else
            select F.clauses{j,1}.Type
            case 1
                gap = trace(F0*dual);
            case 9
                gap = trace(F0*dual);
            case 2
                gap = F0(:)'*dual(:);
            case 3
                gap = F0(:)'*dual(:);
            case 4
                gap = %nan;
            case 5
                gap = %nan;
            case 7
                gap = %nan;
            else
                gap = %nan;
            end
        end
    
    data = [''];
    data(j,1) = strcat(['#', string(j)]);
    data(j,2) = F.clauses{j,1}.symbolic;
    data(j,3) = lmiinfo(F.clauses{j,1}.Type);
    data(j,4) = string(res(j,1));
    data(j,5) = string(resdual(j,1));
    data(j,6) = string(gap);
    data(j,7) = F.clauses{j,1}.Handle;
    
      
    if ~islinear(F.clauses{j,1}.data) then
        if is(F.clauses{j,1}.data,'sigmonial') then
            classification = 'sigmonial';
        elseif is(F.clauses{j,1}.data,'bilinear')   
            classification = 'bilinear';   
        elseif is(F.clauses{j,1}.data,'quadratic')   
            classification = 'quadratic';             
        else
            classification = 'polynomial';    
        end
        data(j,3) = strcat([data(j,3), ' (', classification, ')']);
    end
        
    
end
if length(strcat([data(:,7)]))==0 then
   header = header(:,1:6);
   temp = data(:,1:6);
   tmp=size(temp);
   data = matrix(temp,(tmp(1)*tmp(2))/6,6);
end

if nargout>1 then
    pres = res;
    dres = resdual;
else
    table('',header,data)
    printf(' ');    
end
endfunction
