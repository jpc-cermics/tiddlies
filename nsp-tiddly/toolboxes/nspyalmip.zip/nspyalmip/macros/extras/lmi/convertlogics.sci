function [Fconv1,changed] = convertlogics_lmi(F)

changed = 0;
Fconv1 = lmi_create();
// Loop over all ANDs
for i = 1:size(F.clauses,1)
    
    if size(F.clauses(i),1)>1 || is(F.clauses{i,1}.data,'logic') then
        // Definitely needs
        Fconv1 = Fconv1 + logic2cont1(F.clauses(i));
        changed = 1;
    else
        TMP = size(Fconv1.clauses,1);
        if ~isempty(Fconv1.clauses) && isempty(Fconv1.clauses{TMP,1}) then
         TMP=TMP-1;
        end
        Fconv1.clauses{TMP+1,1} = F.clauses{i,1};
    end  
end
endfunction


function Fcont = logic2cont1(clauses)

M = 1e3;
// How many elements in this clause
n = length(clauses);

// Are all simple letters?
all_letters = 1;
j = 1;
while all_letters & j<=n 
    if (type(clauses{j}.data,'string')== 'Sdpvar') then
        all_letters = all_letters &  is(clauses{j}.data,'logic');
    else
        all_letters = 0;
    end
    j = j + 1;
end

Fcont = Set([]);
if all_letters then
    sum_or = 0;
    // Ah, simple constraints, just add them
    for j = 1:n
        sum_or = sum_or + clauses{j}.data;
    end
else
    // No, mix of letters and constraints, use big-M
    sum_or = 0;
    delta = binvar(size( clauses,2),1);
    for j = 1:length(clauses)
        if is(clauses{j}.data,'logic')
            sum_or = sum_or + clauses{j}.data;
        else
            delta = binvar(1,1);
            Fcont = Fcont + set(clauses{j}.data+M*(1-delta)>0);
            sum_or = sum_or + delta;
        end
    end
end
Fcont = Fcont + set(sum_or>1);

endfunction

 function F = logic2cont2(clauses)
        //
        // F = set([]);
        // M = 1e3;
        //
        // // How many elements in this clause
        // n = size(clauses,2);
        // // Are all simple letters?
        // all_letters = 1;
        // j = 1;
        // while all_letters & j<=n
        //     all_letters = all_letters &  isa(clauses{j}.data,'sdpvar');
        //     j = j + 1;
        // end
        //
        // if all_letters
        //     sum_or = 0;
        //     // Ah, simple constraints, just add them
        //     for j = 1:n
        //         sum_or = sum_or + x.clauses{i}{j};
        //     end
        //
        // else
        //     sum_or = 0;
        //     delta = binvar(size( x.clauses{i},2),1);
        //     for j = 1:size( x.clauses{i},2)
        //         clause_i_j = x.clauses{i}{j};
        //         if isa(clause_i_j,'constraint')
        //             delta = binvar(1,1);
        //             F = F + set(sdpvar(clause_i_j)+M*(1-delta)>0);
        //             sum_or = sum_or + delta;
        //         elseif isa(clause_i_j,'sdpvar')
        //             F = F + set(clause_i_j);
        //             sum_or = sum_or + clause_i_j;
        //         end
        //     end
        //
        // end
        // F = F + set(sum_or>1);
        endfunction
