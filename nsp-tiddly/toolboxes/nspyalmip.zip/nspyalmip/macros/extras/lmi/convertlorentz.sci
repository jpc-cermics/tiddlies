function [F,changed] = convertlorentz(F)
//catsdp          Internal function: converts ratated Lorentz to SOCC
  
// Author Johan L�fberg 
// $Id: convertlorentz.sci,v 1.1 2010-07-18 19:44:35 solovyev Exp $
  
changed = 0;
Counter = size(F.clauses,2);
for i = 1:Counter
    // Yep, Lorentz
    if  (F.clauses{i,1}.Type==5) then
        changed=1;
        xyz = F.clauses{i,1}.data;
        x = xyz(1);
        y = xyz(2);
        z = xyz(3:$);
        F.clauses{i,1}.data = [(x+y)/sqrt(2);(x-y)/sqrt(2);z];
        if is(x+y,'sdpvar') then
            F = F+lmi(x+y>0);
        end
        F.clauses{i,1}.Type = 4;
    end
end
endfunction
