function [F,changed] = convertsocp(F)
//catsdp          Internal function: converts SOCP to LMI

// Author Johan L�fberg 
// $Id: convertsocp.sci,v 1.1 2010-07-18 19:44:35 solovyev Exp $


changed = 0;
counter = size(F.clauses,1);
for i = 1:counter
    if  (F.clauses{i,1}.Type==4)
        changed=1;
        xy = F.clauses{i,1}.data;
        y = xy(1);
        x = xy(2:$);

        F.clauses{i,1}.data = [y x';x eye(length(x),length(x))*y];
        F.clauses{i,1}.Type = 1;
    end
end


endfunction

