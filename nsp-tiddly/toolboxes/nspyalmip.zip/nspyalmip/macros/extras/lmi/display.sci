function sys = ret_lmi(X)
//display           Displays a SET object.

// Author Johan L�fberg
// $Id: display.sci,v 1.2 2010-07-18 19:44:15 solovyev Exp $

sys=[];

nlmi = size(X.clauses,1);

if (nlmi == 0 | X.clauses==cell(1,1)) then
    printf("%s\n",sprintf('empty SET'))
    return
end

lmiinfo = ['Matrix inequality',
           'Element-wise',
           'Equality constraint',
           'Second order cone constraint',
           'Rotated Lorentz constraint',
           'Integrality constraint',
           'Binary constraint'
           'KYP constraint',
           'Eigenvalue constraint'
           'Sum-of-square constraint',
           'Logic constraint',
           'Parametric definition',
           'Low-rank data declaration'];

headers = ['ID','Constraint','Type','Tag'];
if nlmi>0 then
    data=[''];
    for i = 1:nlmi
        data(i,1) = strcat(['#', string(i)]);
        TMP = X.clauses{i,1};
        data(i,2) = TMP.symbolic;//symbolic
        data(i,3) = lmiinfo(X.clauses{i,1}.Type);//type
        
        if X.clauses{i,1}.Type ~= 14 then //type==14
        if or(ismember(getvariables(X.clauses{i,1}.data),yalmip('intvariables')) > 0) then
            data(i,3) = strcat([data(i,3), ' (integer)']);
        end
        
        if size(X.clauses(i,:),2)>1 then
            data(i,3) = strcat([data(i,3), ' (logic)']);
        end
        classification = '';
        if ~islinear(X.clauses{i,1}.data) then //data
            if is(X.clauses{i,1}.data,'sigmonial') then
                classification = strcat([classification, 'sigmonial']);
            elseif is(X.clauses{i,1}.data,'bilinear') then
                classification = strcat([classification, 'bilinear']);
            elseif is(X.clauses{i,1}.data,'quadratic') then
                classification = strcat([classification, 'quadratic']);
            else
                classification = strcat([classification 'polynomial']);
            end
            data(i,3) = strcat([data(i,3), ' (' classification ')']);
        end

        data(i,4) = X.clauses{i,1}.Handle; //handle
        if ~isreal(X.clauses{i,1}.data) then //data
            data(i,3) = strcat([data(i,3), ' (complex)']);
        end
        
        if ismember(X.clauses{i,1}.Type,[1 2 3 4 5 9]) then //type
            data(i,3) = strcat([data(i,3), ' ', string(X.clauses{i,1}.data.n), 'x', string(X.clauses{i,1}.data.m)]);
        end
        end
    end
end

// If no tags, don't show...

if length(data(:,4))==0 then
    headers = headers(:,1:3);
    data = matrix(data(:,1:3),length(length(data(:,1:3)))/3,3);
end


table('',headers,data)
endfunction

function x= truncstring(x,n)
if length(x) > n then
    x = [x(1:n-3) '...'];
end
endfunction
function x = fillstring(x,n)
x = [x blanks(n-length(x))];
endfunction
