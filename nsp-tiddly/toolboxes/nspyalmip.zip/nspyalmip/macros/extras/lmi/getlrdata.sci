function lrdata = getlrdata_lmi(F)

k = 1;
lrdata = [];
for i = 1:size(F.clauses,1)
    Fi = F.clauses(i,1){1,1};
    if Fi.Type == 14 then
        lrdata(length(lrdata)+1) =  Fi.data;
    end    
end
endfunction
