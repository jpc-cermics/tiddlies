function used = getvariables_lmi(F)

used = [];
for i = 1:size(F.clauses,1)
    Fivars = getvariables(F.clauses{i,1}.data);    
    used = unique1D([used Fivars(:)']);
end

endfunction
