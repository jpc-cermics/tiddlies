function Freal = imag2reallmi(F)

// Author Johan L�fberg 
// $Id: imag2reallmi.sci,v 1.1 2010-07-18 19:44:35 solovyev Exp $

Counter = size(F.clauses,2);
Freal = F;
j=1;
for i = 1:Counter
    if isreal(F.clauses{i,1}.data) then
        Freal.clauses{j,1}=F.clauses{i,1};
        j = j+1;
    else
        select F.clauses{i,1}.Type
            case 1
                reF=real(F.clauses{j,1}.data);
                imF=imag(F.clauses{j,1}.data);
                Freal.clauses{j,1}.data=[reF imF;-imF reF];
                j = j+1;
            case 2
                reF=real(F.clauses{j,1}.data);
                imF=imag(F.clauses{j,1}.data);
                Freal.clauses{j,1}.data=[reF;imF];
                j = j+1;
            case 3
                reF=real(F.clauses{j,1}.data);
                imF=imag(F.clauses{j,1}.data);
                Freal.clauses{j,1}.data=[reF;imF];
                j = j+1;
            case 4
                reF=real(F.clauses(j,1).entries.data);
                imF=imag(F.clauses(j,1).entries.data);
                Freal.clauses{j,1}.data=[reF(1);reF(2:$);imF(2:$)];
                j = j+1;       
            else
                error('Internal bug. Please report.');
        end
    end
end

endfunction
