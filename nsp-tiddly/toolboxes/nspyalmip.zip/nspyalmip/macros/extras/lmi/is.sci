function YESNO = is_lmi(F,property)
//IS   Check property of constraint.
//   d = IS(x,property) returns 1 if 'property' holds
//
//   Properties possible to test are: 'elementwise', 'sdp', 'socc',
//   'lmi', 'linear', 'kyp'

// Author Johan L�fberg 
// $Id: is.sci,v 1.1 2010-07-18 19:44:35 solovyev Exp $

if (nargin < 2)
 error('Wrong number of arguments in is_lmi function')
end
   
if isempty(F.clauses) then
    YESNO = 0;
else
    YESNO=bmat_create(1,1);
    for i = 1:size(F.clauses,1)
        Fi = F.clauses(i,1){1,1};
        select ( property )

        case 'equality'
            YESNO(i,1) = (Fi.Type==3);
        case 'element-wise'
            YESNO(i,1) = (Fi.Type==2);
        case 'elementwise'
            YESNO(i,1) = (Fi.Type==2);
        case 'socc'
            YESNO(i,1) = (Fi.Type==4);
        case 'sdp'
            YESNO(i,1) = (Fi.Type==1); 
        case 'lmi'
            YESNO(i,1) = (((Fi.Type==1) | (Fi.Type==9)) | ((Fi.Type==2) & (prod(size(Fi.data))==1))) & (islinear(Fi.data));
        case 'linear'
            YESNO(i,1) = islinear(Fi.data);  
        case 'kyp'
            YESNO(i,1) = (Fi.Type==9);
        case 'sos'
            YESNO(i,1) = (Fi.Type==11);
        case 'eig'
            YESNO(i,1) = (Fi.Type==10);            
        case 'sigmonial'
            monomtable = yalmip('monomtable');
            monomtable = full(monomtable(getvariables(Fi.data),:));
            YESNO(i,1) = or(find(or(0>monomtable,2) | or(monomtable-fix(monomtable)>0,2)>0));
        case 'binary'
            YESNO = Fi.Type ==  8;
        case 'integer'
            YESNO = Fi.Type ==  7;
        case 'logic'
            YESNO(i,1) = Fi.Type == 12; 
        case 'lowrank'
            YESNO(i,1) = Fi.Type == 14; 
        else
            YESNO = error('Huh?');
        end
    end
  //  end
end
endfunction

