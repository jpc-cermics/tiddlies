function itslinear= islinear_lmi(F)
//ISLINEAR Check if all constraints are linear       
//
// p = islinear(F)
//
// F : SET object
// p : boolean 0/1

// Author Johan L�fberg 
// $Id: islinear.sci,v 1.1 2010-07-18 19:44:35 solovyev Exp $  


monomtable = yalmip('monomtable')';// Working with transpose is faster
xvars = [];

itslinear = 1;
i = 1;
while itslinear>0 && (i<=size(F.clauses,1))
    Fi = F.clauses{i,1};
    xvars = getvariables(Fi.data);
    //monomtableX = monomtable(xvars,:);
    //[ii,jj,ss] = find(monomtableX);
    //itslinear = itslinear && all(ss==1);   
    monomtableX = monomtable(:,xvars);
    [ii,jj,ss] = find(monomtableX);
    if ( itslinear > 0 && and(ss==1) ) then
      itslinear=1;
    else
      itslinear=0;
   end
 
   
   
    i = i + 1;
end
endfunction
