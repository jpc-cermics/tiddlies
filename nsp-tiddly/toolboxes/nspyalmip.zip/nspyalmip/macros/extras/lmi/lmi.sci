function F = lmi(X,handlestring)
// The command lmi is obsolete, see help sdpvar/set

// Author Johan L�fberg
// $Id: lmi.sci,v 1.2 2010-10-08 16:22:03 solovyev Exp $

select nargin
case 0 then
    F.clauses=cell(1,1);
    F.savedata = [];
    F=lmi_create();
    //F = class(F,'lmi');
    return
case 1 then
    handlestring = '';
    // ok probably, check later
case 2  then
    if ~(is(handlestring,%types.SMat)) then
        error('The handle must be a string')
    end
else
    error('Wrong number of arguments')
end

F.clauses=cell(1,1);
F.savedata = [];

try
    F=lmi_create(clauses=F.clauses);
    //F = class(F,'lmi');
catch
    print('Failure in creating SET object. Restart MATLAB and try again, or type clear classes')
end

// Return empty LMI in degenerate case
if isscalar(X) then
    return
end

// 0 : Nothing (i.e error)
// 1 : LMI
// 2 : Elementwise
// 3 : Equality
// 4 : SOCC 
// 5 : Rotated Lorentz
// 9 : KYP constraint
//10 : Eigenvalue constraint
//11 : Sum of square constraint
//12 : Logic CNF

if (type(X,'string') == 'SMat') then
 tmp='char';
elseif (type(X,'string') == 'Sdpvar') then
  tmp = 'sdpvar';  
elseif (type(X,'string')=='Constraint') then
  tmp = 'constraint';  
end


select tmp
case 'lmi' then
    F = X;
    return
case 'char' then
    error('not supported string constraints!')
    try
        // Parse (check for old notation, take care of ||...|| notation)
        sdpvarExpr = parseLMI(X);
        // Old notation
        X = strsubst(X,'.>','>');
        X = strsubst(X,'.<','<');
     //   X = strrep(X,'=','==');X = strrep(X,'====','==');
    catch
        error(lasterror)
    end
    // Evaluate
    try
         //Fi=evalin('caller',sdpvarExpr);
        Fi=eval(sdpvarExpr);
        tmp_ = getfield(1,Fi);
        select tmp_(1)
        case 'sdpvar' then
            Fi = list(Fi);
            strict = 0;
        case 'constraint' then
            [Fi,strict] = getlist(Fi);    //Need this function        
        else
        //if ~(tmp_(1) == 'sdpvar') then
            error('The string does not define an SDPVAR object')
        end
        
    catch
        error(lasterror)
    end
    
case 'sdpvar' then
    Fi = list(X);
    strict = 0;
    X='Numeric value';
case 'logic' then
    Fi = list(X);
    strict = 0;
    X = 'Numeric value';
    
case 'constraint' then
    [Fi,strict] = getlist(X);    
    X='Numeric value';
    
else
    error('The first argument should be an sdpvar object or string.')
end

// Return empty LMI in degenerate case
if and(isempty(Fi)) then //Need this function
    F=[];
    return
end

i = 1;
while i <= size(Fi)
    thisFi = Fi(i);
    if  ~isscalar(thisFi) then         
        tmp = type(thisFi,'string'); 
    
        if tmp=='logic' then
            TypeofConstraint = 12;
        else
            TypeofConstraint = gethackflag(Fi(i));
        end

        // User just sent a sdpvar object, interpret as X>0
        if (TypeofConstraint==0) then
            TypeofConstraint = 1;
        end
        
        if (TypeofConstraint==1) then
            [n,m]=size(thisFi);
            if (n~=m)| ((TypeofConstraint == 1) & (n*m==1)) | ~ishermitian(thisFi) then  
                TypeofConstraint = 2;
            end
        end
        if (TypeofConstraint>0)&(TypeofConstraint<14) then
            TMP=hash_create(10);
            TMP.data = list();
            TMP.data = thisFi;
            TMP.Type = TypeofConstraint;
            TMP.symbolic = X;
            TMP.Handle=handlestring;
            TMP.LMIid = yalmip('LMIid');
            TMP.strict=strict(i);
            TMP.cut=0;
            F.clauses(i,1)={TMP};
            i = i + 1;
        else
            error('Error in argument in LMI. Please report bug');
        end
    end
end
endfunction
