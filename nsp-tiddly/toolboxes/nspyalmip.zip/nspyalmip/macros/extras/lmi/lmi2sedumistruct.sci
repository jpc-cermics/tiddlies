function [F_struc,K,KCut] = lmi2sedumistruct(F)
//lmi2sedumistruct   Internal function: Converts LMI to format needed in SeDuMi
// 
// // Author Johan L�fberg
// // $Id: lmi2sedumistruct.sci,v 1.2 2010-10-08 16:22:02 solovyev Exp $

nvars = sdpvar('nvars'); //Needed lot'sa times...

// We first browse to see what we have got and the
// dimension of F_struc (massive speed improvement)
top = 0;
type_of_constraint = zeros(size(F.clauses,1),1);
for i = 1:size(F.clauses,1)
    type_of_constraint(i) = F.clauses{i,1}.Type;
    [n,m] = size(getbasematrixwithoutchec(F.clauses{i,1}.data,0));
    top = top+n*m;
    // Is it a complex linear cone
    if (type_of_constraint(i)==2) && (~isreal(F.clauses{i,1}.data)) then
        top = top+n*m; // We will have constraints on Re and Im
    end
end

F_struc = [];

sdp_con = find(type_of_constraint == 1 | type_of_constraint == 9);
lin_con = find(type_of_constraint == 2 | type_of_constraint == 12);
equ_con = find(type_of_constraint == 3);
qdr_con = find(type_of_constraint == 4);
rlo_con = find(type_of_constraint == 5);


// SeDuMi struct
K.f = 0;
K.l = 0;
K.q = 0;
K.r = 0;
K.s = 0;
K.scomplex = [];
K.xcomplex = [];

KCut.f = [];
KCut.l = [];
KCut.q = [];
KCut.r = [];
KCut.s = [];

top = 1;
localtop = 1;
// Linear constraints
for i = 1:length(equ_con)
    constraints = equ_con(i);
    data = getbase(F.clauses{constraints,1}.data);
    [n,m] = size(F.clauses{constraints,1}.data);
    // Which variables are needed in this constraint
    lmi_variables = getvariables(F.clauses{constraints,1}.data);
    if isreal(data) then
        ntimesm = n*m; //Just as well pre-calc			
    else
        // Complex constraint, Expand to real and Imag
        ntimesm = 2*n*m; //Just as well pre-calc
        data = [real(data);imag(data)];			
    end
    F_structemp  = spalloc(ntimesm,1+nvars,0);

    F_structemp(:,[1 1+lmi_variables(:)'])= data;

    // ...and add them together (efficient for large structures)
    //	F_struc(top:top+ntimesm-1,:) = F_structemp;	
    F_struc = [F_struc;F_structemp];
    
    if F.clauses{constraints,1}.cut then
        KCut.f = [KCut.f localtop:localtop+ntimesm-1];
    end
    
    localtop = localtop+ntimesm;	    
    top = top+ntimesm;	
    K.f = K.f+ntimesm;
end

// Linear constraints
localtop = 1;

for i = 1:length(lin_con)
    constraints = lin_con(i);
    data = getbase(F.clauses{constraints,1}.data);
    [n,m] = size(F.clauses{constraints,1}.data);
    // Which variables are needed in this constraint
    lmi_variables = getvariables(F.clauses{constraints,1}.data);
    if isreal(data) then
        ntimesm = n*m; //Just as well pre-calc			
    else
        // Complex constraint, Expand to real and Imag
        ntimesm = 2*n*m; //Just as well pre-calc
        data = [real(data);imag(data)];			
    end
    F_structemp  = spalloc(ntimesm,1+nvars,0);
    F_structemp(:,[1 1+lmi_variables(:)'])= data;
    // ...and add them together (efficient for large structures)
    //	F_struc(top:top+ntimesm-1,:) = F_structemp;	
    F_struc = [F_struc;F_structemp];
    
    if F.clauses{constraints,1}.cut then
        KCut.l = [KCut.l localtop:localtop+ntimesm-1];
    end

    localtop = localtop+ntimesm;	
    top = top+ntimesm;	
    K.l = K.l+ntimesm;
end

// second order cone constraints
for i = 1:length(qdr_con)
    constraints = qdr_con(i);
    
    [n,m] = size(F.clauses{constraints,1}.data);
     ntimesm = n*m; //Just as well pre-calc
    
    // Which variables are needed in this constraint
    lmi_variables = getvariables(F.clauses{constraints,1}.data);
    
    // We allocate the structure blockwise...
    F_structemp  = spalloc(ntimesm,1+nvars,0);
    // Add these rows only 
    F_structemp(:,[1 1+lmi_variables(:)'])= getbase(F.clauses{constraints,1}.data);
    // ...and add them together (efficient for large structures)
    //	F_struc(top:top+ntimesm-1,:) = F_structemp;
    F_struc = [F_struc;F_structemp];
    
    top = top+ntimesm;
    // Check for a complex structure
    if ~isreal(F_structemp) then
        complex_ind = 1+sum(K.f)+sum(K.l)+sum(K.q):sum(K.f)+sum(K.l)+sum(K.q)+n;
        K.xcomplex = [K.xcomplex(:)' complex_ind(:)'];
    end
    K.q(i) = n;	
end


// Rotated Lorentz cone constraints
for i = 1:length(rlo_con)
    constraints = rlo_con(i);
    
    [n,m] = size(F.clauses{constraints,1}.data);
    ntimesm = n*m; //Just as well pre-calc
    
    // Which variables are needed in this constraint
    lmi_variables = getvariables(F.clauses{constraints,1}.data);
    
    // We allocate the structure blockwise...
    F_structemp  = spalloc(ntimesm,1+nvars,0);
    // Add these rows only 
    F_structemp(:,[1 1+lmi_variables(:)'])= getbase(F.clauses{constraints,1}.data);
    // ...and add them together (efficient for large structures)
    //	F_struc(top:top+ntimesm-1,:) = F_structemp;
    F_struc = [F_struc;F_structemp];
    
    top = top+ntimesm;
    K.r(i) = n;	
end

// semidefinite  constraints


for i = 1:length(sdp_con)
    constraints = sdp_con(i);    
    Fi = F.clauses{constraints,1}.data;
    Fibase = getbase(Fi);
    [n,m] = size(Fi);
    ntimesm = n*m; //Just as well pre-calc
    
    // Which variables are needed in this constraint
    lmi_variables = getvariables(Fi);
    
    // We allocate the structure blockwise...
    F_structemp  = spalloc(ntimesm,1+nvars,nnz(Fibase));
    // Add these rows only
    
    F_structemp(:,[1 1+lmi_variables(:)'])= Fibase;
    // ...and add them together (efficient for large structures)
    //	F_struc(top:top+ntimesm-1,:) = F_structemp;
    F_struc = [F_struc;F_structemp];
        
    if F.clauses{constraints,1}.cut then
        KCut.s = [KCut.s i];
    end
    K.s(i) = n;
    top = top+ntimesm;
    // Check for a complex structure
    if ~isreal(F_structemp) then
        K.scomplex = [K.scomplex i];
    end
end

endfunction
