function info = lmiinfo_lmi(F)
  
// Author Johan L�fberg 
// $Id: lmiinfo.sci,v 1.1 2010-07-18 19:44:35 solovyev Exp $

info.sdp = [];
info.lin = [];
info.equ = [];
info.soc = [];
info.rlc = [];

Counter = size(F.clauses,1);

for i = 1:Counter
    Fi = F.clauses{i,1}.data;

    select  F.clauses{i,1}.Type
        case 1 then
             info.sdp = [info.sdp;size(Fi,1) size(Fi,2) F.clauses{i,1}.LMIid],
        case 2 then
            info.lin = [info.lin;size(Fi,1) size(Fi,2) F.clauses{i,1}.LMIid],
        case 3 then
            info.equ = [info.equ;size(Fi,1) size(Fi,2) F.clauses{i,1}.LMIid],    
        case 4 then
            info.soc = [info.soc;size(Fi,1) size(Fi,2) F.clauses{i,1}.LMIid],
        case 5 then
            info.rlc = [info.rlc;size(Fi,1) size(Fi,2) F.clauses{i,1}.LMIid],
        case 7 then
        case 8 then
 
        case 9
            info.sdp = [info.sdp;size(Fi,1) size(Fi,2) F.clauses{i,1}.LMIid],
 
        else
            error('Error in lmiinfo. Please report bug');
    end
end
endfunction
