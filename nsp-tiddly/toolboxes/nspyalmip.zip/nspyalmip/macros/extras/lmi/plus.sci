function sys = plus_lmi_lmi(X,Y)
//plus            Merges two LMI objects to one LMI
//   
//    See also   LMI, ADDLMI, UPDATELMI, DELLMI

// Author Johan L�fberg
// $Id: plus.sci,v 1.2 2010-10-08 16:22:03 solovyev Exp $

nX = size(X.clauses,1);
nY = size(Y.clauses,1);

sys = X;
for i = 1:nY;
    for j = 1:size(Y.clauses(i),1)
         if nX>0 && length(sys.clauses(i+nX-1,j)) ==0 then
          nX=nX-1;
         end;
         sys.clauses(i+nX,j) = Y.clauses(i,j);
    end
end
endfunction
