function showprogress(thetext,doit)
//SHOWPROGRESS Internal function for printing messages

// Author Johan L�fberg
// $Id: showprogress.sci,v 1.1 2010-07-18 19:44:35 solovyev Exp $

if doit>0 then
	fprintf('+ %s\n',thetext);
end

endfunction
