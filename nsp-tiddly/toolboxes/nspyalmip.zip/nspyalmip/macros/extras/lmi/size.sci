function varargout= size_lmi(varargin)
//size              Returns the number of inequalities and equalities 
//   
//    n = SIZE(F)     Returns the number of inequalities
//    [n,m] = SIZE(F) Returns the number of inequalities and equalities
//
//    See also   LMI, ADDLMI

// Author Johan L�fberg 
// $Id: size.sci,v 1.1 2010-07-18 19:44:35 solovyev Exp $   

F = varargin(1);
varargout=list();
nequ = 0;
nlmi = 0;
for i = 1:size(F.clauses,2)
    if F.clauses{i,1}.Type==3 then
        nequ = nequ + 1;
    else
        nlmi = nlmi + 1;
    end
end

if nargin == 1  then
  select (nargout)
  case 0
    varargout(1) = nlmi;
  case 1
    varargout(1) = nlmi;
  case 2
    varargout(1) = nlmi;
    varargout(2) = nequ;
  else
    varargout(1) = nlmi;
    varargout(2) = nequ;
  end
else
	select(varargin(2))
	case 1
		varargout(1) = nlmi;
	case 2
		varargout(1) = nequ;
  case '*'
    varargout(1) = 0;
	else
		error('Second argument should be 1 (# LMIs) or 2 (# equalities)');
	end
end
endfunction
