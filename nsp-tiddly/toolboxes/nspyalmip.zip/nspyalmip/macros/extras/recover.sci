function x = recover_m(lmi_variables)
//RECOVER Create SDPVAR object using variable indicies

// Author Johan L�fberg
// $Id: recover.sci,v 1.1 2010-06-19 12:50:06 solovyev Exp $

if isempty(lmi_variables) then
    x = [];
else
    n = length(lmi_variables);
    x = sdpvar(n,1,[],lmi_variables(:)',[sparse([],[],[n,1]) speye(n,n)],0);
end
endfunction
