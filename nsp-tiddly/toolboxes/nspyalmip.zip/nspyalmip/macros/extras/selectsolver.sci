function [solver,problem] = selectsolver(options,ProblemString,solvers,socp_are_really_qc);
//SELECT_SOLVER Internal function to select solver based on problem category

// Author Johan L�fberg
// $Id: selectsolver.sci,v 1.1 2010-07-18 19:44:15 solovyev Exp $

// ***************************************************
// Maybe the user is stubborn and wants to pick solver
// ***************************************************
problem = 0;
force_solver = yalmip('solver');

if length(force_solver)>0 && ~(force_solver==0) then
    options.solver = force_solver;
end

if length(options.solver)>0 then
    // Create tags with version also
    temp = solvers;
    for i = 1:size(temp,2)
        if length(temp{i}.version)>0 then
            temp(i).tag = tolower(strcat([temp{i}.tag, '-', temp{i}.version]));
        end
        TMP1(i)=0;
        if (solvers{i}.tag == options.solver)
         TMP1(i)=1;
        end
        TMP2(i)=0;
        if (temp{i}.tag == options.solver)
         TMP2(i)=1;
        end
    end

    index = find(TMP1);
    index2 = find(TMP2);
    if isempty(index) & isempty(index2) then
        solver = [];
        problem = -3;
        return;
    else
        solvers = solvers(union(index,index2));
    end
end
// Constraint types
//
// Semidefinite     (CS)
// Sec. ord. cone   (CC)
// Element-wise     (CE)
// KYP              (CK)
// Bilinear         (CB)
// Polynomial       (CP)
// Geometric        (CG)
//
// Objective functions
//
// MAXDET           (OM)
// Convex quadratic (OQ)
// Non-convex quad. (NQ) 
// Polynomial       (OP) 
// Geometric        (OG)
//
// Datatypes
//
// Complex          (DX)
// Integer          (DI)
// Binary           (DB)
// Multi-parametric (MP)

if ~isempty(strindex(ProblemString,'OM'))  && ~isempty(solvers) then
    keep = ones(max(size(solvers)),1);
    for i = 1:max(size(solvers))
        if solvers{i}.maxdet==0 & solvers{i}.sdp==0 then
            keep(i)=0;
        end
    end
    solvers = solvers(find(keep));
end

if ~isempty(strindex(ProblemString,'CK')) && ~isempty(solvers) then
    keep = ones(max(size(solvers)),1);
    for i = 1:max(size(solvers))
        if solvers{i}.sdp==0
            keep(i)=0;
        end
    end
    solvers = solvers(find(keep));
end

if ~isempty(strindex(ProblemString,'CS')) && ~isempty(solvers) then
    keep = ones(max(size(solvers)),1);
    for i = 1:max(size(solvers))
        if solvers{i}.sdp==0 then
            keep(i)=0;
        end
    end
    solvers = solvers(find(keep));
end

if ~isempty(strindex(ProblemString,'CE')) && ~isempty(solvers) then
    keep = ones(size(solvers,1),1);
    for i = 1:size(solvers,1)
        if solvers{i}.lp==0
            keep(i)=0;
        end
    end
    solvers = solvers(find(keep));
end

if  ~isempty(strindex(ProblemString,'DI')) && ~isempty(solvers) then
    keep = ones(size(solvers,1),1);
    for i = 1:size(solvers,1)
        if solvers{i}.integer==0 then
            keep(i)=0;
        end
    end
    solvers = solvers(find(keep));
end

if ~isempty(strindex(ProblemString,'DB')) && ~isempty(solvers) then
    keep = ones(size(solvers,1),1);
    for i = 1:size(solvers,1)
        if solvers{i}.binary==0 & solvers{i}.integer==0 then
            keep(i)=0;
        end
    end
    solvers = solvers(find(keep));
end

if ~isempty(strindex(ProblemString,'MP')) && ~isempty(solvers) then
    keep = ones(size(solvers,1),1);
    for i = 1:size(solvers,1)
        if solvers{i}.parametric==0 then
            keep(i)=0;
        end
    end
    solvers = solvers(find(keep));
end

// if ismember('B',ProblemString) && ~isempty(solvers)
//     keep = ones(length(solvers),1);
//     for i = 1:length(solvers)
//         if solvers{i}.binary==0
//             keep(i)=0;
//         end
//     end
//     solvers = solvers(find(keep));
// end

if ~isempty(strindex(ProblemString,'CC')) && ~isempty(solvers) && socp_are_really_qc then
    keep = ones(size(solvers,1),1);
    for i = 1:size(solvers,1)
        if (solvers{i}.qc==0) && (solvers{i}.socp==0) && (solvers{i}.sdp==0) then
            keep(i)=0;
        end
    end
    solvers = solvers(find(keep));
elseif  ~isempty(strindex(ProblemString,'CC')) && ~isempty(solvers) then
    keep = ones(size(solvers,1),1);
    for i = 1:size(solvers,1)
        if (solvers{i}.socp==0) && (solvers{i}.sdp==0) then //SPECIAL CASE, SOCP->SDP automatically
            keep(i)=0;
        end
    end
    solvers = solvers(find(keep));
end

if ~isempty(strindex(ProblemString,'NQ')) && ~isempty(solvers) then
    keep = ones(size(solvers,1),1);
    for i = 1:size(solvers,1)
        if (solvers{i}.ncqp==0 ) && (~options.relax) then
            keep(i)=0;
        end
    end
    solvers = solvers(find(keep));
end

// if ismember('Q',ProblemString) && ~isempty(solvers)
//     keep = ones(length(solvers),1);
//     for i = 1:length(solvers)
//         if solvers{i}.qp==0 
//             keep(i)=0;
//         end
//     end
//     solvers = solvers(find(keep));
// end

if ~isempty(strindex(ProblemString,'OQ')) && ~isempty(solvers) then
    keep = ones(max(size(solvers)),1);
    for i = 1:max(size(solvers))
        if solvers{i}.qp==0 && (solvers{i}.socp==0) && (solvers{i}.sdp==0) then //SPECIAL CASE, QP->SOCP->SDP automatically
            keep(i)=0;
        end
    end
    solvers = solvers(find(keep));
end

if ~isempty(strindex(ProblemString,'CB')) && ~isempty(solvers) then
    keep = ones(size(solvers,1),1);
    for i = 1:size(solvers,1)
        if (solvers{i}.bmi==0 ) && (~options.relax) then
            keep(i)=0;
        end
    end
    if find(keep)==[] then
     solvers=[];
    else
     solvers = solvers(find(keep));
    end
end

if ~isempty(strindex(ProblemString,'CP')) && ~isempty(solvers) then
    keep = ones(size(solvers,1),1);
    for i = 1:size(solvers,1)
        if (solvers{i}.pmi==0 ) && (~options.relax) then
            keep(i)=0;
        end
    end
    solvers = solvers(find(keep));
end

if ~isempty(strindex(ProblemString,'CG')) && ~isempty(solvers) then
    keep = ones(size(solvers,1),1);
    for i = 1:size(solvers,1)
        if (solvers{i}.gp==0 ) && (~options.relax) then
            keep(i)=0;
        end
    end
    solvers = solvers(find(keep));
end

if isempty(solvers) then
    solver = [];
else
    solver = solvers(1);
end

if isempty(solver) then
    if length(options.solver)>0 // User selected available solver, but it is not applicable
        problem = -4;
    else
        problem = -2;
    end
end
endfunction
