function F=set(varargin)
F=[];


if (isempty(varargin(:))) then
 F = lmi();
else
 error('perhaprs you are trying to make a string constraint which is not supported')
end

endfunction
