function s = spalloc(m,n,nzmax)
s = sparse([],[],[m,n]);

endfunction


