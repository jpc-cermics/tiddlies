function table(superheader,header,data,formats)
//TABLE Internal function to display tables

// Author Johan L�fberg
// $Id: table.sci,v 1.2 2011-03-22 12:39:15 solovyev Exp $

  [nheadersy,nheadersx] = size(header);
  [ndatay,ndatax] = size(data);
   
  datasizes = zeros(ndatay,ndatax);
  for i = 1:ndatay
    for j = 1:ndatax
    TMP =  (type(data(i,j),'string') == 'Sdpvar');
    if TMP then TMP = TMP & data(i,j)
    else TMP='N';
    end;
      if TMP(1)=='double' then
	data(i,j) = string(data(i,j));
      end
        datasizes(i,j) = length(data(i,j)); 
    end
  end

  headersizes = zeros(1,nheadersx);
  for j = 1:nheadersx
     TMP = (type(header(j),'string') == 'Sdpvar');
     if TMP then TMP = TMP & getfield(1,hader(j))
     else TMP='NO';
     end
    if TMP(1)=='double' then
      header(j) = string(header(j));
    end
    headersizes(1,j) = length(header(j)); 
  end
  
  if nargin<4 then
    formats=list();
    for i = 1:ndatax
      formats(i)=list(['header','just'],'r',['data','just'],'r');
    end
  end
  
  datawidth = sum(datasizes,2);
  
  MaxWidth = max([headersizes;datasizes],"r");
 // print([headersizes;datasizes],"r")
  HeaderLine = ['|'];
  for i = 1:nheadersx
//    printf("%s\n",sprintf(fillstringRight(header(i),MaxWidth(i)+2)))
    HeaderLine = strcat([HeaderLine, ' ', justify(fillstringRight(header(i),MaxWidth(i)+2),formats(i)(2)), '|']);
  end
  HeaderLine = strcat([HeaderLine, '']);
  
DataLine=[''];
  for j = 1:ndatay
    DataLine(j) = ['|'];
    for i = 1:ndatax
      DataLine(j) = strcat([DataLine(j), ' ',  justify(fillstringRight(data(j,i),MaxWidth(i)+2),formats(i)(4)), '|']);
    end
  end 
  if ~isempty(superheader) then
    printf("%s\n",sprintf(ascii(ones(1,length(HeaderLine)).*.ascii('+') )))
    printf("%s\n",sprintf("%s",['|' justify(fillstringLeft(superheader(1),length(HeaderLine)-2),'c') '|']))
  end
  printf("%s\n",sprintf(ascii(ones(1,length(HeaderLine)).*.ascii('+'))));
  printf("%s\n",sprintf(HeaderLine))
  printf("%s\n",sprintf(ascii(ones(1,length(HeaderLine)).*.ascii('+'))));
  for i = 1:size(DataLine,2)
    printf("%s\n",sprintf(DataLine(i)));
  end
  printf("%s\n",sprintf(ascii(ones(1,length(HeaderLine)).*.ascii('+'))));
  
endfunction

function x= truncstring1(x,n)
if length(x) > n
	x = [x(1:n-3) '...'];
end
endfunction

function x = fillstringLeft(x,n)
STR='';
for i=1:n-length(x)
STR=STR+ ' ';
end
x = [x STR];
endfunction


function X1 = fillstringRight(X1,N)
STR='';
for i=1:N-length(X1)
STR=STR+ ' ';
end
X1 = [STR X1];
endfunction


