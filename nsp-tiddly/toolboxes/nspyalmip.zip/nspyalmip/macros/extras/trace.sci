function t = trace_m(a)

    [m,n]=size(a)
    if m<>n then error('the argument of trace must be a square matrix');end
    t=sum(diag(a));


endfunction
