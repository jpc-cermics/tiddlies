function b = unique1D(a)
//UNIQUE1D  Internal function (version without checkings etc.)

// Author Johan L�fberg
// $Id: unique1D.sci,v 1.1 2010-07-18 19:44:15 solovyev Exp $
a=-a;
b = sort(a(:)');
b=-b;
b = b(diff([b %nan])~=0);
endfunction

