function options = sdpsettings(varargin)
//SDPSETTINGS Create/alter solver options structure.
//
//   OPTIONS = SDPSETTINGS with no input arguments returns
//   setting structure with default values
//
//   OPTIONS = SDPSETTINGS('NAME1',VALUE1,'NAME2',VALUE2,...) creates a
//   solution options structure OPTIONS in which the named properties have
//   the specified values.  Any unspecified properties have default values.
//   It is sufficient to type only the leading characters that uniquely
//   identify the property.  Case is ignored for property names.
//
//   OPTIONS = SDPSETTINGS(OLDOPTS,'NAME1',VALUE1,...) alters an existing options
//   structure OLDOPTS.
//
//
//   SDPSETTINGS PROPERTIES
//
//   GENERAL
//
//    solver             - Specify solver [''|sdpt3|sedumi|sdpa|pensdp|penbmi|csdp|dsdp|maxdet|lmilab|cdd|cplex|xpress|mosek|nag|quadprog|linprog|bnb|bmibnb|kypd|mpt|none ('')]
//    verbose            - Display-level [0|1|2|...(0)] (0-silent, 1-normal, >1-loud)
//    showprogress       - Show progress of YALMIP (suitable for large problems) [0|1 (0)]
//    cachesolvers       - Check for available solvers only first time solvesdp is called [0|1 (0)]
//    warning            - Shows a warning if a problems occurs when solving a problem (infeasibility, numerical problem etc.) [0|1 (0)]
//    beeponproblem      - Beeps when certain warning/error occurs [ integers -2|-1|1|2|3|4|5|6|7|8|9|10|11]
//    saveduals          - Dual variables are saved in YALMIP [0|1 (1)]
//    savesolverinput    - Keep all data sent to solver [0|1 (0)]
//    savesolveroutput   - Keep all data returned from solver [0|1 (0)]
//    removeequalities   - Let YALMIP remove equality constraints [-1|0|1 (0)] (-1:with double inequalities, 0:don't, 1:by QR decomposition)
//    convertconvexquad  - Convert convex quadratic constraints to second order cones [0|1 (1)]
//    radius             - Add radius constraint on all pimal variables ||x||<radius [double >=0 (inf)]
//    shift              - Add small perturbation to (try to) enforce strict feasibility [double >=0 (0)]
//    relax              - Disregard integrality constraint and relax nonlinear terms  [0|1 (0)]
//    reduce             - not supported yet
//    usex0              - Use the current value obtained from double as initial guess [0|1 (0)]
//
//   SUM-OF-SQUARES
//
//    options.sos, see help solvesos
//
//   BRANCH AND BOUND for mixed integer programs
//
//    options.bnb, see help bnb
//
//   BRANCH AND BOUND for BMIs (BETA)
//
//    options.bmibnb, see help bmibnb
//
//   APPROXIMATE MULTI-PARAMETRIC
//
//    options.mpcvx, see help mpcvx
//
//   EXTERNAL SOLVERS
//
//    See solver manuals.
//
//   See also SOLVESDP, SET, SDPVAR

// Author Johan L�fberg (ripped from odeset)
// $Id: sdpsettings.sci,v 1.2 2010-08-03 18:15:40 solovyev Exp $

// Print out possible values of properties.
if (nargin == 0) & (nargout == 0) then
    help sdpsettings
    return;
end
Names = ['solver'
    'verbose'
    'showprogress'
    'cachesolvers'
    'savesolveroutput'
    'savesolverinput'
    'saveduals'
    'removeequalities'
    'convertconvexquad'
    'beeponproblem'
    'warning'
    'radius'
    'shift'
    'reduce'
    'relax'
    'usex0'
    'savedebug'
    'bnb.branchrule'
    'bnb.method'
    'bnb.verbose'
    'bnb.solver'
    'bnb.inttol'
    'bnb.gaptol'
    'bnb.maxiter'
    'bnb.round'
    'bmilin.trust'
    'bmilin.alpha'
    'bmilin.beta'
    'bmilin.solver'
    'bmilin.maxiterls'
    'bmilin.maxiter'
    'bmibnb.branchmethod'
    'bmibnb.branchrule'
    'bmibnb.lpreduce'
    'bmibnb.lowrank'
    'bmibnb.lowersolver'
    'bmibnb.uppersolver'
    'bmibnb.lpsolver'
    'bmibnb.target'
    'bmibnb.vartol'
    'bmibnb.relgaptol'
    'bmibnb.absgaptol'
    'bmibnb.pdtol'
    'bmibnb.eqtol'
    'bmibnb.maxiter'
    'bmibnb.maxtime'
    'bmibnb.roottight'
    'mpcvx.solver'
    'mpcvx.eps'
    'sp.AbsTol'
    'sp.RelTol'
    'sp.nu'
    'sp.tv'
    'sp.Mfactor'
    'sp.NTiters'
    'maxdet.AbsTol'
    'maxdet.RelTol'
    'maxdet.gam'
    'socp.AbsTol'
    'socp.RelTol'
    'socp.target'
    'socp.max_iter'
    'socp.nu'
    'socp.outmode'
    'sdpt3.vers'
    'sdpt3.gam'
    'sdpt3.predcorr'
    'sdpt3.expon'
    'sdpt3.gaptol'
    'sdpt3.inftol'
    'sdpt3.steptol'
    'sdpt3.maxit'
    'sdpt3.sw2PC_tol'
    'sdpt3.use_corrprim'
    'sdpt3.printyes'
    'sdpt3.scale_data'
    'sdpt3.schurfun'
    'sdpt3.schurfun_parms'
    'sdpt3.randnstate'
    'sdpt3.spdensity'
    'sdpt3.rmdepconstr'
    'sdpt3.CACHE_SIZE'
    'sdpt3.LOOP_LEVEL'
    'sdpt3.cachesize'
    'sdpt3.linsys_options'
    'sdpt3.smallblkdim'
    'sedumi.removeequalities'
    'sedumi.alg'
    'sedumi.beta'
    'sedumi.theta'
    'sedumi.stepdif'
    'sedumi.w'
    'sedumi.mu'
    'sedumi.eps'
    'sedumi.bigeps'
    'sedumi.maxiter'
    'sedumi.vplot'
    'sedumi.stopat'
    'sedumi.denq'
    'sedumi.denf'
    'sedumi.numtol'
    'sedumi.bignumtol'
    'sedumi.numlvl'
    'sedumi.chol.skip'
    'sedumi.chol.abstol'
    'sedumi.chol.canceltol'
    'sedumi.chol.maxu'
    'sedumi.chol.maxuden'
    'sedumi.chol.numlvl'
    'sedumi.chol.deptol'
    'sedumi.chol.ph1tol'
    'sedumi.cg.qprec'
    'sedumi.cg.restol'
    'sedumi.cg.stagtol'
    'sedumi.cg.maxiter'
    'sedumi.cg.refine'    
    'dsdp.mu0'
    'dsdp.gaptol'
    'dsdp.maxit'
    'dsdp.penalty' 
    'dsdp.steptol'
    'dsdp.dobjmin'
    'dsdp.cc'
    'dsdp.dual_bound'
    'dsdp.bigM'    
    'dsdp.lp_barrier'
    'dsdp.r0'    
    'dsdp.objectiveconstant'    
    'dsdp.matrixfreesize'
    'dsdp.scale_data'    
    'dsdp.maxlanczos'
    'dsdp.max_trust_radius'
    'dsdp.maxtrustradius'
    'dsdp.max_mu_reduction'
    'dsdp.max_infeasible_trust_rad'
    'dsdp.max_infeasible_mu_reduct'   
    'sdplr.feastol'
    'sdplr.centol'
    'sdplr.dir'
    'sdplr.penfac'
    'sdplr.reduce'
    'sdplr.limit'
    'sdplr.maxrank'
    'sdplr.soln_factored'
    'sdpa.maxIteration'
    'sdpa.epsilonStar'
    'sdpa.lambdaStar'
    'sdpa.omegaStar'
    'sdpa.lowerBound'
    'sdpa.upperBound'
    'sdpa.betaStar'
    'sdpa.betaBar'
    'sdpa.gammaStar'
    'sdpa.epsilonDash'
    'sdpa.searchDir'
    'sdpa.isSymmetric'
    'glpk.lpsolver'
    'glpk.scale'
    'glpk.dual'
    'glpk.price'
    'glpk.relax'
    'glpk.tolbnd'
    'glpk.toldj'
    'glpk.tolpiv'
    'glpk.round'
    'glpk.objll'
    'glpk.objul'
    'glpk.itlim'
    'glpk.tmlim'
    'glpk.branch'
    'glpk.btrack'
    'glpk.tolint'
    'glpk.tolobj'
    'glpk.presol'
    'glpk.save'
    'cplex.presol'
    'cplex.niter'
    'cplex.epgap'
    'cplex.epagap'
    'cplex.relobjdif'
    'cplex.objdif'
    'cplex.tilim'
    'qsopt.dual'
    'qsopt.primalprice'
    'qsopt.dualprice'
    'qsopt.scale'
    'qsopt.maxiter'
    'qsopt.maxtime'
    'xpress.presol'
    'cdd.method'
    'pensdp.DEF'
    'pensdp.PBM_MAX_ITER'
    'pensdp.UM_MAX_ITER'
    'pensdp.OUTPUT'
    'pensdp.DENSE'
    'pensdp.LS'
    'pensdp.XOUT'
    'pensdp.UOUT'
    'pensdp.U0'
    'pensdp.MU'
    'pensdp.MU2'
    'pensdp.PBM_EPS'
    'pensdp.P_EPS'
    'pensdp.UMIN'
    'pensdp.ALPHA'
    'pensdp.P0'
    'penbmi.DEF'
    'penbmi.PBM_MAX_ITER'
    'penbmi.UM_MAX_ITER'
    'penbmi.OUTPUT'
    'penbmi.DENSE'
    'penbmi.LS'
    'penbmi.XOUT'
    'penbmi.UOUT'
    'penbmi.U0'
    'penbmi.MU'
    'penbmi.MU2'
    'penbmi.PBM_EPS'
    'penbmi.P_EPS'
    'penbmi.UMIN'
    'penbmi.ALPHA'
    'penbmi.P0'
    'lmilab.reltol'
    'lmilab.maxiter'
    'lmilab.feasradius'
    'lmilab.L'
    'miqp.solver'
    'miqp.method'
    'miqp.branchrule'
    'miqp.order'
    'miqp.verbose'
    'miqp.maxqp'
    'miqp.inftol'
    'miqp.matrixtol'
    'miqp.postol'
    'miqp.integtol'
    'miqp.maxQPiter'
    'sos.model'
    'sos.newton'
    'sos.congruence'
    'sos.clean'
    'sos.traceobj'
    'sos.reuse'
    'sos.inconsistent'
    'sos.separable'
    'csdp.axtol'
    'csdp.atytol'
    'csdp.objtol'
    'csdp.pinftol'
    'csdp.dinftol'
    'csdp.maxiter'
    'csdp.minstepfrac'
    'csdp.maxstepfrac'
    'csdp.minstepp'
    'csdp.minstepd'
    'csdp.usexzgap'
    'csdp.tweakgap'
    'specsdp.gatol1'
    'specsdp.gatol2'
    'specsdp.niter=20'
    'specsdp.faiseps'
    'specsdp.compleps'
    'specsdp.stateps'
    'specsdp.penfact'
    'specsdp.penmin'
    'specsdp.pendiv'
    'specsdp.peneps'
    'specsdp.Vinit'
    'specsdp.radius'
    'nag.featol'
    'nag.itmax'
    'nag.bigbnd'
    'nag.orthog'
    'kypd.solver'
    'kypd.lyapunovsolver'
    'kypd.reduce'
    'kypd.transform'
    'kypd.rho'
    'kypd.tol'];

    // Optimset has been deleted since is not supported by SciLab yet
    quadprognames = [''];
    linprognames = [''];

obsoletenames =[
    'abstol'
    'reltol'
    'accelerator'
    'maxiters'
    'abstol_init'
    'reltol_init'
    'accelerator_init'
    'maxiters_init'
    'tv'
    'mfactor'
    'sedumi.maxradius'
    'sedumi.uselpsolver'
    'sedumi.removeequalities'
    'silent'
    'sos.solvedual'];

[m,n] = size(Names);
names = tolower(Names);

if (nargin>0) && isstruct(varargin(1)) then
    options = varargin(1);
    paramstart = 2;
else
    paramstart = 1;
    // YALMIP options
    options.solver = '';
    options.verbose = 1;
    options.Warning = 1;
    options.cachesolvers = 0;
    options.beeponproblem = [-5 -4 -3 -2 -1];
    options.showprogress = 0;
    options.saveduals = %t;
    options.removeequalities = 0;
    options.savesolveroutput = 0;
    options.savesolverinput  = 0;
    options.convertconvexquad = 1;
    options.radius = %inf;
    options.relax = 0;
    options.usex0 = 0;
    options.shift = 0;
    options.reduce = 0;
    options.savedebug = 0;

    options.sos = hash_create(7);
    options.sos.model = 0;
    options.sos.newton = 1;
    options.sos.congruence = 2;
    options.sos.inconsistent = 0;
    options.sos.Clean = 1e-4;
    options.sos.traceobj = 0;
    options.sos.reuse = 1;

    options.bnb = hash_create(8);
    options.bnb.branchrule = 'max';
    options.bnb.method = 'depthbest';
    options.bnb.verbose = 1;
    options.bnb.solver = '';
    options.bnb.inttol = 1e-4;
    options.bnb.gaptol = 0;
    options.bnb.Round = 1;
    options.bnb.maxiter = 300;

    options.bmilin = hash_create(6);
    options.bmilin.trust = 2;
    options.bmilin.alpha = 0.75;
    options.bmilin.Beta = 0.01;
    options.bmilin.solver = '';
    options.bmilin.maxiterls = 10;
    options.bmilin.maxiter = 15;

    // Options for global BMI solver
    options.bmibnb = hash_create(17);
    options.bmibnb.branchmethod = 'best';
    options.bmibnb.branchrule = 'omega';
    options.bmibnb.sdpcuts = 0;
    options.bmibnb.lpreduce = 1;
    options.bmibnb.lowrank  = 0;
    options.bmibnb.lowersolver = '';
    options.bmibnb.uppersolver = '';
    options.bmibnb.lpsolver = 'glpk';
    options.bmibnb.target = -%inf;
    options.bmibnb.vartol = 1e-3;
    options.bmibnb.relgaptol = 1e-2;
    options.bmibnb.absgaptol = 1e-2;
    options.bmibnb.pdtol = -1e-6;
    options.bmibnb.eqtol = 1e-6;
    options.bmibnb.maxiter = 100;
    options.bmibnb.maxtime = 3600;
    options.bmibnb.roottight = 1;

    // Options for approximate multi-parametric
    //     options.mpcvx.solver = '';
    //     options.mpcvx.eps = 0.25;

    options.cdd = hash_create(1);
    options.cdd.method = 'criss-cross';

    options.cplex = hash_create(7);
    options.cplex.presol = 1;
    options.cplex.niter = 1;
    options.cplex.epgap = 1e-4;
    options.cplex.epagap = 1e-6;
    options.cplex.relobjdif = 0.0;
    options.cplex.objdif = 0.0;
    options.cplex.tilim = 1e75;

    options.csdp = hash_create(12);
    options.csdp.axtol  = 1e-8;
    options.csdp.atytol = 1e-8;
    options.csdp.objtol = 1e-8;
    options.csdp.pinftol = 1e8;
    options.csdp.dinftol = 1e8;
    options.csdp.maxiter = 100;
    options.csdp.minstepfrac = 0.93;
    options.csdp.maxstepfrac = 0.99;
    options.csdp.minstepp = 1e-8;
    options.csdp.minstepd = 1e-8;
    options.csdp.usexzgap = 0;
    options.csdp.tweakgap = 1;

    // Options for DSDP (3.4 -> 5.0)      
    options.dsdp = hash_create(20);
    options.dsdp.mu0 = -1;
    options.dsdp.gaptol = 1e-6;
    options.dsdp.maxit  = 400;
    options.dsdp.penalty  = 1e8;
    options.dsdp.steptol=1e-2;      
    options.dsdp.dual_bound = 1e30;
    options.dsdp.inftol = 1e-8;  
    options.dsdp.bigM = 0;  
    options.dsdp.lp_barrier = 0.01;    
    options.dsdp.r0 = -1;
    options.dsdp.cc = 0;
    options.dsdp.objectiveconstant = 0;    
    options.dsdp.matrixfreesize = 3000;
    options.dsdp.scale_data = 1;    
    options.dsdp.max_trust_radius = -1;
    options.dsdp.maxtrustradius = 1e8;
    options.dsdp.max_infeasible_trust_rad = -1;
    options.dsdp.max_infeasible_mu_reduct = 2;
    options.dsdp.max_mu_reduction = 1e8;    
    options.dsdp.maxlanczos = 20;

    // Options for GLPK
    options.glpk = hash_create(19);
    options.glpk.lpsolver = 1;
    options.glpk.scale = 1;
    options.glpk.dual = 0;
    options.glpk.price = 1;
    options.glpk.relax = 0.07;
    options.glpk.tolbnd = 1e-7;
    options.glpk.toldj = 1e-7;
    options.glpk.tolpiv = 1e-9;
    options.glpk.Round = 0;
    options.glpk.objll = -1e12;
    options.glpk.objul = 1e12;
    options.glpk.itlim = 1e4;
    options.glpk.tmlim = -1;
    options.glpk.branch = 2;
    options.glpk.btrack = 2;
    options.glpk.tolint = 1e-6;
    options.glpk.tolobj = 1e-7;
    options.glpk.presol = 1;
    options.glpk.Save = 0;

    //     options.specsdp.gatol1 = 5d-1;
    //     options.specsdp.gatol2 = 5d-3;
    //     options.specsdp.niter=20;
    //     options.specsdp.faiseps=1d-8;
    //     options.specsdp.compleps=1d-6;
    //     options.specsdp.stateps=1e-6;
    //     options.specsdp.penfact=2;
    //     options.specsdp.penmin=300;
    //     options.specsdp.pendiv= 5;
    //     options.specsdp.peneps=1.0d-8;
    //     options.specsdp.Vinit = 1.0;
    //     options.specsdp.radius= 1e9;

    options.kypd = hash_create(6);
    options.kypd.solver = '';
    options.kypd.lyapunovsolver = 'schur';
    options.kypd.reduce = 0;
    options.kypd.transform = 0;
    options.kypd.rho = 1;
    options.kypd.tol = 1e-8;

    options.lmilab = hash_create(4);
    options.lmilab.reltol = 1e-3;
    options.lmilab.maxiter = 100;
    options.lmilab.feasradius = 1e9;
    options.lmilab.L = 10;

    // Options for MAXDET solver
    options.maxdet = hash_create(4);
    options.maxdet.AbsTol = 1e-6;
    options.maxdet.RelTol = 1e-6;
    options.maxdet.gam    = 25;
    options.maxdet.NTiters= 50;

    options.nag = hash_create(4);
    options.nag.featol = sqrt(%eps);
    options.nag.itmax = 500;
    options.nag.bigbnd = 1e10;
    options.nag.orthog = 0;

    options.penbmi = hash_create(16);
    options.penbmi.DEF = 1;
    options.penbmi.PBM_MAX_ITER = 50;
    options.penbmi.UM_MAX_ITER = 100;
    options.penbmi.OUTPUT = 1;
    options.penbmi.DENSE = 0;
    options.penbmi.LS = 0;
    options.penbmi.XOUT = 0;
    options.penbmi.UOUT = 0;
    options.penbmi.U0 = 1;
    options.penbmi.MU = 0.7;
    options.penbmi.MU2 = 0.1;
    options.penbmi.PBM_EPS = 1e-7;
    options.penbmi.P_EPS = 1e-6;
    options.penbmi.UMIN = 1e-14;
    options.penbmi.ALPHA = 1e-2;
    options.penbmi.P0 = 0.01;

    options.pensdp = hash_create(16);
    options.pensdp.DEF = 1;
    options.pensdp.PBM_MAX_ITER = 50;
    options.pensdp.UM_MAX_ITER = 100;
    options.pensdp.OUTPUT = 1;
    options.pensdp.DENSE = 0;
    options.pensdp.LS = 0;
    options.pensdp.XOUT = 0;
    options.pensdp.UOUT = 0;
    options.pensdp.U0 = 1;
    options.pensdp.MU = 0.7;
    options.pensdp.MU2 = 0.1;
    options.pensdp.PBM_EPS = 1e-7;
    options.pensdp.P_EPS = 1e-6;
    options.pensdp.UMIN = 1e-14;
    options.pensdp.ALPHA = 1e-2;
    options.pensdp.P0 = 0.9;

    // Options for SDPA
    options.sdpa=hash_create(12);
    options.sdpa.maxIteration = 40 ;
    options.sdpa.epsilonStar = 1.0E-7;
    options.sdpa.lambdaStar  = 1.0E2  ;
    options.sdpa.omegaStar  = 2.0 ;
    options.sdpa.lowerBound  = -1.0E5  ;
    options.sdpa.upperBound  = 1.0E5  ;
    options.sdpa.betaStar  = 0.1  ;
    options.sdpa.betaBar  = 0.2 ;
    options.sdpa.gammaStar  = 0.9 ;
    options.sdpa.epsilonDash  = 1.0E-7 ;
    options.sdpa.searchDir = 1 ;
    options.sdpa.isSymmetric = 0 ;

    options.sdplr = hash_create(8);
    options.sdplr.feastol = 1e-5;
    options.sdplr.centol = 1e-1;
    options.sdplr.dir = 1;
    options.sdplr.penfac = 2;
    options.sdplr.reduce = 1;
    options.sdplr.limit = 3600;
    options.sdplr.soln_factored = 0;
    options.sdplr.maxrank = 0;

    // Options for SDPT3 (2.3 -> 3.01)
    options.sdpt3 = hash_create(22);
    options.sdpt3.vers     = 2;
    options.sdpt3.gam      = 0;
    options.sdpt3.predcorr = 1;
    options.sdpt3.expon    = [3 1 1 1];
    options.sdpt3.gaptol   = 1e-7;
    options.sdpt3.inftol   = 1e-7;
    options.sdpt3.steptol  = 1e-6;
    options.sdpt3.maxit    = 50;
    options.sdpt3.sw2PC_tol  = %inf;
    options.sdpt3.use_corrprim  = 0;
    options.sdpt3.printyes   = 1;
    options.sdpt3.scale_data = 0;
    options.sdpt3.schurfun   = [];
    options.sdpt3.schurfun_parms = [];
    options.sdpt3.randnstate = 0;
    options.sdpt3.spdensity   = 0.5;
    options.sdpt3.rmdepconstr = 0;
    options.sdpt3.CACHE_SIZE = 256;
    options.sdpt3.LOOP_LEVEL = 8;
    options.sdpt3.cachesize = 256;
    options.sdpt3.linsys_options = 'raugmatsys';
    options.sdpt3.smallblkdim = 15;

    // Options for SeDuMi (1.03 -> 1.05)
    options.sedumi = hash_create(27);
    options.sedumi.alg    = 2;
    options.sedumi.Beta   = 0.5;
    options.sedumi.theta  = 0.25;
    options.sedumi.stepdif= 0;
    options.sedumi.w      = [1 1];
    options.sedumi.mu     = 1.0;
    options.sedumi.eps    = 1e-9;
    options.sedumi.bigeps = 1e-3;
    options.sedumi.maxiter= 150;
    options.sedumi.vplot  = 0;
    options.sedumi.stopat     = -1;
    options.sedumi.denq   = 0.75;
    options.sedumi.denf   = 10;
    options.sedumi.numtol = 5e-7;
    options.sedumi.bignumtol = 0.9;
    options.sedumi.numlvlv = 0;
    options.sedumi.Chol = hash_create(5);
    options.sedumi.Chol.skip = 1;
    options.sedumi.Chol.canceltol = 1e-12;
    options.sedumi.Chol.maxu   = 5e5;
    options.sedumi.Chol.abstol = 1e-20;
    options.sedumi.Chol.maxuden= 5e2;

    options.sedumi.cg = hash_create(5);
    options.sedumi.cg.maxiter = 25;
    options.sedumi.cg.restol  = 5e-3;
    options.sedumi.cg.refine  = 1;
    options.sedumi.cg.stagtol = 5e-14;
    options.sedumi.cg.qprec   = 0;
    options.sedumi.maxradius = %inf;

    options.qsopt = hash_create(6);
    options.qsopt.dual = 0;
    options.qsopt.primalprice = 1;
    options.qsopt.dualprice = 6;
    options.qsopt.scale = 1;
    options.qsopt.maxiter = 300000;
    options.qsopt.maxtime = 10000.0;

    options.xpress = hash_create(1);
    options.xpress.presol = 1;

   // Assume optim is not available
    options.quadprog = [];
    options.linprog  = [];
    
end

i = paramstart;
// A finite state machine to parse name-value pairs.
n = fix((nargin-i+1)./2);
if (nargin-i+1-n.*2) ~= 0 then
    error('Arguments must occur in name-value pairs.');
end
expectval = 0;                          // start expecting a name, not a value
while i <= nargin do
    arg = varargin(i);

    if expectval == 0 then
        if ~(type(arg,'string') == 'SMat')
            error(sprintf('Expected argument %d to be a string property name.', i));
        end

        lowArg = tolower(arg);

        [temp,j_old] = strindex(lowArg,obsoletenames);
        if ~isempty(j_old) then
            // For compability...

            if strcmp(lowArg,'sedumi.removeequalities') then
                lowArg = 'removeequalities';
                arg = lowArg;

            elseif strcmp(lowArg,'silent') then
                lowArg = 'verbose';
                if varargin(i+1)==1
                    varargin(i+1) = 0;
                else
                    varargin(i+1) = 1;
                end
                warning('The field ''silent'' is obsolete. Use ''verbose'' instead')
            elseif strcmp(lowArg,'sedumi.maxradius') then
                lowArg = 'radius';
                arg = lowArg;
                warning('The field ''sedumi.maxradius'' is obsolete. Use ''radius'' instead')
            elseif strcmp(lowArg,'sos.solvedual') then
                lowArg = 'sos.model';
                arg = lowArg;
            else
                error(sprintf('The property name ''%s'' is obsolete. Sorry...', arg));
            end
        end
        
        [temp,j] = strindex(lowArg,names); //strmatch has been replaced with strindex
        if isempty(j) then                       // if no matches
            error(sprintf('Unrecognized property name ''%s''.', arg));
        elseif length(j) > 1  then              // if more than one match
            // Check for any exact matches (in case any names are subsets of others)
            [temp,k] = strindex(lowArg,names,'exact'); //strmatch has been replaced with strindex
            if length(k) == 1 then
                j = k;
            else
                msg = sprintf('Ambiguous property name ''%s'' ', arg);
                msg = [msg '(' deblank(Names(j(1)))];
                for k = j(2:length(j))'
                    msg = [msg ', ' stripblanks(Names(k))];
                end
                msg = sprintf('%s).', msg);
                error(msg);
            end
        end
        expectval = 1;                      // we expect a value next
    else
        execstr(strcat(['options.', Names(j), '= arg;']));
        expectval = 0;
    end
    i = i + 1;
end

if expectval then
    error(sprintf('Expected value for property ''%s''.', arg));
end
endfunction
