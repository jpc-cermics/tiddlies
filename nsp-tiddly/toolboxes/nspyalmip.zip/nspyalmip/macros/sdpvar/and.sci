function z = and_sdpvar_sdpvar(x,y)
//AND (overloaded)

// Author Johan L�fberg 
// $Id: and.sci,v 1.1 2010-07-09 17:59:29 solovyev Exp $   
x = true(x);
y = true(y);

z = x & y;
endfunction
