function Z= clean_sdpvar(X,tol)
//CLEAN Remove terms with small coefficients
//
// Z = clean(X,tol) removes all variables with a coefficient smaller than tol
//
// 

// Author Johan L�fberg 
// $Id: clean.sci,v 1.2 2011-03-22 12:39:15 solovyev Exp $  

temp=zeros(1, size(X.basis,'c'));

if nargin==1 then
    for i = 1:size(X.basis,'c')
      if( or(full(X.basis(:,i))~=0) ) then
       temp(i)=1;
      end
    end
    temp=temp';
    //temp(1)=[]; Does not work on 5.3.1
    temp = temp(2:max(size(temp,2),size(temp,1)));
    index = find(temp);
else
    X.basis(abs(X.basis)<tol)=0;
    index = find(or(abs(X.basis(:,2:size(X.basis,'c')))>tol,1));
end
if ~isempty(index) then
    Z = X;
    if length(index)~=length(Z.lmi_variables) then
        Z.basis = Z.basis(:,[1 1+index]);
        Z.lmi_variables = Z.lmi_variables(index);
    end
else
    Z = full(matrix(X.basis(:,1),X.n,X.m));
end

endfunction
