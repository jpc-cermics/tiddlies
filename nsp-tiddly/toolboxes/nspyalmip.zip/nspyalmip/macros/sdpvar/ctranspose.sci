function X=quote_sdpvar(X)
//CTRANSPOSE (overloaded)

// Author Johan L�fberg 
// $Id: ctranspose.sci,v 1.1 2010-07-25 19:21:05 solovyev Exp $

n = X.n;
m = X.m;
ind = matrix(matrix(1:n*m,n,m)',n*m,1);
X.basis = sparse(conj(full(X.basis(ind,:))));
X.n = m;
X.m = n;

endfunction
