function  LinearVariables = depends_sdpvar(x)
//DEPENDS Returns indicies to variables used in an SDPVAR object
//
// i = depends(x)
//
// Input
//    x : SDPVAR object
// Output
//    i : DOUBLE

// Author Johan L�fberg 
// $Id: depends.sci,v 1.1 2010-06-19 12:50:42 solovyev Exp $  

// FIX : SLOW, use code below, but that one fails for posynomials...
mt = full(yalmip('monomtable'));
LinearVariables = find(or(mt(x.lmi_variables,:)>0,dim=1));    
LinearVariables = LinearVariables(:)';

//nlv = yalmip('nonlinearvariables')';
// Messy for nonlinear variables
//if  any(ismembc(x.lmi_variables,nlv(1,:))) //& ~isempty(nlv) 
//    mt = yalmip('monomtable');
//    LinearVariables = find(any(mt(x.lmi_variables,:),1));    
//    LinearVariables = LinearVariables(:)';
//else
//    LinearVariables = x.lmi_variables;
//end
endfunction
