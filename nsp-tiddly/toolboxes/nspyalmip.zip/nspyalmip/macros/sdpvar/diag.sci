function Y= diag_sdpvar(X)
//DIAG (overloaded)

// Author Johan L�fberg 
// $Id: diag.sci,v 1.1 2010-07-18 19:43:52 solovyev Exp $  

Y = X;
n = X.n;
m = X.m;

// If it is a vector, all variables will be used
// so we have special code for this case

if min([n m])==1 then
	diagX = diag(X.basis(:,1));
	Y.basis = diagX(:);
	for i = 1:length(X.lmi_variables)
		diagX = diag(X.basis(:,i+1));
		Y.basis(:,i+1) = diagX(:);
	end   
	Y.lmi_variables = X.lmi_variables;
	Y.n = size(diagX,1);
	Y.m = size(diagX,2);
else
	lmi_variables = [];
	x_lmi_variables = X.lmi_variables;
	diagX = diag(matrix(X.basis(:,1),n,m));
	Y.basis = diagX(:);
	j = 1;
	for i = 1:length(x_lmi_variables)
		diagX = diag(matrix(X.basis(:,i+1),n,m));
		if (norm(diagX,%inf)>0) then
			Y.basis(:,j+1) = diagX(:);
			lmi_variables = [lmi_variables x_lmi_variables(i)];
			j = j+1;
		end
	end   
	Y.lmi_variables = lmi_variables;
	Y.n = size(diagX,1);
	Y.m = size(diagX,2);
end

Y = clean(Y);

endfunction
