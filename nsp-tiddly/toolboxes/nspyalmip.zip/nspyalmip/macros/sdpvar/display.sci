function ret_sdpvar(X)
//DISPLAY (overloaded)
// Author Johan L�fberg 
// $Id: display.sci,v 1.4 2010-09-26 18:04:09 jpc Exp $  
if (X.typeflag == 0) | (X.typeflag == 9) then
    n = X.n;
    m = X.m;
    if (n*m==1)
        
        if islinear(X) then
            classification = 'Linear scalar variable ';
        elseif is(X,'sigmonial') then
            classification = 'Sigmonial scalar variable ';
        elseif is(X,'bilinear')   then
            classification = 'Bilinear scalar variable ';   
        elseif is(X,'quadratic')   then
            classification = 'Quadratic scalar variable ';             
        else
            classification = 'Polynomial scalar variable ';    
        end
        
        if ~isreal(X.basis) then
            classification = strcat([classification, '(complex']);
        else
            classification = strcat([classification, '(real']);
        end		
        if ~islinear(X) then
            variables = getvariables(X);
            monomtable = yalmip('monomtable');
            if ((nnz(sdp_getbasematrix(X,0))==0) ) && (sum(diff(sum(monomtable(variables,:),2)))==0)
                classification = strcat([classification, ', homogeneous']); 
            end
        end
        if or(ismember(depends(X),yalmip('intvariables')) == 0) then
            classification = strcat([classification, ', integer']);
        else
            if or(ismember(depends(X),yalmip('binvariables')) == 0) then
                classification = strcat([classification, ', binary']);
            else
                if or(ismember(depends(X),yalmip('uncvariables')) == 0) then
                classification = strcat([classification, ', uncertain']);
            end
            end
        end   
        if or(ismember(depends(X),yalmip('parvariables')) == 0) then
            classification = strcat([classification, ', parametric']);        
        end            
          if ~isnan(double(X)) then
            classification = strcat([classification, ', current value : ', string(double(X))]);
        end
        classification = strcat([classification, ')']);
        
        printf("%s\n",[classification]);
    else
        if islinear(X) then
            classification = 'Linear matrix variable ';
        elseif is(X,'sigmonial') then
            classification = 'Sigmonial matrix variable ';
        elseif is(X,'bilinear')   then
            classification = 'Bilinear matrix variable ';   
        elseif is(X,'quadratic')  then 
            classification = 'Quadratic matrix variable ';             
        else
            classification = 'Polynomial matrix variable ';    
        end
        
        if isreal(X.basis) then
            if issymmetric(X)
                info = ' (symmetric, ';
            else
                info = ' (full, ';
            end;
            info = strcat([info, 'real']);
        else
            if issymmetric(X) then
                info = ' (symmetric, ';
            elseif ishermitian(X) then
                info = ' (hermitian, ';
            else
                info = ' (full, ';
            end;
            info = strcat([info, 'complex']);
        end;
        if X.typeflag==9 then
            info = strcat([info, ', KYP']);
        end
        if or(ismember(depends(X),yalmip('intvariables'))>0) then
            info = [info ', integer'];
        else
            if or(ismember(depends(X),yalmip('binvariables'))>0) then
                info = strcat([info, ', binary']);
            else
                if or(ismember(depends(X),yalmip('uncvariables'))>0) then
                info = strcat([info, ', uncertain']);
            end
            end
        end
        if or(ismember(depends(X),yalmip('parvariables'))>0) then
            info = strcat([info, ', parametric']);        
        end     
        x = recover(depends(X));
        if ~or(or(isnan(double(x))))
            doubleX = double(X);
            [n,m] = size(doubleX);
        else
            n = X.n;
            m = X.m;
        end
//        [n,m] = size(doubleX);
        if ~or(or(isnan(double(x)))) & (n==m) then
            eigX = spec(doubleX);
            eigX=abs(eigX);
            info = strcat([info, ', eigenvalues between [', string(min(eigX)), ',', string(max(eigX)), ']']);
        end
        info = strcat([info, ')']);
        printf("%s\n",sprintf(strcat([classification, string(n), 'x', string(m), info])));
    end;
elseif (X.typeflag==1) then
    printf("%s\n",sprintf('Relational object'));
elseif (X.typeflag==3) then
    printf("%s\n",sprintf('Relational object'));
elseif (X.typeflag==4) then
    printf("%s\n",sprintf('Relational object'));
elseif (X.typeflag==5) then
    printf("%s\n",sprintf('Cone object'));
elseif (X.typeflag==6) then
    printf("%s\n",sprintf('logdet object'));
elseif (X.typeflag==7) then
    printf("%s\n",sprintf('Integrality constraint'));
elseif (X.typeflag==10) then
    printf("%s\n",sprintf('Eigenvalue object'));  
elseif (X.typeflag==11) then
    printf("%s\n",sprintf('SOS object'));  
else
end
endfunction
