function sys=double_sdpvar(X)
//DOUBLE Returns current numerical value 

// Author Johan L�fberg 
// $Id: double.sci,v 1.1 2010-06-19 12:50:42 solovyev Exp $  

// Definition of nonlinear variables
mt = yalmip('monomtable');
mt_t = mt';
solution = sdpvar('getSolution');
lmi_variables = X.lmi_variables;
x_variables = depends(X);
opt_variables = solution.variables;
nonlinears = setdiff(lmi_variables,x_variables);

// All double values
values = ones(size(mt,1),1)*%nan;
values(solution.variables) = solution.optvar;
//disp(solution.variables);
if ~isempty(nonlinears) then
    use_these = find(ismember(lmi_variables,nonlinears));
    for i=use_these//1:length(lmi_variables)
        //if ismember(lmi_variables(i),nonlinears);
            //monom_i = mt(lmi_variables(i),:);
            monom_i = mt_t(:,lmi_variables(i));
            used_in_monom = find(monom_i);
            the_product = 1;
            for j = 1:length(used_in_monom)
//                the_product = the_product*values(used_in_monom(j))^mt(lmi_variables(i),used_in_monom(j));                
                the_product = the_product*values(used_in_monom(j))^monom_i(used_in_monom(j));                                
            end
            values(lmi_variables(i)) = the_product;
       // end
    end
end
sys = X.basis*[1;values(lmi_variables(:))];
if X.typeflag==10 then
    sys = spec(full(matrix(sys,X.n,X.m)));  
else
    sys = full(matrix(sys,X.n,X.m));
end

endfunction
