function Y1 = eq_sdpvar_sdpvar(X,Y)
//EQ (overloaded)

// Author Johan L�fberg
// $Id: eq.sci,v 1.2 2011-03-05 00:04:15 solovyev Exp $

try
    Y1 = X-Y;
    if type(Y1,'string')=='Mat' then
        if nnz(Y1)>0 then
            // What to do here?
        else
            Y1 = [];
            return
        end
    end
    Y1.typeflag = 3;
catch
    error('sdpvar eq has failed')
end

endfunction

function Y1 = eq_sdpvar_m(X,Y)
//EQ (overloaded)

// Author Johan L�fberg
// $Id: eq.sci,v 1.2 2011-03-05 00:04:15 solovyev Exp $

try
    Y1 = X-Y;
    if type(Y1,'string')=='Mat' then
        if nnz(Y1)>0 then
            // What to do here?
        else
            Y1 = [];
            return
        end
    end
    Y1.typeflag = 3;
catch
    error('eq_sdpvar_m has failed')
end

endfunction
