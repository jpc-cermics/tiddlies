function ML = exponents_sdpvar(poly,x)
//EXPONENTS Internal function to extract powers of nonlinear expression

// Author Johan L�fberg
// $Id: exponents.sci,v 1.1 2010-07-10 20:34:20 solovyev Exp $

mt = yalmip('monomtable');
x_lin = getvariables(poly);

x_var = getvariables(x);

ML = mt(x_lin,x_var);
if or(ismember(1,poly)>0)
    ML = [zeros(1,length(x));ML];
end
endfunction
