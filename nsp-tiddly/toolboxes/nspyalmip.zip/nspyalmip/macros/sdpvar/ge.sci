function y = ge_sdpvar_m(X,Y)
//GE (overloaded)

// Author Johan L�fberg
// $Id: ge.sci,v 1.1 2010-07-09 17:59:29 solovyev Exp $

try
    y = constraint(X,'>=',Y);
catch
    error(lasterror)
end

endfunction

function y = ge_sdpvar_sdpvar(X,Y)
//GE (overloaded)

// Author Johan L�fberg
// $Id: ge.sci,v 1.1 2010-07-09 17:59:29 solovyev Exp $

try
    y = constraint(X,'>=',Y);
catch
    error(lasterror)
end

endfunction

function y = ge_m_sdpvar(X,Y)
//GE (overloaded)

// Author Johan L�fberg
// $Id: ge.sci,v 1.1 2010-07-09 17:59:29 solovyev Exp $

try
    y = constraint(X,'>=',Y);
catch
    error(lasterror)
end

endfunction
