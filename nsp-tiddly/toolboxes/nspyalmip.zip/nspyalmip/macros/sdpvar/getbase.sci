function Q=getbase_sdpvar(X)
//GETBASE Internal function to extract all base matrices

// Author Johan L�fberg 
// $Id: getbase.sci,v 1.1 2010-07-18 19:43:52 solovyev Exp $  

Q=X.basis;

endfunction
  
      
