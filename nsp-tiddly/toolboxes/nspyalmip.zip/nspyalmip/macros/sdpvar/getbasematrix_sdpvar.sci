function Q=getbasematrix_sdpvar(X,ind)
//GETBASEMATRIX Internal function to extract basematrix for variable IND

// Author Johan L�fberg 
// $Id: getbasematrix_sdpvar.sci,v 1.1 2010-09-26 17:46:44 jpc Exp $  
  if ind==0 then
    base = X.basis(:,1);
    Q = matrix(base,X.n,X.m);
    return;
  end
  here = find(X.lmi_variables==ind);
  if isempty(here) then
    Q = sparse([],[],[X.n,X.m]);
  else
    base = X.basis(:,here+1);
    Q = matrix(base,X.n,X.m);
  end
endfunction


