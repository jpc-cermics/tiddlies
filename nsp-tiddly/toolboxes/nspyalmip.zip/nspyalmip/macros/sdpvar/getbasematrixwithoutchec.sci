function Q=getbasematrixwithoutchec_sdpvar(X,ind)
//GETBASEMATRIXWITHOUTCHECK Internal function to extract basematrix for variable IND

// Author Johan L�fberg 
// $Id: getbasematrixwithoutchec.sci,v 1.1 2010-07-18 19:43:52 solovyev Exp $  
Q=matrix(X.basis(:,ind+1),X.n,X.m);

endfunction
  
  
      
