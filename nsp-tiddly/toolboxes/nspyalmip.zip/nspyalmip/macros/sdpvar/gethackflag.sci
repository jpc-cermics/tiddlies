function y = gethackflag_sdpvar(X)
//GETHACKFLAG Internal function to extract constraint type

// Author Johan L�fberg 
// $Id: gethackflag.sci,v 1.1 2010-07-09 17:59:29 solovyev Exp $  

y = X.typeflag;
endfunction
