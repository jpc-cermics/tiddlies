function varargout = getvariables_sdpvar(X,whatvars)
//GETVARIABLES Returns variable indicies to variables used in a SDPVAR object
//
// i = getvariables(x)
//
// Input
//    x : SDPVAR object
// Output
//    i : DOUBLE
//
// Note : The difference compared DEPENDS is that nonlinear terms
//        are reported as separate variables.

// Author Johan L�fberg
// $Id: getvariables.sci,v 1.1 2010-06-19 12:50:42 solovyev Exp $

varargout = list([],[]);

select nargin
    case 1
        varargout(1) = X.lmi_variables;
    case 2
        [sqrList,CompressedList] = yalmip('nonlinearvariables');
        used_variables = sdp_getvariables(X);
        if isempty(sqrList) then
            LinearVariables = used_variables;
            NonlinearVariables=[];
        else
            LinearVariables    = setdiff(used_variables,sqrList(:,1));
            NonlinearVariables = setdiff(used_variables,LinearVariables);
        end
        select whatvars
            case 'linear' then
                varargout(1) = LinearVariables;
            case 'nonlinear' then
                varargout(1) = NonlinearVariables;
            case 'both' then
                varargout(1) = LinearVariables;
                varargout(2) = NonlinearVariables;
            else
                error
        end
    else
        error
end
endfunction
