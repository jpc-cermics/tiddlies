function y = gt_sdpvar_m(X,Y)
//GT (overloaded)

// Author Johan L�fberg
// $Id: gt.sci,v 1.2 2011-03-05 00:04:15 solovyev Exp $

try
    y = constraint(X,'>',Y);
catch
    error("cant make a constraint >")
end

endfunction

function y = gt_m_sdpvar(X,Y)
//GT (overloaded)

// Author Johan L�fberg
// $Id: gt.sci,v 1.2 2011-03-05 00:04:15 solovyev Exp $

try
    y = constraint(X,'>',Y);
catch
    error("cant make a constraint >")
end

endfunction

function y = gt_sdpvar_sdpvar(X,Y)
//GT (overloaded)

// Author Johan L�fberg
// $Id: gt.sci,v 1.2 2011-03-05 00:04:15 solovyev Exp $

try
    y = constraint(X,'>',Y);
catch
    error("cant make a constraint > ")
end

endfunction
