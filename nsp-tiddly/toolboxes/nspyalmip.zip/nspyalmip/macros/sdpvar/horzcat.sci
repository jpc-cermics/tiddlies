function y = concatr_sdpvar_m(varargin)
//HORZCAT (overloaded)

// Author Johan L�fberg 
// $Id: horzcat.sci,v 1.1 2010-07-25 19:21:05 solovyev Exp $  
prenargin = nargin;
// Fast exit
if prenargin<2 then
    y=varargin(1);
    return
end

// Get dimensions
n = zeros(prenargin,1);
m = zeros(prenargin,1);
for i = 1:prenargin
    [n(i),m(i)]=size(varargin(i));
end

// Keep only non-empty
keep_these = find((n.*m)~=0);
if length(keep_these)<length(n) then
    varargin = list(varargin(keep_these));
    n = n(keep_these);
    m = m(keep_these);
end;

// All heights should be equal
if or(n~=n(1))
    error('All matrices on a row in the bracketed expression must have the same number of rows.');
end

// Same code for vert and horz
y = stack(varargin);
endfunction

function y = concatr_sdpvar_sdpvar(varargin)
//HORZCAT (overloaded)

// Author Johan L�fberg 
// $Id: horzcat.sci,v 1.1 2010-07-25 19:21:05 solovyev Exp $  
prenargin = nargin;
// Fast exit
if prenargin<2 then
    y=varargin(1);
    return
end

// Get dimensions
n = zeros(prenargin,1);
m = zeros(prenargin,1);
for i = 1:prenargin
    [n(i),m(i)]=size(varargin(i));
end

// Keep only non-empty
keep_these = find((n.*m)~=0);
if length(keep_these)<length(n) then
    varargin = list(varargin(keep_these));
    n = n(keep_these);
    m = m(keep_these);
end;

// All heights should be equal
if or(n~=n(1)) then
    error('All matrices on a row in the bracketed expression must have the same number of rows.');
end

// Same code for vert and horz
y = stack(varargin);

endfunction

function y = concatr_m_sdpvar(varargin)
//HORZCAT (overloaded)

// Author Johan L�fberg 
// $Id: horzcat.sci,v 1.1 2010-07-25 19:21:05 solovyev Exp $  
prenargin = nargin;
// Fast exit
if prenargin<2 then
    y=varargin(1);
    return
end

// Get dimensions
n = zeros(prenargin,1);
m = zeros(prenargin,1);
for i = 1:prenargin
    [n(i),m(i)]=size(varargin(i));
end

// Keep only non-empty
keep_these = find((n.*m)~=0);
if length(keep_these)<length(n) then
    varargin = list(varargin(keep_these));
    n = n(keep_these);
    m = m(keep_these);
end;

// All heights should be equal
if or(n~=n(1))
    error('All matrices on a row in the bracketed expression must have the same number of rows.');
end

// Same code for vert and horz
y = stack(varargin);

endfunction
