function YESNO = is_sdpvar(X,property,additional)
//IS Check property of variable.
//   d = IS(x,property) returns 1 if 'property' holds
//
//   Properties possible to test are: 'real', 'symmetric', 'hermitian',
//   'scalar', 'linear', 'homogeneous', 'integer', 'binary'

// Author Johan L�fberg 
// $Id: is.sci,v 1.2 2010-07-10 20:34:20 solovyev Exp $   

select property
    case 'logic' then
        YESNO = X.typeflag==12;
    case 'binary' then
        YESNO = or(ismember(depends(X),yalmip('binvariables')));
    case 'integer' then
        YESNO = or(ismember(depends(X),yalmip('intvariables')));
    case 'real' then
        YESNO = isreal(X);
    case 'symmetric' then
        YESNO = issymmetric(X);
    case 'hermitian' then
        YESNO = ishermitian(X);
    case 'scalar' then
        YESNO = (X.n*X.m)==1;
    case 'linear' then
        monomtable = yalmip('monomtable');
         monomtable = full(monomtable(getvariables(X),:));
         YESNO = ~(or(find(or(0>monomtable,dim=2) | or(monomtable-fix(monomtable)>0,dim=2))>0));   
         YESNO = YESNO &  and(sum(monomtable,2)<=1);
       // YESNO = islinear(X);   
    case 'bilinear' then
         monomtable = yalmip('monomtable');
         monomtable = full(monomtable(getvariables(X),:));
         YESNO = ~(or(find(or(0>monomtable,dim=2) | or(monomtable-fix(monomtable)>0,dim=2))>0));   
         YESNO = YESNO & and(sum(monomtable,2)<=2);
         mt = full(monomtable);
         YESNO = YESNO & and(max(mt,'r')<=1);
     case 'quadratic' then
         YESNO = (degree(X)==2);   
    case 'sigmonial' then
          monomtable = yalmip('monomtable');
          monomtable = full(monomtable(getvariables(X),:));
          YESNO = any(find(any(monomtable<0,2) | any(monomtable-fix(monomtable),2)));   
    case 'nonlinear' then
        YESNO = ~islinear(X);   
    case 'homogeneous' then   
        [sqrList,CompressedList] = yalmip('nonlinearvariables');
        [LinearTerms,NonlinearVariables] = getvariables(X,'both');
        if isempty(NonlinearVariables) then
            YESNO = nnz(getbasematrix(X,0))==0;
        else
            // No linear terms
            YESNO = isempty(LinearTerms);
            // No constant terms
            YESNO = YESNO & (nnz(getbasematrix(X,0))==0);
            // Largest degree+1
            maxdegree = sum(mtlb_any(CompressedList(find(ismember(CompressedList,NonlinearVariables)),:),1));
            // All same degree
            YESNO = YESNO & mtlb_all(mtlb_all(CompressedList(find(ismember(CompressedList,NonlinearVariables)),2:maxdegree)>0));
        end
    case 'sos' then
        YESNO = (X.typeflag==11);
    else
        YESNO = 5;
end
endfunction

