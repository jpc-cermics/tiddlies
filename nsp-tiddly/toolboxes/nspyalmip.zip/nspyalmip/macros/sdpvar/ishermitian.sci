function issym=ishermitian_sdpvar(X)
//ISHERMITIAN Check if variable is Hermitian

// Author Johan L�fberg 
// $Id: ishermitian.sci,v 1.2 2011-03-22 12:39:15 solovyev Exp $  

n = X.n;
m = X.m;
issym = 0;
if (n==m) then
    // What are the linear indicies to the transposed matrices
    ind = matrix(matrix(1:n^2,n,n)',n^2,1);
    X1 = X.basis;
    X2 = conj(X1(ind,:));
    issym = norm(X1-X2,1)<1e-10;
end
endfunction
