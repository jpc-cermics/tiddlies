function sys=islinear_sdpvar(x)
//ISLINEAR Check if variable is linear       
//
// p = islinear(X)
//
// X : SDPVAR object
// p : boolean 0/1

// Author Johan L�fberg 
// $Id: islinear.sci,v 1.1 2010-06-19 12:50:42 solovyev Exp $  
try
    sys = is(x,'linear');
catch
    print('I have messed up something internally in YALMIP. Sorry...')
    print('Type yalmip(''clear'') and re-define the problem.');
    print(' ')
    print('This problem typically occurs if you have SDPVAR variables in');
    print('work-space, and call a function where you are using ')
    print('the command yalmip(''clear''). When control is returned to');
    print('the work-space, things are messed up...');
    print('Internal problems in YALMIP');
end

endfunction
