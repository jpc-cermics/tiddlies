function YESNO = ismember_double(x,p)
//ISMEMBER (overloaded)

// Author Johan L�fberg 
// $Id: ismember.sci,v 1.1 2010-06-19 12:50:42 solovyev Exp $  

YESNO = or(full(p.basis(:,1)));
endfunction
    
function YESNO = ismember_sdpvar(x,p)
x_base = x.basis;
x_vars = x.lmi_variables;

p_base = x.basis;
p_vars = x.lmi_variables;

// Member at all
YESNO = ismember(x.lmi_variables,p.lmi_variables);
if YESNO then
    index_in_x_vars = find(x.lmi_variables == p.lmi_variables);
    YESNO = full(or(p.basis(:,1+index_in_x_vars),2));
    if min(p.n,p.m)~=1 then
        YESNO = matrix(YESNO,p.n,p.m);
    end
end
endfunction