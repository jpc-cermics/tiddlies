function res = isreal_sdpvar(Y)
//ISREAL (overloaded)

// Author Johan L�fberg 
// $Id: isreal.sci,v 1.1 2010-07-09 17:59:29 solovyev Exp $   
res = isreal(Y.basis);

endfunction
