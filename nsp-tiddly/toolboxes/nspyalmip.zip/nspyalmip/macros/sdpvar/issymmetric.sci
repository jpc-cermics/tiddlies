function issym=issymmetric_sdpvar(X)
//ISSYMMETRIC Check if variable is symmetric

// Author Johan L�fberg 
// $Id: issymmetric.sci,v 1.1 2010-06-19 12:50:42 solovyev Exp $  

tmp=X;


n = tmp.n;
m = tmp.m;
issym = 0;
if (n==m) then
	// What are the linar indicies to the transposed matrices
	ind = matrix(matrix(1:n^2,n,n)',n^2,1);
	issym = norm(tmp.basis-tmp.basis(ind,:),1)<1e-10;
end
endfunction
