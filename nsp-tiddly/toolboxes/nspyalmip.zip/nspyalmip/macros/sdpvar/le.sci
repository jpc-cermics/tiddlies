function y = le_sdpvar_m(X,Y)
//LE (overloaded)

// Author Johan L�fberg
// $Id: le.sci,v 1.1 2010-07-09 17:59:29 solovyev Exp $

try
    y = constraint(X,'<=',Y);
catch
    error(lasterror)
end

endfunction

function y = le_sdpvar_sdpvar(X,Y)
//LE (overloaded)

// Author Johan L�fberg
// $Id: le.sci,v 1.1 2010-07-09 17:59:29 solovyev Exp $

try
    y = constraint(X,'<=',Y);
catch
    error(lasterror)
end

endfunction

function y = le_m_sdpvar(X,Y)
//LE (overloaded)

// Author Johan L�fberg
// $Id: le.sci,v 1.1 2010-07-09 17:59:29 solovyev Exp $

try
    y = constraint(X,'<=',Y);
catch
    error(lasterror)
end

endfunction
