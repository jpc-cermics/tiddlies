function y = lt_sdpvar_m(X,Y)
//LT (overloaded)

// Author Johan L�fberg
// $Id: lt.sci,v 1.1 2010-07-09 17:59:29 solovyev Exp $

try
    y = constraint(X,'<',Y);
catch
    error(lasterror)
end

endfunction

function y = lt_sdpvar_sdpvar(X,Y)
//LT (overloaded)

// Author Johan L�fberg
// $Id: lt.sci,v 1.1 2010-07-09 17:59:29 solovyev Exp $

try
    y = constraint(X,'<',Y);
catch
    error(lasterror)
end

endfunction

function y = lt_m_sdpvar(X,Y)
//LT (overloaded)

// Author Johan L�fberg
// $Id: lt.sci,v 1.1 2010-07-09 17:59:29 solovyev Exp $

try
    y = constraint(X,'<',Y);
catch
    error(lasterror)
end

endfunction
