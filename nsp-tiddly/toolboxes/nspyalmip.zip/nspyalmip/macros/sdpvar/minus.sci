function y = minus_sdpvar_sdpvar(X,Y)
//MINUS (overloaded)

// Author Johan L�fberg
// $Id: minus.sci,v 1.2 2010-07-10 20:34:20 solovyev Exp $
 //	if (X.typeflag~=0) | (Y.typeflag~=0)
        //		error('Relational objects cannot be manipulated')
        //	end
        n_X = X.n;
        m_X = X.m;
        n_Y = Y.n;
        m_Y = Y.m;
        x_isscalar = (n_X*m_X==1);
        y_isscalar = (n_Y*m_Y==1);
        any_scalar = x_isscalar | y_isscalar; 
 
        if (~((n_X==n_Y) & (m_X==m_Y)) & (any_scalar==%f)) then
            error('Matrix dimensions must agree.')
        end

   
        all_lmi_variables = unique1D([X.lmi_variables Y.lmi_variables]);
        y = X;
           y.lmi_variables = all_lmi_variables;

        in_X = find(ismember(all_lmi_variables,X.lmi_variables));
        in_Y = find(ismember(all_lmi_variables,Y.lmi_variables));
        // Preallocate good for large problems
        if 0 then
            [ix,jx,sx] = find(X.basis);
            [iy,jy,sy] = find(Y.basis);
            mapX = [1 1+in_X];
            mapY = [1 1+in_Y];
            jx = mapX(jx);
            jy = mapY(jy);
            basis_X = sparse(ix,jx,sx,n_X*m_X,1+length(all_lmi_variables));
            basis_Y = sparse(iy,jy,sy,n_Y*m_Y,1+length(all_lmi_variables));
        else
            basis_X = sparse(n_X*m_X,1+length(all_lmi_variables),nnz(X.basis));
            basis_Y = sparse(n_Y*m_Y,1+length(all_lmi_variables),nnz(Y.basis));
            basis_X(:,[1 1+in_X])=X.basis;
            basis_Y(:,[1 1+in_Y])=Y.basis;
        end
        // Fix addition of matrix+scalar
        if n_X*m_X<n_Y*m_Y then
            y.n = n_Y;
            y.m = m_Y;
            basis_X = ones(n_Y*m_Y,1).*.basis_X;
        end
        if n_Y*m_Y<n_X*m_X then
            y.n = n_X;
            y.m = m_X;
            basis_Y = ones(n_X*m_X,1).*.basis_Y;
        end
  
        // OK, solution is...
        y.basis = basis_X-basis_Y;
        y = clean(y);
// Update info on KYP objects
if  X.typeflag==9 & Y.typeflag==9 then
    error('Substraction of KYP objects currently not supported')
end
if  Y.typeflag==9 then
    y.extra.M = -Y.extra.M+X;
    y.extra.negated = ~Y.extra.negated;
    return
end
if  X.typeflag==9 then
    y.extra.M = y.extra.M-Y;
    return
end
endfunction

function y = minus_sdpvar_m(X,Y)
        //	if X.typeflag~=0
        //		error('Relational objects cannot be manipulated')
        //	end
        if isempty(Y) then
            y=[];
            return
        end
        y = X;
        n_X = X.n;
        m_X = X.m;
        [n_Y,m_Y] = size(Y);
        x_isscalar = (n_X*m_X==1);
        y_isscalar = (n_Y*m_Y==1);
        any_scalar = x_isscalar | y_isscalar;

        // Silly hack
        // Taking X-scalar(0) takes unnecessary time
        // and is used in most definitions of LMIs
        if (y_isscalar & (Y==0)) then
            return
        end

        if any_scalar | ([n_Y m_Y]==[n_X m_X]) then
            if x_isscalar then
                y.basis = ones(n_Y*m_Y,1).*.y.basis;
                y.n = n_Y;
                y.m = m_Y;
            end
            y.basis(:,1) = y.basis(:,1)-Y(:);
        else
            error('Matrix dimensions must agree.');
        end



if  X.typeflag==9 then
    y.extra.M = y.extra.M-Y;
    return
end
endfunction

function y = minus_m_sdpvar(X,Y)
        if isempty(X) then
            y = [];
            return
        end

        y = Y;
        n_Y = Y.n;
        m_Y = Y.m;
        [n_X,m_X] = size(X);
        x_isscalar = (n_X*m_X==1);
        y_isscalar = (n_Y*m_Y==1);
        any_scalar = x_isscalar | y_isscalar;

        if any_scalar | ([n_Y m_Y]==[n_X m_X]) then
            if y_isscalar then
                y.basis = ones(n_X*m_X,1).*.y.basis;
                y.n = n_X;
                y.m = m_X;
            end
            y.basis = -y.basis;
            y.basis(:,1) = y.basis(:,1)+X(:);
        else
            error('Matrix dimensions must agree.');
        end

// Update info on KYP objects
if  Y.typeflag==9 then
    y.extra.M = -Y.extra.M+X;
    y.extra.negated = ~Y.extra.negated;
    return
end
endfunction


