function Z = mult_sdpvar_m(X,Y)

//if isempty(X) | isempty(Y) then
//    Z = [];
//    return
//end
 n_X = X.n;
        m_X = X.m;
        [n_Y,m_Y] = size(Y);

        x_isscalar =  (n_X*m_X==1);
        y_isscalar =  (n_Y*m_Y==1);

        if ~x_isscalar then
            if ((m_X~= n_Y & ~y_isscalar))
                error('Inner matrix dimensions must agree.')
            end
        end

        if ((~y_isscalar) & (X.typeflag == 5)) | ((y_isscalar) & (X.typeflag == 5) & (Y<0)) then
            error('Norm expression can only be multiplied with non-negative scalar');
        end

        n = n_X;
        m = m_Y;
        Z = X;

        if x_isscalar then
            Z.n = n_Y;
            Z.m = m_Y;
            Z.basis = sparse(kron(full(Z.basis),Y(:)));
            Z = clean(Z);
            return
        elseif y_isscalar then
            Z.n = n_X;
            Z.m = m_X;
            Z.basis = Z.basis*Y;
            Z = clean(Z);
            return
        end

        Z.n = n;
        Z.m = m;
        Z.basis = sparse(kron(Y.',eye(n_X,n_X))*X.basis);

Z = clean(Z);
endfunction


function Z = mult_sdpvar_sdpvar(X,Y)
//if (X==[]) | (Y==[]) then
//    Z = [];
//    return
//end

        if (X.typeflag==5) & (Y.typeflag==5) then
            error('Product of norms not allowed');
        end

        try
            x_isscalar =  (X.n*X.m==1);
            y_isscalar =  (Y.n*Y.m==1);

            all_lmi_variables = unique1D([X.lmi_variables Y.lmi_variables]);
            Z = X;
            Z.n = 1;
            Z.m = 1;
            Z.lmi_variables = all_lmi_variables;
            Z.basis = sparse([]);

            // Awkward code due to bug in ML6.5
            Xbase = matrix(X.basis(:,1),X.n,X.m);
            Ybase = matrix(Y.basis(:,1),Y.n,Y.m);
            if x_isscalar then
                Xbase = sparse(full(Xbase));
            end
            if y_isscalar then
                Ybase = sparse(full(Ybase));
            end
            

  
            // This is what we want, but not supported in 5.3.1
            //index_X = ismembc2(all_lmi_variables,X.lmi_variables);
            //index_Y = ismembc2(all_lmi_variables,Y.lmi_variables);
           
            index_Y = zeros(length(all_lmi_variables),1);
            index_X = zeros(length(all_lmi_variables),1);

            for j = 1:length(all_lmi_variables)
                indexy = find(all_lmi_variables(j)==Y.lmi_variables);
                indexx = find(all_lmi_variables(j)==X.lmi_variables);
                if ~isempty(indexy) then
                    index_Y(j) = indexy;
                end
                if ~isempty(indexx) then
                    index_X(j) = indexx;
                end
            end

            ny = Y.n;
            my = Y.m;
            nx = X.n;
            mx = X.m;

            Z.lmi_variables = [Z.lmi_variables zeros(1,length(X.lmi_variables)*length(Y.lmi_variables))];
            
            // Linear terms
            base = Xbase*Ybase;
            Z.basis = base(:);
            x_base_not_zero = nnz(Xbase)>0;
            y_base_not_zero = nnz(Ybase)>0;
            i=0;
            for i = 1:length(all_lmi_variables)
                base = 0;
                if index_Y(i) <> 0 & x_base_not_zero then
                    base = Xbase*getbasematrixwithoutchec(Y,index_Y(i));
                end
                if index_X(i) <> 0  & y_base_not_zero then
                    base = base + getbasematrixwithoutchec(X,index_X(i))*Ybase;
                end
                Z.basis(:,i+1) = base(:);
            end

            // Nonlinear terms
            i = length(all_lmi_variables)+1;
             
            mt = yalmip('monomtable');
            oldmt = mt;
            nvar = length(all_lmi_variables);
            local_mt = mt(all_lmi_variables,:);
            used_variables = find((or(full(local_mt)>0,dim=1)));            
            local_mt = local_mt(:,used_variables);
            theyvars = find(index_Y);
            thexvars = find(index_X);
            hash = randn(size(mt,2),1);
            mt_hash = mt*hash;
            hash = hash(used_variables);

            for ix = thexvars(:)'

                if mx==1 then
                    Xibase = X.basis(:,1+index_X(ix));
                else
                    Xibase = matrix(X.basis(:,1+index_X(ix)),nx,mx);
                end                
                mt_x = local_mt(ix,:);

                if my==1 then
                    Yibase = Xibase*Y.basis; //Matrix vector, complete basis in one shot
                end

                for iy = theyvars(:)'
                    if my==1 then
                        prodbase = Yibase(:,1+index_Y(iy));
                    else
                        ff=Y.basis(:,1+index_Y(iy));
                        Yibase = matrix(ff,ny,my);
                        prodbase = Xibase*Yibase;
                    end
                    if (norm(prodbase,%inf)>1e-12) then

                        mt_y = local_mt(iy,:);
                        // Idiot-hash the lists
                        mt_xplusy = mt_x+mt_y;
                        new_hash = mt_xplusy*hash;

                        if abs(new_hash)<%eps then
                            Z.basis(:,1) = Z.basis(:,1) + prodbase(:);
                        else

                            before = find(mt_hash==new_hash);

                            if isempty(before) then
                                mt(size(mt,'r')+1,used_variables) = mt_xplusy;
                                mt_hash = [mt_hash;new_hash];                                
                                Z.lmi_variables(i) = size(mt,1);
                            else                                
                                Z.lmi_variables(i) = before;
                            end
                            Z.basis(:,i+1)  = prodbase(:);i = i+1;
                        end
                    end
                end
            end

            // We pre-allocated a sufficiently long, now picke the ones we
            // actually filled with values
            Z.lmi_variables = Z.lmi_variables(1:i-1);

            // Fucked up order (lmi_variables should be sorted)
            if or(diff(Z.lmi_variables)<0) then
                [i,j]=sort(Z.lmi_variables);
                Z.lmi_variables = Z.lmi_variables(j);
                Z.basis(:,2:size(Z.basis,'c')) = Z.basis(:,j+1);
            end
            
            //[un_Z_vars] = unique1D(Z.lmi_variables);
            [un_Z_vars,k] = unique(Z.lmi_variables);
            tmp=Z.lmi_variables(:);
            hh=[];
            jj=[];
            for j=1:length(un_Z_vars)
            for i=1:length(tmp)
             if tmp(length(tmp)-i+1)==un_Z_vars(j) then
                hh(length(hh)+1)=length(tmp)-i+1;
                break;
             end
            end
            end
            hh=hh';
            for j=1:length(tmp)
            for i=1:length(un_Z_vars)
             if un_Z_vars(length(un_Z_vars)-i+1)==tmp(j) then
                jj(length(jj)+1)=length(un_Z_vars)-i+1;
                break;
             end
            end
            end
            jj=jj';
            if length(Z.lmi_variables) ~=length(un_Z_vars) then           
                //newZbase = Z.basis(:,1);
                //for i = 1:length(un_Z_vars)
                //    newZbase = [newZbase sum(Z.basis(:,find(un_Z_vars(i)==Z.lmi_variables)+1),2)];
                //end
                ij = zeros(length([1; 1+jj]'),2);
                ij(:,1)=[1; 1+jj];
                ij(:,2)=[1 1+(1:length(jj))]';
                vv=ones(1,1+length(jj));
                Z.basis = Z.basis*sparse(ij,vv)';               
                //Z.basis = newZbase;
                Z.lmi_variables = un_Z_vars;
            end

            if full(mt) ~= full(oldmt) then
                yalmip('setmonomtable',mt);
            end

            if ~(x_isscalar | y_isscalar) then
                Z.n = X.n;
                Z.m = Y.m;
            else
                Z.n = max(X.n,Y.n);
                Z.m = max(X.m,Y.m);
            end
        catch
            error("internal error. please report")
        end

Z = clean(Z);
endfunction


function ZZ = mult_m_sdpvar(X,Y)
//MTIMES (overloaded)
clear ZZ;
// Author Johan L�fberg
// $Id: mtimes.sci,v 1.1 2010-07-10 20:34:20 solovyev Exp $

//if isempty(X) | isempty(Y) then
//    Z = [];
//    return
//end
        n_Y = Y.n;
        m_Y = Y.m;
        [n_X,m_X] = size(X);

        x_isscalar =  (n_X*m_X==1);
        y_isscalar =  (n_Y*m_Y==1);

        if ~x_isscalar then
            if ((m_X~= n_Y & ~y_isscalar))
                error('Inner matrix dimensions must agree.')
            end
        end

        if ((~x_isscalar) & (Y.typeflag == 5)) | ((x_isscalar) & (Y.typeflag == 5) & (X<0)) then
            error('Norm expression can only be multiplied with non-negative scalar');
        end

        n = n_X;
        m = m_Y;
        ZZ = Y;


        // Special cases
        if x_isscalar then
            ZZ.n = n_Y;
            ZZ.m = m_Y;
            ZZ.basis = X*Y.basis;
            ZZ.basis = clean(ZZ.basis);
        elseif y_isscalar then
            ZZ.n = n_X;
            ZZ.m = m_X;
            ZZ.basis = X(:)*Y.basis;
            ZZ.basis = clean(ZZ.basis);
        else
        
        ZZ.basis = sparse(kron(eye(m_Y,m_Y),X)*Y.basis);
        ZZ.n = n;
        Z.m = m;

        ZZ.basis = clean(ZZ.basis);
        end
endfunction

function t11 = minus_sdpvar(X)
t11=X;
t11.basis=-X.basis;
endfunction
