function y = plus_sdpvar_sdpvar(X,Y)

n_X = X.n;
        m_X = X.m;
        n_Y = Y.n;
        m_Y = Y.m;
        x_isscalar = (n_X*m_X==1);
        y_isscalar = (n_Y*m_Y==1);
        any_scalar = x_isscalar | y_isscalar;

        if (~((n_X==n_Y) & (m_X==m_Y))) & ~any_scalar then
            error('Matrix dimensions must agree.')
        end

        all_lmi_variables = unique1D([X.lmi_variables Y.lmi_variables]);
        y = X;
        y.lmi_variables = all_lmi_variables;

        // ismembc faster (buggy?)
        	in_X = find(ismember(all_lmi_variables,X.lmi_variables));
        	in_Y = find(ismember(all_lmi_variables,Y.lmi_variables));
       // in_X = find(ismember(all_lmi_variables,X.lmi_variables));
       // in_Y = find(ismember(all_lmi_variables,Y.lmi_variables));

        //Preallocate good for large problems
        basis_X = sparse(n_X*m_X,1+length(all_lmi_variables),nnz(X.basis));
        basis_Y = sparse(n_Y*m_Y,1+length(all_lmi_variables),nnz(Y.basis));
        basis_X(:,[1 1+in_X])=X.basis;
        basis_Y(:,[1 1+in_Y])=Y.basis;

        // Fix addition of matrix+scalar
        if n_X*m_X<n_Y*m_Y then
            y.n = n_Y;
            y.m = m_Y;
            basis_X = ones(n_Y*m_Y,1).*.basis_X;//repmat(basis_X,n_Y*m_Y,1);
        end
        if n_Y*m_Y<n_X*m_X then
            y.n = n_X;
            y.m = m_X;
            basis_Y = ones(n_X*m_X,1).*.basis_Y;//repmat(basis_Y,n_X*m_X,1);
        end

        // OK, solution is...
        y.basis = basis_X+basis_Y;
        y = clean(y);
endfunction

function y = plus_sdpvar_m(X,Y)
        if isempty(Y) then
            y=X;
            return
        end

        y = X;
        n_X = X.n;
        m_X = X.m;
        [n_Y,m_Y] = size(Y);
        x_isscalar = (n_X*m_X==1);
        y_isscalar = (n_Y*m_Y==1);
        any_scalar = x_isscalar | y_isscalar;

        if any_scalar | ([n_Y m_Y]==[n_X m_X]) then
            if x_isscalar then
                y.basis = ones(n_Y*m_Y,1).*.y.basis;//repmat(y.basis,n_Y*m_Y,1);
                y.n = n_Y;
                y.m = m_Y;
            end
            y.basis(:,1) = y.basis(:,1)+Y(:);
        else
            error('Matrix dimensions must agree.');
        end
endfunction

function y = plus_m_sdpvar(X,Y)
//PLUS (overloaded)

// Author Johan L�fberg
// $Id: plus.sci,v 1.1 2010-07-10 20:34:20 solovyev Exp $

        if isempty(X) then
            y = Y;
            return
        end

        y = Y;
        n_Y = Y.n;
        m_Y = Y.m;
        [n_X,m_X] = size(X);
        x_isscalar = (n_X*m_X==1);
        y_isscalar = (n_Y*m_Y==1);
        any_scalar = x_isscalar | y_isscalar;

        if any_scalar | ([n_Y m_Y]==[n_X m_X]) then
            if y_isscalar then
                y.basis = ones(n_X*m_X,1).*.y.basis;//repmat(y.basis,n_X*m_X,1);
                y.n = n_X;
                y.m = m_X;
            end
            y.basis(:,1) = y.basis(:,1)+X(:);
        else
            error('Matrix dimensions must agree.');
        end 
endfunction

