function sys = sdpvar(varargin)
//SDPVAR Create symbolic decision variable
//       
//   You can create a sdpvar variable by: 
//     X = SDPVAR(n)               Symmetric nxn matrix
//     X = SDPVAR(n,n)             Symmetric nxn matrix
//     X = SDPVAR(n,m)             Full nxm matrix
//
//   Definition of multiple scalars can be simplified 
//     SDPVAR x y z w
//
//   The parametrizations supported are
//     X = SDPVAR(n,n,'symmetric') Symmetric nxn matrix 
//     X = SDPVAR(n,n,'full')      Full nxn matrix
//     X = SDPVAR(n,n,'toeplitz')  Symmetric Toeplitz
//     X = SDPVAR(n,n,'hankel')    Symmetric Hankel
//     X = SDPVAR(n,n,'skew')      Skew-symmetric       
//
//   The letters 'sy','f','ha', 't' and 'sk' are searched for in the third argument   
//   hence sdpvar(n,n,'toeplitz') gives the same result as sdpvar(n,n,'t')
//
//   Only square Toeplitz and Hankel matries are supported
//
//   A scalar is defined as a 1x1 matrix
//
//   In addition to the matrix type, a fourth argument 
//   can be used to obtain a complex matrix. All the 
//   matrix types above apply to a complex matrix, and
//   in addition a Hermitian type is added
//
//     X = SDPVAR(n,n,'hermitian','complex')            
//
//   The other types are obtained as above
//     X = SDPVAR(n,n,'symmetric','complex') Complex symmetric nxn matrix
//     X = SDPVAR(n,n,'full','complex')      Complex full nxn matrix
//     ... and the same for Toeplitz, Hankel and skew-symmetric
//
//   See also SEE, @SDPVAR/SET, INTVAR, BINVAR, methods('sdpvar')

// Author Johan L�fberg
// $Id: sdpvar.sci,v 1.2 2010-07-18 19:43:52 solovyev Exp $

global varCount;
global optSolution;

//varCount = yalmip('nvars')

//superiorto('double')
//try
//    inferiorto('logdet')
//catch
//    display('Do you really have yalmip/extras in your path?');
//    error(lasterr);
//end

// First time called, reset #free variables and solution
if isempty(varCount) then
    varCount=0;
    optSolution=hash_create(10); 
    optSolution.info = "Initialized by YALMIP";
    optSolution.variables = [];
    optSolution.optvar  =[];
end
 
//nargin=argn(2) 
if nargin==0 then
    //help sdpvar
    sys=[];
    return
end

// Check for commmand OR sdpvar x y z syntax
tmp = varargin(1);
if is(tmp,%types.SMat) then
    select tmp   
        case 'clear' then
            varCount=0;  
            optSolution.info = 'Initialized by YALMIP';
            optSolution.variables = [];
            optSolution.optvar  =[];
            sys=[];
            return
        case 'nvars' then
            sys = varCount;
             return;
        case 'setAllSolution' then
            optSolution.optvar = varargin(2).optvar;
            optSolution.variables = varargin(2).variables;
            sys = [];
            return 
        case 'setSolution' then
            if isempty(optSolution.variables) then
                optSolution.info = varargin(2).info;
                optSolution.variables = varargin(2).variables;
                optSolution.optvar = varargin(2).optvar;
            else
                // Just save some stuff first
                newSolution = varargin(2);
                oldSolution = optSolution;
                optSolution.info = varargin(2).info;
                optSolution.variables = varargin(2).variables;
                optSolution.optvar = varargin(2).optvar;
                keep_these = find(ismember(oldSolution.variables,newSolution.variables)==0);
                optSolution.optvar    = [oldSolution.optvar(keep_these);newSolution.optvar(:)];
                optSolution.variables = [oldSolution.variables(keep_these);newSolution.variables(:)]; 
            end
             sys = [];
             return
        case 'getSolution' then
            sys = optSolution;
            return;
        case 'setnvars' then// Hard-core, extremely private
            varCount = varargin(2);
            sys = [];
            return;
        else 
            n = length(varargin);
           // ����� ���������� isvarname ��� scilab
           // for k = 1:n
           //     if ~isvarname(varargiargn is obsolete, as in matlab you can use nargin,nargoutn{k})
           //         error('symbolic:sym:errmsg1','Not a valid variable name.')
           //     end
           // end
            for k = 1:n
                global varname;
                varname = varargin(k);                
                varname = spdvar(1,1);
                //assignin('caller',varname,sdpvar(1,1));
            end
            sys = [];
            return
    end
end

// Supported matrix types
// - symm
// - full
// - skew
// - hank
// - toep
  if  nargin == 1 then//Bug in MATLAB 5.3!! sdpvar called from horzcat!!!!????
        if isempty(varargin(1)) then
            sys = [];
            return
        end
        n = varargin(1);
        m = varargin(1);
        if n*m==0 then
            sys = zeros(n,m);
            return;
        end
        if (n==m) then
            matrix_type = 'symm';
            nvar = n*(n+1)/2;
        else
            matrix_type = 'full';
            nvar = n*m;
        end 
    elseif nargin == 2 then
        
        n = varargin(1);
        m = varargin(2);
        if n*m==0 then
            sys = zeros(n,m);
            return;
        end
        if (n==m) then
            matrix_type = 'symm';
            nvar = n*(n+1)/2;
        else
            matrix_type = 'full';
            nvar = n*m;
        end
     elseif (nargin == 3 | nargin == 4) then
        n = varargin(1);
        m = varargin(2);
        if n*m==0 then
            sys = zeros(n,m);
            return;
        end
        
        // Check for complex or real
        if (nargin == 4) then
            if ~(is(varargin(4),%types.SMat)) then
                help sdpvar
                error('Fourth argument should be ''complex'' or ''real''')
            end            
            [temp,index_cmrl] = strindex(varargin(4),['real','complex']);            
            if isempty(index_cmrl) then
                error('Fourth argument should be ''complex'' or ''real''. See help above')
            end	
        else
            if ~(is(varargin(3),%types.SMat)) then
                help sdpvar
                error('Third argument should be ''symmetric'', ''full'', ''hermitian'',...See help above')
            end
            index_cmrl = 1;
        end;
        
        if isempty(varargin(3)) then
            index_type = 7; //Default symmetric
        else
            [temp,which]=strindex(varargin(3),['complex','real']);
            if ~isempty(which) then
                // User had third argument as complex or real
                error(['Third argument should be ''symmetric'', ''full'', ''toeplitz''... Maybe you meant sdpvar(n,n,''full'',''' varargin{3} ''')'])
            end
            [temp,index_type] = strindex(varargin(3),['toeplitz','hankel','symmetric','full','rhankel','skew','hermitian']);
        end
        
        if isempty(index_type) then
            error(['Matrix type "' varargin{3} '" not supported'])
        else
            tmp_ = index_type+100*(index_cmrl-1);
            select tmp_
                case 1 then
                    if n~=m then
                        error('Toeplitz matrix must be square')
                    else
                        matrix_type = 'toep';
                        nvar = n;
                    end
                    
                case 2 then
                    if n~=m
                        error('Hankel matrix must be square')
                    else
                        matrix_type = 'hank';
                        nvar = n;
                    end
                    
                case 3 then
                    if n~=m then
                        error('Symmetric matrix must be square')
                    else
                        matrix_type = 'symm';
                        nvar = n*(n+1)/2;
                    end
                    
                case 4 then
                    matrix_type = 'full';
                    nvar = n*m;
                    if nvar==1 then
                        matrix_type = 'symm';
                    end
                    
                case 5 then
                    if n~=m then
                        error('Hankel matrix must be square')
                    else
                        matrix_type = 'rhankel';
                        nvar = 2*n-1;
                    end
                    
                case 6 then
                    if n~=m then
                        error('Skew symmetric matrix must be square')
                    else
                        matrix_type = 'skew';
                        nvar = (n*(n+1)/2)-n;
                    end
                    
                case 7 then
                    if n~=m then
                        error('Symmetric matrix must be square')
                    else
                        matrix_type = 'symm';
                        nvar = n*(n+1)/2;
                    end
                    
                case 101 then
                    if n~=m then
                        error('Toeplitz matrix must be square')
                    else
                        matrix_type = 'toep complex';
                        nvar = 2*n;
                    end
                    
                case 102 then
                    if n~=m then
                        error('Hankel matrix must be square')
                    else
                        matrix_type = 'hank complex';
                        nvar = (2*n);
                    end
                    
                case 103 then
                    if n~=m then
                        error('Symmetric matrix must be square')
                    else
                        matrix_type = 'symm complex';
                        nvar = 2*n*(n+1)/2;
                    end
                    
                case 104 then
                    matrix_type = 'full complex';
                    nvar = 2*n*m;
                    if nvar==1 then
                        matrix_type = 'symm complex';
                    end
                    
                case 105  then
                    if n~=m then
                        error('Hankel matrix must be square')
                    else
                        matrix_type = 'rhankel complex';
                        nvar = 2*(2*n-1);
                    end
                    
                case 106 then
                    if n~=m then
                        error('Skew symmetric matrix must be square')
                    else
                        matrix_type = 'skew complex';
                        nvar = 2*((n*(n+1)/2)-n);
                    end
                    
                case 107 then
                    if n~=m then
                        error('Hermitian matrix must be square')
                    else
                        matrix_type = 'herm complex';
                        nvar = n*(n+1)/2+(n*(n+1)/2-n);
                    end
                    
                    
                else
                    error('Bug! Report!');
            end
            
        end
        
    elseif nargin==5  then // Fast version for internal use
        sys.basis = varargin(5);
        sys.lmi_variables=varargin(4);
        sys.n = varargin(1);
        sys.m = varargin(2);
        sys.typeflag = 0;
        sys.savedata = [];
        sys.extra = [];
        
        // Find zero-variables
        constants = find(sys.lmi_variables==0);
        if ~isempty(constants);
            sys.lmi_variables(constants)=[];
            sys.basis(:,1) = sys.basis(:,1) + sum(sys.basis(:,1+constants),2);
            sys.basis(:,1+constants)=[];
        end
        if isempty(sys.lmi_variables) then
            sys = full(matrix(sys.basis(:,1),sys.n,sys.m));        
        else
            //sys = class(sys,'sdpvar');
            sys = sdpvar_create(basis=sys.basis,lmi_variables=sys.lmi_variables,n=sys.n,m=sys.m,typeflag=sys.typeflag,savedata=sys.savedata,extra=sys.extra);
            //sys=mlist(['sdpvar','basis','lmi_variables','n','m','typeflag','savedata','extra'],sys.basis,sys.lmi_variables,sys.n,sys.m,sys.typeflag,sys.savedata,sys.extra);           
        end
        return;
    elseif nargin==6 then// Fast version for internal use
        sys.basis = varargin(5);
        sys.lmi_variables=varargin(4);
        sys.n = varargin(1);
        sys.m = varargin(2);
        sys.typeflag = varargin(6);
        sys.savedata = [];
        sys.extra = [];
        // Find zero-variables
        constants = find(sys.lmi_variables==0);
        if ~isempty(constants);
            sys.lmi_variables(constants)=[];
            sys.basis(:,1) = sys.basis(:,1) + sum(sys.basis(:,1+constants),2);
            sys.basis(:,1+constants)=[];
        end
        if isempty(sys.lmi_variables) then
            sys = full(matrix(sys.basis(:,1),sys.n,sys.m));        
        else
            //sys = class(sys,'sdpvar');
              sys = sdpvar_create(basis=sys.basis,lmi_variables=sys.lmi_variables,n=sys.n,m=sys.m,typeflag=sys.typeflag);
            //sys=mlist(['sdpvar','basis','lmi_variables','n','m','typeflag','savedata','extra'],sys.basis,sys.lmi_variables,sys.n,sys.m,sys.typeflag,sys.savedata,sys.extra); 
        end
        return;
    elseif nargin==7 then// Fast version for internal use
        sys.basis = varargin(5);
        sys.lmi_variables=varargin(4);
        sys.n = varargin(1);
        sys.m = varargin(2);
        sys.typeflag = varargin(6);
        sys.savedata = [];
        sys.extra = varargin(7);
        // Find zero-variables
        constants = find(sys.lmi_variables==0);
        if ~isempty(constants);
            sys.lmi_variables(constants)=[];
            sys.basis(:,1) = sys.basis(:,1) + sum(sys.basis(:,1+constants),2);
            sys.basis(:,1+constants)=[];
        end
        if isempty(sys.lmi_variables) then
            sys = full(matrix(sys.basis(:,1),sys.n,sys.m));        
        else
            //sys = class(sys,'sdpvar');
             sys = sdpvar_create(basis=sys.basis,lmi_variables=sys.lmi_variables,n=sys.n,m=sys.m,typeflag=sys.typeflag,savedata=sys.savedata,extra=sys.extra);
            //sys=mlist(['sdpvar','basis','lmi_variables','n','m','typeflag','savedata','extra'],sys.basis,sys.lmi_variables,sys.n,sys.m,sys.typeflag,sys.savedata,sys.extra);
        end
        return;
        
    else
        error('Wrong number of arguments in sdpvar creation');
end

if isempty(n) | isempty(m) then
    error('Size must be integer valued')
end;
if ~((abs((n-ceil(n)))+ abs((m-ceil(m))))==0) then
    error('Size must be integer valued')
end

lmi_variables = (1:nvar)+varCount;
//lmi_variables = lmi_variables(:);

end_ = length(lmi_variables);
varCount = lmi_variables(end_);

select matrix_type
    
    case 'full' then
        basis = [sparse([],[],[m*n,1]) speye(nvar,nvar)]; //spalloc replaced with the SciLab sparse

    case 'full complex' then
        basis = [sparse([],[],[m*n,1]) speye(nvar/2,nvar/2) speye(nvar/2,nvar/2)*sqrt(-1)];//spalloc replaced with the SciLab sparse
        
    case 'symm' then
        basis = sparse([],[],[n^2,(1+nvar)]);//spalloc(n^2,1+nvar,2);
        l = 2;
        an_empty = sparse([],[],[n,n]);//spalloc(n,n,2);
        for i=1:n
           temp = an_empty;
            temp(i,i)=1;
            basis(:,l)=matrix(temp,size(temp,'*'),1) ;//temp(:);
            l = l+1;
            for j=i+1:n,
                temp = an_empty;
                temp(i,j)=1;
                temp(j,i)=1;
                basis(:,l)=matrix(temp,size(temp,'*'),1) ;//temp(:);
                l = l+1;
          end
          end
   case 'symm complex' then
        basis = sparse([],[],[n^2,(1+nvar)]);//spalloc(n^2,1+nvar,2);
        l = 2;
        an_empty = sparse([],[],[n,n]);//spalloc(n,n,2);
        for i=1:n
            temp = an_empty;
            temp(i,i)=1;
            basis(:,l)=temp(:);
            l = l+1;
            for j=i+1:n,
                temp = an_empty;
                temp(i,j)=1;
                temp(j,i)=1;
                basis(:,l)=temp(:);
                l = l+1;
            end
        end
        for i=1:n
            temp = an_empty;
            temp(i,i)=sqrt(-1);
            basis(:,l)=temp(:);
            l = l+1;
            for j=i+1:n,
                temp = an_empty;
                temp(i,j)=sqrt(-1);
                temp(j,i)=sqrt(-1);
                basis(:,l)=temp(:);
                l = l+1;
            end
        end
        
    case 'herm complex' then
        basis = sparse([],[],[n^2,(1+nvar)]);//spalloc(n^2,1+nvar,2);
        l = 2;
        an_empty = sparse([],[],[n,n]);//spalloc(n,n,2);
        for i=1:n
            temp = an_empty;
            temp(i,i)=1;
            basis(:,l)=temp(:);
            l = l+1;
            for j=i+1:n,
                temp = an_empty;
                temp(i,j)=1;
                temp(j,i)=1;
                basis(:,l)=temp(:);
                l = l+1;
            end
        end
        for i=1:n
            for j=i+1:n,
                temp = an_empty;
                temp(i,j)=sqrt(-1);
                temp(j,i)=-sqrt(-1);
                basis(:,l)=temp(:);
                l = l+1;
            end
        end
        
    case 'skew' then
        basis = sparse([],[],[n^2,1+nvar]);//spalloc(n^2,1+nvar,2);
        l = 2;
        an_empty = sparse([],[],[n,n]);//spalloc(n,n,2);
        for i=1:n
            for j=i+1:n,
                temp = an_empty;
                temp(i,j)=1;
                temp(j,i)=-1;
                basis(:,l)=temp(:);
                l = l+1;
            end
        end
        
    case 'skew complex' then
        basis = sparse([],[],[n^2,1+nvar]);//spalloc(n^2,1+nvar,2);
        l = 2;
        an_empty = sparse([],[],[n,n]);//spalloc(n,n,2);
        for i=1:n
            for j=i+1:n,
                temp = an_empty;
                temp(i,j)=1;
                temp(j,i)=-1;
                basis(:,l)=temp(:);
                l = l+1;
            end
        end
        for i=1:n           
            for j=i+1:n,
                temp = an_empty;
                temp(i,j)=sqrt(-1);
                temp(j,i)=-sqrt(-1);
                basis(:,l)=temp(:);
                l = l+1;
            end
        end
        
    case 'toep' then
        basis = sparse([],[],[n^2,1+nvar]);//spalloc(n^2,1+nvar,2);
        an_empty = sparse([],[],[n,1]);//spalloc(n,1,1);
        for i=1:n,
            v = an_empty;
            v(i)=1;
            temp = sparse(toeplitz(v));
            basis(:,i+1) = temp(:);
        end
        
        // Notice, complex Toeplitz not Hermitian
    case 'toep complex' then
        basis = sparse([],[],[n^2,1+nvar]);
        an_empty = sparse([],[],[n,1]);//spalloc(n,1,1)
        for i=1:n
            v = an_empty;
            v(i)=1;
            v=full(v);
            temp = sparse(toeplitz(v));
            basis(:,i+1) = temp(:);
        end
        for i=1:n
            v = zeros(n,1);
            v(i)=sqrt(-1);
            temp = mtlb_toeplitz(v);
            basis(:,n+i+1) = temp(:);
        end
    case 'hank' then
        basis = sparse([],[],[n^2,1+nvar]);//spalloc(n^2,1+nvar,2);
        an_empty = sparse([],[],[n,1]);//spalloc(n,1,1)
        for i=1:n,
            v = an_empty;
            v(i)=1;
            temp = sparse(hankel(v));
            basis(:,i+1) = temp(:);
        end
        
    case 'hank complex' then
        basis = sparse([],[],[n^2,1+nvar]);//spalloc(n^2,1+nvar,2);
        an_empty = sparse([],[],[n,1]);//spalloc(n,1,1)
        for i=1:n,
            v = an_empty;
            v(i)=1;
            temp = sparse(hankel(v));
            basis(:,i+1) = temp(:);
        end
        for i=1:n,
            v = an_empty;
            v(i)=sqrt(-1);
            temp = sparse(hankel(v));
            basis(:,n+i+1) = temp(:);
        end
        
    case 'rhankel' then
        basis = sparse([],[],[n^2,1+nvar]);//spalloc(n^2,1+nvar,2);
        an_empty = sparse([],[],[2*n-1,1]);//spalloc(n,1,1)spalloc(2*n-1,1,1);
        for i=1:nvar,
            v = an_empty;
            v(i)=1;
            temp = sparse(hankel(v(1:n),[v(n);v(n+1:2*n-1)]));
            basis(:,i+1) = temp(:);
        end	
        
    case 'rhankel complex' then
        basis = sparse([],[],[n^2,1+nvar]);//spalloc(n^2,1+nvar,2);
        an_empty = sparse([],[],[2*n-1,1]);//spalloc(n,1,1)spalloc(2*n-1,1,1);
        for i=1:nvar/2,
            v = an_empty;
            v(i)=1;
            temp = sparse(hankel(v(1:n),[v(n);v(n+1:2*n-1)]));
            basis(:,i+1) = temp(:);
        end	
        for i=1:nvar/2,
            v = an_empty;
            v(i)=sqrt(-1);
            temp = sparse(hankel(v(1:n),[v(n);v(n+1:2*n-1)]));
            basis(:,nvar/2+i+1) = temp(:);
        end	
        
    else
        error('Bug! Report')
end

// Update monomtable
mt = yalmip('monomtable');
n_mt = size(mt,1);
m_mt = size(mt,2);
if min(lmi_variables)>m_mt then // New variables
    if (is(mt,%types.SpColMat)) then
      [ij1,v,mn]=spget(mt);
      ij=zeros(size([ij1(:,1);lmi_variables(:)])(1),2);
      ij(:,1)=[ij1(:,1);lmi_variables(:)];
      ij(:,2)=[ij1(:,2);lmi_variables(:)];
      vv=[v;ones(length(lmi_variables(:)),1)];
    else
       [i,j] = find(mt);
       for index = 1:length(i)
         k(index) = mt(i(index),j(index));
       end
       
       ij(:,1)=[i';lmi_variables(:)];
       ij(:,2)=[j';lmi_variables(:)];
       vv=[k;ones(length(lmi_variables(:)),1)];
    end    

    mt = sparse(ij,vv,[max(n_mt,max(lmi_variables)),max(m_mt,max(lmi_variables))]);
else
    mt(lmi_variables,lmi_variables) = speye(length(lmi_variables),length(lmi_variables));
end
//mt = blkdiag(mt,speye(length(lmi_variables)));
yalmip('setmonomtable',mt);

// Create an object
sys.basis=basis;  //Fixme
sys.lmi_variables = lmi_variables;
sys.n = n;
sys.m = m;
sys.typeflag = 0;
sys.savedata = [];
sys.extra = [];
//sys = class(sys,'sdpvar');
sys = sdpvar_create(basis=sys.basis,lmi_variables=sys.lmi_variables,n=sys.n,m=sys.m,typeflag=sys.typeflag);
//sys=mlist(['sdpvar','basis','lmi_variables','n','m','typeflag','savedata','extra'],sys.basis,sys.lmi_variables,sys.n,sys.m,sys.typeflag,sys.savedata,sys.extra);
//superiorto('double')
//inferiorto('logdet')
// Typeflags 
// 0 Standard variable
// 1 Inequality (LMI)
// 2 Inequality (element)
// 3 Equality
// 4 Cone
// 5 norm object
// 6 logdet object
// 8 KYP object
endfunction
