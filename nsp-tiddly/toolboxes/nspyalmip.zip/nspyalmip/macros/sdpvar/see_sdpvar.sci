function see_sdpvar(X,showfull)
//SEE Displays internal structure of variable
//
//    Shows the base matrices that build up the variable
//  
//    X = X0+x_1*X1+x_2*X2+...
//  
//    SEE(X)            Display matrices Xi in dense format
//    SEE(X,'sparse')   Display matrices Xi in sparse format
//
//    See also   SDPVAR

// Author Johan L�fberg
// $Id: see_sdpvar.sci,v 1.1 2010-09-26 17:46:44 jpc Exp $
  // nargin=argn(2);
  printf(' ');
  if nargin==1   then
    printf('Constant matrix\n');
    print(full(sdp_getbasematrix(X,0)))
    printf('Base matrices\n');
    for i = 1:length(X.lmi_variables);       
      print(full(sdp_getbasematrix(X,X.lmi_variables(i))))       
      printf('\n')			
    end;
    printf('Used variables\n');
    print(X.lmi_variables)
  else	
    select showfull
     case 'sparse'
      printf('Constant matrix\n');
      print((getbasematrix(X,0)))
      printf('Base matrices\n');
      for i = 1:length(X.lmi_variables);
	print((sdp_getbasematrix(X,X.lmi_variables(i))));
	printf('\n')
      end;
      printf('Used variables\n');
      print(X.lmi_variables)
     case 'full'
      see(X)
    else
      error('Second argument should be ''sparse'' or ''full')
    end
  end
endfunction
