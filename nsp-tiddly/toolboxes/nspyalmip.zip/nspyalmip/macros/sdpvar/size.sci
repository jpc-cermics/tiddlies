function varargout=size_sdpvar(varargin)
//SIZE (overloaded)

// Author Johan L�fberg 
// $Id: size.sci,v 1.1 2010-07-18 19:43:52 solovyev Exp $   

varargout=list();

if nargin == 1    then
  bsize  = [varargin(1).n varargin(1).m];
  select (nargout)
  case 0 then
    varargout(1) = bsize;
  case 1 then
    varargout(1) = bsize;
  case 2 then
    varargout(1) = bsize(1);
    varargout(2) = bsize(2);
  else
    error('>2 outputs in size?');
  end
else
	select varargin(2)
	case 1 then
		varargout(1) = varargin(1).n;
	case 2 then
		varargout(1) = varargin(1).m;
	case '*'
	  varargout(1) = varargin(1).n*varargin(1).m;
	else
		error('Report bug in size')
	end
end
endfunction
