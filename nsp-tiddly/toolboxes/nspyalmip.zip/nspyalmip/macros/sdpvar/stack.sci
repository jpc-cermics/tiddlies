function y = stack_l(blocks)
//STACK Internal function used for horzcat and vertcat

// Author Johan L�fberg
// $Id: stack.sci,v 1.1 2010-07-25 19:21:05 solovyev Exp $
nblocks = size(blocks);
// Get dimensions
n = zeros(nblocks,1);
m = zeros(nblocks,1);
isasdpvar = (zeros(nblocks,1) == 1);
// Get dimensions
for i = 1:nblocks
    [n(i),m(i)]=size(blocks(i));
    if type(blocks(i),'string')=='Sdpvar' then
     isasdpvar(i) = %t;
    else
     isasdpvar(i) = %f;
    end
end

// Keep only non-empty
keep_these = find((n.*m)~=0);
if length(keep_these)<length(n) then
    blocks = list(blocks(keep_these));
    n = n(keep_these);
    m = m(keep_these);
    isasdpvar=isasdpvar(keep_these);
    nblocks = length(n);
end;

// Find all free variables used
all_lmi_variables = [];
for i = 1:nblocks
    if isasdpvar(i) then
        all_lmi_variables = [all_lmi_variables blocks(i).lmi_variables];
    end
end
all_lmi_variables = unique1D(all_lmi_variables);

// Pick one of the sdpvar objects to build on...
y = blocks(min(find(isasdpvar)));

// Some indexation tricks
n = n(1);
   for ind = 1: length(all_lmi_variables(:))+1
     ij(ind,1)=1;
   end
   ij(:,2)=[1;1+all_lmi_variables(:)];
   vv=1:1+length(all_lmi_variables);

allindextopos = sparse(ij,vv,[1,1+all_lmi_variables(length(all_lmi_variables))]);

basis = [];
basis_i = [];
basis_j = [];
basis_s = [];
shft = 0;
for j = 1:nblocks
    if isasdpvar(j) then
        in_this = find(ismember(all_lmi_variables,blocks(j).lmi_variables));
        dummy = [1 1+in_this];
        [i2,j2,s2] = find(blocks(j).basis);

        j2 = dummy(j2);
        add_shift = size(blocks(j).basis,1);
    else
        [i2,j2,s2] = find(blocks(j)(:));

        add_shift = size(blocks(j)(:),1);
    end
        if i2(:)==[] then
         tmp_=[]
        else
         tmp_ = i2(:)+shft;
        end
        basis_i = [basis_i;tmp_];
        basis_j = [basis_j;j2(:)];
        basis_s = [basis_s;s2(:)];
        shft = shft + add_shift;   
end

   clear ij;
   clear vv;
   ij      = basis_i(:);
   ij(:,2) = basis_j(:);
   vv=full(basis_s(:));
basis = sparse(ij,vv,[sum(m)*n,1+length(all_lmi_variables)]);

y.n = n;
y.m = sum(m);
y.basis = basis;
y.lmi_variables = all_lmi_variables;
endfunction

