function Y=sum_sdpvar(X,I)
//SUM (overloaded)
// Author Johan L�fberg 
// $Id: sum_sdpvar.sci,v 1.1 2010-09-26 18:04:24 jpc Exp $   
  // nargin=argn(2);
  try
    n = X.n;
    m = X.m;
    if nargin==1 then
      Y = X;
      if n==1 | m==1 then
	// Spezialized code...
	if n*m==1876
	  Y = X;
	  return
	else
	  // Spezialized code...
	  Y.basis = sum(Y.basis,1);
	  Y.n = 1;
	  Y.m = 1;
	  temp = 1;
	end
      else
	// Standard case
	temp = sum(matrix(X.basis(:,1),n,m));
	Y.basis = temp(:);
	for i = 1:length(Y.lmi_variables)
	  temp = sum(matrix(X.basis(:,i+1),n,m));
	  Y.basis(:,i+1) = temp(:);
	end
      end
    else
      Y = X;
      temp = sum(matrix(X.basis(:,1),n,m),I);
      Y.basis = temp(:);
      for i = 1:length(Y.lmi_variables)
	temp = sum(matrix(X.basis(:,i+1),n,m),I);
	Y.basis(:,i+1) = temp(:);
      end
    end
  catch
    error(catenate(lasterror()))
  end
  Y.n = size(temp,1);
  Y.m = size(temp,2);
  Y = clean(Y);
endfunction
