function t=trace_sdpvar(a)
//TRACE (overloaded)

// Author Johan L�fberg 
// $Id: trace.sci,v 1.1 2010-07-18 19:43:52 solovyev Exp $   
 
if a.typeflag <> 0 then
	error('Relational objects cannot be manipulated')
end

t = a;
x_lmi_variables = a.lmi_variables;
lmi_variables = [];
n = a.n;
m = a.m;
traceX = trace(matrix(full(a.basis(:,1)),n,m));
t.basis = sparse(traceX(:));

j = 1;
for i = 1:length(x_lmi_variables)
	traceX = trace(matrix(full(a.basis(:,i+1)),n,m));
	if (norm(traceX,%inf)>0) then
		t.basis(:,j+1) = sparse(traceX(:));
		lmi_variables = [lmi_variables x_lmi_variables(i)];
		j = j+1;
	end
end   
if isempty(lmi_variables) then
    t = full(trace(matrix(full(a.basis(:,1)),n,m)));
else
    t.n = size(traceX,1);
    t.m = size(traceX,2);
    t.lmi_variables = lmi_variables;
end


endfunction
