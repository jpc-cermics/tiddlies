function X=dprim_sdpvar(X)
//TRANSPOSE (overloaded)

// Author Johan L�fberg 
// $Id: transpose.sci,v 1.2 2010-07-25 19:21:05 solovyev Exp $

n = X.n;
m = X.m;
ind = matrix(matrix(1:n*m,n,m)',n*m,1);
//[i1,j1,s1] = find(X.basis);
//X.basis = sparse(ind(i1),j1,s1,n*m,1+length(X.lmi_variables));
X.basis = X.basis(ind,:);
X.n = m;
X.m = n;
endfunction
