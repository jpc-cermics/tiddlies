function x = true_sdpvar(x)

x.typeflag = 12;
x = set(x);

endfunction
