function y = concatd_sdpvar_sdpvar(varargin)
//VERTCAT (overloaded)

// Author Johan L�fberg 
// $Id: vertcat.sci,v 1.1 2010-07-25 19:21:05 solovyev Exp $   

prenargin = nargin;
// Fast exit
if prenargin<2 then
    y=varargin(1);
    return
end

// Get dimensions
n = zeros(prenargin,1);
m = zeros(prenargin,1);
for i = 1:prenargin
    [n(i),m(i)]=size(varargin(i));
end

// Keep only non-empty
keep_these = find((n.*m)~=0);
if length(keep_these)<length(n) then
    varargin = list(varargin(keep_these));
    n = n(keep_these);
    m = m(keep_these);
end;

// All widths should be equal
if or(m~=m(1)) then
    error('All rows in the bracketed expression must have the same number of columns.');
end

// Same code as for horzcat
dummy=list();
for i = 1:length(varargin)
    dummy(i)=varargin(i).';
end
y=stack(dummy).';
endfunction

function y = concatd_sdpvar_m(varargin)
//VERTCAT (overloaded)

// Author Johan L�fberg 
// $Id: vertcat.sci,v 1.1 2010-07-25 19:21:05 solovyev Exp $   

prenargin = nargin;
// Fast exit
if prenargin<2 then
    y=varargin(1);
    return
end

// Get dimensions
n = zeros(prenargin,1);
m = zeros(prenargin,1);
for i = 1:prenargin
    [n(i),m(i)]=size(varargin(i));
end

// Keep only non-empty
keep_these = find((n.*m)~=0);
if length(keep_these)<length(n) then
    varargin = list(varargin(keep_these));
    n = n(keep_these);
    m = m(keep_these);
end;

// All widths should be equal
if or(m~=m(1)) then
    error('All rows in the bracketed expression must have the same number of columns.');
end

// Same code as for horzcat
dummy=list();
for i = 1:length(varargin)
    dummy(i)=varargin(i).';
end
y=stack(dummy).';
endfunction

function y = concatd_m_sdpvar(varargin)
//VERTCAT (overloaded)

// Author Johan L�fberg 
// $Id: vertcat.sci,v 1.1 2010-07-25 19:21:05 solovyev Exp $   

prenargin = nargin;
// Fast exit
if prenargin<2 then
    y=varargin(1);
    return
end

// Get dimensions
n = zeros(prenargin,1);
m = zeros(prenargin,1);
for i = 1:prenargin
    [n(i),m(i)]=size(varargin(i));
end

// Keep only non-empty
keep_these = find((n.*m)~=0);
if length(keep_these)<length(n) then
    varargin = list(varargin(keep_these));
    n = n(keep_these);
    m = m(keep_these);
end;

// All widths should be equal
if or(m~=m(1)) then
    error('All rows in the bracketed expression must have the same number of columns.');
end

// Same code as for horzcat
dummy=list();
for i = 1:length(varargin)
    dummy(i)=varargin(i).';
end
y=stack(dummy).';
endfunction
