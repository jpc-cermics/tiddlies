function  varargout = yalmip(varargin)
//YALMIP Returns various information about YALMIP
//
//   YALMIP can be used to check version numbers and
//   find the SDPVAR and SET objects available in workspace
//
//   EXAMPLES
//    [V,D] = YALMIP('version') // Returns version and release date
//    YALMIP('nvars')           // Returns total number of declared variables
//    YALMIP('info')            // Display basic info.
//    YALMIP('solver','tag')    // Sets the solver 'solvertag' (see sdpsettings) as default solver
//
//   See also YALMIPTEST, YALMIPDEMO

// Author Johan L�fberg
// $Id: yalmip.sci,v 1.3 2011-03-22 12:39:15 solovyev Exp $

global prefered_solver_yalmip;
global internal_sdpvarstate_yal;
global internal_setstate_yalmip;

if nargin==0 then
    help yalmip
    return
end

varargout = list([],[]);

if isempty(internal_sdpvarstate_yal) then
    internal_sdpvarstate_yal = hash_create(10); 
    internal_sdpvarstate_yal.monomtable = sparse([],[],[0,0]);//spalloc(0,0,0);
    internal_sdpvarstate_yal.intVariables = [];
    internal_sdpvarstate_yal.binVariables = [];
    internal_sdpvarstate_yal.uncVariables = [];
    internal_sdpvarstate_yal.parVariables = [];   
    internal_sdpvarstate_yal.internalconstraints = [];
    internal_sdpvarstate_yal.functiontable = [];
    internal_sdpvarstate_yal.sosid = 0;
    internal_sdpvarstate_yal.sos_index = [];
    internal_sdpvarstate_yal.sos_data = [];
    internal_sdpvarstate_yal.sos_ParV = [];
    sdpvar('setnvars',size(internal_sdpvarstate_yal.monomtable,1));
end
if isempty(internal_setstate_yalmip) then
    internal_setstate_yalmip = hash_create(10); 
    internal_setstate_yalmip.LMIid = 0;
    internal_setstate_yalmip.duals_index = [];
    internal_setstate_yalmip.duals_data = [];
end

spaces = ['                                    '];
tmp = tolower(varargin(1));
select tmp

    case 'lmiid' then
        if ~(isempty(internal_setstate_yalmip.LMIid)) then
            internal_setstate_yalmip.LMIid = internal_setstate_yalmip.LMIid+1;
            varargout(1)=internal_setstate_yalmip.LMIid;
        else
            internal_setstate_yalmip.LMIid=1;
            varargout(1)=internal_setstate_yalmip.LMIid;
        end

    case 'setnonlinearvariables' then
        error('Internal error (ref. setnonlinearvariables). Report please.')

    case 'clear' then
        sdpvar('clear');

//        [W,mem]=who('get');
//        for i=1:max(size(W))
//            if typeof(evstr(W(i)))=='sdpvar' | typeof(evstr(W(i))) == 'lmi' then              
//               clear(W(i));
//            end
//        end

        internal_setstate_yalmip.LMIid = 0;
        internal_setstate_yalmip.duals_index = [];
        internal_setstate_yalmip.duals_data = [];

        internal_sdpvarstate_yal.sosid = 0;
        internal_sdpvarstate_yal.sos_index = [];
        internal_sdpvarstate_yal.sos_data = [];
        internal_sdpvarstate_yal.sos_ParV = [];

        internal_sdpvarstate_yal.monomtable = sparse([],[],[0,0]);//spalloc(0,0,0);
        internal_sdpvarstate_yal.intVariables = [];
        internal_sdpvarstate_yal.binVariables = [];
        internal_sdpvarstate_yal.uncVariables = [];
        internal_sdpvarstate_yal.parVariables = [];       
        internal_sdpvarstate_yal.internalconstraints = [];
        internal_sdpvarstate_yal.functiontable = [];
        sdpvar('setnvars',0);

    case 'cleardual' then
        if nargin==1 then
            internal_setstate_yalmip.duals_index = [];
            internal_setstate_yalmip.duals_data = [];
        else
            if ~isempty(internal_setstate_yalmip.duals_index) then
                internal_setstate_yalmip.lmiid = varargin(2);
                for i = 1:length(varargin(2))
                    j = find(internal_setstate_yalmip.duals_index==internal_setstate_yalmip.lmiid(i));
                    if ~isempty(j) then
                        internal_setstate_yalmip.duals_index = internal_setstate_yalmip.duals_index([1:1:j-1 j+1:1:length(internal_setstate_yalmip.duals_index)]);
                        internal_setstate_yalmip.duals_data = internal_setstate_yalmip.duals_data([1:1:j-1 j+1:1:length(internal_setstate_yalmip.duals_data)]);
                    end
                end
            end
        end

    case 'setdual' then
        internal_setstate_yalmip.duals_index = varargin(2);
        internal_setstate_yalmip.duals_data = varargin(3);

    case 'dual' then
        if isempty(internal_setstate_yalmip.duals_index) then
            varargout(1)=[];
        else
            LMIid = varargin(2);
            index_to_dual = find(LMIid==internal_setstate_yalmip.duals_index);
            if isempty(index_to_dual) then
                varargout(1)=[];
            else
                varargout(1) = internal_setstate_yalmip.duals_data(index_to_dual);
            end
        end

    case 'clearsos' then
        if nargin==1 then
            internal_sdpvarstate_yal.sos_index = [];
            internal_sdpvarstate_yal.sos_data = [];
            internal_sdpvarstate_yal.sos_ParV = [];
        end

    case 'setsos' then
        if ~isempty(internal_sdpvarstate_yal.sos_index) then
            where_ = find(internal_sdpvarstate_yal.sos_index==varargin(2));
            if ~isempty(where_) then
                internal_sdpvarstate_yal.sos_index(where_) = varargin(2);
                internal_sdpvarstate_yal.sos_data(where_) = varargin(3);
                internal_sdpvarstate_yal.sos_ParV(where_) = varargin(4);
            else
                end_ = length(internal_sdpvarstate_yal.sos_index);
                internal_sdpvarstate_yal.sos_index(end_+1) = varargin(2);
                end_ = length(internal_sdpvarstate_yal.sos_data);
                internal_sdpvarstate_yal.sos_data(end_+1) = varargin(3);
                end_ = length(internal_sdpvarstate_yal.sos_ParV);
                internal_sdpvarstate_yal.sos_ParV(end_+1) = varargin(4);
            end
        else
            end_ = length(internal_sdpvarstate_yal.sos_index);
            internal_sdpvarstate_yal.sos_index(end_+1) = varargin(2);
            end_ = length(internal_sdpvarstate_yal.sos_data);
            internal_sdpvarstate_yal.sos_data(end_+1) = varargin(3);
            end_ = length(internal_sdpvarstate_yal.sos_ParV);
            internal_sdpvarstate_yal.sos_ParV(end_+1) = varargin(4);
        end

    case 'sosid' then
        if not(isempty(internal_sdpvarstate_yal.sosid)) then
            internal_sdpvarstate_yal.sosid = internal_sdpvarstate_yal.sosid+1;
            varargout(1)=internal_sdpvarstate_yal.sosid;
        else
            internal_sdpvarstate_yal.sosid=1;
            varargout(1)=internal_sdpvarstate_yal.sosid;
        end

    case 'getsos' then
        if isempty(internal_sdpvarstate_yal.sos_index) then
            varargout(1)=[];
            varargout(2)=[];
        else
            SOSid = varargin(2);
            index_to_sos = find(SOSid==internal_sdpvarstate_yal.sos_index);
            if isempty(index_to_sos) then
                varargout(1)=[];
                varargout(2)=[];
            else
                varargout(1) = internal_sdpvarstate_yal.sos_data(index_to_sos);
                varargout(2) = internal_sdpvarstate_yal.sos_ParV(index_to_sos);
                // FIX
            end
        end


    case 'getinternalsetstate' then
        varargout(1) = internal_setstate_yalmip; // Get internal state, called from saveobj

    case 'setinternalsetstate' then
        internal_setstate_yalmip = varargin(2); // Set internal state, called from loadobj

    case 'getinternalsdpvarstate' then
        varargout(1) = internal_sdpvarstate_yal; // Get internal state, called from saveobj

    case 'setinternalsdpvarstate' then
        internal_sdpvarstate_yal = varargin(2); // Set internal state, called from loadobj
        sdpvar('setnvars',size(internal_sdpvarstate_yal.monomtable,1));

    case 'version' then
        varargout(1)=3;
        if nargout==2 then
            varargout(2) = '20041015';
        end

    case 'setintvariables' then
        internal_sdpvarstate_yal.intVariables = varargin(2);

    case 'intvariables' then
        varargout(1) = internal_sdpvarstate_yal.intVariables;

    case 'setbinvariables' then
        internal_sdpvarstate_yal.binVariables = varargin(2);

    case 'binvariables' then
        varargout(1) = internal_sdpvarstate_yal.binVariables;

    case 'setuncvariables' then
        internal_sdpvarstate_yal.uncVariables = varargin(2);

    case 'uncvariables' then
        varargout(1) = internal_sdpvarstate_yal.uncVariables;

    case 'setparvariables' then
        internal_sdpvarstate_yal.parVariables = varargin(2);

    case 'parvariables' then
        varargout(1) = internal_sdpvarstate_yal.parVariables;

    case 'setmonomtable' then
        internal_sdpvarstate_yal.monomtable = varargin(2);
        sdpvar('setnvars',size(internal_sdpvarstate_yal.monomtable,1));
    case 'monomtable' then
        varargout(1) = internal_sdpvarstate_yal.monomtable;
        
    case 'setfunctiontable' then
        internal_sdpvarstate_yal.functiontable = varargin(2);

    case 'functiontable' then
        varargout(1) = internal_sdpvarstate_yal.functiontable;

    case 'nonlinearvariables' then
        error('Internal error (ref. nonlinear variables). Report!')
        varargout(1) = internal_sdpvarstate_yal.nonlinearvariables;
        if nargout==2 then
            varargout(2) = internal_sdpvarstate_yal.nonlinearvariablesCompre;
        end

    case 'addinternal' then
        end_ = length(internal_sdpvarstate_yal.internalconstraints);
        internal_sdpvarstate_yal.internalconstraints(end_+1) = varargin(1);

    case 'setnvars' then
        sdpvar('setnvars',varargin(2));


    case 'nvars' then
        varargout(1) = sdpvar('nvars');

    case 'info' then
        [version,release] = yalmip('version');
        currentversion = string(version(1));
        i = 1;
        while i<length(version)
            i = i+1;
            currentversion = [currentversion '.' string(version(i))];
        end

        info_str = ['- - - - YALMIP ' currentversion ' ' string(release) ' - - - -'];

        printf(' ');
        disp(char(ones(1,length(info_str)).*.asciimat('*'))); //repmat(asciimat('*'),1,length(info_str))
        disp(info_str)
        disp(char(ones(1,length(info_str)).*.asciimat('*'))); //repmat(asciimat('*'),1,length(info_str))
        disp(' ');
        disp(['Variable     Size'])
        spaces = ['                                    '];
        ws = execstr('whos');
        n = 0;
        for i = 1:size(ws,1)
            if ws(i).class == 'sdpvar' then
                n = n+1;
                wsname = ws(i).name;
                wssize = [string(ws(i).size(1)) 'x' string(ws(i).size(2))];
                disp([wsname spaces(1:13-length(wsname)) wssize]);
            end
        end
        if n == 0 then
            disp('No SDPVAR objects found');
        end
        print(' ');
        print(['LMI']);
        n = 0;
        for i = 1:size(ws,1)
            if ws(i).class == 'lmi' then
                n = n+1;
                wsname = ws(i).name;
                disp([wsname]);
            end
        end
        if n == 0 then
            print('No SET objects found');
        end
    case 'solver' then
        if (nargin==2) then
            if type(varargin(2)) == 10 then
                solver = varargin(2);
                prefered_solver_yalmip = solver;
            else
                error('Second argument should be a string with solver name');
            end
        else
            if isempty(prefered_solver_yalmip) then
                varargout(1)='';
            else
                varargout(1) = prefered_solver_yalmip;
            end
        end
    else
        print('Command not supported');
end
 if isempty(varargout) then
  varargout(1) = 0;
 end
endfunction
