function output = callcsdp(interfacedata);

// Retrieve needed data
options = interfacedata.options;
F_struc = interfacedata.F_struc;
c       = interfacedata.c;
K       = interfacedata.K;
x0      = interfacedata.x0;
pars   = interfacedata.options.csdp;
ub      = interfacedata.ub;
lb      = interfacedata.lb;


// Bounded variables converted to constraints
if ~isempty(ub) then
    [F_struc,K] = addbounds(F_struc,K,ub,lb);
end

pars.printlevel=options.verbose;

if options.savedebug then
   // save csdpdebug F_struc c K pars
end

solvertime = cputime();
[x_s,y_s,z_s,info]=csdp(-F_struc(:,2:$),-c,F_struc(:,1),K,pars);
clockt = cputime();
solvertime = clockt -solvertime;

// We solve dual problem with CSDP
D_struc = x_s;
x = y_s;

select info
case 0
    problem = 0;
case 1
    problem = 2;
case 2
    problem = 1;
case 3
   problem = 4;
case 5
   problem = 4;
case 6
   problem = 4;
case 7
  problem = 4;
case 8
  problem = 4;
case 9
    problem = 4;
case 4
    problem = 3;
else
    problem = 9;
end 
infostr = yalmiperror(problem,'CSDP');

// Save ALL data sent to solver
if options.savesolverinput then
    solverinput.A = F_struc(:,2:$);
    solverinput.c = F_struc(:,1);
    solverinput.b = c;
    solverinput.K = K;
    solverinput.pars = pars;
else
    solverinput = [];
end

// Save ALL data from the solution?
if options.savesolveroutput then
    solveroutput.x = x_s;
    solveroutput.y = y_s;
    solveroutput.info = info;
else
    solveroutput = [];
end

// Standard interface 
output.x           = x;
output.problem     = problem;
output.infostr     = infostr;
output.solverinput = solverinput;
output.solveroutput= solveroutput;
output.solvertime  = solvertime;
output.D_struc = D_struc;

endfunction
