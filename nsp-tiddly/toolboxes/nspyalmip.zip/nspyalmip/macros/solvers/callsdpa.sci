function output = callsdpa(interfacedata)

// Author Johan L�fberg
// $Id: callsdpa.sci,v 1.1 2010-08-08 20:35:40 solovyev Exp $ 

// Retrieve needed data
options = interfacedata.options;
F_struc = interfacedata.F_struc;
c       = interfacedata.c;
K       = interfacedata.K;
x0      = interfacedata.x0;
ub      = interfacedata.ub;
lb      = interfacedata.lb;

// Bounded variables converted to constraints
if ~isempty(ub) then
    [F_struc,K] = addbounds(F_struc,K,ub,lb);
end

// Convert from internal (sedumi) format
[mDIM,nBLOCK,bLOCKsTRUCT,c,F] = sedumi2sdpa(F_struc,c,K);

// Preconditions
gensdpafile('sdpa.dat-s',mDIM,nBLOCK,bLOCKsTRUCT,c,F);

solvertime = getdate();

if options.verbose==0 then
    options.sdpa.Print = 'no';
else
    options.sdpa.Print = 'display';
end

if options.savedebug then
     //save sdpadebug mDIM nBLOCK bLOCKsTRUCT c F options.sdpa
end

solvertime = cputime();
[objVal,x,X,Y,INFO]=sdpam(mDIM,nBLOCK,bLOCKsTRUCT,c,F,[],[],[],options.sdpa);
solvertime = cputime() - solvertime;

// Create dual variable in internal format
D_struc = [];

for i = 1:length(Y)
    D_struc = [D_struc;Y(i)(:)];
end

select (INFO.phasevalue)
    case 'pdOPT'
        problem = 0;
    case 'noINFO'
        problem = 3;
    case 'pFEAS'
        problem = 3;
    case 'dFEAS'
        problem = 3;
    case 'pdFEAS'
        problem = 3;
    case 'pFEAS_dINF'
        problem = 2;
    case 'pINF_dFEAS'
        problem = 1;
    case 'pUNBD'
        problem = 2;
    case 'dUNBD'
        problem = 1;
    case 'pdINF'
        problem = 12;
    else
        problem = -1;
end

infostr = yalmiperror(problem,'SDPA');
if options.savesolveroutput then
    solveroutput.objVal = objVal;
    solveroutput.x = x;
    solveroutput.X = X;
    solveroutput.Y = Y;
    solveroutput.INFO = INFO;
else
    solveroutput = [];
end

if options.savesolverinput then
    solverinput.mDIM = mDIM;
    solverinput.nBLOCK=nBLOCK;
    solverinput.bLOCKsTRUCT=bLOCKsTRUCT;
    solverinput.c=c;
    solverinput.F=F;
else
    solverinput = [];
end

// Standard interface 
output.x           = x;
output.problem     = problem;
output.infostr     = infostr;
output.solverinput = solverinput;
output.solveroutput= solveroutput;
output.solvertime  = solvertime;
output.D_struc = D_struc;
endfunction
