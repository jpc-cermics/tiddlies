function output = callsedumi(interfacedata)

// Author Johan L�fberg 
// $Id: callsedumi.sci,v 1.5 2011-03-22 12:39:15 solovyev Exp $

// Retrieve needed data
options = interfacedata.options;
F_struc = interfacedata.F_struc;
c       = interfacedata.c;
K       = interfacedata.K;
ub      = interfacedata.ub;
lb      = interfacedata.lb;

interfacedata.getsolvertime = 1;
// Create the parameter structure
pars = options.sedumi;
pars.fid = options.verbose;
// *********************************************
// Bounded variables converted to constraints
// N.B. Only happens when caller is BNB
// *********************************************
if ~isempty(ub)
    [F_struc,K] = addbounds(F_struc,K,ub,lb);
end

// Avoid bug (by design?) in SeDuMi on 1D second order cones
if or(K.q == 2)
    [F_struc,K] = fix1Dqcone(F_struc,K);
end

//if options.savedebug
//    save sedumidebug F_struc c K pars
//end

// *********************************************
// Call SeDuMi
// *********************************************
if options.showprogress;showprogress(['Calling ' interfacedata.solver.tag],options.showprogress);end

solvertime = cputime(); 
problem = 0;
   //pars.free = 0;
try
  [x_s,y_s,info] = sedumi(-F_struc(:,2:$),-c,F_struc(:,1),K,pars);    
catch
    try
        if options.verbose > 0
            printf("%s\n",' ');
            printf("%s\n",'SeDuMi had unexplained problems, probably due to linear dependence.')
            printf("%s\n",'YALMIP tweaks the problem and restarts...')
            printf("%s\n",' ');
        end
        // Boring issue in sedumi for trivial problem min x+y, s.t x+y>0
        n = length(c);
        [F_struc,K] = addbounds(F_struc,K,ones(n,1)*1e6,-ones(n,1)*1e6);
        [x_s,y_s,info] = sedumi(-F_struc(:,2:$),-c,F_struc(:,1),K,pars);
        x_s((1:2*n)+K.f)=[];
        K.l=K.l-2*n;
    catch
        printf("%s\n",'Unexplained crash in SeDuMi! (could be memory issues)')
        printf("%s\n",'If you have SDPT3 3.02 on you path, remove it.')
        printf("%s\n",'If this doesn''t work, make sure you have a recent and compiled version')
    end
end
// solvertime = cputime - solvertime;//etime(clock,solvertime
if interfacedata.getsolvertime then solvertime = cputime() - solvertime;else solvertime = 0;end
// Internal format
Primal = y_s; 
Dual   = x_s;

temp = info.pinf;
pinf = info.dinf;
dinf = temp;

// Check for reported errors
if (pinf==0) &&  (dinf==0)
    problem = 0; // No problems
end

// We can only report one error, use priorities
if (problem==0) && (pinf==1)
    problem = 1; // Primal infeasability
end

if (problem==0) && (dinf==1)
    problem = 2; // Dual infeasability
end

if (problem==0) && (info.numerr==1) || (info.numerr==2)
    problem = 4; //Numerical problems
end

if (problem==0) && (info.iter >= options.sedumi.maxiter)
    // Did we need exactly maxiter iterations to find optimum
    if (pinf==0) && (dinf==0) && (info.numerr==0)
        problem = 0; // Yes
    else
        problem = 3; // No, we are not optimal yet
    end
end

if (problem==0) && (info.feasratio<0.98) 
    problem = 4; 
end

// Fix for cases not really explained in documentation of sedumi?
if (abs(info.feasratio+1)<0.1) & (pinf==0) &  (dinf==0)
    problem = 1; 
end
if (abs(info.feasratio+1)<0.1) & (pinf==0) &  (dinf==0) & (c'*y_s<-1e10)
    problem = 2; 
end

infostr = yalmiperror(problem,interfacedata.solver.tag);

// Save ALL data sent to solver
if options.savesolverinput
    solverinput.A = -F_struc(:,2:$);
    solverinput.c = F_struc(:,1);
    solverinput.b = -c;
    solverinput.K = K;
    solverinput.pars = pars;
else
    solverinput = [];
end

// Save ALL data from the solution?
if options.savesolveroutput >0 then
 solveroutput.x = x_s;
    solveroutput.y = y_s;
    solveroutput.info = info;
else
    solveroutput = [];
end
// Standard interface 
output.x      = Primal;
output.D_struc        = Dual;
output.Slack       = [];
output.problem     = problem;
output.infostr     = infostr;
output.solverinput = solverinput;
output.solveroutput= solveroutput;
output.solvertime  = solvertime;
endfunction

function [new_F_struc,K] = fix1Dqcone(F_struc,K); 

new_F_struc = F_struc(1:(K.l+K.f),:);
top = K.f + K.l + 1;
for i = 1:length(K.q)
    if K.q(i) == 2
      new_F_struc = [new_F_struc;F_struc(top,:);F_struc(top+1,:);F_struc(top,:)*0];
      K.q(i) = 3;
      top = top + 2;
    else
      new_F_struc = [new_F_struc;F_struc(top:top+K.q(i)-1,:)];
      top = top + K.q(i);
    end
end
new_F_struc = [new_F_struc;F_struc(top:$,:)];
endfunction
