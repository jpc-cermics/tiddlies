function [solvers,keep] = getavailablesolvers(findallsolvers);

solvers = solverdefinitions();
keep = ones(size(solvers,2),1);
if findallsolvers == 0 then
    for i = 1:size(solvers,2)
        isavailable = %t;
        for j = 1:size(solvers{i}.checkfor,1)
            isavailable = isavailable && exists(solvers{i}.checkfor(j),'nsp-function');
        end
        if ~isavailable then
            keep(i)=0;
        end
    end
end


if nargout == 1 then
    if (find(keep)==[]) then
    solvers=[];
    else
    solvers = solvers(find(keep));
    end
end


endfunction
