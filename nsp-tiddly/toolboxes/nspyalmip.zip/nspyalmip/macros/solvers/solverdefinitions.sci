function solver = solverdefinitions()

printf("%s\n",sprintf('Initializing solvers...Please Wait'))

// ****************************************
// DESCRIPTION OF GENERAL SOLVER INTERFACE
// ****************************************
//solver{i}.tag     =   name in YALMIP
//solver{i}.version =   additional identifier
//solver{i}.bmi     =   Bilinear constraints
//solver{i}.pmi     =   Polynomial constraint
//solver{i}.sciaxdet  =   MAXDET objective
//solver{i}.sdp     =   SDP constraints
//solver{i}.kyp     =   KYP constraints
//solver{i}.lp      =   Element-wise constraints
//solver{i}.qp      =   Quadratic objective functions
//solver{i}.gp      =   Sigmonial objective/constraints
//solver{i}.ncqp    =   NOT USED
//solver{i}.socp    =   Second order constraints
//solver{i}.rotsocp =   Rotated second order constraints
//solver{i}.equalities= Equality constraints
//solver{i}.duals   =   Returns dual variables
//solver{i}.Complex =   Handles Complex data
//solver{i}.integer =   Handles integer variables
//solver{i}.binary  =   Handles binary variables
//solver{i}.parametric  =   Handles parametric variables
//solver{i}.checkfor=   File to look for to see if solver is available
//solver{i}.call    =   Interface code
//solver{i}.subcall =   NOT USED

// ****************************
// INITIALIZE COUNTER
// ****************************
i = 1;

// ****************************
// DEFINE SOLVERS
// ****************************



// solver{i}.tag     = 'ipqp';
// solver{i}.version = '';
// solver{i}.bmi     = 0;
// solver{i}.pmi     = 0;
// solver{i}.sciaxdet  = 0;
// solver{i}.sdp     = 0;
// solver{i}.kyp     = solver{i}.sdp;
// solver{i}.lp      = 1;
// solver{i}.qp      = 1;
// solver{i}.gp      = 0;
// solver{i}.ncqp    = 0;
// solver{i}.socp    = 0;
// solver{i}.rotsocp = 0;
// solver{i}.qc = 0;
// solver{i}.equalities = 1;
// solver{i}.duals   = 0;
// solver{i}.Complex = 0;
// solver{i}.integer = 0;
// solver{i}.binary  = 0;
// solver{i}.parametric = 0;
// solver{i}.checkfor= {'ipqp'};
// solver{i}.call    = 'callipqp';
// solver{i}.subcall = '';
// solver{i}.show    = 1;
// i = i+1;

solver = cell(1);

solver{i} = hash_create(24);

solver{i}.tag     = 'linprog';
solver{i}.version = '';
solver{i}.bmi     = 0;
solver{i}.pmi     = 0;
solver{i}.maxdet  = 0;
solver{i}.sdp     = 0;
solver{i}.kyp     = solver{i}.sdp;
solver{i}.lp      = 1;
solver{i}.qp      = 0;
solver{i}.gp      = 0;
solver{i}.ncqp    = 0;
solver{i}.socp    = 0;
solver{i}.rotsocp = 0;
solver{i}.qc = 0;
solver{i}.equalities = 1;
solver{i}.duals   = 1;
solver{i}.Complex = 0;
solver{i}.integer = 0;
solver{i}.binary  = 0;
solver{i}.parametric = 0;
solver{i}.checkfor= list('linpro');
solver{i}.Call    = 'calllinprog';
solver{i}.subcall = '';
solver{i}.show    = 1;
i = i+1;

solver{i} = hash_create(24);

solver{i}.tag     = 'quadprog';
solver{i}.version = '';
solver{i}.bmi     = 0;
solver{i}.pmi     = 0;
solver{i}.maxdet  = 0;
solver{i}.sdp     = 0;
solver{i}.kyp     = solver{i}.sdp;
solver{i}.lp      = 1;
solver{i}.qp      = 1;
solver{i}.gp      = 0;
solver{i}.ncqp    = 0;
solver{i}.socp    = 0;
solver{i}.rotsocp = 0;
solver{i}.qc = 0;
solver{i}.equalities = 1;
solver{i}.duals   = 1;
solver{i}.Complex = 0;
solver{i}.integer = 0;
solver{i}.binary  = 0;
solver{i}.parametric = 0;
solver{i}.checkfor= list('quapro');
solver{i}.Call    = 'callquadprog';
solver{i}.subcall = '';
solver{i}.show    = 1;
i = i+1;

solver{i} = hash_create(24);

solver{i}.tag     = 'glpk';
solver{i}.version = '';
solver{i}.bmi     = 0;
solver{i}.pmi     = 0;
solver{i}.maxdet  = 0;
solver{i}.sdp     = 0;
solver{i}.kyp     = solver{i}.sdp;
solver{i}.lp      = 1;
solver{i}.qp      = 0;
solver{i}.gp      = 0;
solver{i}.ncqp    = 0;
solver{i}.socp    = 0;
solver{i}.rotsocp = 0;
solver{i}.qc = 0;
solver{i}.equalities = 1;
solver{i}.duals   = 1;
solver{i}.Complex = 0;
solver{i}.integer = 1;
solver{i}.binary  = 0;
solver{i}.parametric = 0;
solver{i}.checkfor= list('glpkmex.m');
solver{i}.Call    = 'callglpk';
solver{i}.subcall = '';
solver{i}.show    = 1;
i = i+1;

solver{i} = hash_create(24);

solver{i}.tag     = 'csdp';
solver{i}.version = '';
solver{i}.bmi     = 0;
solver{i}.pmi     = 0;
solver{i}.maxdet  = 0;
solver{i}.sdp     = 1;
solver{i}.kyp     = solver{i}.sdp;
solver{i}.lp      = 1;
solver{i}.qp      = 0;
solver{i}.gp      = 0;
solver{i}.ncqp    = 0;
solver{i}.socp    = 0;
solver{i}.rotsocp = 0;
solver{i}.qc = 0;
solver{i}.equalities = 0;
solver{i}.duals   = %t;
solver{i}.Complex = 0;
solver{i}.integer = 0;
solver{i}.binary  = 0;
solver{i}.parametric = 0;
solver{i}.checkfor= list('csdp','readsol','writesdpa');
solver{i}.Call    = 'callcsdp';
solver{i}.subcall = '';
solver{i}.show    = 1;
i = i+1;

solver{i} = hash_create(24);

solver{i}.tag     = 'sedumi';
solver{i}.version = '';
solver{i}.bmi     = 0;
solver{i}.pmi     = 0;
solver{i}.maxdet  = 0;
solver{i}.sdp     = 1;
solver{i}.kyp     = solver{i}.sdp;
solver{i}.lp      = 1;
solver{i}.qp      = 0;
solver{i}.gp      = 0;
solver{i}.ncqp    = 0;
solver{i}.socp    = 1;
solver{i}.rotsocp = 0;
solver{i}.qc = 0;
solver{i}.equalities = 0;
solver{i}.duals   = %t;
solver{i}.Complex = 0;
solver{i}.integer = 0;
solver{i}.binary  = 0;
solver{i}.parametric = 0;
solver{i}.checkfor= list('sedumi');
solver{i}.Call    = 'callsedumi';
solver{i}.subcall = '';
solver{i}.show    = 1;
i = i+1;


solver{i} = hash_create(24);

solver{i}.tag     = 'sdpa';
solver{i}.version = '';
solver{i}.bmi     = 0;
solver{i}.pmi     = 0;
solver{i}.maxdet  = 0;
solver{i}.sdp     = 1;
solver{i}.kyp     = solver{i}.sdp;
solver{i}.lp      = 1;
solver{i}.qp      = 0;
solver{i}.gp      = 0;
solver{i}.ncqp    = 0;
solver{i}.socp    = 0;
solver{i}.rotsocp = 0;
solver{i}.qc = 0;
solver{i}.equalities = 0;
solver{i}.duals   = 1;
solver{i}.Complex = 0;
solver{i}.integer = 0;
solver{i}.binary  = 0;
solver{i}.parametric = 0;
solver{i}.checkfor= list('sdpam');
solver{i}.Call    = 'callsdpa';
solver{i}.subcall = '';
solver{i}.show    = 1;
i = i+1;


// solver{i}.tag     = 'specsdp';
// solver{i}.version = '';
// solver{i}.bmi     = 0;
// solver{i}.pmi     = 0;
// solver{i}.sciaxdet  = 0;
// solver{i}.sdp     = 1;
// solver{i}.kyp     = solver{i}.sdp;
// solver{i}.lp      = 1;
// solver{i}.qp      = 0;
// solver{i}.gp      = 0;
// solver{i}.ncqp    = 0;
// solver{i}.socp    = 0;
// solver{i}.rotsocp = 0;
// solver{i}.equalities = 0;
// solver{i}.duals   = 1;
// solver{i}.Complex = 0;
// solver{i}.integer = 0;
// solver{i}.binary  = 0;
//solver{i}.parametric = 0;
// solver{i}.checkfor= {'SPSDPLSCX'};
// solver{i}.call    = 'callspecsdp';
// solver{i}.subcall = '';
// solver{i}.show    = 1;
// i = i+1;


solver{i} = hash_create(24);

solver{i}.tag     = 'lmisolver';
solver{i}.version = '';
solver{i}.bmi     = 0;
solver{i}.pmi     = 0;
solver{i}.maxdet  = 0;
solver{i}.sdp     = 1;
solver{i}.kyp     = solver{i}.sdp;
solver{i}.lp      = 1;
solver{i}.qp      = 0;
solver{i}.gp      = 0;
solver{i}.ncqp    = 0;
solver{i}.socp    = 0;
solver{i}.rotsocp = 0;
solver{i}.qc = 0;
solver{i}.equalities = 0;
solver{i}.duals   = 0;
solver{i}.Complex = 0;
solver{i}.integer = 0;
solver{i}.binary  = 0;
solver{i}.parametric = 0;
solver{i}.checkfor= list('lmisolver');
solver{i}.Call    = 'calllmilab';
solver{i}.subcall = '';
solver{i}.show    = 1;
i = i+1;

// solver{i}.tag     = 'mpcvx';
// solver{i}.version = '';
// solver{i}.bmi     = 0;
// solver{i}.pmi     = 0;
// solver{i}.sciaxdet  = 0;
// solver{i}.sdp     = 1;
// solver{i}.kyp     = solver{i}.sdp;
// solver{i}.lp      = 1;
// solver{i}.qp      = 1;
// solver{i}.gp      = 0;
// solver{i}.ncqp    = 1;
// solver{i}.socp    = 1;
// solver{i}.rotsocp = 0;
// solver{i}.qc = 0;
// solver{i}.equalities = 0;
// solver{i}.duals   = 0;
// solver{i}.Complex = 0;
// solver{i}.integer = 0;
// solver{i}.binary  = 0;
// solver{i}.parametric = 1;
// solver{i}.checkfor= {'mpcvx'};
// solver{i}.call    = 'mpcvx';
// solver{i}.subcall = '';
// solver{i}.show    = 1;
// i = i+1;

// // ***************************************
// // SOMEWHAT MORE Complex DEFINITIONS OF
// // THE INTERNAL MICP SOLVER
// // ***************************************

// 
// // ***************************************
// // SOMEWHAT MORE Complex DEFINITIONS OF
// // THE INTERNAL MICP CUTTING PLANE SOLVER
// // ***************************************
// solver{i}.tag     = 'cp';
// solver{i}.version = '';
// solver{i}.bmi     = 0;
// solver{i}.pmi     = 0;
// solver{i}.sciaxdet  = 0;
// solver{i}.sdp     = 1;
// solver{i}.kyp     = 0;
// solver{i}.lp      = 1;
// solver{i}.qp      = 0;
// solver{i}.gp      = 0;
// solver{i}.ncqp    = 0;
// solver{i}.socp    = 0;
// solver{i}.rotsocp = 0;
// solver{i}.qc = 0;
// solver{i}.equalities = 1;
// solver{i}.duals   = 0;
// solver{i}.Complex = 0;
// solver{i}.integer = 1;
// solver{i}.binary  = 1;
// solver{i}.checkfor= {'callcp'};
// solver{i}.call    = 'callcp';
// solver{i}.subcall = '';
// solver{i}.show    = 0;
// i = i+1;

// ***************************************
// SOMEWHAT MORE Complex DEFINITIONS OF
// THE INTERNAL GLOBAL BMI SOLVER
// ***************************************

solver{i} = hash_create(24);

solver{i}.tag     = 'kypd';
solver{i}.version = '';
solver{i}.bmi     = 0;
solver{i}.pmi     = 0;
solver{i}.maxdet  = 0;
solver{i}.sdp     = 1;
solver{i}.kyp     = solver{i}.sdp;
solver{i}.lp      = 1;
solver{i}.qp      = 0;
solver{i}.gp      = 0;
solver{i}.ncqp    = 0;
solver{i}.socp    = 0;
solver{i}.rotsocp = 0;
solver{i}.qc = 0;
solver{i}.equalities = 0;
solver{i}.duals   = 1;
solver{i}.Complex = 0;
solver{i}.integer = 0;
solver{i}.binary  = 0;
solver{i}.parametric = 0;
solver{i}.checkfor= list('kypd_solver');
solver{i}.Call    = 'callkypd';
solver{i}.subcall = '';
solver{i}.show    = 1;
i = i+1;

solver{i} = hash_create(24);

solver{i}.tag     = 'none';
solver{i}.version = '';
solver{i}.bmi     = 1;
solver{i}.pmi     = 0;
solver{i}.sciaxdet  = 0;
solver{i}.sdp     = 1;
solver{i}.kyp     = solver{i}.sdp;
solver{i}.lp      = 1;
solver{i}.qp      = 0;
solver{i}.gp      = 0;
solver{i}.ncqp    = 0;
solver{i}.socp    = 0;
solver{i}.rotsocp = 0;
solver{i}.qc = 0;
solver{i}.equalities = 1;
solver{i}.duals   = 0;
solver{i}.Complex = 0;
solver{i}.integer = 0;
solver{i}.binary  = 0;
solver{i}.parametric = 0;
solver{i}.checkfor= list('callnone.sci');
solver{i}.Call    = 'callnone';
solver{i}.subcall = '';
solver{i}.show    = 0;

endfunction
