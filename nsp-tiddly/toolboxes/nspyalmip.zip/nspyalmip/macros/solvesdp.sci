function diagnostic = solvesdp(varargin)
//SOLVESDP Computes solution to optimization problem
//
//   DIAGNOSTIC = SOLVESDP(F,h,options) is the common command to 
//   solve optimization problems of the following kind
// 
//    min        h
//    subject to
//            F >(=) 0
//
//   NOTES
//    Desptite the name, SOLVESDP is the interface for solving all 
//    supported problem classes (LP, QP, SOCP, SDP, BMI, MILP,MIQP,...)
//
//    To obtain solution for a variable, use DOUBLE. 
//
//    To obtain dual variable for a constraint, use DUAL.
//
//    See YALMIPERROR for error codes returned in output.
//
//   OUTPUT 
//     diagnostic : Diagnostic information
//
//   INPUT 
//     F          : SET object describing the constraints. Can be [].
//     h          : SDPVAR or LOGDET object describing the objective h(x). Can be [].
//     options    : Options structure. See SDPSETTINGS. Can be [].
//
//   EXAMPLE
//    x = sdpvar(5,1);A = randn(15,5);b = rand(15,1)*5;c = randn(5,1);
//    solvesdp(set(A*x<b),c'*x);double(x)
//
//   See also @SDPVAR/SET, DUAL, @SDPVAR/DOUBLE, SDPSETTINGS, YALMIPERROR

// Author Johan L�fberg
// $Id: solvesdp.sci,v 1.4 2011-03-22 12:39:15 solovyev Exp $

CACHED_SOLVERS=0
 // Let us see how much time we spend
yalmiptime = cputime();
// Arrrgh, new format with logdet much better, but we have to 
// take care of old code, requires some testing...
varargin = combatible(list(varargin(:)));
// *********************************
// CHECK INPUT
// *********************************
if nargin<1 then
    help solvesdp
    return
else
    F = varargin(1);  
    if ~isempty(F) then
         TMP = type(F,'string'); 
       if ~(TMP == 'Lmi') then 
           error('First argument (F) should be an lmiobject.');
       end
    end
end

if nargin>=2 then
    h = varargin(2);
    
    if ~isempty(h) then
     TMP=type(h,'string');
    end
    
    if ~(isempty(h)) && ((TMP == 'Sdpvar') || (TMP=='Logdet'))  then
        error('Second argument (the objective function h) should be an sdpvar or logdet object (or empty).');
    end

    if ~(isempty(h)) && (TMP =='Logdet') then
        P  = getP(h);
        g  = getgain(h);
        if g>0 then
            warning('Perhaps you mean -logdet(P)...')
            diagnostic.yalmiptime = cputime() - yalmiptime;          
            diagnostic.solvertime = 0;
            diagnostic.info = yalmiperror(-2,'YALMIP');
            diagnostic.problem = -2;
            return
        end
        h = getcx(h);
        G = lmi(P>0);
        F = F + G;
    else
        P = [];
        G = [];
    end
else
    P = [];
    h = [];
    G = [];
end
if nargin>=3 then
    options = varargin(3);     
    //if ~(isempty(options) | ) then
    //    error('Third argument (options) should be an sdpsettings struct (or empty).');
    //end
    if isempty(options) then
        options = sdpsettings;
    end
else  
    options = sdpsettings();
end


options.solver = tolower(options.solver);

// Just for safety

if size(F,2)==0 && size(F,1)==0 && isempty(G) then
    F = lmi();
end
if or(is(F,'sos')) then
    error('You have SOS constraints. Perhaps you meant to call SOLVESOS.');
end

// ******************************************
// COMPILE IN GENERALIZED YALMIP FORMAT
// ******************************************
options.cachesolvers = 1;

[interfacedata,recoverdata,solver,diagnostic,F] = compileinterfacedata(F,G,P,h,options,0);

// ******************************************
// FAILURE?
// ******************************************
if ~isempty(diagnostic) then
    diagnostic.yalmiptime = cputime() - yalmiptime;     
    return
end

// ******************************************
// SOME SOLVERS ARE CALLED ON A HIGHR LEVEL..
// ******************************************

// ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
// DID WE SELECT THE KYPD SOLVER
// ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
if solver.tag == 'kypd' then
    diagnostic = callkypd(F,h,options);
    diagnostic.yalmiptime = cputime() - yalmiptime -diagnostic.solvertime;     
    return
end

// ******************************************
// DID WE SELECT THE BMILIN SOLVER (obsolete)
// ******************************************
if solver.tag=='bmilin'  then
    diagnostic = callbmilin(F,h,options);
    return
end

// ******************************************
// DID WE SELECT THE BMIALT SOLVER (obsolete)
// ******************************************
if solver.tag=='bmialt' then
    diagnostic = callbmialt(F,h,options);
    return
end

//******************************************
// DID WE SELECT THE MPT solver (backwards comb)
//******************************************
if (solver.tag=='mpt') | (solver.tag=='mpcvx') then
    actually_save_output = interfacedata.options.savesolveroutput;
    interfacedata.options.savesolveroutput = 1;
    if isempty(interfacedata.parametric_variables) then
        if (nargin < 4 | (type(varargin(4))==15 & getfield(1,varargin(4))(1)=='sdpvar'))
            error('You must specify parametric variables.')
        else
            interfacedata.parametric_variables = getvariables(varargin(4));
        end
    end
//else
//    parametric_variables = [];
end

// ********************************
// TRY TO SOLVE PROBLEM
// ********************************
try
    execstr(strcat(['output = ', solver.Call, '(interfacedata);']));
    if options.saveduals & solver.duals then
       // e = (output.solverinput.A)'*(output.D_struc)-output.solverinput.b;
       // delta = (output.solverinput.A)'\e;
       // output.D_struc = -delta + output.D_struc;               
        setduals(F,output.D_struc,interfacedata.K);
    end    
catch   
//    output.solverinput  = [];
//    output.solveroutput = [];
//    output.problem = 9;
//    output.solvertime   = %nan;
//   output.infostr = yalmiperror(output.problem,solver.tag);
//    //Output NaN-solution
//    output.x = zeros(length(interfacedata.c),1)+%nan;
end
// ********************************
// ORIGINAL COORDINATES
// ********************************
tmpx=[];
for i=1:length(output.x)
tmpx(i) = output.x(i);
end
output.x = tmpx(:);

output.x = recoverdata.x_equ+recoverdata.H*output.x;

// ********************************
// OUTPUT
// ********************************
diagnostic.yalmiptime = cputime() - yalmiptime - output.solvertime;
diagnostic.solvertime = output.solvertime;
diagnostic.info = output.infostr;
diagnostic.problem = output.problem;

// Some more info is saved internally
solution_internal = diagnostic;
solution_internal.variables = recoverdata.used_variables(:);
solution_internal.optvar = output.x;

if ~isempty(interfacedata.parametric_variables) then
    diagnostic.mpsol = output.solveroutput;
    options.savesolveroutput = actually_save_output;
end;

if interfacedata.options.savesolveroutput then
    diagnostic.solveroutput = output.solveroutput;
end
if interfacedata.options.savesolverinput then
    diagnostic.solverinput = output.solverinput;
end

if (options.Warning>0) && isempty(strindex(output.infostr,'No problems detected')) then
    printf("%s\n",strcat(['Warning: ', output.infostr]));
end

if ismember(output.problem,options.beeponproblem) then
   try
       beep; // does not exist on all ML versions
   catch
   end
end

// And we are done! Save the result
sdpvar('setSolution',solution_internal);

endfunction

function newinputformat = combatible(varargin)
varargin = varargin(1);

classification = 0;
// 0 : Ambigious
// 1 : Old
// 2 : New

// Try some fast methods to determine...
m = length(varargin);
if m==1 then
    classification = 2;
elseif m>=3 & isstruct(varargin(3)) then
    classification = 2;
elseif m>=4 & isstruct(varargin(4)) then
    classification = 1;
elseif m>=2 & isa(varargin(2),'lmi') then
    classification = 1;
elseif m>=3 & isa(varargin(3),'sdpvar') then
    classification = 1;
elseif m>=2 & type(varargin(2))==15&getfield(1,varargin(2))(1)=='sdpvar' & min(size(varargin(2)))==1 then
    classification = 2; 
elseif m>=2 & type(varargin(2))==15&getfield(1,varargin(2))(1)=='sdpvar' & prod(size(varargin(2)))>=1 then
    classification = 1;     
elseif m>=2 & type(varargin(2))==15&getfield(1,varargin(2))(1)=='logdet' then
    classification = 2; 
elseif m==2 & isempty(varargin(2)) then
    classification = 2; 
end

if classification==0 then
    warning('I might have interpreted this problem wrong due to the new input format in version 3. To get rid of this warning, use an options structure');
    classification = 2;    
end

if classification==2 then
    newinputformat = varargin;
else
    newinputformat = varargin;
    P = varargin(2);
    // 99.9// of the cases....
    if isempty(P) then
        newinputformat = newinputformat([1 3:length(newinputformat)]);
    else
        if type(P)==15 & getfield(1,P)(1)=='lmi' then
            P = sdpvar(P);
        end
        if m>=3 then
            cxP = newinputformat(3)-logdet(P);
            newinputformat(3)=cxP;
        else
            cxP = -logdet(P);
            newinputformat(3)=cxP;
        end
        newinputformat = newinputformat([1 3:length(newinputformat)]);
    end
end
endfunction
