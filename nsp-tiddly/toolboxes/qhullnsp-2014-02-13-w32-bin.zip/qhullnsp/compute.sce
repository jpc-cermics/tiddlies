xclear();
npts=1000;
nstrips=100;
xmin=-1;xmax=1;ymin=-1;ymax=1;
x=grand(npts,1,"unf",xmin,xmax);
y=grand(npts,1,"unf",ymin,ymax);

voronoi(x,y); // draw the diagram 
// [Ca,V,C]=SquareBV(x,y,rect=[xmin,xmax,ymin,ymax]);

// some vertical strips 
xi=linspace(xmin,xmax,nstrips);
epsilon=0.05;
for k=1:size(xi,'*')-1 
  [Ca,V,C]=SquareBV(x,y,rect=[xi(k),xi(k+1),ymin,ymax]);
  // In strip k we have to compute uk 
  // which is given by 
  // sum(p_ik j(u_k,w_i) 
  // and j(u,w)= epsilon*u^2 + (u + w_0+w_1)^2 
  // uk = - ( sum(pik*(w_i^1 + w_i^0))/(1+ epsilon*sum(pik))
  // Ca/4 are the pik 
  u(k) = - Ca'*(x+y)/((1+epsilon)*sum(Ca));
end

xclear();
mid=(xi(2:$)+xi(1:$-1))/2;
plot2d2(xi(1:$-1),u,style=2)
plot2d(mid,-mid/(1+epsilon),style=3)




