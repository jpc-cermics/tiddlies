xclear();
n=100;
xmin=-1;xmax=1;ymin=-1;ymax=1;
x=grand(n,1,"unf",xmin,xmax);
y=grand(n,1,"unf",ymin,ymax);
voronoi(x,y); // draw the diagram 
[Ca,V,C]=SquareBV(x,y,rect=[xmin,xmax,ymin,ymax]);

// associer les surfaces aux points

pos=-1*ones(1,n);
for i=1:n
  pi=C{i};
  xv=V(pi,1);yv=V(pi,2);
  in=inpolygon(x,y,xv,yv);
  I=find(in); 
  if size(I,'*')== 1 then pos(i)=I;end 
end

// some vertical strips 
xi=linspace(xmin,xmax,10);
xclear();plot2d([],[],rect=[xmin,ymin,xmax,ymax]);
for i=1:size(xi,'*')-1 
  [Ca,V,C]=SquareBV(x,y,rect=[xi(i),xi(i+1),ymin,ymax]);
  I=find(Ca<>0);
  xclear();plot2d([],[],rect=[xmin,ymin,xmax,ymax]);
  voronoi(x,y,toggleplot=%t);
  xrect([xi(i),ymax,xi(i+1)-xi(i),ymax-ymin]);
  for j=I
    xstring(x(j),y(j),"ok");
  end
  xpause(1000000,%t);
end



