// This is the builder.sce 
// must be run from this directory 

// [1] generate Path.incl 
if exists('%nsp') then 
  ilib_path_incl()
end 

// [3] the part devoted to shared lib generation 
ilib_name  = 'libvoro' 		// interface library name 

// objects files (but do not give mexfiles here)
files = ['voronoi.o'];

// other libs needed for linking (must be shared library names)
// libs  = ['lib/liblpsolve55']; 				

if %win32 then 
  libs =['lib/libqhull-5'];
else
  libs =[];
end

// table of (scilab_name,interface-name or mexfile-name, type) 
table =['voronoi_internal','int_voronoi'];
ldflags ="-lqhull -lm "// "`pkg-config lp_solve --libs`";
cflags = ""// "`pkg-config lp_solve --cflags`"

// do not modify below 
// ----------------------------------------------

ilib_build(ilib_name,table,files,libs,ldflags = ldflags,cflags = cflags );


