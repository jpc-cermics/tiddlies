/*
 * Main program 
 */

#include <time.h>
#include <omp.h>

#include "utils.h"
#include "problem.h"
#include "preprocessing.h"

int main(int argc, char **argv)
{
  static Dam_data Dams[]=
    {
      /* efficiency,cost_conv, cost_coeff,stock_target,stock_min,stock_max, nx, 
       * control min, max, nu, z_min,z_max, nz, intakes_m, intakes; 
       */
      {0.066, 1000.0, 500.0, 40,  0, 80, 41, 0, 40, 6, 0, 0  , 01, 10, NULL},
      {0.066, 1000.0, 500.0, 40,  0, 80, 41, 0, 40, 6, 0, 120, 60, 10, NULL},
      {0.066, 1000.0, 500.0, 40,  0, 80, 41, 0, 40, 6, 0, 180, 90, 10, NULL},
    };
  
  static Pb_data Pb=
    {
      3, /* number of dams */
      Dams, /* pointer to dams data */
      12,  /* Horizon */
      1,   /* number of price samples, here price is determinist */
      NULL,/* pointer to prices */
      500, /* number of scenarios samples for simulation */
      NULL,
      500, /* number of scenarios samples for uzawa if needed */
      NULL,
      4,   /* number of noises in the pb */
    };

  if ( argc == 2 ) 
    {
      if ( strcmp(argv[1],"-init") == 0)
	{ 
	  if ( init(&Pb) == FAIL ) 
	    {	 
	      printf("Error: init failed\n");
	      exit(1);
	    }

				     
	  exit(0);
	}
      else if (strcmp(argv[1],"-dp") == 0) 
	{ 
	  if ( load_datas(&Pb) == FAIL ) 
	    {
	      printf("Error: failed to read data\n");
	      exit(1);
	    }
	  else
	    {
	      Algo_dp Algo ={ NULL,0,0};
	      Dp_algorithm(&Pb,&Algo);
	      /* simulation */
	      soc_simul(Algo.ntotu,Algo.V, Algo.ntotx, &Pb);
	    }
	}
      else if (strcmp(argv[1],"-dadp") == 0)
	{
	  if ( load_datas(&Pb) == FAIL ) 
	    {
	      printf("Error: failed to read data\n");
	      exit(1);
	    }
	  else
	    {
	      Algo_dadp Algo={2,NULL,NULL,NULL,NULL,NULL};
	      if ( Dadp_algorithm(&Pb,&Algo) == FAIL) 
		{
		  printf("Error: failed to run Dadp\n");
		  exit(1);
		}
	    }
	} 
      else 
	{ 
	  goto err;
	}
    }
  else
    {
      goto err;
    }
  return 0;
 err:
  printf("Usage: %s -init | -dp | -dadp\n",argv[0]);
  exit(1);
}

