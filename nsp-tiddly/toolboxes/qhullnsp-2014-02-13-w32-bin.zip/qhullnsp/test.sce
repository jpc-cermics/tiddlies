M=fscanfMat('../SquareBV/data-saved.txt');
M=matrix(M,10,3);
x=M(:,1);y=M(:,2);

x=[1/4,1/4,7/8,7/8]';
y=[7/8,0.5,7/8,0.5]';
SquareBV(x+rand(size(x))*0.01,y+rand(size(x))*0.01,0);

