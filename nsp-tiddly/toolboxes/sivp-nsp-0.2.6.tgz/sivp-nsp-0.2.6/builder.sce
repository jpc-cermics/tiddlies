// This is the builder.sce
// must be run from this directory

// generate Path.incl

ilib_path_incl(relative=%t)

// build the source 

chdir('src');
ok=exec('builder.sce',errcatch=%t);
chdir('../');
if ~ok then 
  printf(strcat(lasterror()));
  error('exec builder.sce failed in src');
end

// exec("src/builder.sce");
// add_lib('./macros',compile=%t);


