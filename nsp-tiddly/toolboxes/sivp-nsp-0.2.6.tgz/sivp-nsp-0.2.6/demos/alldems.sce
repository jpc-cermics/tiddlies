//---------------------------------------------------
// Copyright (C) 2004-2017 Jean-Philippe Chancelier Cermics/Enpc
// jpc@cermics.enpc.fr
// sivp demos 
//---------------------------------------------------

titles =list();

titles($+1)= list( 'Read and show', "unknown", "sivp_dem_2");

function sivp_dem_2()
  B=imread(file('join',[ getenv('SIVP_PATH'),'images/lena.png']));
  B.show[name="Lena"];
endfunction

titles($+1)= list( 'Read and show (autosize=%f)', "unknown", "sivp_dem_9");

function sivp_dem_9()
  im=imread(file('join',[ getenv('SIVP_PATH'),'images/lena.png']));
  imshow(im,autosize=%f,name="Lena autosize=%f");
endfunction

titles($+1)= list( 'Read, convert, show', "unknown", "sivp_dem_2_1");

function sivp_dem_2_1()
  B=imread(file('join',[ getenv('SIVP_PATH'),'images/lena.png']));
  B=convert(B,'RGB2GRAY');
  B.show[name="Lena"];
endfunction

titles($+1)= list( 'Read, Write', "unknown", "sivp_dem_2_2");

function sivp_dem_2_2()
  B=imread(file('join',[ getenv('SIVP_PATH'),'images/lena.png']));
  B=convert(B,'RGB2GRAY');
  B.write[ file('join',[ getenv('NSP_TMPDIR'),"adapth.png"])];
  B=imread(file('join',[ getenv('NSP_TMPDIR'),"adapth.png"]));
  B.show[name="Lena after rewrite gray version"];
endfunction

titles($+1)= list( 'Channels', "unknown", "sivp_dem_2_3");

function sivp_dem_2_3()
  A=imread(file('join',[getenv('SIVP_PATH'),'images/lena.png']));
  A=imresize(A,0.5);
  A.show[];    
  B=imread(file('join',[getenv('SIVP_PATH'),'images/peppers.png']));
  B=imresize(B,0.5);
  B.show[];    
  Bc=B.get_channels[];
  Ac=A.get_channels[];
  Rc={[Bc{1},Ac{1}],[Bc{2},Ac{2}],[Bc{3},Ac{3}]};
  R=iplimage(Rc,"8U");
  R.show[];
endfunction

titles($+1)= list( 'Change Channels', "unknown", "sivp_dem_2_5");

function sivp_dem_2_5()
  A=imread(file('join',[getenv('SIVP_PATH'),'images/lena.png']));
  Ac=A.get_channels[];
  for i=1:3 do Ac{i}= min(Ac{i} + grand(A.width,A.height,'uin',0,100),256);end
  R=iplimage(Ac,"8U");
  R.show[];
endfunction

titles($+1)= list( 'imtopixbuf and pixbuftoim', "unknown", "sivp_dem_11");

function sivp_dem_11()
  im=imread(file('join',[ getenv('SIVP_PATH'),'images/lena.png']));
  pix = imtopixbuf(im);
  im1 = pixbuftoim(pix);
  im1.show[];
endfunction

titles($+1)= list( 'rectangle,circles, lines ', "unknown", "sivp_dem_11_1");

function sivp_dem_11_1()
  // add a rectangle 
  im=imread(file('join',[getenv('SIVP_PATH'),'images/lena.png']));
  rect=[im.width/12,im.height/12,im.width/3,im.height/3];
  im.rectangle[rect,rgb=[0,0,255],thickness=3];
  // add a filled rectangle 
  rect=[2/3*im.width,im.height/12,im.width/3,im.height/3];
  im.rectangle[rect,rgb=[0,124,255],thickness=-1];
  // a circle 
  center=[im.width/3,im.height/3];
  im.circle[center,min(im.width,im.height)/6,rgb=[123,0,56],thickness=-1];
  // line
  center=[im.width/2,im.height/2];
  im.line[center,center+min(im.width,im.height)/3,rgb=[255,0,255],thickness=3];
  im.show[]
endfunction

titles($+1)= list( 'mix with gtk widgets', "unknown", "sivp_dem_11_2");

function sivp_dem_11_2()
  win = gtkwindow_new()
  //win.connect["delete_event", demo_delete];
  win.set_title["range_controls"];
  box1 = gtkvbox_new(homogeneous=%f,spacing=0)
  win.add[box1]
  box1.show[]
  
  adjustment =gtkadjustment_new(value=0,lower=0,upper=10,step_incr=0.1,page_incr=1,page_size=1)
  scale = gtkhscale_new(adjustment=adjustment)
  scale.set_size_request[150,-1]
  scale.set_update_policy[GTK.UPDATE_DELAYED];
  scale.set_digits[1];
  scale.set_draw_value[%t];
  
  box1.pack_start[scale]
  scale.show[]
  separator = gtkhseparator_new ();
  box1.pack_start[separator];
  separator.show[];
  
  im=imread(file('join',[getenv('SIVP_PATH'),'images/lena.png']));
  pixbuf=imtopixbuf(im)
  image = gtkimage_new("pixbuf",pixbuf);
  box1.pack_start[image,expand=%f,fill=%f,padding=0]

  scale.connect["change_value",scale_changed,list(image)];
  image.user_data=im;
  
  function button_destroy_win(but,args)  
    // button handler which destroy args(1)
    //printf("in win destroy \n");
    args(1).destroy[];
  endfunction 

  function y=scale_changed(w,scr,val,args)
    // val is the value   
    //im=dilate(im,1);
    image = args(1);
    im=dilate(image.user_data,val)
    pixbuf=imtopixbuf(im);
    image.set_from_pixbuf[pixbuf=pixbuf];
    y=%f
  endfunction 
  
  button = gtkbutton_new(label="close")
  button.connect["clicked", button_destroy_win,list(win)];
  box1.pack_start[button]
  button.set_flags[GTK.CAN_DEFAULT]
  button.grab_default[]
  button.show[]
  
  win.show_all[];
  //gtk_main()
endfunction

titles($+1)= list( 'convert to gtktimage', "unknown", "sivp_dem_11_3");

function sivp_dem_11_3()
  im=imread(file('join',[getenv('SIVP_PATH'),'images/lena.png']));
  pixbuf=imtopixbuf(im)
  image = gtkimage_new("pixbuf",pixbuf);
  window = gtkwindow_new()
  window.set_title["Lena"];
  window.set_border_width[  8]
  vbox = gtkvbox_new(homogeneous=%f,spacing=8);
  vbox.set_border_width[  8]
  window.add[vbox]
  label = gtklabel_new();
  label.set_markup["<u>Lena</u>"];
  vbox.pack_start[ label,expand=%f,fill=%f,padding=0]
  frame = gtkframe_new();
  frame.set_shadow_type[GTK.SHADOW_IN];
  align = gtkalignment_new(xalign=0.5,yalign=0.5,xscale=0,yscale=0);
  align.add[  frame]
  vbox.pack_start[ align,expand=%f,fill=%f,padding=0]
  frame.add[image]
  window.show_all[];
endfunction

titles($+1)= list( 'Adaptative Threshold', "unknown", "sivp_dem_1");

function sivp_dem_1()
  A=imread(file('join',[ getenv('SIVP_PATH'),'images/baboon.png']));
  B=convert(A,'BGR2GRAY');
  i=4;
  select i 
    case 1; C=adaptativethreshold(B,200,'ADAPTIVE_THRESH_MEAN_C','THRESH_BINARY',3,1);
    case 2; C=adaptativethreshold(B,200,'ADAPTIVE_THRESH_MEAN_C','THRESH_BINARY',5,-1);
    case 3; C=adaptativethreshold(B,200,'ADAPTIVE_THRESH_GAUSSIAN_C','THRESH_BINARY_INV',7,2);
    case 4; C=adaptativethreshold(B,200,'ADAPTIVE_THRESH_GAUSSIAN_C','THRESH_BINARY_INV',9,-2);
  end 
  C.show[name="baboon"];
endfunction

titles($+1)= list( 'canny', "unknown", "sivp_dem_2_4");

function sivp_dem_2_4()
  B=imread(file('join',[ getenv('SIVP_PATH'),'images/lena.png']));
  A=canny(B,100,150,3);
  A.show[name="Lena"];
endfunction

titles($+1)= list( 'cmp', "unknown", "sivp_dem_3");

function sivp_dem_3()
  B=imread(file('join',[ getenv('SIVP_PATH'),'images/baboon.png']));
  B=convert(B,'RGB2GRAY');
  V= B.get_channel[1];
  V(100:400,100:400)=100;
  C=iplimage({V},"8U");
  i=1;
  select i 
    case 1;A=cmp(B,C,"CMP_EQ");A.show[];
    case 2;A=cmp(B,C,"CMP_GT");A.show[];
    case 3;A=cmp(B,C,"CMP_GE");A.show[];
    case 4;A=cmp(B,C,"CMP_LT");A.show[];
    case 5;A=cmp(B,C,"CMP_LE");A.show[];
    case 6;A=cmp(B,C,"CMP_NE");A.show[];    
  end
endfunction

titles($+1)= list( 'convertscale', "unknown", "sivp_dem_3_1") ;

function sivp_dem_3_1()
  im=imread(file('join',[ getenv('SIVP_PATH'),'images/lena.png']));
  im1 = convertscale(im,"8U",scale=0.5);
  im1.show[];
endfunction

titles($+1)= list( 'dilate', "unknown", "sivp_dem_4");

function sivp_dem_4()
  B=imread(file('join',[ getenv('SIVP_PATH'),'images/lena.png']));
  A=dilate(B,4);A.show[];
  //A=dilate(B,3,'RECT',3,3,1,1);A.show[];
  //A=dilate(B,4,'CROSS',3,3,1,1);A.show[];
  //A=dilate(B,5,'ELLIPSE',3,3,1,1);A.show[];    
endfunction

titles($+1)= list( 'erode', "unknown", "sivp_dem_6");

function sivp_dem_6()
  B=imread(file('join',[ getenv('SIVP_PATH'),'images/lena.png']));
  A=erode(B,2);A.show[];
  //A=erode(B,3,'RECT',3,3,1,1);
  //A=erode(B,4,'CROSS',3,3,1,1);
  //A=erode(B,5,'ELLIPSE',3,3,1,1);    
endfunction

titles($+1)= list( 'imsmooth and goodfeaturestotrack', "unknown", "sivp_dem_7");

function sivp_dem_7()
  B=imread(file('join',[ getenv('SIVP_PATH'),'images/lena.png']));
  C=convert(B,'BGR2GRAY');
  D=imsmooth(C,'GAUSSIAN',7,7,0);
  D.show[name="Lena smoothed"]
  A=goodfeaturestotrack(D,22,0.01,20);
  A.show[name="Lena goodfeaturestotrack"];    
endfunction

titles($+1)= list( 'imsmooth', "unknown", "sivp_dem_10");

function sivp_dem_10()
  B=imread(file('join',[ getenv('SIVP_PATH'),'images/lena.png']));
  A=imsmooth(B,'GAUSSIAN',3,3,0);A.show[];
  //A=imsmooth(B,'BILATERAL',3,3,0);A.show[];
  //A=imsmooth(B,'MEDIAN',3,3,0);A.show[];
  //A=imsmooth(B,'BLUR',3,3,0);A.show[];
  //A=imsmooth(B,'BLUR_NO_SCALE',3,3,0);A.show[];
  A.show[];
endfunction

titles($+1)= list( 'laplace', "unknown", "sivp_dem_12");

function sivp_dem_12()
  A=imread(file('join',[ getenv('SIVP_PATH'),'images/lena.png']));
  B=convert(A,'RGB2GRAY');
  A=laplace(B,3);
  A.show[];    
endfunction

titles($+1)= list( 'precornerdetect', "unknown", "sivp_dem_13");

function sivp_dem_13()
  B=imread(file('join',[ getenv('SIVP_PATH'),'images/lena.png']));
  C=convert(B,'RGB2GRAY');
  A=precornerdetec(C,3);
  A.show[];    
endfunction

titles($+1)= list( 'detectobjects', "unknown", "sivp_dem_13_1");

function sivp_dem_13_1()
  im=imread(file('join',[getenv('SIVP_PATH'),'images/lena.png']));
  face = detectobjects(im,'haarcascade_frontalface_alt2.xml');
  rrect = face(1,:) ;
  im.rectangle[ rrect,rgb=[255,0,0]];
  im.show[];
    
  subface = imcrop(im, rrect);
  // search eyes in the first found face 
  reyes = detectobjects(subface, 'righteye.xml');
  lrect = face * [1,0,0,0; 0,1,0,0; 0.3,0,0.7,0; 0,0,0,0.6];
  subface = imcrop(im, lrect);
  leyes = detectobjects(subface, 'lefteye.xml');
  [m,n] = size(reyes);
  for i=1:m,  
    im.rectangle[ reyes(i,:)+rrect.*[1,1,0,0], rgb=[0,255,0]];
  end;
  [m,n] = size(leyes);
  for i=1:m,  
    im.rectangle[ leyes(i,:)+lrect.*[1,1,0,0] ,rgb= [0,0,255]];
  end;
  im.show[];
endfunction

titles($+1)= list( 'pyrdown', "unknown", "sivp_dem_14");

function sivp_dem_14()
  B=imread(file('join',[ getenv('SIVP_PATH'),'images/lena.png']));
  A=pyrdown(B,'GAUSSIAN_5x5');
  A.show[];    
endfunction

titles($+1)= list( 'pyrup', "unknown", "sivp_dem_15");

function sivp_dem_15()
  B=imread(file('join',[ getenv('SIVP_PATH'),'images/lena.png']));
  A=pyrup(B,'GAUSSIAN_5x5');
  imshow(A,autosize=%t);    
endfunction

titles($+1)= list( 'sobel', "unknown", "sivp_dem_16");

function sivp_dem_16()
  B=imread(file('join',[ getenv('SIVP_PATH'),'images/lena.png']));
  B=convert(B,'RGB2GRAY');
  A=sobel(B,1,2,3);
  imshow(A);    
endfunction

titles($+1)= list( 'threshold', "unknown", "sivp_dem_17");

function sivp_dem_17()
  A=imread(file('join',[ getenv('SIVP_PATH'),'images/peppers.png']));
  B=convert(A,'BGR2GRAY');
  C=threshold(B,'THRESH_BINARY',90,150);
  //C=threshold(B,'THRESH_BINARY_INV',90,150);
  //C=threshold(B,'THRESH_TRUNC',90,150);
  //C=threshold(B,'THRESH_TOZERO',90,150);
  //C=threshold(B,'THRESH_TOZERO_INV',90,150);
  C.show[];
endfunction

titles($+1)= list( 'xor', "unknown", "sivp_dem_18");

function sivp_dem_18()
  B=imread(file('join',[ getenv('SIVP_PATH'),'images/peppers.png']));
  C=imread(file('join',[ getenv('SIVP_PATH'),'images/lena.png']));
  B=convert(B,'RGB2GRAY');
  C=convert(C,'RGB2GRAY');
  A=xor(B,C);
  A.show[];
endfunction

titles($+1)= list( 'cvcapture', "unknown", "sivp_dem_19");

function sivp_dem_19()
  X=cvcapture(file('join',[ getenv('SIVP_PATH'),'images/walking.avi']));
  while %t
    ok = execstr('im=X.query_frame[];',errcatch=%t);
    if ~ok then break;end 
    im.show[]; 
    xpause(10000, %t);
  end 
endfunction

titles($+1)= list( 'detectforeground', "unknown", "sivp_dem_19_1");

function sivp_dem_19_1()
  // foregound detection 
  X=cvcapture(file('join',[ getenv('SIVP_PATH'),'images/parking.avi']));
  start = %t;
  count=1;
  while %t 
    ok = execstr('F=X.query_frame[];',errcatch=%t);
    if ~ok then break;end 
    if start == %t then 
      fg = detectforeground(F, 'LI');
      start = %f
    else
      fg = detectforeground(F );
    end
    F.show[name="parking"];
    fg.show[name="foreground"];
    xpause(10000,%t);
  end
endfunction

titles($+1)= list( 'cvvideowriter', "unknown", "sivp_dem_20");

function sivp_dem_20()
  // "PIM1","MJPG","MP42","DIV3","DIVX","U263","I263","FLV1","XVID"
  // X=cvvideowriter('/tmp/poo.avi',codec);
  // On Linux "DIVX" and  "XVID" only seams to work.
  // a tester : 'DIB '  RGB(A), Uncompressed RGB, 24 or 32 bit
  //            'I420', RAW I420, Uncompressed YUV, 4:2:0 chroma subsampled
  //             'IYUV', RAW I420, identical to I420
  X=cvvideowriter(file('join',[ getenv('NSP_TMPDIR'),"poo.avi"]));
  t=%pi*(-1:0.1:1);
  I=80:-1:1;
  ebox=[min(t),max(t),min(t),max(t),-1,1];
  wins=winsid();
  if ~isempty(wins) then id=max(wins)+1; else id=0;end
  xset('window',id)
  xset('wresize',0)
  xset('wdim',512,512);
  xset('wpdim',512,512);
  i=1;
  plot3d1(t,t,sin((I(i)/10)*t)'*cos((I(i)/10)*t),alpha=35,theta=45,colormap=jetcolormap(64),ebox=ebox);
  A=get_current_objs3d();
  for i=1:size(I,'*')
    A.children=list();
    plot3d1(t,t,sin((I(i)/10)*t)'*cos((I(i)/10)*t),alpha=35,theta=45,colormap=jetcolormap(64),ebox=ebox)
    // get the graphic window as a pixbuf
    A.invalidate[];
    pixbuf = xget_pixbuf();
    // opencv image from pixbuf 
    img = pixbuftoim(pixbuf);
    // img.show[];
    // fname=sprintf("image%0.4d.png",i);
    // imwrite(img,"/tmp/"+fname);
    X.write_frame[img];  
  end
  X.close[];
  x_message("Playing the recorded video");
  X=cvcapture(file('join',[ getenv('NSP_TMPDIR'),"poo.avi"]));
  while %t
    ok = execstr('im=X.query_frame[];',errcatch=%t);
    if ~ok then break;end 
    im.show[]; 
    xpause(10000, %t);
  end 
endfunction

titles($+1)= list('camshift: tracking a red car', "unknown", "sivp_dem_21");

function sivp_dem_21()
  X=cvcapture(file('join',[ getenv('SIVP_PATH'),'images','red-car-video.avi']));
  // skip the first frames
  for i=1:5
    ok = execstr('im=X.query_frame[];',errcatch=%t);
    if ~ok then lasterror();break;end
  end
  obj_win = camshift(im, [21, 2, 50, 40]); //initialize tracker
  // start tracking the red car 
  while %t do
    ok = execstr('im=X.query_frame[];',errcatch=%t);
    if ~ok then lasterror();break;end
    obj_win = camshift(im); //camshift tracking
    im.rectangle[obj_win(1:4),rgb=[0,255,1],thickness=2];
    im.show[]; 
    xpause(100000, %t);
  end
  camshift(im,[]); // force camshift to clean static data
  X.close[];
endfunction

titles($+1)= list('cvcapture with camera', "unknown", "sivp_dem_22");

function sivp_dem_22()
  // first argument is the id of connected camera
  X=cvcapture(0);
  for i=1:100
    ok = execstr('im=X.query_frame[];',errcatch=%t);
    if ~ok then lasterror();break;end
    im.show[]; 
    xpause(0, %t);
  end
  X.close[];
endfunction

exec('NSP/demos/graphics/main_graphic.sci');

sivp_demos_all = list( list("Sivp", "", "", titles) );

graphics_demo_in_gtk(sivp_demos_all,%f);

