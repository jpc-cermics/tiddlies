// sivp loader for nsp 


if exists('gtk_get_major_version','function') then
  printf('sivp toolbox NOT LOADED: sivp only works with gtk2 versions of nsp\n');
else
  
  exec("src/loader.sce");
  // path to here
  sivp_path = get_current_exec_dir()
  if file('pathtype',sivp_path) == 'relative' then 
    sivp_path= file('join',[getcwd(),sivp_path]);
  end
  // we want to be able to access to sivppath event after a clear 
  setenv('SIVP_PATH',sivp_path);
  sivp_init(sivp_path);
  printf('sivp toolbox loaded (Copyright (C) 2005-2017 V. Etienne, S. Shang, S. Yu)\n');
end


