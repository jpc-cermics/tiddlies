/***********************************************************************
 * SIVP - Scilab Image and Video Processing toolbox
 * Copyright (C) 2005  Vincent Etienne
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ***********************************************************************/

/* Ported to nsp: Jean-Philippe Chancelier 2005-2006.
 *
 */

#include "common.h"

#ifdef __cplusplus
extern "C" {
#endif


int int_adaptativethreshold(Stack stack, int rhs, int opt, int lhs)
{
  int nsp_ret = RET_BUG;
  NspIplImage* nsp_img;
  IplImage* img2 = NULL, *img1=NULL;
  //create variable for parameters
  char * nom1 = NULL, * nom2= NULL;
  double param1,  param3;
  int  param2;

  CheckRhs(6,6);
  CheckLhs(1,1);
  if ((nsp_img= GetIplImage(stack,1))== NULL) goto exit;  
  if ( GetScalarDouble(stack,2,&param1) == FAIL) goto exit;
  if ((nom1 = GetString(stack,3)) == (char*)0) goto exit;
  if ((nom2 = GetString(stack,4)) == (char*)0) goto exit;
  if ( GetScalarInt(stack,5,&param2) == FAIL) goto exit;
  if ( GetScalarDouble(stack,6,&param3) == FAIL) goto exit;
  img1 = nsp_img->img;
  if ((img2=cvCreateImage(cvGetSize(img1),img1->depth,img1->nChannels))==NULL)
    {
      Scierror("Error: can't create the output matrix\n");
      goto exit;
    }
  if (strcmp(nom1,"ADAPTIVE_THRESH_MEAN_C")==0)
    {
      if (strcmp(nom2,"THRESH_BINARY")==0) 
	{
	  cvAdaptiveThreshold( img1, img2,param1,CV_ADAPTIVE_THRESH_MEAN_C,CV_THRESH_BINARY,param2,param3);
	}
      else if (strcmp(nom2,"THRESH_BINARY_INV")==0)
	{
	  cvAdaptiveThreshold( img1, img2,param1,CV_ADAPTIVE_THRESH_MEAN_C,CV_THRESH_BINARY_INV,param2,param3);
	}
      else
	{
	  Scierror("Error: %s fourth argument has wrong value\n",NspFname(stack));
	  goto exit;
	}
    }
  else if (strcmp(nom1,"ADAPTIVE_THRESH_GAUSSIAN_C")==0)
    {
      if ( strcmp(nom2,"THRESH_BINARY")==0)
	{
	  cvAdaptiveThreshold( img1, img2,param1,CV_ADAPTIVE_THRESH_GAUSSIAN_C,CV_THRESH_BINARY,param2,param3);
	}
      else if (strcmp(nom2,"THRESH_BINARY_INV")==0 )
	{
	  cvAdaptiveThreshold( img1, img2,param1,CV_ADAPTIVE_THRESH_GAUSSIAN_C,CV_THRESH_BINARY_INV,param2,param3);
	}
      else
	{
	  Scierror("Error: %s fourth argument has wrong value\n",NspFname(stack));
	  goto exit;
	}
    }
  else 
    {
      Scierror("Error: %s third argument has wrong value\n");
      goto exit;
    } 
  if ( cvGetErrStatus() < 0 )
    {
      cvSetErrStatus( CV_StsOk );
      Scierror("Error:  %s , cv AdaptiveThreshold failed \n",NspFname(stack));
      goto exit;
    }
  if((nsp_img = nsp_iplimage_create(NVOID))==NULL) goto exit;
  nsp_img->img = img2;
  MoveObj(stack,1,NSP_OBJECT(nsp_img));
  return 1;
 exit: 
  if (img2) cvReleaseImage( &img2 );
  return nsp_ret;
}

#ifdef __cplusplus
}
#endif
