// This is the builder.sce 
// must be run from this directory 
// [1] generate Path.incl 
ilib_path_incl()
// [3] the part devoted to shared lib generation 
ilib_name="libsivp";
// objects files (but do not give mexfiles here)
files = [ 'adaptativethreshold.o';
	  'camshift.o';
	  'canny.o';
	  'cmp.o';
	  'common.o';
	  'convert.o';
	  'convertscale.o';
	  'cvcaptureobj.o';
	  'cvwriterobj.o';
	  'detectforeground.o';
	  'detectobjects.o';
	  'dilate.o';
	  'erode.o';
	  'goodfeaturestotrack.o';
	  'hough.o';
	  'imcrop.o';
	  'imops.o';
	  'imread.o';
	  'imresize.o';
	  'imshow.o';
	  'imsmooth.o';
	  'imtopixbuf.o';
	  'imwrite.o';
	  'iplimageobj.o';
	  'laplace.o';
	  'not.o';
	  'precornerdetec.o';
	  'pyrdown.o';
	  'pyrup.o';
	  'rectangle.o';
	  'resize.o';
	  'sivp_init.o';
	  'sobel.o';
	  'threshold.o';
	  'xor.o'];


// other libs needed for linking (must be shared library names)
libs  = [];
// table of (nsp_name,interface-name or mexfile-name, type) 

table = ['adaptativethreshold', 'int_adaptativethreshold';
	 'camshift', 'int_camshift';
	 'canny', 'int_canny';
	 'cmp', 'int_cmp';
	 'convert', 'int_convert';
	 'dilate', 'int_dilate';
	 'erode', 'int_erode';
	 'goodfeaturestotrack', 'int_goodfeaturestotrack';
	 'hough', 'int_hough'
	 'imread', 'int_imread';
	 'imresize', 'int_imresize';
	 'imsmooth', 'int_imsmooth';
	 'imwrite', 'int_imwrite';
	 'laplace', 'int_laplace';
	 'not', 'int_not';
	 'precornerdetec', 'int_precornerdetec';
	 'pyrdown', 'int_pyrdown';
	 'pyrup', 'int_pyrup';
	 'sivp_init','int_sivp_init';
	 'sobel', 'int_sobel';
	 'threshold', 'int_threshold';
	 'xor', 'int_xor';
	 'convertscale','int_convertscale';
	 'cvcapture', 'int_cvcapture_new';
	 'cvvideowriter','int_cvvideowriter_new';
	 'delete_imview', 'int_delete_imview';
	 'detectforeground','int_detectforeground';
	 'detectobjects','int_detectobjects';
	 'imadd','int_cvadd';
	 'imcrop','int_cvimcrop';
	 'imdiv','int_cvdiv';
	 'immul','int_cvmul';
	 'imshow','int_imshow';
	 'imsub','int_cvsub';
	 'imtopixbuf','int_imtopixbuf';
	 'iplimage', 'int_iplimage_new';
	 'pixbuftoim','int_pixbuftoim';
	 'rectangle','int_cvrectangle';
	 'setrowscols_cvcap','int_set_attribute'];

cflags="`pkg-config opencv --cflags`";
ldflags="`pkg-config opencv --libs`";

// do not modify below 
// ----------------------------------------------
ilib_build(ilib_name,table,files,libs,cflags=cflags,ldflags=ldflags)

