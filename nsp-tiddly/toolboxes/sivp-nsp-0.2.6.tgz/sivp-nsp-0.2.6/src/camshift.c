/*****************************************************************************
 * SIVP - Scilab Image and Video Processing toolbox
 * Copyright (C) 2008-2017  Jia Wu
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *****************************************************************************/

/* Ported to nsp: Jean-Philippe Chancelier 2017-2017
 *
 */

#include "common.h"

/*********************************************************************************************
 * this function only supports 3-channel image, and uses hue histogram to calc back projection
 * [object]=camshift(im) or [object]=camshift(im,window)
 * object is a 1x5 matrix of the object window and object orientation [x,y,w,h,theta]
 * window is a 1x4 matrix of the initial search window [x,y,w,h]
 *********************************************************************************************/

#ifdef __cplusplus
extern "C" {
#endif

  
  int int_camshift(Stack stack, int rhs, int opt, int lhs)
  {
    int ret = RET_BUG;
    static CvHistogram *histogram = NULL;
    static CvRect object_window;
    NspMatrix *nsp_rect=NULL, *Res=NULLMAT; 
    NspIplImage *nsp_img_in=NULL;
    IplImage *img_in=NULL, *img_hsv= NULL, *img_hue= NULL, *img_mask= NULL;
    IplImage *img_obj = NULL;

    CvConnectedComp comp;
    CvBox2D box;

    CheckStdRhs(1, 2);
    CheckLhs(1, 1); 

    if ((nsp_img_in= GetIplImage(stack,1))== NULL) return RET_BUG;
    
    if ( rhs -opt  == 2)
      {
	if ((nsp_rect=GetRealMat(stack,2)) == NULLMAT ) return FAIL;
	if ( nsp_rect->mn == 0 && histogram != NULL)
	  {
	    cvReleaseHist(&histogram);
	    return 0;
	  }
	CheckLength(NspFname(stack),2,nsp_rect,4);
      }
    
    img_in = nsp_img_in->img;
  
    if (img_in->nChannels != 3)
      {
	Scierror("Error: Only 3-channel image is supported in %s\n", NspFname(stack));
	goto exit;
      }
  
    if ((img_hsv = cvCreateImage(cvGetSize(img_in), img_in->depth, 3)) == NULL)
      {
	Scierror("Error: can't create output image in %s\n", NspFname(stack));
	goto exit;
      }
    if ((img_hue = cvCreateImage(cvGetSize(img_in), img_in->depth, 1)) == NULL)
      {
	Scierror("Error: can't create output image in %s\n", NspFname(stack));
	goto exit;
      }
    if ((img_mask = cvCreateImage(cvGetSize(img_in), img_in->depth, 1)) == NULL)
      {
	Scierror("Error: can't create output image in %s\n", NspFname(stack));
	goto exit;
      }
  
    //convert the input RGB image to HSV image
    cvCvtColor(img_in, img_hsv, CV_BGR2HSV);
    cvSplit( img_hsv, img_hue, 0, 0, 0);
    cvInRangeS(img_hsv, cvScalar(0, 30, 10, 0), cvScalar(180, 256, 256, 0), img_mask);

    if (( img_obj = cvCreateImage(cvSize(5, 1), IPL_DEPTH_64F, 1))==NULL)
      {
	Scierror("Error: can't create output image in %s\n", NspFname(stack));
	goto exit;
      }
  
    if ( rhs -opt  == 1)
      {
	/* object tracking */
	IplImage *img = NULL;
	if(histogram == NULL)
	  {
	    Scierror("Error: Object histogram not initialized. Please input a window to initialize the tracker.\n",
		     NspFname(stack));	  
	    goto exit;
	  }
     	if (( img = cvCreateImage(cvGetSize(img_in), img_in->depth, 1)) == NULL)
	  {
	    Scierror("Error: Cannot create backproject image.\n",NspFname(stack));
	    goto exit;
	  }
	/* calculate backproject image */
	cvCalcBackProject(&img_hue, img, histogram);
	cvAnd(img, img_mask, img, 0);
	/* camshift tracking */
	cvCamShift(img, object_window, cvTermCriteria(CV_TERMCRIT_EPS | CV_TERMCRIT_ITER, 10, 1), &comp, &box); 
	/* object window */
	object_window = comp.rect;
	cvReleaseImage(&img);
      }
    else if ( rhs -opt == 2)
      {
	CvRect rect;
	int h_bins = 20;
	int hist_size[] = {h_bins};
	float h_range[] = {0, 180};
	float *range[] = {h_range};
	rect.x = nsp_rect->R[0] -1;
	rect.y = nsp_rect->R[1] -1;
	rect.width = nsp_rect->R[2];
	rect.height = nsp_rect->R[3];
	if(rect.x<0 || rect.y<0 || rect.width<0 || rect.height<0
	   || rect.x+rect.width >img_in->width ||   rect.y+rect.height>img_in->height)
	  {
	    Scierror("Erroe: Improper values in second argument of %s\n", NspFname(stack));
	    goto exit;
	  }
	/* search window*/
	object_window = rect;
	box.angle = 0;
	/*create histogram */
	if(histogram == NULL)
	  {
	    histogram = cvCreateHist(1, hist_size, CV_HIST_ARRAY, range, 1);
	  }
	cvSetImageROI(img_hue, rect);
	cvSetImageROI(img_mask, rect);
	/* calculate the hue histogram */
	cvCalcHist(&img_hue, histogram, 0, img_mask);
	cvResetImageROI(img_hue);   
	cvResetImageROI(img_mask); 
      }
    if (( Res = nsp_matrix_create(NVOID,'r',1,5)) == NULLMAT) goto exit;
    Res->R[0] = object_window.x+1;
    Res->R[1]   = object_window.y+1;
    Res->R[2]   = object_window.width;
    Res->R[3]   = object_window.height;
    Res->R[4]   = box.angle;
    MoveObj(stack,1,NSP_OBJECT(Res));
    ret = 1;
  exit:
    if ( img_hsv != NULL) cvReleaseImage(&img_hsv);
    if ( img_hue != NULL) cvReleaseImage(&img_hue);
    if ( img_mask != NULL) cvReleaseImage(&img_mask);
    if ( img_obj != NULL) cvReleaseImage(&img_obj);
    return ret;
  }
  
#ifdef __cplusplus
}
#endif


