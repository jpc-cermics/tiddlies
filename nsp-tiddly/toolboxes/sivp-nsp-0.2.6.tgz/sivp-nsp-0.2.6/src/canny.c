/***********************************************************************
 * SIVP - Scilab Image and Video Processing toolbox
 * Copyright (C) 2005  Shiqi Yu
 * Copyright (C) 2005  Vincent Etienne
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ***********************************************************************/

/* Ported to nsp: Jean-Philippe Chancelier 2005-2006.
 *
 */

#include "common.h"

#ifdef __cplusplus
extern "C" {
#endif

int int_canny(Stack stack, int rhs, int opt, int lhs)
{
  double param1,param2;
  int param3, nsp_ret = RET_BUG;
  NspIplImage *nsp_img_in=NULL, *nsp_img_out=NULL;
  IplImage *img_out=NULL,*img_in=NULL,*img_work = NULL;

  CheckRhs(4,4);
  CheckLhs(1,1);
  
  if ((nsp_img_in= GetIplImage(stack,1))== NULL) return RET_BUG;
  if ( GetScalarDouble(stack,2,&param1) == FAIL) goto exit;
  if ( GetScalarDouble(stack,3,&param2) == FAIL) goto exit;
  if ( GetScalarInt(stack,4,&param3) == FAIL) goto exit;

  img_work = img_in = nsp_img_in->img;
  
  /* output image IPL_DEPTH_8U, 1 */
  if ((img_out = cvCreateImage(cvGetSize(img_in),  IPL_DEPTH_8U, 1)) == NULL)
    {
      Scierror("Error: %s can't create the output image in %s\n",NspFname(stack));
      goto exit;
    }
  
  /* convert the input to UING8 Gray image */
  if(img_in->depth != IPL_DEPTH_8U)
    {
      IplImage *imgTmp = NULL;
      if ((imgTmp = cvCreateImage(cvGetSize(img_work), IPL_DEPTH_8U, img_work->nChannels))==NULL)
	{
	  Scierror("Error: can't create the output image in %s\n", NspFname(stack));
	  goto exit;
	}
      cvConvert(img_work, imgTmp);
      if ( cvGetErrStatus() < 0 )
	{
	  cvSetErrStatus( CV_StsOk );
	  Scierror("Error:  cvConvert failed in %s\n",NspFname(stack));
	  goto exit;
	}
      /* new work image */
      img_work = imgTmp;
    }

  /* convert the image to 1 channel image */
  if(img_work->nChannels != 1)
    {
      IplImage *imgTmp = NULL;
      if((imgTmp = cvCreateImage(cvGetSize(img_work), IPL_DEPTH_8U, 1))==NULL)
	{
	  Scierror("Error: can't create the output image in %s\n", NspFname(stack));
	  goto exit;
	}
      cvCvtColor(img_work, imgTmp, CV_BGR2GRAY);
      if ( cvGetErrStatus() < 0 )
	{
	  cvSetErrStatus( CV_StsOk );
	  Scierror("Error: cvCvtColor failed int %s\n",NspFname(stack));
	  goto exit;
	}
      if ( img_work != img_in )  cvReleaseImage(&img_work);
      /* new work image */
      img_work = imgTmp;
    }
  
  cvCanny( img_work , img_out ,param1,param2,param3);
  if ( cvGetErrStatus() < 0 )
    {
      cvSetErrStatus( CV_StsOk );
      Scierror("Error:  %s , cvCanny failed \n",NspFname(stack));
      goto exit;
    }
  if((nsp_img_out = nsp_iplimage_create(NVOID))==NULL) goto exit;
  nsp_img_out->img = img_out;
  MoveObj(stack,1,NSP_OBJECT(nsp_img_out));
  if ( img_work != img_in)  cvReleaseImage(&img_work);
  return 1;
 exit: 
  if ( img_out != NULL ) cvReleaseImage( &img_out );
  if ( img_work != NULL && img_work != img_in)  cvReleaseImage(&img_work);
  return nsp_ret;
}


#ifdef __cplusplus
}
#endif
