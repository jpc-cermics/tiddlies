/***********************************************************************
 * SIVP - Scilab Image and Video Processing toolbox
 * Copyright (C) 2005  Vincent Etienne
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ***********************************************************************/

/* Ported to nsp: Jean-Philippe Chancelier 2005-2006.
 *
 */

#include "common.h"

#ifdef __cplusplus
extern "C" {
#endif

int int_cmp(Stack stack, int rhs, int opt, int lhs)
{
  const char *Table[] = {"CMP_EQ","CMP_GT","CMP_GE","CMP_LT","CMP_LE","CMP_NE",NULL};
  const int op[] = {CV_CMP_EQ,CV_CMP_GT,CV_CMP_GE,CV_CMP_LT,CV_CMP_LE,CV_CMP_NE};
  char *nom;
  NspIplImage* nsp_img2 = NULL, *nsp_img1=NULL,* nsp_img;
  IplImage* img2 = NULL, *img1=NULL,* img3 = NULL;
  int ret,nsp_ret = RET_BUG;

  CheckRhs(3,3);
  CheckLhs(1,1);

  if ((nsp_img1= GetIplImage(stack,1))== NULL) goto exit;
  if ((nsp_img2= GetIplImage(stack,2))== NULL) goto exit;
  if ((nom = GetString(stack,3)) == (char*)0) goto exit;

  ret = is_string_in_array(nom,Table,1);
  if ( ret < 0 ) 
    {
      string_not_in_array(stack,nom,Table,"second argument");
      goto exit;
    }

  img1 = nsp_img1->img;
  img2 = nsp_img2->img;

  if(img1->nChannels != img2->nChannels  || img1->depth != img2->depth 
     || img1->width != img2->width   || img1->height != img2->height) 
    {
      Scierror("Error:wrong depth or wrong size of picture\n");
      goto exit;
    }
  if ((img3=cvCreateImage(cvGetSize(img1),img1->depth,img1->nChannels))==NULL)
    {
      Scierror("Error: can't create the output matrix\n");
      goto exit;
    }
  cvCmp(img1,img2,img3,op[ret]);
  if ( cvGetErrStatus() < 0 )
    {
      cvSetErrStatus( CV_StsOk );
      Scierror("Error:  %s , cvCmp failed \n",NspFname(stack));
      goto exit;
    }

  if((nsp_img = nsp_iplimage_create(NVOID))==NULL) goto exit;
  nsp_img->img = img3;
  MoveObj(stack,1,NSP_OBJECT(nsp_img));
  return 1;  
 exit: 
  if (img3) cvReleaseImage( &img3 );
  return nsp_ret;
}

#ifdef __cplusplus
}
#endif


