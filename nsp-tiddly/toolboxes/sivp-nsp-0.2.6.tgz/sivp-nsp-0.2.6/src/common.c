/***********************************************************************
 * SIVP - Scilab Image and Video Processing toolbox
 * Copyright (C) 2005  Jean-Philippe Chancelier
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * convertion between cells and IplImage 
 *
 ***********************************************************************/

#include "common.h"

#ifdef __cplusplus
extern "C" {
#endif

static void fill_nsp_cells_from_iplimage(IplImage * pImage,NspCells *C);

NspCells *sivp_iplimage_to_nsp_cells(IplImage * pImage)
{
  int i;
  NspCells *loc; 
  NspMatrix *mat;
  if (pImage == NULL ) return nsp_cells_create(NVOID,0,0);
  if ( (loc =nsp_cells_create(NVOID,1,pImage->nChannels)) == NULLCELLS) return NULLCELLS;
  for ( i = 0 ; i < pImage->nChannels ; i++ ) 
    {
      if ((mat = nsp_matrix_create("ce",'r',pImage->height,pImage->width))== NULLMAT) return  NULLCELLS;
      loc->objs[i]= NSP_OBJECT(mat);
    }
  fill_nsp_cells_from_iplimage(pImage,loc);
  return loc;
}

static void fill_nsp_cells_from_iplimage(IplImage * pImage,NspCells *C)
{
  int row, col, ch=0, nBytes;
  char * pSrc;
  if (pImage == NULL ) return ;
  pSrc = (char*) pImage->imageData;

  /*how many bytes per pixel per channel*/
  nBytes = pImage->depth;
  if (nBytes > IPL_DEPTH_SIGN)
    nBytes -= IPL_DEPTH_SIGN;
  nBytes = nBytes >> 3;
  
  for(ch = 0; ch < pImage->nChannels ; ch++) //the order of IplImage is BGR  
    for(col =0; col < pImage->width; col++)
      for(row = 0; row < pImage->height; row++)
	{
	  void *psrc = pSrc + pImage->widthStep*row + (col*pImage->nChannels + (pImage->nChannels-ch-1))*nBytes;
	  switch (pImage->depth) 
	    {
	    case IPL_DEPTH_8U: ((NspMatrix *) C->objs[ch])->R[row+pImage->height*col]= *((unsigned char *) psrc);break;
	    case IPL_DEPTH_8S: ((NspMatrix *) C->objs[ch])->R[row+pImage->height*col]= *((char *) psrc);break;
	    case IPL_DEPTH_16U:((NspMatrix *) C->objs[ch])->R[row+pImage->height*col]= *((unsigned short *) psrc);break;
	    case IPL_DEPTH_16S:((NspMatrix *) C->objs[ch])->R[row+pImage->height*col]= *((short *) psrc);break;
	    case IPL_DEPTH_32S:((NspMatrix *) C->objs[ch])->R[row+pImage->height*col]= *((int *) psrc);break;
	    case IPL_DEPTH_32F:((NspMatrix *) C->objs[ch])->R[row+pImage->height*col]= *((float *) psrc);break;
	    case IPL_DEPTH_64F:((NspMatrix *) C->objs[ch])->R[row+pImage->height*col]= *((double *) psrc);break;
	    default: ((NspMatrix *) C->objs[ch])->R[row+pImage->height*col]= 0.0;
	    }
	}
}


static void fill_nsp_matrix_from_iplimage_channel(IplImage * pImage,NspMatrix *M,int channel);

NspMatrix *sivp_iplimage_get_channel(IplImage * pImage,int channel)
{
  NspMatrix *mat;
  if (pImage == NULL ) return nsp_matrix_create(NVOID,'r',0,0);
  if ((mat = nsp_matrix_create(NVOID,'r',pImage->height,pImage->width))== NULLMAT) 
    return  NULLMAT;
  fill_nsp_matrix_from_iplimage_channel(pImage,mat,channel);
  return mat;
}

static void fill_nsp_matrix_from_iplimage_channel(IplImage * pImage,NspMatrix *M,int channel)
{
  int row, col, ch=0, nBytes;
  char * pSrc;
  if (pImage == NULL ) return ;
  pSrc = (char*) pImage->imageData;
  
  /*how many bytes per pixel per channel*/
  nBytes = pImage->depth;
  if (nBytes > IPL_DEPTH_SIGN)
    nBytes -= IPL_DEPTH_SIGN;
  nBytes = nBytes >> 3;

  ch = Max(Min(channel, pImage->nChannels-1),0);
  for(col =0; col < pImage->width; col++)
    for(row = 0; row < pImage->height; row++)
      {
	void *psrc = pSrc + pImage->widthStep*row + (col*pImage->nChannels + (pImage->nChannels-ch-1))*nBytes;
	switch (pImage->depth) 
	  {
	  case IPL_DEPTH_8U: M->R[row+pImage->height*col]= *((unsigned char *) psrc);break;
	  case IPL_DEPTH_8S: M->R[row+pImage->height*col]= *((char *) psrc);break;
	  case IPL_DEPTH_16U:M->R[row+pImage->height*col]= *((unsigned short *) psrc);break;
	  case IPL_DEPTH_16S:M->R[row+pImage->height*col]= *((short *) psrc);break;
	  case IPL_DEPTH_32S:M->R[row+pImage->height*col]= *((int *) psrc);break;
	  case IPL_DEPTH_32F:M->R[row+pImage->height*col]= *((float *) psrc);break;
	  case IPL_DEPTH_64F:M->R[row+pImage->height*col]= *((double *) psrc);break;
	  default: M->R[row+pImage->height*col]= 0.0;
	  }
      }
}




/* the given cell must be composed of real matrices 
 * of the same size this is not checked here.
 *
 */

IplImage *sivp_cells_to_iplimage(NspCells *C)
{
#if DEPTH64F
  int col,row,ch,nBytes, iplType = IPL_DEPTH_64F;
#else 
  int col,row,ch,nBytes, iplType = IPL_DEPTH_16U;
#endif 
  IplImage *loc;
  char * pSrc;
  int nRow = ((NspMatrix *) C->objs[0])->m; 
  int nCol = ((NspMatrix *) C->objs[0])->n;
  /* create an IplImage for storing data*/
  if ((loc = cvCreateImage(cvSize(nCol, nRow), iplType, C->mn))== NULL)
    {
      Scierror("Error: IplImage creation failed\n");
      return NULL;
    }
  /*how many bytes per pixel per channel*/
  nBytes = loc->depth;
  if (nBytes > IPL_DEPTH_SIGN)
    nBytes -= IPL_DEPTH_SIGN;
  nBytes = nBytes >> 3;

  pSrc = (char*) loc->imageData;
  for(ch = 0; ch < loc->nChannels ; ch++) //the order of IplImage is BGR  
    for(col =0; col < loc->width; col++)
      for(row = 0; row < loc->height; row++)
	{
#if DEPTH64F
	  double  * psrc = (double *)
	    (pSrc + loc->widthStep*row + (col*loc->nChannels + (loc->nChannels-ch-1))*nBytes);
#else 
	  unsigned short * psrc = (unsigned short *) 
	    (pSrc + loc->widthStep*row + (col*loc->nChannels + (loc->nChannels-ch-1))*nBytes);
#endif
	  *psrc = ((NspMatrix *) C->objs[ch])->R[row+loc->height*col];
	}
  return loc;
}


IplImage *get_ipl_from_cells(Stack stack,int pos) 
{
  int i,nRow=0,nCol=0;
  NspCells *C; 
  if ((C = GetCells(stack,pos)) == NULL) return NULL;
  /* first checks that all the matrices in the cell are of same dimension */
  for ( i = 0 ; i < C->mn ; i++) 
    {
      if ( check_cast(C->objs[i],nsp_type_matrix_id) == FALSE) 
	{
	  Scierror("Error: element %d of cell array is not a Matrix\n",i+1);
	  return NULL;
	}
      if ( i==0) 
	{  nRow = ((NspMatrix *) C->objs[i])->m; nCol = ((NspMatrix *) C->objs[i])->n;}
      else 
	{
	  if (( nRow != ((NspMatrix *) C->objs[i])->m) || nCol != ((NspMatrix *) C->objs[i])->n) 
	    {
	      Scierror("Error: cell array elements should be of the same size\n",i+1);
	      return NULL;
	    }
	}
      if ( ((NspMatrix *) C->objs[i])->rc_type != 'r') 
	{
	  Scierror("Error: cell array elements should be a real matrix\n",i+1);
	  return NULL;
	}
    }
  return sivp_cells_to_iplimage(C);
}
  




#ifdef __cplusplus
}
#endif
