/***********************************************************************
 * SIVP - Scilab Image and Video Processing toolbox
 * Copyright (C) 2005  Shiqi Yu
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ***********************************************************************/

#ifndef SIVP_COMMON_H
#define SIVP_COMMON_H
  
#define CV_INLINE static inline 
typedef int BOOL;

#include <stdio.h>
#include <cv.h> 
#include <highgui.h>
/* #include <cvaux.h> */
//#include <opencv2/legacy/legacy.hpp>

#ifdef __cplusplus
extern "C" {
#endif

#include <nsp/package_undef.h>
#include <nsp/nsp.h> 
#include <nsp/interf.h>
#include <nsp/objects.h>
#include <nsp/cells.h>
#include <nsp/ivect.h>
#include "iplimage.h"

  extern IplImage * get_ipl_from_cells(Stack stack,int pos) ;
  extern NspCells *sivp_iplimage_to_nsp_cells(IplImage * pImage);
  extern NspMatrix *sivp_iplimage_get_channel(IplImage * pImage,int channel);
#define FSIZE 1024
  extern char  sSIVP_PATH[FSIZE+1];

#ifdef __cplusplus
}
#endif

#endif
