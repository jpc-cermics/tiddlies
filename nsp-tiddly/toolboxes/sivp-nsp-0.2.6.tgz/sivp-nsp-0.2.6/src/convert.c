/***********************************************************************
 * SIVP - Scilab Image and Video Processing toolbox
 * Copyright (C) 2005  Vincent Etienne
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ***********************************************************************/

/* Ported to nsp: Jean-Philippe Chancelier 2005-2006.
 *
 */

#include "common.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef struct _convert_img convert_img ;

struct _convert_img {
  const char *name;
  int nChannels,nChannels_dest, code;
};

convert_img tags[]= {
  {"GRAY2BGR",  1 , 3,    CV_GRAY2BGR},
  {"GRAY2RGB",  1 , 3,    CV_GRAY2RGB},
  {"RGB2GRAY",      3, 1,	  CV_RGB2GRAY},
  {"BGR2GRAY",      3 , 1,	  CV_BGR2GRAY},
  {"XYZ2BGR",      3 , 3,    CV_XYZ2BGR},
  {"BGR2XYZ",    3 , 3,    CV_BGR2XYZ},
  {"XYZ2RGB",    3 , 3,    CV_XYZ2RGB},
  {"RGB2XYZ",    3 , 3,    CV_RGB2XYZ},
  {"YCrCb2RGB",    3 , 3,    CV_YCrCb2RGB},
  {"YCrCb2BGR",    3 , 3,    CV_YCrCb2BGR},
  {"RGB2YCrCb",    3 , 3,    CV_RGB2YCrCb},
  {"BGR2YCrCb",    3 , 3,    CV_BGR2YCrCb},
  {"BGR2HSV",    3 , 3,    CV_BGR2HSV},
  {"RGB2HSV",    3 , 3,    CV_RGB2HSV},
  {"BGR2Lab",    3 , 3,    CV_BGR2Lab},
  {"RGB2Lab",    3 , 3,    CV_RGB2Lab},
  {"BayerBG2BGR",    1 , 3,    CV_BayerBG2BGR},
  {"BayerGB2BGR",    1 , 3,    CV_BayerGB2BGR},
  {"BayerRG2BGR",    1 , 3,    CV_BayerRG2BGR},
  {"BayerGR2BGR",    1 , 3,    CV_BayerGR2BGR},
  {"BayerBG2RGB",    1 , 3,    CV_BayerBG2RGB},
  {"BayerRG2BGR",    1 , 3,    CV_BayerRG2BGR},
  {"BayerGB2RGB",    1 , 3,    CV_BayerGB2RGB},
  {"BayerGR2RGB",    1 , 3,    CV_BayerGR2RGB},
  {"BayerRG2RGB",    1 , 3,    CV_BayerRG2RGB},
  {"BayerBG2BGR",    1 , 3,    CV_BayerBG2BGR},
  {"BayerGR2RGB",    1 , 3,    CV_BayerGR2RGB},
  {"BayerGB2BGR",    1 , 3,    CV_BayerGB2BGR},
  {NULL, 0 , 0, 0}
};

int int_convert(Stack stack, int rhs, int opt, int lhs)
{
  IplImage* img2 = NULL, *img1=NULL;
  NspIplImage *nsp_img = NULL;
  char * nom = NULL;
  int rep,nsp_ret = RET_BUG;
  //check the number of in/out parametres

  CheckRhs(2,2);
  CheckLhs(1,1);

  if ((nsp_img= GetIplImage(stack,1))== NULL) goto exit;
  if ((nom = GetString(stack,2)) == (char*)0) goto exit;

  img1 = nsp_img->img;

  /* The source 8-bit (8u), 16-bit (16u) 
   * or single-precision floating-point (32f) image.
   */
  switch ( img1->depth)
    {
    case IPL_DEPTH_8U: 
    case IPL_DEPTH_16U:
    case IPL_DEPTH_32F: break; 
    default: 
      Scierror("Error: image must be (8u) (16u) or (32f) \n");
      goto exit;
    }

  rep = is_string_in_struct(nom,(const void **)tags,sizeof(convert_img),0);
  if ( rep <0 ) 
    {
      Scierror("Error: format for conversion %s is wrong\n",nom);
      goto exit;
    }
 
  if (0 && img1->nChannels != tags[rep].nChannels) 
    {
      Scierror("Error: Wrong number of channels for input image %d expected\n", 
	       tags[rep].nChannels);
      goto exit;
    }
  img2=cvCreateImage(cvGetSize(img1),img1->depth,tags[rep].nChannels_dest);
  if(img2==NULL)
    {
      Scierror("Error: can't create the output matrix\n");
      goto exit;
    }
  cvCvtColor(img1, img2, tags[rep].code);

  if ( cvGetErrStatus() < 0 )
    {
      cvSetErrStatus( CV_StsOk );
      Scierror("Error:  %s , cvCvtColor failed \n",NspFname(stack));
      goto exit;
    }

  if((nsp_img = nsp_iplimage_create(NVOID))==NULL) goto exit;
  nsp_img->img = img2;
  MoveObj(stack,1,NSP_OBJECT(nsp_img));
  return 1;
 exit:
  if ( img2) cvReleaseImage( &img2 );
  return nsp_ret;
}


#ifdef __cplusplus
}
#endif



