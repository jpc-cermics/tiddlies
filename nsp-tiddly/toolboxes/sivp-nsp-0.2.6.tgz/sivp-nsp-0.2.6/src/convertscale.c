/***********************************************************************
 * SIVP - Scilab Image and Video Processing toolbox
 * Copyright (C) 2005  Jean-Philippe Chancelier 
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ***********************************************************************/

#include "common.h"

#ifdef __cplusplus
extern "C" {
#endif


/* FIXME: rajouter dScale et dShift en parametre optionnels.
 *
 */

int int_convertscale(Stack stack, int rhs, int opt, int lhs)
{
  const char *Table[] = {"8U", "8S",  "16U",  "16S", "32S",  "32F", "64F",  NULL};
  const int depth[]= { IPL_DEPTH_8U,IPL_DEPTH_8S, IPL_DEPTH_16U, IPL_DEPTH_16S,
		       IPL_DEPTH_32S, IPL_DEPTH_32F,IPL_DEPTH_64F};
  int ret;
  IplImage *img1=NULL, *img2=NULL;
  NspIplImage *nsp_img1=NULL,*nsp_img=NULL;
  double dScale = 1.0;
  double dShift = 0.0;
  char *nom;
  nsp_option opts[] ={{"scale",s_double,NULLOBJ,-1},
		      {"shift",s_double,NULLOBJ,-1},
		      { NULL,t_end,NULLOBJ,-1}};

  CheckStdRhs(2, 2);
  CheckLhs(1, 1);

  if ((nsp_img1= GetIplImage(stack,1))== NULL) return RET_BUG;
  img1 = nsp_img1->img;
  if ((nom = GetString(stack,2)) == (char*)0) goto exit;
  ret = is_string_in_array(nom,Table,1);
  if ( ret < 0 ) 
    {
      string_not_in_array(stack,nom,Table,"second argument");
      goto exit;
    }

  if ( get_optional_args(stack, rhs, opt, opts, &dScale, &dShift) == FAIL )
    return RET_BUG;

  if ((img2 = cvCreateImage(cvSize(img1->width, img1->height),depth[ret] , img1->nChannels))== NULL)
    {
      Scierror("%f: Create IplImage error\n",NspFname(stack));
      goto exit;
    }
  cvConvertScale(img1, img2, dScale, dShift);
  if ( cvGetErrStatus() < 0 )
    {
      cvSetErrStatus( CV_StsOk );
      Scierror("Error:  %s , cvConvertScale failed \n",NspFname(stack));
      goto exit;
    }

  if((nsp_img = nsp_iplimage_create(NVOID))==NULL) goto exit;
  nsp_img->img = img2;
  MoveObj(stack,1,NSP_OBJECT(nsp_img));
  return 1;
 exit:
  if ( img2) cvReleaseImage( &img2 );
  return RET_BUG;
}


#ifdef __cplusplus
}
#endif
