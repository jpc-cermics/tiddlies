#ifndef NSP_INC_CVCAPTURE
#define NSP_INC_CVCAPTURE

/*
 * This Software is GPL (Copyright ENPC 1998-2005) 
 * Jean-Philippe Chancelier Enpc/Cermics         
 */

#include "nsp/sciio.h" 
#include "nsp/object.h"
#include "nsp/xdr.h"
#include <cv.h>
#include <cxcore.h>

/*
 * NspCvCapture inherits from NspObject 
 */

typedef struct _NspCvCapture NspCvCapture;

typedef struct _NspTypeCvCapture { 
  NSP_TYPE_OBJECT__ 
  /*< public >*/
} NspTypeCvCapture;

struct _NspCvCapture {
  /*< private >*/
  NspObject father; 
  NspTypeCvCapture *type; 
  /*< public >*/
  CvCapture *capture;
};

extern int nsp_type_cvcapture_id;
extern NspTypeCvCapture *nsp_type_cvcapture;

NspTypeCvCapture *new_type_cvcapture(type_mode mode);

NspCvCapture *nsp_new_cvcapture();

/*
 * Object methods redefined for file 
 */

extern NspCvCapture *nsp_cvcapture_create(const char *name);
extern NspCvCapture *nsp_cvcapture_copy(NspCvCapture *H);
extern void nsp_cvcapture_destroy(NspCvCapture *H);
extern int nsp_cvcapture_info(NspCvCapture *H, int indent,char *name, int rec_level);
extern int nsp_cvcapture_print(NspCvCapture *H, int indent,char *name, int rec_level);

#define NULLCVCAPTURE (NspCvCapture *) 0

/* CvCaptureObj.c */

extern NspCvCapture *nsp_cvcapture_object(NspObject *O);
extern int IsCvCaptureObj (Stack stack, int i);
extern NspCvCapture *GetCvCaptureCopy (Stack stack, int i);
extern NspCvCapture *GetCvCapture (Stack stack, int i);

#endif 

#ifdef CvCapture_Private 
static int nsp_init_cvcapture(NspCvCapture *ob,NspTypeCvCapture *type);
static int nsp_cvcapture_size(NspCvCapture *Mat, int flag);
static char *nsp_cvcapture_type_as_string(void);
static char *nsp_cvcapture_type_short_string(NspObject *v);
static int nsp_cvcapture_eq(NspObject *A, NspObject *B);
static int nsp_cvcapture_neq(NspObject *A, NspObject *B);
static NspMethods *nsp_cvcapture_get_methods(void);
static AttrTab nsp_cvcapture_attrs[];
#endif 
