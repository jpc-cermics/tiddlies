/* Nsp
 * Copyright (C) 2005-2017 Jean-Philippe Chancelier Enpc/Cermics
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public
 * License along with this library; if not, write to the
 * Free Software Foundation, Inc., 59 Temple Place - Suite 330,
 * Boston, MA 02111-1307, USA.
 *
 * Interface with the opencv library. 
 *
 */

#include "common.h"

#ifdef __cplusplus
extern "C" {
#endif

#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <gdk/gdk.h>

#define CvCapture_Private 
#include "nsp/object.h"
#include "nsp/pr-output.h" 
#include "nsp/interf.h"
#include "nsp/matutil.h"
#include "cvcapture.h" 

/*
 * NspCvCapture inherits from NspObject 
 */

int nsp_type_cvcapture_id=0;
NspTypeCvCapture *nsp_type_cvcapture=NULL;

NspTypeCvCapture *new_type_cvcapture(type_mode mode)
{
  NspTypeCvCapture *type = NULL;
  NspTypeObject *top;
  if ( nsp_type_cvcapture != 0 && mode == T_BASE )
    {
      /* initialization performed and T_BASE requested */
      return nsp_type_cvcapture;
    }
  if (( type = (NspTypeCvCapture *) malloc(sizeof(NspTypeCvCapture)))== NULL) return NULL;
  type->interface = NULL;
  type->surtype =(NspTypeBase *) new_type_object(T_DERIVED);
  if ( type->surtype == NULL) return NULL;
  type->attrs = nsp_cvcapture_attrs ;
  type->get_attrs = (attrs_func *) int_get_attribute; 
  type->set_attrs = (attrs_func *) int_set_attribute; 
  type->methods =nsp_cvcapture_get_methods; 
  type->new = (new_func *)nsp_new_cvcapture;

  top = NSP_TYPE_OBJECT(type->surtype);
  while ( top->surtype != NULL ) top= NSP_TYPE_OBJECT(top->surtype);

  /* object methods redefined for cvcapture */ 

  top->pr = (print_func *)nsp_cvcapture_print;	              /* printing */   
  top->dealloc = (dealloc_func *)nsp_cvcapture_destroy;           /* dealloc */  
  top->copy  =  (copy_func *)nsp_cvcapture_copy;                  /* copy object */  
  top->size  = (size_func *)nsp_cvcapture_size;                   /* m,n or m*n  */  
  top->s_type =  (s_type_func *)nsp_cvcapture_type_as_string;               /* type as a String */  
  top->sh_type = (sh_type_func *)nsp_cvcapture_type_short_string;           /* type as a short string */  
  top->info = (info_func *)nsp_cvcapture_info;                    /* info */  
  /* top->is_true = (is_true_func  *) cvcapture_IsTrue;  */         /* check if object can be considered as true */  
  /*top->loop =(loop_func *) cvcapture_LoopExtract;     */	/* for loops */  
  top->path_extract =  NULL;					/* used for x(1)(2)(...) */  
  top->get_from_obj = (get_from_obj_func *)nsp_cvcapture_object;    	/* get object stored in SciObj */  
  top->eq  = (eq_func *)nsp_cvcapture_eq;			/* equality check */  
  top->neq  = (eq_func *)nsp_cvcapture_neq;		        /* non-equality check */

  /* specific methods for cvcapture */
  type->init = (init_func *)nsp_init_cvcapture;

  /* 
   * interfaces can be added here 
   * type->interface = (NspTypeBase *) new_type_b();
   * type->interface->interface = (NspTypeBase *) new_type_C()
   * ....
   */
  
  if ( nsp_type_cvcapture_id == 0 ) 
    {
      /* 
       * the first time we get here we initialize the type id and
       * an instance of NspTypeMatrix called nsp_type_cvcapture
       */
      type->id =  nsp_type_cvcapture_id = nsp_new_type_id();
      nsp_type_cvcapture = type;
      if ( nsp_register_type(nsp_type_cvcapture) == FALSE) return NULL;
      return ( mode == T_BASE ) ? type : new_type_cvcapture(mode);
    }
  else 
    {
      type->id = nsp_type_cvcapture_id;
      return type;
    }
}
/*
 * initialize Scifile instances 
 * locally and by calling initializer on parent class 
 */

static int nsp_init_cvcapture(NspCvCapture *o,NspTypeCvCapture *type)
{
  /* to be done always */ 
  if ( type->surtype->init(&o->father,type->surtype) == FAIL) return FAIL;
  o->type = type; 
  NSP_OBJECT(o)->basetype = (NspTypeBase *)type;
  /* specific */
  return OK;
}

/*
 * new instance of CvCapture 
 */

NspCvCapture *nsp_new_cvcapture() 
{
  NspCvCapture *loc; 
  /* type must exists */
  nsp_type_cvcapture = new_type_cvcapture(T_BASE);
  if ( (loc = (NspCvCapture *) malloc(sizeof(NspCvCapture)))== NULLCVCAPTURE) return loc;
  /* initialize object */
  if (nsp_init_cvcapture(loc,nsp_type_cvcapture) == FAIL) return NULLCVCAPTURE;
  return loc;
}

/*----------------------------------------------
 * Object method redefined for cvcapture 
 *-----------------------------------------------*/

/*
 * size 
 */

static int nsp_cvcapture_size(NspCvCapture  *H, int flag)
{
  return 0;
}

/*
 * type as string 
 */

static char nsp_cvcapture_type_name[]="CvCapture";
static char nsp_cvcapture_short_type_name[]="cvcap";

static char *nsp_cvcapture_type_as_string(void)
{
  return(nsp_cvcapture_type_name);
}

static char *nsp_cvcapture_type_short_string(NspObject *v)
{
  return(nsp_cvcapture_short_type_name);
}


static int nsp_cvcapture_full_comp(NspCvCapture * A,NspCvCapture * B,const char *op,int *err)
{
  Scierror("CvCaptureFullComp: to be implemented \n");
  return FALSE;
}

static int nsp_cvcapture_eq(NspObject *A, NspObject *B)
{
  int err,rep;
  if ( check_cast(B,nsp_type_ivect_id) == FALSE) return FALSE ;
  rep =nsp_cvcapture_full_comp((NspCvCapture *) A,(NspCvCapture *) B,"==",&err);
  if ( err == 1) return FALSE ; 
  return rep;
}

static int nsp_cvcapture_neq(NspObject *A, NspObject *B)
{
  int err=0,rep;
  if ( check_cast(B,nsp_type_ivect_id) == FALSE) return TRUE;
  rep =nsp_cvcapture_full_comp((NspCvCapture *) A,(NspCvCapture *) B,"<>",&err);
  if ( err == 1) return TRUE ; 
  return rep;
}

/*
 * delete 
 */

void nsp_cvcapture_destroy(NspCvCapture  *F)
{
  cvReleaseCapture(&F->capture);
  FREE(F) ;
}

/*
 * info 
 */

int nsp_cvcapture_info(NspCvCapture  *F, int indent,char *name,int rec_level)
{
  int i;
  if (F == NULLCVCAPTURE) 
    {
      Sciprintf("Null Pointer CvCapture \n");
      return TRUE;
    }
  for ( i=0 ; i < indent ; i++) Sciprintf(" ");
  if ( strcmp(NSP_OBJECT(F)->name,NVOID) == 0) 
    Sciprintf("CvCapture fname=0x%x\n",F->capture);
  else
    Sciprintf("%s =\tCvCapture fname=0x%x\n",NSP_OBJECT(F)->name,F->capture);
  return TRUE;
}

/*
 * print 
 */

int nsp_cvcapture_print(NspCvCapture  *F, int indent,char *name, int rec_level)
{
  nsp_cvcapture_info(F,indent,NULL,0);
  return TRUE;
}

/*-----------------------------------------------------
 * a set of functions used when writing interfaces 
 * for Hash objects 
 * Note that some of these functions could become MACROS XXXXX 
 *-----------------------------------------------------*/

NspCvCapture  *nsp_cvcapture_object(NspObject *O)
{
  /* Follow pointer **/
  HOBJ_GET_OBJECT(O,NULL);
  /* Check type **/
  if ( check_cast(O,nsp_type_cvcapture_id) == TRUE) return ((NspCvCapture *) O);
  else 
    Scierror("Error:\tArgument should be a %s\n",type_get_name(nsp_type_cvcapture));
  return(NULL);
}


int IsCvCaptureObj(Stack stack, int i)
{
  return nsp_object_type(NthObj(i) , nsp_type_cvcapture_id);
}

int IsCvCapture(NspObject *obj)
{
  return nsp_object_type(obj, nsp_type_cvcapture_id);
}

NspCvCapture *GetCvCaptureCopy(Stack stack, int i)
{
  if (  GetCvCapture(stack,i) == NULL ) return NULL;
  return (NspCvCapture *) MaybeObjCopy(&NthObj(i));
}

NspCvCapture *GetCvCapture(Stack stack, int i)
{
  NspCvCapture *M;
  if (( M =nsp_cvcapture_object(NthObj(i))) == NULLCVCAPTURE  )
    ArgMessage(stack,i);
  return M;
}

/*-----------------------------------------------------
 * constructor 
 *-----------------------------------------------------*/

NspCvCapture *nsp_cvcapture_create(const char *name)
{
  NspCvCapture *F =nsp_new_cvcapture() ;
  if ( F == NULLCVCAPTURE) 
    {
      Scierror("Error:\tRunning out of memory\n");
      return NULLCVCAPTURE;
    }
  /* shared by all objects */
  if ( nsp_object_set_initial_name(NSP_OBJECT(F),name) == NULL)
    return(NULLCVCAPTURE);
  NSP_OBJECT(F)->ret_pos = -1 ; 
  F->capture = NULL;
  return(F);
}

/*
 * copy: cloning image 
 */

NspCvCapture *nsp_cvcapture_copy(NspCvCapture  *A)
{
  Scierror("Error: Cannot copy a CvCapture object\n");
  return NULLCVCAPTURE;
}

/*------------------------------------------------------
 * attributes  (set/get methods) 
 *------------------------------------------------------*/

/* 
   double cvGetCaptureProperty( CvCapture* capture, int property_id );
   -------------------------------------------------------
   capture
   video capturing structure. 
   property_id
   property identifier. Can be one of the following:
   CV_CAP_PROP_POS_MSEC - film current position in milliseconds or video capture timestamp
   CV_CAP_PROP_POS_FRAMES - 0-based index of the frame to be decoded/captured next
   CV_CAP_PROP_POS_AVI_RATIO - relative position of video file (0 - start of the film, 1 - end of the film)
   CV_CAP_PROP_FRAME_WIDTH - width of frames in the video stream
   CV_CAP_PROP_FRAME_HEIGHT - height of frames in the video stream
   CV_CAP_PROP_FPS - frame rate
   CV_CAP_PROP_FOURCC - 4-character code of codec. 
   CV_CAP_PROP_FRAME_COUNT - number of frames in video file. 
*/


static NspObject * int_cvcapture_get_pos_msec(void *Hv,const char *attr)
{
  return nsp_create_object_from_double(NVOID,cvGetCaptureProperty(((NspCvCapture *) Hv)->capture,
								  CV_CAP_PROP_POS_MSEC));
}

static int int_cvcapture_set_pos_msec(void *Hv,const  char *attr, NspObject *Obj)
{
  double pos;
  if (DoubleScalar(Obj,&pos) == FAIL) return RET_BUG;
  cvSetCaptureProperty(((NspCvCapture *) Hv)->capture, CV_CAP_PROP_POS_MSEC,pos);
  if ( cvGetErrStatus() < 0 )
    {
      cvSetErrStatus( CV_StsOk );
      Scierror("Error: while trying to set capture position at %f\n",pos);
      return FAIL;
    }
  return OK;
}

static NspObject * int_cvcapture_get_pos_frames(void *Hv,const char *attr)
{
  return nsp_create_object_from_double(NVOID,cvGetCaptureProperty(((NspCvCapture *) Hv)->capture,
								  CV_CAP_PROP_POS_FRAMES));
}

static int int_cvcapture_set_pos_frames(void *Hv,const  char *attr, NspObject *Obj)
{
  int pos;
  if (IntScalar(Obj,&pos) == FAIL) return RET_BUG;
  cvSetCaptureProperty(((NspCvCapture *) Hv)->capture, CV_CAP_PROP_POS_FRAMES,pos);
  if ( cvGetErrStatus() < 0 )
    {
      cvSetErrStatus( CV_StsOk );
      Scierror("Error: while trying to set capture position at frame position %d\n",pos);
      return FAIL;
    }
  return OK;
}


static NspObject * int_cvcapture_get_avi_ratio(void *Hv,const char *attr)
{
  return nsp_create_object_from_double(NVOID,cvGetCaptureProperty(((NspCvCapture *) Hv)->capture,
								  CV_CAP_PROP_POS_AVI_RATIO));
}

static int int_cvcapture_set_avi_ratio(void *Hv,const char *attr, NspObject *Obj)
{
  double pos;
  if (DoubleScalar(Obj,&pos) == FAIL) return RET_BUG;
  cvSetCaptureProperty(((NspCvCapture *) Hv)->capture, CV_CAP_PROP_POS_AVI_RATIO,pos);
  if ( cvGetErrStatus() < 0 )
    {
      cvSetErrStatus( CV_StsOk );
      Scierror("Error: while trying to set capture position at avi ratio %f\n",pos);
      return FAIL;
    }
  return OK;
}

static NspObject * int_cvcapture_get_frame_width(void *Hv,const char *attr)
{
  return nsp_create_object_from_double(NVOID,cvGetCaptureProperty(((NspCvCapture *) Hv)->capture,
								  CV_CAP_PROP_FRAME_WIDTH));
}

static NspObject * int_cvcapture_get_frame_height(void *Hv,const char *attr)
{
  return nsp_create_object_from_double(NVOID,cvGetCaptureProperty(((NspCvCapture *) Hv)->capture,
								  CV_CAP_PROP_FRAME_HEIGHT));
}
static NspObject * int_cvcapture_get_prop_fps(void *Hv,const char *attr)
{
  return nsp_create_object_from_double(NVOID,cvGetCaptureProperty(((NspCvCapture *) Hv)->capture,
								  CV_CAP_PROP_FPS));
}

static void dump_four_cc(unsigned int four_cc,char *str)
{
  str[0] = four_cc & 0xff;
  str[1] = four_cc >> 8 & 0xff;
  str[2] = four_cc >> 16 & 0xff;
  str[3] = four_cc >> 24 & 0xff;
  str[4] = 0;
}

static NspObject * int_cvcapture_get_prop_fourcc(void *Hv,const char *attr)
{
  char str[5];
  unsigned int fc= (unsigned int) cvGetCaptureProperty(((NspCvCapture *) Hv)->capture, CV_CAP_PROP_FOURCC);
  if ( cvGetErrStatus() < 0 )
    {
      cvSetErrStatus( CV_StsOk );
      Scierror("Error: get codec failed \n");
      return NULLOBJ;
    }
  dump_four_cc(fc,str);
  /* Sciprintf("Fourcc %s\n",str); */
  return nsp_create_object_from_str(NVOID,str);
}

static NspObject * int_cvcapture_get_frame_count(void *Hv,const char *attr)
{
  double nf = (double) cvGetCaptureProperty(((NspCvCapture *) Hv)->capture, CV_CAP_PROP_FRAME_COUNT);
  if ( cvGetErrStatus() < 0 )
    {
      cvSetErrStatus( CV_StsOk );
      Scierror("Error: get_frame_count failed\n");
      return NULLOBJ;
    }
  return nsp_create_object_from_double(NVOID,nf);
}


static int int_cvcapture_set_void(void *Hv,const char *attr, NspObject *O)
{
  Scierror("Error: attribute of cvcapture objects cannot be changed\n");
  return FAIL;
}



/* XXXX Attention certain parametre peuvent etre change ex 
 * cvSetCaptureProperty(capture, CV_CAP_PROP_POS_AVI_RATIO, (double)0.9);
 * faire un cvQueryFrame(capture) avec un un get 
 */
 

static AttrTab nsp_cvcapture_attrs[] = {
  {"pos_msec",int_cvcapture_get_pos_msec, int_cvcapture_set_pos_msec,  NULL,NULL},
  {"pos_frames",int_cvcapture_get_pos_frames, int_cvcapture_set_pos_frames,NULL,NULL},
  {"avi_ratio",int_cvcapture_get_avi_ratio, int_cvcapture_set_avi_ratio,NULL,NULL},
  {"frame_width",int_cvcapture_get_frame_width, int_cvcapture_set_void,NULL,NULL},
  {"frame_height",int_cvcapture_get_frame_height, int_cvcapture_set_void,NULL,NULL},
  {"fps",int_cvcapture_get_prop_fps, int_cvcapture_set_void,NULL,NULL},
  {"fourcc",int_cvcapture_get_prop_fourcc, int_cvcapture_set_void,NULL,NULL},
  {"frame_count",int_cvcapture_get_frame_count, int_cvcapture_set_void,NULL,NULL},
  { (char *) 0, NULL,NULL,NULL,NULL}
};


/*------------------------------------------------------
 * methods 
 *------------------------------------------------------*/

/* a test to compute count_frames ! */

static int int_meth_count_frames(void *self,Stack stack, int rhs, int opt, int lhs)
{
  unsigned int number_of_frames;
  NspCvCapture *obj= (NspCvCapture *) self;
  CheckRhs(0,0);
  CheckLhs(1,1);
  /* Go to the end of the AVI (ie: the fraction is "1") */
  cvSetCaptureProperty(obj->capture, CV_CAP_PROP_POS_AVI_RATIO, 1.0 );
  /* Now that we're at the end, read the AVI position in frames */
  number_of_frames = (unsigned int) cvGetCaptureProperty(obj->capture,CV_CAP_PROP_POS_FRAMES);
  /* Return to the current position */
  cvSetCaptureProperty(obj->capture, CV_CAP_PROP_POS_FRAMES, 0.0 );
  nsp_move_double(stack,1,number_of_frames);
  return 1;
}


/*
 * f.query_frame[]  IplImage* cvQueryFrame( CvCapture* capture );
 * cvGrabFrame(capture);          // capture a frame
 * img=cvRetrieveFrame(capture);  // retrieve the captured frame 
 * cvQueryFrame(capture); // this call is necessary to get correct 
 */

static int int_meth_query_frame(void *self,Stack stack, int rhs, int opt, int lhs)
{
  NspCvCapture *obj= (NspCvCapture *) self;
  IplImage *frame,*img; 
  NspIplImage *nsp_img1=NULL;
  CheckRhs(0,0);
  CheckLhs(1,1);
  frame = cvQueryFrame( obj->capture);
  if ( frame == NULL ||  cvGetErrStatus() < 0 )
    {
      cvSetErrStatus( CV_StsOk );
      Scierror("Error: capture of frame failed\n");
      return RET_BUG;
    }
  img  = cvCloneImage(frame);
  if ( cvGetErrStatus() < 0 )
    {
      cvSetErrStatus( CV_StsOk );
      Scierror("Error: frame copy failed\n");
      return RET_BUG;
    }
  if((nsp_img1 = nsp_iplimage_create(NVOID))==NULL) 
    {
      cvReleaseImage( &img );
      return RET_BUG;
    }
  nsp_img1->img = img ;
  MoveObj(stack,1,NSP_OBJECT(nsp_img1));
  return 1;
}

static int int_meth_grab_frame(void *self,Stack stack, int rhs, int opt, int lhs)
{
  int rep;
  NspCvCapture *obj= (NspCvCapture *) self;
  CheckRhs(0,0);
  CheckLhs(1,1);
  rep =  cvGrabFrame( obj->capture);
  if ( cvGetErrStatus() < 0 )
    {
      cvSetErrStatus( CV_StsOk );
      Scierror("Error: grab frame failed\n");
      return RET_BUG;
    }
  if ( nsp_move_boolean(stack,1,rep) == FAIL) return RET_BUG;
  return 1;
}

static int int_meth_retrieve_frame(void *self,Stack stack, int rhs, int opt, int lhs)
{
  NspCvCapture *obj= (NspCvCapture *) self;
  IplImage *frame,*img; 
  NspIplImage *nsp_img1=NULL;
  CheckRhs(0,0);
  CheckLhs(1,1);
  frame =  cvRetrieveFrame( obj->capture,0);
  if ( frame == NULL ||  cvGetErrStatus() < 0 )
    {
      cvSetErrStatus( CV_StsOk );
      Scierror("Error: retrieve of frame failed\n");
      return RET_BUG;
    }
  img  = cvCloneImage(frame);
  if ( cvGetErrStatus() < 0 )
    {
      cvSetErrStatus( CV_StsOk );
      Scierror("Error: frame copy failed\n");
      return RET_BUG;
    }
  if((nsp_img1 = nsp_iplimage_create(NVOID))==NULL) 
    {
      cvReleaseImage( &img );
      return RET_BUG;
    }
  nsp_img1->img = img ;
  MoveObj(stack,1,NSP_OBJECT(nsp_img1));
  return 1;
}


/* release the capture 
 *
 */

static int int_meth_release_capture(void *self,Stack stack, int rhs, int opt, int lhs)
{
  NspCvCapture *F= (NspCvCapture *) self;
  cvReleaseCapture(&F->capture);
  return 0;
}


static NspMethods nsp_cvcapture_methods[] = {
  {(char *)"query_frame",int_meth_query_frame},
  {(char *)"grab_frame", int_meth_grab_frame},
  {(char *)"retrieve_frame", int_meth_retrieve_frame},
  {(char *)"count_frames",int_meth_count_frames},
  {(char *)"close", int_meth_release_capture},
  { (char *) 0, NULL}
};

static NspMethods *nsp_cvcapture_get_methods(void) { return nsp_cvcapture_methods;};

/*----------------------------------------------------
 * Interface 
 * i.e a set of function which are accessible at nsp level
 * the function are added in the iplimage table.
 *----------------------------------------------------*/

int int_cvcapture_new(Stack stack, int rhs, int opt, int lhs)
{
  int camera;
  char *nom=NULL;
  CvCapture *capture=NULL;
  NspCvCapture *nsp_capture=NULL;
  CheckRhs(1,1);
  CheckLhs(1,1);
  if ( IsSMatObj(stack, 1) )
    {
      if ((nom = GetString(stack,1)) == (char*)0) return RET_BUG;
    }
  else
    {
      if ( GetScalarInt(stack, 1, &camera) == FAIL ) return RET_BUG;
    }
  if ( nom != NULL)
    capture = cvCaptureFromAVI(nom);
  else
    capture = cvCaptureFromCAM(camera);
  
  if( !capture )
    {
      if ( nom == NULL )
	Scierror("Error: Could not initialize capturing from camera %d\n",camera);
      else
	Scierror("Error: Could not initialize capturing from file %s\n",nom);
      return RET_BUG;
    }
  if((nsp_capture = nsp_cvcapture_create(NVOID))==NULL) 
    {
      cvReleaseCapture(&capture);
      return RET_BUG;
    }
  nsp_capture->capture = capture;
  MoveObj(stack,1,NSP_OBJECT(nsp_capture));
  return 1;
}

#ifdef __cplusplus
}
#endif

