#ifndef NSP_INC_CVVIDEOWRITER
#define NSP_INC_CVVIDEOWRITER

/*
 * This Software is GPL (Copyright ENPC 1998-2005) 
 * Jean-Philippe Chancelier Enpc/Cermics         
 */

#include "nsp/sciio.h" 
#include "nsp/object.h"
#include "nsp/xdr.h"
#include <cv.h>
#include <cxcore.h>

/*
 * NspCvVideoWriter inherits from NspObject 
 */

typedef struct _NspCvVideoWriter NspCvVideoWriter;

typedef struct _NspTypeCvVideoWriter { 
  NSP_TYPE_OBJECT__ 
  /*< public >*/
} NspTypeCvVideoWriter;

struct _NspCvVideoWriter {
  /*< private >*/
  NspObject father; 
  NspTypeCvVideoWriter *type; 
  /*< public >*/
  CvVideoWriter *videowriter;
};

extern int nsp_type_cvvideowriter_id;
extern NspTypeCvVideoWriter *nsp_type_cvvideowriter;

NspTypeCvVideoWriter *new_type_cvvideowriter(type_mode mode);

NspCvVideoWriter *nsp_new_cvvideowriter();

/*
 * Object methods redefined for file 
 */

extern NspCvVideoWriter *nsp_cvvideowriter_create(const char *name);
extern NspCvVideoWriter *nsp_cvvideowriter_copy(NspCvVideoWriter *H);
extern void nsp_cvvideowriter_destroy(NspCvVideoWriter *H);
extern int nsp_cvvideowriter_info(NspCvVideoWriter *H, int indent,char *name, int rec_level);
extern int nsp_cvvideowriter_print(NspCvVideoWriter *H, int indent,char *name, int rec_level);

#define NULLCVVIDEOWRITER (NspCvVideoWriter *) 0

/* CvVideoWriterObj.c */

extern NspCvVideoWriter *nsp_cvvideowriter_object(NspObject *O);
extern int IsCvVideoWriterObj (Stack stack, int i);
extern NspCvVideoWriter *GetCvVideoWriterCopy (Stack stack, int i);
extern NspCvVideoWriter *GetCvVideoWriter (Stack stack, int i);

#endif 

#ifdef CvVideoWriter_Private 
static int nsp_init_cvvideowriter(NspCvVideoWriter *ob,NspTypeCvVideoWriter *type);
static int nsp_cvvideowriter_size(NspCvVideoWriter *Mat, int flag);
static char *nsp_cvvideowriter_type_as_string(void);
static char *nsp_cvvideowriter_type_short_string(NspObject *v);
static int nsp_cvvideowriter_eq(NspObject *A, NspObject *B);
static int nsp_cvvideowriter_neq(NspObject *A, NspObject *B);
static NspMethods *nsp_cvvideowriter_get_methods(void);
static AttrTab nsp_cvvideowriter_attrs[];
#endif 
