/* Nsp
 * Copyright (C) 2005 Jean-Philippe Chancelier Enpc/Cermics
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public
 * License along with this library; if not, write to the
 * Free Software Foundation, Inc., 59 Temple Place - Suite 330,
 * Boston, MA 02111-1307, USA.
 *
 * Interface with the opencv library. 
 *
 */


#include "common.h"

#ifdef __cplusplus
extern "C" {
#endif

#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <gdk/gdk.h>

#define CvVideoWriter_Private 
#include "nsp/object.h"
#include "nsp/pr-output.h" 
#include "nsp/interf.h"
#include "nsp/matutil.h"
#include "cvvideowriter.h" 

/*
 * NspCvVideoWriter inherits from NspObject 
 */

int nsp_type_cvvideowriter_id=0;
NspTypeCvVideoWriter *nsp_type_cvvideowriter=NULL;

NspTypeCvVideoWriter *new_type_cvvideowriter(type_mode mode)
{
  NspTypeCvVideoWriter *type = NULL;
  NspTypeObject *top;
  if ( nsp_type_cvvideowriter != 0 && mode == T_BASE )
    {
      /* initialization performed and T_BASE requested */
      return nsp_type_cvvideowriter;
    }
  if (( type = (NspTypeCvVideoWriter *) malloc(sizeof(NspTypeCvVideoWriter)))== NULL) return NULL;
  type->interface = NULL;
  type->surtype =(NspTypeBase *) new_type_object(T_DERIVED);
  if ( type->surtype == NULL) return NULL;
  type->attrs = nsp_cvvideowriter_attrs ;
  type->get_attrs = (attrs_func *) int_get_attribute; 
  type->set_attrs = (attrs_func *) int_set_attribute; 
  type->methods =nsp_cvvideowriter_get_methods; 
  type->new = (new_func *)nsp_new_cvvideowriter;

  top = NSP_TYPE_OBJECT(type->surtype);
  while ( top->surtype != NULL ) top= NSP_TYPE_OBJECT(top->surtype);

  /* object methods redefined for cvvideowriter */ 

  top->pr = (print_func *)nsp_cvvideowriter_print;	              /* printing */   
  top->dealloc = (dealloc_func *)nsp_cvvideowriter_destroy;           /* dealloc */  
  top->copy  =  (copy_func *)nsp_cvvideowriter_copy;                  /* copy object */  
  top->size  = (size_func *)nsp_cvvideowriter_size;                   /* m,n or m*n  */  
  top->s_type =  (s_type_func *)nsp_cvvideowriter_type_as_string;               /* type as a String */  
  top->sh_type = (sh_type_func *)nsp_cvvideowriter_type_short_string;           /* type as a short string */  
  top->info = (info_func *)nsp_cvvideowriter_info;                    /* info */  
  /* top->is_true = (is_true_func  *) cvvideowriter_IsTrue;  */         /* check if object can be considered as true */  
  /*top->loop =(loop_func *) cvvideowriter_LoopExtract;     */	/* for loops */  
  top->path_extract =  NULL;					/* used for x(1)(2)(...) */  
  top->get_from_obj = (get_from_obj_func *)nsp_cvvideowriter_object;    	/* get object stored in SciObj */  
  top->eq  = (eq_func *)nsp_cvvideowriter_eq;			/* equality check */  
  top->neq  = (eq_func *)nsp_cvvideowriter_neq;		        /* non-equality check */

  /* specific methods for cvvideowriter */
  type->init = (init_func *)nsp_init_cvvideowriter;

  /* 
   * interfaces can be added here 
   * type->interface = (NspTypeBase *) new_type_b();
   * type->interface->interface = (NspTypeBase *) new_type_C()
   * ....
   */
  
  if ( nsp_type_cvvideowriter_id == 0 ) 
    {
      /* 
       * the first time we get here we initialize the type id and
       * an instance of NspTypeMatrix called nsp_type_cvvideowriter
       */
      type->id =  nsp_type_cvvideowriter_id = nsp_new_type_id();
      nsp_type_cvvideowriter = type;
      if ( nsp_register_type(nsp_type_cvvideowriter) == FALSE) return NULL;
      return ( mode == T_BASE ) ? type : new_type_cvvideowriter(mode);
    }
  else 
    {
      type->id = nsp_type_cvvideowriter_id;
      return type;
    }
}
/*
 * initialize Scifile instances 
 * locally and by calling initializer on parent class 
 */

static int nsp_init_cvvideowriter(NspCvVideoWriter *o,NspTypeCvVideoWriter *type)
{
  /* to be done always */ 
  if ( type->surtype->init(&o->father,type->surtype) == FAIL) return FAIL;
  o->type = type; 
  NSP_OBJECT(o)->basetype = (NspTypeBase *)type;
  /* specific */
  return OK;
}

/*
 * new instance of CvVideoWriter 
 */

NspCvVideoWriter *nsp_new_cvvideowriter() 
{
  NspCvVideoWriter *loc; 
  /* type must exists */
  nsp_type_cvvideowriter = new_type_cvvideowriter(T_BASE);
  if ( (loc = (NspCvVideoWriter *) malloc(sizeof(NspCvVideoWriter)))== NULLCVVIDEOWRITER) return loc;
  /* initialize object */
  if (nsp_init_cvvideowriter(loc,nsp_type_cvvideowriter) == FAIL) return NULLCVVIDEOWRITER;
  return loc;
}

/*----------------------------------------------
 * Object method redefined for cvvideowriter 
 *-----------------------------------------------*/

/*
 * size 
 */

static int nsp_cvvideowriter_size(NspCvVideoWriter  *H, int flag)
{
  return 0;
}

/*
 * type as string 
 */

static char nsp_cvvideowriter_type_name[]="CvVideoWriter";
static char nsp_cvvideowriter_short_type_name[]="cvcap";

static char *nsp_cvvideowriter_type_as_string(void)
{
  return(nsp_cvvideowriter_type_name);
}

static char *nsp_cvvideowriter_type_short_string(NspObject *v)
{
  return(nsp_cvvideowriter_short_type_name);
}


static int nsp_cvvideowriter_full_comp(NspCvVideoWriter * A,NspCvVideoWriter * B,const char *op,int *err)
{
  Scierror("CvVideoWriterFullComp: to be implemented \n");
  return FALSE;
}

static int nsp_cvvideowriter_eq(NspObject *A, NspObject *B)
{
  int err,rep;
  if ( check_cast(B,nsp_type_ivect_id) == FALSE) return FALSE ;
  rep =nsp_cvvideowriter_full_comp((NspCvVideoWriter *) A,(NspCvVideoWriter *) B,"==",&err);
  if ( err == 1) return FALSE ; 
  return rep;
}

static int nsp_cvvideowriter_neq(NspObject *A, NspObject *B)
{
  int err=0,rep;
  if ( check_cast(B,nsp_type_ivect_id) == FALSE) return TRUE;
  rep =nsp_cvvideowriter_full_comp((NspCvVideoWriter *) A,(NspCvVideoWriter *) B,"<>",&err);
  if ( err == 1) return TRUE ; 
  return rep;
}

/*
 * delete 
 */

void nsp_cvvideowriter_destroy(NspCvVideoWriter  *F)
{
  cvReleaseVideoWriter(&F->videowriter);
  FREE(F) ;
}

/*
 * info 
 */

int nsp_cvvideowriter_info(NspCvVideoWriter  *F, int indent,char *name,int rec_level)
{
  int i;
  if (F == NULLCVVIDEOWRITER) 
    {
      Sciprintf("Null Pointer CvVideoWriter \n");
      return FALSE;
    }
  for ( i=0 ; i < indent ; i++) Sciprintf(" ");
  if ( strcmp(NSP_OBJECT(F)->name,NVOID) == 0) 
    Sciprintf("CvVideoWriter fname=%x\n",F->videowriter);
  else
    Sciprintf("%s =\tCvVideoWriter fname=%x\n",NSP_OBJECT(F)->name,F->videowriter);
  return TRUE;

}

/*
 * print 
 */

int nsp_cvvideowriter_print(NspCvVideoWriter  *F, int indent,char *name, int rec_level)
{
  nsp_cvvideowriter_info(F,indent,NULL,0);
  return TRUE;
}

/*-----------------------------------------------------
 * a set of functions used when writing interfaces 
 * for Hash objects 
 * Note that some of these functions could become MACROS XXXXX 
 *-----------------------------------------------------*/

NspCvVideoWriter  *nsp_cvvideowriter_object(NspObject *O)
{
  /* Follow pointer **/
  HOBJ_GET_OBJECT(O,NULL);
  /* Check type **/
  if ( check_cast(O,nsp_type_cvvideowriter_id) == TRUE) return ((NspCvVideoWriter *) O);
  else 
    Scierror("Error:\tArgument should be a %s\n",type_get_name(nsp_type_cvvideowriter));
  return(NULL);
}


int IsCvVideoWriterObj(Stack stack, int i)
{
  return nsp_object_type(NthObj(i) , nsp_type_cvvideowriter_id);
}

int IsCvVideoWriter(NspObject *obj)
{
  return nsp_object_type(obj, nsp_type_cvvideowriter_id);
}

NspCvVideoWriter *GetCvVideoWriterCopy(Stack stack, int i)
{
  if (  GetCvVideoWriter(stack,i) == NULL ) return NULL;
  return (NspCvVideoWriter *)MaybeObjCopy(&NthObj(i));
}

NspCvVideoWriter *GetCvVideoWriter(Stack stack, int i)
{
  NspCvVideoWriter *M;
  if (( M =nsp_cvvideowriter_object(NthObj(i))) == NULLCVVIDEOWRITER  )
    ArgMessage(stack,i);
  return M;
}

/*-----------------------------------------------------
 * constructor 
 *-----------------------------------------------------*/

NspCvVideoWriter *nsp_cvvideowriter_create(const char *name)
{
  NspCvVideoWriter *F =nsp_new_cvvideowriter() ;
  if ( F == NULLCVVIDEOWRITER) 
    {
      Scierror("Error:\tRunning out of memory\n");
      return NULLCVVIDEOWRITER;
    }
  /* shared by all objects */
  if ( nsp_object_set_initial_name(NSP_OBJECT(F),name) == NULL)
    return NULLCVVIDEOWRITER;
  NSP_OBJECT(F)->ret_pos = -1 ; 
  F->videowriter = NULL;
  return(F);
}

/*
 * copy: cloning image 
 */

NspCvVideoWriter *nsp_cvvideowriter_copy(NspCvVideoWriter  *A)
{
  Scierror("Error: Cannot copy a CvVideoWriter object\n");
  return NULLCVVIDEOWRITER;
}

/*------------------------------------------------------
 * attributes  (set/get methods) 
 *------------------------------------------------------*/


static AttrTab nsp_cvvideowriter_attrs[] = {
  { (char *) 0, NULL}
};


/*------------------------------------------------------
 * methods 
 *------------------------------------------------------*/

/*
 * f.write_frame[]
 */

static int int_meth_write_frame(void *self,Stack stack, int rhs, int opt, int lhs)
{
  int rep,status;
  NspObject *obj1;
  NspCvVideoWriter *nsp_obj= (NspCvVideoWriter *) self;
  NspIplImage *nsp_img=NULL;

  CheckRhs(1,1); 
  CheckLhs(0,0);
  if ((nsp_img= GetIplImage(stack,1))== NULL) return RET_BUG;
  rep= cvWriteFrame(nsp_obj->videowriter, nsp_img->img);
  if ( (status = cvGetErrStatus()) < 0 ) 
    {
      cvSetErrStatus( CV_StsOk );
      Scierror("Error: write frame failed with status %d\n",status );
      return RET_BUG;
    } 
  if ((obj1= nsp_create_object_from_double(NVOID,rep))==NULLOBJ)
    return RET_BUG;
  MoveObj(stack,1,obj1);
  return 1;
}

static int int_meth_close_video(void *self,Stack stack, int rhs, int opt, int lhs)
{
  NspCvVideoWriter * nsp_obj= (NspCvVideoWriter *) self;
  CheckRhs(0,0);
  CheckLhs(0,0);
  cvReleaseVideoWriter(&nsp_obj->videowriter);
  if ( cvGetErrStatus() < 0 )
    {
      cvSetErrStatus( CV_StsOk );
      Scierror("Error: write frame failed\n");
      return RET_BUG;
    } 
  return 0;
}

static NspMethods nsp_cvvideowriter_methods[] = {
  {(char *)"write_frame",int_meth_write_frame},
  {(char *)"close",int_meth_close_video},
  { (char *) 0, NULL}
};

static NspMethods *nsp_cvvideowriter_get_methods(void) { return nsp_cvvideowriter_methods;};

/*----------------------------------------------------
 * Interface 
 * i.e a set of function which are accessible at nsp level
 * the function are added in the iplimage table.
 *----------------------------------------------------*/

int int_cvvideowriter_new(Stack stack, int rhs, int opt, int lhs)
{
  int fps=25,is_color=1,width=512,height=512;
  char def_codec[]="XVID", *nom, *fourcc=def_codec,*codec;
  CvVideoWriter *videowriter=NULL;
  NspCvVideoWriter *nsp_videowriter=NULL;
  const char *Table[]  = { "PIM1","MJPG","MP42","DIV3","DIVX","U263",
			   "I263","FLV1","XVID","DIB ", "IYUV", "I420", NULL};

  CheckRhs(1,2);
  CheckLhs(1,1);

  if ((nom = GetString(stack,1)) == (char*)0) return RET_BUG;
  if ( rhs >= 2 ) 
    {
      int ret;
      if ((codec = GetString(stack,2)) == (char*)0) return RET_BUG;
      ret = is_string_in_array(codec,Table,1);
      if ( ret < 0 ) 
	{
	  string_not_in_array(stack,nom,Table,(char *) "second argument");
	  return RET_BUG;
	}
      fourcc = codec;
    }
  
  videowriter = cvCreateVideoWriter(nom,CV_FOURCC(fourcc[0],fourcc[1],fourcc[2],fourcc[3]),
				    fps,cvSize(width,height),is_color);
  if( !videowriter )
    {
      Scierror("Error: Could not initialize video writer for file %s\n",nom);
      return RET_BUG;
    }
  if((nsp_videowriter = nsp_cvvideowriter_create(NVOID))==NULL) 
    {
      cvReleaseVideoWriter(&videowriter);
      return RET_BUG;
    }
  nsp_videowriter->videowriter = videowriter;
  MoveObj(stack,1,NSP_OBJECT(nsp_videowriter));
  return 1;
}







#ifdef __cplusplus
}
#endif
