/*****************************************************************************
 * SIVP - Scilab Image and Video Processing toolbox
 * Copyright (C) 2008  Jia Wu
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *****************************************************************************/

/* Ported to nsp: Jean-Philippe Chancelier 2008.
 */

#include "common.h"
#include <opencv2/legacy/legacy.hpp>

#ifdef __cplusplus
extern "C" {
#endif

/*
 * if two arguments are given then the CvBGStatModel is cleared 
 * and recreated according to second argument value. 
 * when just one argument is given the CvBGStatModel is just updated.
 */

int int_detectforeground(Stack stack, int rhs, int opt, int lhs)
{
  static CvBGStatModel *bg_model = NULL;
  NspIplImage *nsp_img=NULL,*nsp_img_out=NULL;
  IplImage *img_in =NULL,*img_out=NULL;
  const char *type_sm[]={ "LI", "GMM", NULL };
  int rep_type=0;

  CheckRhs(1,2);
  CheckLhs(1,1);
  
  if ((nsp_img= GetIplImage(stack,1))== NULL) return RET_BUG;
  img_in = nsp_img->img;

  if ( rhs >= 2) 
    {
      if ((rep_type= GetStringInArray(stack,2,type_sm,1)) == -1) return RET_BUG; 
      if (bg_model != NULL) cvReleaseBGStatModel(&bg_model);
      if ( rep_type == 0 ) 
	{
	  bg_model = cvCreateFGDStatModel(img_in, NULL);
	}
      else
	{
	  bg_model = cvCreateGaussianBGModel(img_in, NULL);
	}
      if ( cvGetErrStatus() < 0 )
	{
	  cvSetErrStatus( CV_StsOk );
	  Scierror("Error: creation of a CvBGStatModel failed\n");
	  goto exit;
	}
    }
  else
    {
      /* update */
      if ( bg_model == NULL) bg_model = cvCreateFGDStatModel(img_in, NULL);
      if ( cvGetErrStatus() < 0 )
	{
	  cvSetErrStatus( CV_StsOk );
	  Scierror("Error: creation of a CvBGStatModel failed\n");
	  goto exit;
	}
      cvUpdateBGStatModel(img_in, bg_model,0.0);
    }  

  img_out  = cvCloneImage(bg_model->foreground );  
  if ( cvGetErrStatus() < 0 )
    {
      cvSetErrStatus( CV_StsOk );
      Scierror("Error: Image clone failed\n");
      goto exit;
    }

  if((nsp_img_out = nsp_iplimage_create(NVOID))==NULL) goto exit;
  nsp_img_out->img = img_out;
  
  MoveObj(stack,1,NSP_OBJECT(nsp_img_out));
  return 1;
 exit:
  cvReleaseBGStatModel(&bg_model);
  if ( img_out != NULL) cvReleaseImage( &img_out );
  return RET_BUG;
}


#ifdef __cplusplus
}
#endif
