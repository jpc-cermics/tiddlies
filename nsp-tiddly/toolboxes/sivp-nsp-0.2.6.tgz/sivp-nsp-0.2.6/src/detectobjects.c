/*****************************************************************************
 * SIVP - Scilab Image and Video Processing toolbox
 * Copyright (C) 2008  Jia Wu
 * Copyright (C) 2008  Shiqi Yu (shiqi.yu@gmail.com)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *****************************************************************************/

/* Ported to nsp: Jean-Philippe Chancelier 2008-2017.
 */

#include "common.h"

#ifdef __cplusplus
extern "C" {
#endif

/**********************************************************************
 * this function only supports UINT8
 * [objects]=detectobjects(im, xmlfile);
 * objects is a Nx4 matrix.
 * each row of objects is an object location [x,y,w,h]
 **********************************************************************/

int int_detectobjects(Stack stack, int rhs, int opt, int lhs)
{
  int idx;
  NspMatrix *res=NULL;
  static CvHaarClassifierCascade* pCascade = NULL;
  static char xmlname[FSIZE]={0};
  char       sFileName[FSIZE];
  NspIplImage *nsp_img=NULL;
  char *str;
  CvMemStorage* pStorage = NULL;
  IplImage * img_in = NULL;
  CvSeq    * pObjects = NULL;

  CheckRhs(2, 2);
  CheckLhs(1, 1);

  if ((nsp_img = GetIplImage(stack,1))== NULL) return RET_BUG;
  img_in = nsp_img->img;

  if( img_in->depth != IPL_DEPTH_8U )
    {
      Scierror("Error: detectojects only works for 8-bit unsigned images\n");
      return RET_BUG;
    }
  
  if ((str  = GetString(stack,2)) ==  NULLSTRING) return RET_BUG;

  if( pCascade != NULL && strncmp(xmlname, str, FSIZE) != 0 )
    {
      /* changing xmlfile */
      cvReleaseHaarClassifierCascade(&pCascade);
      pCascade = NULL;
    }
  
  if ( pCascade == NULL ) 
    {
      sprintf(xmlname, "%s", str);
      sprintf(sFileName,"%s/etc/%s", sSIVP_PATH, str);
      pCascade = (CvHaarClassifierCascade*) cvLoad( sFileName, 0, 0, 0 );
      if ( pCascade == NULL || cvGetErrStatus() < 0 )
	{
	  cvSetErrStatus( CV_StsOk );
	  Scierror("Error: failed to load object haar cascade from file %s\n",sFileName);
	  return RET_BUG;
	}
    }

  if ((pStorage = cvCreateMemStorage(0)) == NULL) 
    {
      Scierror("Error: cannot create memory storage for detector\n");
      return RET_BUG;
    }
  pObjects = cvHaarDetectObjects( img_in, pCascade, pStorage,
				  1.1, 3, CV_HAAR_DO_CANNY_PRUNING,
				  cvSize(0, 0),cvSize(0,0) );
  if ( cvGetErrStatus() < 0 )
    {
      cvSetErrStatus( CV_StsOk );
      Scierror("Error: failed to load object haar cascade from file %s\n",sFileName);
      return RET_BUG;
    }
  
  /* copy object locations to output matrix */
  if (( res = nsp_matrix_create(NVOID,'r',pObjects->total,4)) == NULLMAT ) 
    return RET_BUG;
  for( idx = 0; idx < pObjects->total; idx++ )
    {
      CvRect* r = (CvRect*)cvGetSeqElem( pObjects, idx );
      res->R[idx+res->m*0]= r->x;
      res->R[idx+res->m*1]= r->y;
      res->R[idx+res->m*2]= r->width;
      res->R[idx+res->m*3]= r->height;
    }
  MoveObj(stack,1,NSP_OBJECT(res));
  cvReleaseMemStorage(&pStorage);
  return 1;
}

  
#ifdef __cplusplus
}
#endif
