/***********************************************************************
 * SIVP - Scilab Image and Video Processing toolbox
 * Copyright (C) 2005  Vincent Etienne
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ***********************************************************************/

/* Ported to nsp: Jean-Philippe Chancelier 2005-2006.
 *
 */

#include "common.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef void (*cvde)(const IplImage* img1,IplImage* img2 ,IplConvKernel *truc,int nbr_it);


static int int_dilate_erode(Stack stack, int rhs, int opt, int lhs,cvde Func)
{
  int  a, b, c, d, nbr_it=0;  /* variable pour le nombre d'it�ration */
  IplImage* img1 = NULL,* img2 = NULL;
  NspIplImage* nsp_img = NULL ;
  char * nom = NULL; /* variable pour le texte a recuperer */
  IplConvKernel * truc=NULL; /* variable pr creer la forme optionel du filtre d'�rodage */
  int nsp_ret = RET_BUG;
  CheckRhs(2,7);
  CheckLhs(1,1);

  if ( rhs != 2 && rhs != 7 ) 
    {
      Scierror("Error: parameters number must be 2 or 7\n");
      return RET_BUG;
    }

  if ((nsp_img= GetIplImage(stack,1))== NULL) goto exit;
  img1 = nsp_img->img;

  if ( GetScalarInt(stack,2,&nbr_it) == FAIL) goto exit;
  if (rhs == 7)
    {
      if ((nom = GetString(stack,3)) == (char*)0) goto exit;
      if ( GetScalarInt(stack,4,&a) == FAIL) goto exit;
      if ( GetScalarInt(stack,5,&b) == FAIL) goto exit;
      if ( GetScalarInt(stack,6,&c) == FAIL) goto exit;
      if ( GetScalarInt(stack,7,&d) == FAIL) goto exit;
      if ( strcmp(nom,"RECT")==0 ) 
	{
	  truc=cvCreateStructuringElementEx( a, b, c, d, CV_SHAPE_RECT,NULL );
	}
      else if (strcmp(nom,"CROSS")== 0) 
	{
	  truc=cvCreateStructuringElementEx( a, b, c, d, CV_SHAPE_CROSS,NULL );
	}	
      else if (strcmp(nom,"ELLIPSE")==0) 
	{
	  truc=cvCreateStructuringElementEx( a, b, c, d, CV_SHAPE_ELLIPSE,NULL );
	}
      else 
	{
	  truc = NULL;
	}
    }
  
  if ((img2=cvCreateImage(cvGetSize(img1),img1->depth,img1->nChannels))==NULL) 
    {
      Scierror("Error: can't create the output matrix\n");
      goto exit;
    }

  (*Func)(img1,img2 ,truc,nbr_it);
  if ( cvGetErrStatus() < 0 )
    {
      cvSetErrStatus( CV_StsOk );
      Scierror("Error:  %s  failed \n",NspFname(stack));
      goto exit;
    }

  if((nsp_img = nsp_iplimage_create(NVOID))==NULL) goto exit;
  nsp_img->img = img2;
  MoveObj(stack,1,NSP_OBJECT(nsp_img));
  return 1;
 exit:
  if (img2) cvReleaseImage( &img2 );	
  return nsp_ret;
}


int int_dilate(Stack stack, int rhs, int opt, int lhs)
{
  return int_dilate_erode(stack, rhs, opt, lhs,(cvde) cvDilate);
}


int int_erode(Stack stack, int rhs, int opt, int lhs)
{
  return  int_dilate_erode(stack, rhs, opt, lhs,(cvde) cvErode);
}

#ifdef __cplusplus
}
#endif
