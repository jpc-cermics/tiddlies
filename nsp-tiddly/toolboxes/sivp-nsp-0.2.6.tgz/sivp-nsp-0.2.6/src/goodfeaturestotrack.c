/***********************************************************************
 * SIVP - Scilab Image and Video Processing toolbox
 * Copyright (C) 2005  Vincent Etienne
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ***********************************************************************/

#include "common.h"

#ifdef __cplusplus
extern "C" {
#endif

/* Ported to nsp: Jean-Philippe Chancelier 2005-2006.
 *
 */

int int_goodfeaturestotrack(Stack stack, int rhs, int opt, int lhs)
{
  CvPoint2D32f corners[1000];
  int i=1;
  IplImage* img1=NULL,* img2 = NULL,* img3 = NULL,* imgout = NULL;
  NspIplImage* nsp_img = NULL;
  int param1,nsp_ret = RET_BUG; 
  double param2, param3;

  CheckRhs(4,4);
  CheckLhs(1,1);
  if ((nsp_img= GetIplImage(stack,1))== NULL) return RET_BUG;
  img1 = nsp_img->img;
  
  if ( GetScalarInt(stack,2,&param1) == FAIL) goto tag_exit;
  if ( GetScalarDouble(stack,3,&param2) == FAIL) goto tag_exit;
  if ( GetScalarDouble(stack,4,&param3) == FAIL) goto tag_exit;
  
  if(img1->nChannels !=1)
    {
      Scierror("Error:wrong number of channel for input matrice\n");
      goto tag_exit;
    }
  //create the output image
  if ((img2=cvCreateImage(cvGetSize(img1),IPL_DEPTH_32F,1))==NULL) 
    {
      Scierror("Error: %s can't create the output matrix\n",NspFname(stack));
      goto tag_exit;
    }
  if ((img3=cvCreateImage(cvGetSize(img1),IPL_DEPTH_32F,1))==NULL)
    {
      Scierror("Error: %s can't create the output matrix\n",NspFname(stack));
      goto tag_exit;
    }
  if ((imgout=cvCreateImage(cvGetSize(img1),IPL_DEPTH_8U,3))==NULL)
    {
      Scierror("Error: %s can't create the output matrix\n",NspFname(stack));
      goto tag_exit;
    }
  cvCvtColor(img1,imgout,CV_GRAY2BGR);
  // check if the output image is correctly loaded
  cvGoodFeaturesToTrack(img1,img2,img3,corners,&param1,param2,param3,NULL,3,0,0.04);
  if ( cvGetErrStatus() < 0 )
    {
      cvSetErrStatus( CV_StsOk );
      Scierror("Error:  %s , cvGoodFeaturesToTrack failed \n",NspFname(stack));
      goto tag_exit;
    }

  for (i=1;i<=param1;i++)
    {
      cvCircle(imgout,cvPoint(corners[i-1].x,corners[i-1].y),10,CV_RGB(255,0,0),2,8,0);
      //Scierror("number of corner :%i\n",param1);
      //Scierror("point number %i x=%f y=%f\n",i,corners[i].x,corners[i].y);
      // goto tag_exit;
    }

  if((nsp_img = nsp_iplimage_create(NVOID))==NULL) goto tag_exit;
  nsp_img->img = imgout;
  MoveObj(stack,1,NSP_OBJECT(nsp_img));
  nsp_ret =1;
 tag_exit:
  if ( img2) cvReleaseImage( &img2 );
  if ( img3) cvReleaseImage( &img3 );
  if (nsp_ret != 1 &&  imgout) cvReleaseImage( &imgout );
  return nsp_ret;
}


#ifdef __cplusplus
}
#endif



