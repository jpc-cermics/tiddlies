/***********************************************************************
 * SIVP - Scilab Image and Video Processing toolbox
 * Copyright (C) 2005  Vincent Etienne
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ***********************************************************************/

#include "common.h"

#ifdef __cplusplus
extern "C" {
#endif

/* Ported to nsp: Jean-Philippe Chancelier 2005-2006.
 *
 */

int int_hough(Stack stack, int rhs, int opt, int lhs)
{
  IplImage *img1=NULL;
  NspIplImage *nsp_img1=NULL,* nsp_img;
  IplImage* color_img2=NULL;
  CvSeq* lines = 0;
  CvMemStorage* storage=NULL;
  char * param2=NULL;
  double param3,param4,param6,param7;
  int param5,nsp_ret=RET_BUG;
  int i,flag=0; 
  CheckRhs(7,7);
  CheckLhs(1,1);

  if ((nsp_img1= GetIplImage(stack,1))== NULL) goto exit;
  img1 = nsp_img1->img;

  if ((param2 = GetString(stack,2)) == (char*)0) goto exit;
  if ( GetScalarDouble(stack,3,&param3) == FAIL) goto exit; 
  if ( GetScalarDouble(stack,4,&param4) == FAIL) goto exit;
  if ( GetScalarInt(stack,5,&param5) == FAIL) goto exit;
  if ( GetScalarDouble(stack,6,&param6) == FAIL) goto exit;
  if ( GetScalarDouble(stack,7,&param7) == FAIL) goto exit;
  color_img2 = cvCreateImage( cvGetSize(img1), IPL_DEPTH_8U , 3 );
  storage = cvCreateMemStorage(0);
  cvCvtColor( img1, color_img2, CV_GRAY2BGR );
  flag=strcmp(param2,"CV_HOUGH_PROBABILISTIC");
  if (flag==0)
    {
      lines = cvHoughLines2(img1,storage,CV_HOUGH_PROBABILISTIC,param3,CV_PI/param4,param5,param6,param7);
      for( i = 0; i < lines->total; i++ ) 
	{
	  CvPoint* line = (CvPoint*)cvGetSeqElem(lines,i);
	  cvLine( color_img2, line[0], line[1], CV_RGB(255,0,0), 1, CV_AA,0 );
	}
	}  	
  flag=strcmp(param2,"CV_HOUGH_STANDARD");
  if (flag==0)
    {
      lines = cvHoughLines2(img1,storage,CV_HOUGH_STANDARD,param3,CV_PI/param4,param5,param6,param7);
      for( i = 0; i < lines->total; i++ )
	{
	  float* line = (float*)cvGetSeqElem(lines,i);
	  float rho = line[0];
	  float theta = line[1];
	  CvPoint pt1, pt2;
	  double a = cos(theta);
	  double b = sin(theta);
	  if( fabs(a) < 0.001 )
	    {
	      pt1.y = pt2.y = cvRound(rho);
	      pt1.x = 0;
	      pt2.x = color_img2->height;
	    }
	  else if( fabs(b) < 0.001 )
	    {
	      pt1.x = pt2.x = cvRound(rho);
	      pt1.y = 0;
	      pt2.y = color_img2->width;
	    }
	  else
	    {
	      pt1.y = 0;
	      pt1.x = cvRound(rho/b);
	      pt2.y = cvRound(rho/a);
	      pt2.x = 0;
	      //pt2.x = color_img2->width;
	      //pt2.y = pt1.y - color_img2->width * a / b;			
	    }
	  cvLine( color_img2, pt1, pt2, CV_RGB(255,0,0), 1, CV_AA,0 );
	}
    }
  if ( cvGetErrStatus() < 0 )
    {
      cvSetErrStatus( CV_StsOk );
      Scierror("Error:  %s ,  failed \n",NspFname(stack));
      goto exit;
    }

  if((nsp_img = nsp_iplimage_create(NVOID))==NULL) goto exit;
  nsp_img->img = color_img2;
  MoveObj(stack,1,NSP_OBJECT(nsp_img));
  return 1;
 exit:
  if (color_img2) cvReleaseImage( &color_img2 );
  return nsp_ret;    
}

#ifdef __cplusplus
}
#endif
