/***********************************************************************
 * SIVP - Scilab Image and Video Processing toolbox
 * Copyright (C) 2008  Jean-Philippe Chancelier 
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ***********************************************************************/

#include "common.h"

#ifdef __cplusplus
extern "C" {
#endif




int int_cvimcrop(Stack stack, int rhs, int opt, int lhs)
{
  CvMat* src_region;
  NspMatrix *rect; 
  NspIplImage *nsp_img=NULL,*nsp_img_out=NULL;
  IplImage *img2=NULL,*img1=NULL;

  CheckRhs(2,2);
  CheckLhs(1,1);
  
  if ((nsp_img= GetIplImage(stack,1))== NULL) return RET_BUG;
  img1 = nsp_img->img;

  if ((rect=GetRealMat(stack,2)) == NULLMAT ) return FAIL;
  CheckLength(NspFname(stack),2,rect,4);
  
  src_region = cvCreateMatHeader(rect->R[3], rect->R[2], CV_8UC3 ); 
  cvGetSubRect(img1, src_region , cvRect(rect->R[0],rect->R[1],rect->R[2],rect->R[3]));
  img2 = cvCreateImage( cvSize(rect->R[2],rect->R[3]), IPL_DEPTH_8U , 3);
  cvCopy(src_region, img2, NULL);

  if ( cvGetErrStatus() < 0 )
    {
      cvSetErrStatus( CV_StsOk );
      Scierror("Error: Image crop failed\n");
      goto exit;
    }
  
  if((nsp_img_out = nsp_iplimage_create(NVOID))==NULL) goto exit;
  nsp_img_out->img  = img2;
  MoveObj(stack,1,NSP_OBJECT(nsp_img_out));
  return 1;
 exit:
  return RET_BUG;
}

#ifdef __cplusplus
}
#endif

