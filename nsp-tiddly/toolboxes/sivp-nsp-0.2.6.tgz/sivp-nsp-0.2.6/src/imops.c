/*
 * SIVP - Scilab Image and Video Processing toolbox
 * Copyright (C) 2007 Jean-Philippe Chancelier 
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *-------------------------------------------------------------------------*/

#include "common.h"

#ifdef __cplusplus
extern "C" {
#endif


int int_cvadd(Stack stack, int rhs, int opt, int lhs)
{
  double param1;
  int scalar=FALSE;
  NspIplImage *nsp_img1=NULL,*nsp_img2=NULL,*nsp_img_out=NULL;
  IplImage *img2=NULL,*img1=NULL,*img_out=NULL;
  
  CheckRhs(2,2);
  CheckLhs(1,1);
  
  if ((nsp_img1 = GetIplImage(stack,1))== NULL) return RET_BUG;
  img1 = nsp_img1->img;
  if ( IsMatObj(stack,2) )
    {
      scalar=TRUE;
      if ( GetScalarDouble(stack,2,&param1) == FAIL) goto exit;
    }
  else
    {
      if ((nsp_img2= GetIplImage(stack,2))== NULL) return RET_BUG;
      img2 = nsp_img2->img;
      if(( img1->width != img2->width) || (img1->height != img2->height))
	{
	  Scierror("Error:%s: The two input images should have the same size\n",NspFname(stack));
	  goto exit;
	}
      if(img1->nChannels != img2->nChannels)
	{
	  Scierror("Error:%s: The two input images should have same channel numbers\n",NspFname(stack));
	  goto exit;
	}
      if(img1->depth != img2->depth)
	{
	  Scierror("Error:%s: The two input images should have same depth\n",NspFname(stack));
	  goto exit;
	}
    }
  
  if ((img_out = cvCreateImage(cvGetSize(img1), img1->depth, img1->nChannels))==NULL)
    {
      Scierror("Error: can't create the output matrix\n");
      goto exit;
    }
  if ( scalar ) 
    cvAddS(img1, cvScalarAll(param1),img_out,NULL);
  else
    cvAdd(img1, img2, img_out, NULL);
  if ( cvGetErrStatus() < 0 )
    {
      cvSetErrStatus( CV_StsOk );
      Scierror("Error:  %s , cvAdd failed \n",NspFname(stack));
      goto exit;
    }

  if((nsp_img_out = nsp_iplimage_create(NVOID))==NULL) goto exit;
  nsp_img_out->img = img_out;
  MoveObj(stack,1,NSP_OBJECT(nsp_img_out));
  return 1;
 exit: 
  if (img_out) cvReleaseImage( &img_out );
  return RET_BUG;
}

int int_cvsub(Stack stack, int rhs, int opt, int lhs)
{
  double param1;
  int scalar=FALSE;
  NspIplImage *nsp_img1=NULL,*nsp_img2=NULL,*nsp_img_out=NULL;
  IplImage *img2=NULL,*img1=NULL,*img_out=NULL;
  
  CheckRhs(2,2);
  CheckLhs(1,1);
  
  if ((nsp_img1 = GetIplImage(stack,1))== NULL) return RET_BUG;
  img1 = nsp_img1->img;
  if ( IsMatObj(stack,2) )
    {
      scalar=TRUE;
      if ( GetScalarDouble(stack,2,&param1) == FAIL) goto exit;
    }
  else
    {
      if ((nsp_img2= GetIplImage(stack,2))== NULL) return RET_BUG;
      img2 = nsp_img2->img;
      if(( img1->width != img2->width) || (img1->height != img2->height))
	{
	  Scierror("Error:%s: The two input images should have the same size\n",NspFname(stack));
	  goto exit;
	}
      if(img1->nChannels != img2->nChannels)
	{
	  Scierror("Error:%s: The two input images should have same channel numbers\n",NspFname(stack));
	  goto exit;
	}
      if(img1->depth != img2->depth)
	{
	  Scierror("Error:%s: The two input images should have same depth\n",NspFname(stack));
	  goto exit;
	}
    }
  
  if ((img_out = cvCreateImage(cvGetSize(img1), img1->depth, img1->nChannels))==NULL)
    {
      Scierror("Error: can't create the output matrix\n");
      goto exit;
    }
  if ( scalar ) 
    cvSubS(img1, cvScalarAll(param1),img_out,NULL);
  else
    cvSub(img1, img2, img_out, NULL);
  if ( cvGetErrStatus() < 0 )
    {
      cvSetErrStatus( CV_StsOk );
      Scierror("Error:  %s , cvAdd failed \n",NspFname(stack));
      goto exit;
    }

  if((nsp_img_out = nsp_iplimage_create(NVOID))==NULL) goto exit;
  nsp_img_out->img = img_out;
  MoveObj(stack,1,NSP_OBJECT(nsp_img_out));
  return 1;
 exit: 
  if (img_out) cvReleaseImage( &img_out );
  return RET_BUG;
}



int int_cvmul(Stack stack, int rhs, int opt, int lhs)
{
  double param1=1.0;
  int scalar=FALSE;
  NspIplImage *nsp_img1=NULL,*nsp_img2=NULL,*nsp_img_out=NULL;
  IplImage *img2=NULL,*img1=NULL,*img_out=NULL;
  
  CheckRhs(2,2);
  CheckLhs(1,1);
  
  if ((nsp_img1 = GetIplImage(stack,1))== NULL) return RET_BUG;
  img1 = nsp_img1->img;
  if ( IsMatObj(stack,2) )
    {
      scalar=TRUE;
      if ( GetScalarDouble(stack,2,&param1) == FAIL) goto exit;
      img2  = cvCloneImage(img1);
      if ( cvGetErrStatus() < 0 )
	{
	  cvSetErrStatus( CV_StsOk );
	  Scierror("Error: Image clone failed\n");
	  goto exit;
	}
      cvSet(img2, cvScalarAll(1.0), NULL);
    }
  else
    {
      if ((nsp_img2= GetIplImage(stack,2))== NULL) return RET_BUG;
      img2 = nsp_img2->img;
      if(( img1->width != img2->width) || (img1->height != img2->height))
	{
	  Scierror("Error:%s: The two input images should have the same size\n",NspFname(stack));
	  goto exit;
	}
      if(img1->nChannels != img2->nChannels)
	{
	  Scierror("Error:%s: The two input images should have same channel numbers\n",NspFname(stack));
	  goto exit;
	}
      if(img1->depth != img2->depth)
	{
	  Scierror("Error:%s: The two input images should have same depth\n",NspFname(stack));
	  goto exit;
	}
    }

  if ((img_out = cvCreateImage(cvGetSize(img1), img1->depth, img1->nChannels))==NULL)
    {
      Scierror("Error: can't create the output matrix\n");
      goto exit;
    }
  
  cvMul(img1,img2, img_out ,param1);
  if ( cvGetErrStatus() < 0 )
    {
      cvSetErrStatus( CV_StsOk );
      Scierror("Error:  %s , cvAdd failed \n",NspFname(stack));
      goto exit;
    }

  if((nsp_img_out = nsp_iplimage_create(NVOID))==NULL) goto exit;
  nsp_img_out->img = img_out;
  MoveObj(stack,1,NSP_OBJECT(nsp_img_out));
  return 1;
 exit: 
  if (img_out) cvReleaseImage( &img_out );
  if (scalar == TRUE && img2 != NULL)  cvReleaseImage( &img2 );
  return RET_BUG;
}

int int_cvdiv(Stack stack, int rhs, int opt, int lhs)
{
  double param1=1.0;
  int scalar=FALSE;
  NspIplImage *nsp_img1=NULL,*nsp_img2=NULL,*nsp_img_out=NULL;
  IplImage *img2=NULL,*img1=NULL,*img_out=NULL;
  
  CheckRhs(2,2);
  CheckLhs(1,1);
  
  if ((nsp_img1 = GetIplImage(stack,1))== NULL) return RET_BUG;
  img1 = nsp_img1->img;
  if ( IsMatObj(stack,2) )
    {
      scalar=TRUE;
      if ( GetScalarDouble(stack,2,&param1) == FAIL) goto exit;
      img2  = cvCloneImage(img1);
      if ( cvGetErrStatus() < 0 )
	{
	  cvSetErrStatus( CV_StsOk );
	  Scierror("Error: Image clone failed\n");
	  goto exit;
	}
      cvSet(img2, cvScalarAll(1.0), NULL);
    }
  else
    {
      if ((nsp_img2= GetIplImage(stack,2))== NULL) return RET_BUG;
      img2 = nsp_img2->img;
      if(( img1->width != img2->width) || (img1->height != img2->height))
	{
	  Scierror("Error:%s: The two input images should have the same size\n",NspFname(stack));
	  goto exit;
	}
      if(img1->nChannels != img2->nChannels)
	{
	  Scierror("Error:%s: The two input images should have same channel numbers\n",NspFname(stack));
	  goto exit;
	}
      if(img1->depth != img2->depth)
	{
	  Scierror("Error:%s: The two input images should have same depth\n",NspFname(stack));
	  goto exit;
	}
    }

  if ((img_out = cvCreateImage(cvGetSize(img1), img1->depth, img1->nChannels))==NULL)
    {
      Scierror("Error: can't create the output matrix\n");
      goto exit;
    }
  
  cvDiv(img1,img2, img_out ,param1);
  if ( cvGetErrStatus() < 0 )
    {
      cvSetErrStatus( CV_StsOk );
      Scierror("Error:  %s , cvAdd failed \n",NspFname(stack));
      goto exit;
    }

  if((nsp_img_out = nsp_iplimage_create(NVOID))==NULL) goto exit;
  nsp_img_out->img = img_out;
  MoveObj(stack,1,NSP_OBJECT(nsp_img_out));
  return 1;
 exit: 
  if (img_out) cvReleaseImage( &img_out );
  if (scalar == TRUE && img2 != NULL)  cvReleaseImage( &img2 );
  return RET_BUG;
}

#ifdef __cplusplus
}
#endif
