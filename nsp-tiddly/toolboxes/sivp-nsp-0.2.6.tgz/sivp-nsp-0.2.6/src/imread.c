/***********************************************************************
 * SIVP - Scilab Image and Video Processing toolbox
 * Copyright (C) 2005  Vincent Etienne
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ***********************************************************************/

#include "common.h"

#ifdef __cplusplus
extern "C" {
#endif


int int_imread(Stack stack, int rhs, int opt, int lhs)
{
  int nsp_ret=RET_BUG;
  char *nom;
  NspIplImage *nsp_pImage=NULL;
  IplImage *pImage=NULL;
  CheckRhs(1, 1);
  CheckLhs(1, 1);
  if ((nom = GetString(stack,1)) == (char*)0) return RET_BUG;
  if ((pImage = cvLoadImage(nom, -1)) == NULL)
    {
      Scierror("Error: %s Cannot open file %s.\n",NspFname(stack),nom);
      return RET_BUG;
    }
  if ( cvGetErrStatus() < 0 )
    {
      cvSetErrStatus( CV_StsOk );
      Scierror("Error:  %s  failed \n",NspFname(stack));
      goto exit;
    }
  if((nsp_pImage= nsp_iplimage_create(NVOID))==NULL) goto exit;
  nsp_pImage->img = pImage;
  MoveObj(stack,1,NSP_OBJECT(nsp_pImage));
  return 1;
 exit: 
  if (pImage) cvReleaseImage(&pImage);
  return nsp_ret;
}

#ifdef __cplusplus
}
#endif


