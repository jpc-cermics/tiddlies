/***********************************************************************
 * SIVP - Scilab Image and Video Processing toolbox
 * Copyright (C) 2005  Shiqi Yu
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ***********************************************************************/

/* Ported to nsp: Jean-Philippe Chancelier 2005-2006.
 *
 */

#include "common.h"

#ifdef __cplusplus
extern "C" {
#endif

/*
 * this function only supports UINT8, UINT16, INT32, SINGLE, DOUBLE
 * imout=imresize(imin, scale);
 * imout=imresize(imin, scale, interp);
 * imout=imresize(imin, [mrows ncols]);
 * imout=imresize(imin, [mrows ncols], interp);
 * interp = 'nearest', 'bilinear', 'bicubic' or 'area'
 */


int int_imresize(Stack stack, int rhs, int opt, int lhs)
{
  NspMatrix *S;
  char *nom= NULL;
  const char *Table[] = {"nearest","bilinear", "bicubic","area",NULL};
  const int interp[]= {CV_INTER_NN,CV_INTER_LINEAR, CV_INTER_CUBIC, CV_INTER_AREA,0};
  NspIplImage* nsp_img = NULL;
  IplImage *pSrcImg = NULL, *pTmp = NULL, *pDstImg = NULL; 
  int nSrcDepth = 0;
  int Interpolation = CV_INTER_NN; //Interpolation method, default method is nearest neigbor
  int nDestW = 0, nDestH = 0;

  CheckRhs(2, 3);
  CheckLhs(1, 1);

  if ((nsp_img= GetIplImage(stack,1))== NULL) 
    return RET_BUG; 
  pSrcImg = nsp_img->img;

  /* size for destination image
   */
  if ((S = GetRealMat(stack,2)) == NULLMAT) return RET_BUG; 

  if( S->m == 1 && S->n == 1)
    {
      nDestW = cvRound(pSrcImg->width * S->R[0]);
      nDestH = cvRound(pSrcImg->height *S->R[0]);
    }
  else if( S->mn  == 2)
    {
      nDestW = cvRound(S->R[0]);
      nDestH = cvRound(S->R[1]);
    }
  else
    {
      Scierror("Error: The second parameter of %s should be a double or a vector of size 2\r\n",  NspFname(stack));
      return RET_BUG;
    }
  
  if( rhs == 3)
    {
      int ret;
      /* interpolation method */
      if ((nom = GetString(stack,3)) == (char*)0) goto exit;
      ret = is_string_in_array(nom,Table,1);
      if ( ret < 0 ) 
	{
	  string_not_in_array(stack,nom,Table,"third argument");
	  goto exit;
	}
      Interpolation = interp[ret];
    }

  nSrcDepth = pSrcImg->depth;
  /* 
   * if the input image is of INT32 or DOUBLE class convert to FLOAT first
   */
  if( nSrcDepth==IPL_DEPTH_32S || nSrcDepth==IPL_DEPTH_64F)
    {
      pTmp = cvCreateImage(cvSize(pSrcImg->width, pSrcImg->height),
			   IPL_DEPTH_32F, pSrcImg->nChannels);
      if(pTmp == NULL)
	{
	  Scierror("Error: Internal error in %s when trying to create an image\n",  NspFname(stack));
	  return RET_BUG;
	}
      cvConvert(pSrcImg, pTmp);
      pSrcImg = pTmp;
    }
  

  /* check whether the width and height of destination image is valid. 
   */

  if(nDestW <=0 || nDestH <=0)
    {
      Scierror("Error: given size in function %s (%d,%d) is invalid.\n",  NspFname(stack),nDestW, nDestH );
      goto exit; 
    }

  pDstImg = cvCreateImage(cvSize(nDestW, nDestH), pSrcImg->depth,  pSrcImg->nChannels);

  if(pDstImg == NULL)
    {
      Scierror("Error: Internal error in %s when trying to create an image\n",  NspFname(stack));
      goto exit; 
    }

  cvResize(pSrcImg, pDstImg, Interpolation);

  /* convert the depth to original depth
   */
  if(nSrcDepth != pDstImg->depth)
    {
      IplImage *pTmp1 = NULL;
      pTmp1 = cvCreateImage(cvSize(pDstImg->width, pDstImg->height), nSrcDepth, pDstImg->nChannels);
      if(pTmp1 == NULL)
	{
	  Scierror("Error: Internal error in %s when trying to create an image\n",  NspFname(stack));
	  goto exit; 
	}
      cvConvert(pDstImg, pTmp1);
      cvReleaseImage(&pDstImg);
      pDstImg = pTmp1;
    }
  
  if((nsp_img = nsp_iplimage_create(NVOID))==NULL) goto exit;
  nsp_img->img = pDstImg  ;
  MoveObj(stack,1,NSP_OBJECT(nsp_img));
  if (pTmp) cvReleaseImage( &pTmp );
  return 1;
 exit:
  if (pTmp) cvReleaseImage( &pTmp );
  if (pDstImg) cvReleaseImage(&pDstImg);
  return RET_BUG;
}
#ifdef __cplusplus
}
#endif
