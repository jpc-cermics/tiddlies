/***********************************************************************
 * SIVP - Scilab Image and Video Processing toolbox
 * Copyright (C) 2005  Vincent Etienne
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ***********************************************************************/

/* Ported to nsp: Jean-Philippe Chancelier 2005-2008.
 *
 */

#include "common.h"

#ifdef __cplusplus
extern "C" {
#endif

  /* should be merged with int_meth_imshow in ipmlimageobj.c */

int int_imshow(Stack stack, int rhs, int opt, int lhs)
{
  char def_name[] ="Image view", *name = def_name;
  int autosize= TRUE;
  int flags=CV_WINDOW_AUTOSIZE;
  nsp_option opts[] ={{"autosize",s_bool,NULLOBJ,-1},
		      {"name",string,NULLOBJ,-1},
		      { NULL,t_end,NULLOBJ,-1}};

  NspIplImage *nsp_img1=NULL;
  IplImage *img1=NULL;
  CheckStdRhs(1,1);
  CheckLhs(0,0);
  if ((nsp_img1= GetIplImage(stack,1))== NULL) goto exit;  

  if ( get_optional_args(stack, rhs, opt, opts, &autosize, &name) == FAIL )
    return RET_BUG;

  img1 = nsp_img1->img;
  /*
   * cvShowImage seams to work only with IPL_DEPTH_8U
   */
  if( img1->nChannels != 1 && img1->nChannels != 3 && img1->nChannels != 4 )
    {
      Scierror( "Error: %s only single-channel or 3-channels images, or 4-channels images.\n", NspFname(stack));
      goto exit;
    }  
  if(img1->depth != IPL_DEPTH_8U)
    {
      IplImage  *pDstImage=NULL;
      double dScale = 1.0, dShift = 0.0;
      pDstImage = cvCreateImage(cvSize(img1->width, img1->height), IPL_DEPTH_8U, img1->nChannels);
      if(pDstImage == NULL)
	{
	  Scierror("%f: Create IplImage error\n",NspFname(stack));
	  goto exit ;
	}
      cvConvertScale(img1, pDstImage, dScale, dShift);
      img1 = pDstImage;
    }
  cvNamedWindow( name, (autosize == TRUE) ? flags: 0 );
  cvShowImage(name, img1 );
  cvWaitKey(1); /* event processing loop inside */
  /* release extra copy */
  if ( img1 != nsp_img1->img) cvReleaseImage(&img1);
  return 0;
 exit:
  return RET_BUG;
}

#ifdef __cplusplus
}
#endif


