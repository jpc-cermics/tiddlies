/***********************************************************************
 * SIVP - Scilab Image and Video Processing toolbox
 * Copyright (C) 2005  Vincent Etienne
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ***********************************************************************/

/* Ported to nsp: Jean-Philippe Chancelier 2005-2006.
 *
 */

#include "common.h"

#ifdef __cplusplus
extern "C" {
#endif

int int_imsmooth(Stack stack, int rhs, int opt, int lhs)
{
  const char *Table[] = {"BLUR", "BLUR_NO_SCALE","GAUSSIAN","BILATERAL","MEDIAN",NULL};
  const int op[]={CV_BLUR ,CV_BLUR_NO_SCALE,CV_GAUSSIAN ,CV_BILATERAL,CV_MEDIAN};

  char * nom = NULL;
  int param1=3,param2=0,nsp_ret = RET_BUG,ret;
  double  param3=0,param4=0;
  IplImage *img1=NULL, *img2 = NULL;
  NspIplImage *nsp_img=NULL;
  CheckRhs(5,6);
  CheckLhs(1,1);

  if ((nsp_img= GetIplImage(stack,1))== NULL) goto exit;
  img1 = nsp_img->img;
  if ((nom = GetString(stack,2)) == (char*)0) goto exit;
  if ( GetScalarInt(stack,3,&param1) == FAIL) goto exit;
  if ( GetScalarInt(stack,4,&param2) == FAIL) goto exit;
  if ( GetScalarDouble(stack,5,&param3) == FAIL) goto exit;
  if ( rhs == 6 ) 
    {
      if ( GetScalarDouble(stack,6,&param4) == FAIL) goto exit;
    }
  ret = is_string_in_array(nom,Table,1);
  if ( ret < 0 ) 
    {
      string_not_in_array(stack,nom,Table,"second argument");
      goto exit;
    }

  if ((img2=cvCreateImage(cvGetSize(img1),img1->depth,img1->nChannels))==NULL)
    {
      Scierror("Error: can't create the output matrix\n");
      goto exit;
    }
  cvSmooth( img1, img2 , op[ret] ,param1,param2,param3,param4);
  if ( cvGetErrStatus() < 0 )
    {
      cvSetErrStatus( CV_StsOk );
      Scierror("Error:  %s , cvSmooth failed \n",NspFname(stack));
      goto exit;
    }

  if((nsp_img = nsp_iplimage_create(NVOID))==NULL) goto exit;
  nsp_img->img = img2;
  MoveObj(stack,1,NSP_OBJECT(nsp_img));
  return 1;
 exit:
  if ( img2) cvReleaseImage( &img2 );
  return nsp_ret;
}
#ifdef __cplusplus
}
#endif
