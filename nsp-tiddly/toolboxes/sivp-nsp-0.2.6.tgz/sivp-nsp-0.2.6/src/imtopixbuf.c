/***********************************************************************
 * SIVP - Scilab Image and Video Processing toolbox
 * iplimage and GdkPixbuf
 * Copyright (C) 2005-2008  Jean-Philippe Chancelier 
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ***********************************************************************/

#include "common.h"

#ifdef __cplusplus
extern "C" {
#endif

#include "nsp/gtk/gdkpixbuf.h"

/* Converts an iplimage to a pixbuf 
 * the iplimage is first converted to a RBG8U image 
 */

int int_imtopixbuf(Stack stack, int rhs, int opt, int lhs)
{
  int nChannels,nsp_ret= RET_BUG;
  NspObject *ret;
  guchar *pixels;
  GdkPixbuf* pix=NULL;
  NspIplImage *nsp_pImage;
  CvMat* image;

  CheckRhs(1, 1);
  CheckLhs(1, 1);

  if ((nsp_pImage= GetIplImage(stack,1))== NULL) return RET_BUG;
  image = cvCreateMat( nsp_pImage->img->width, nsp_pImage->img->height, CV_8UC3 );
  if ( image == NULL ||  cvGetErrStatus() < 0 )
    {
      cvSetErrStatus( CV_StsOk );
      Scierror("Error:  %s , cvCreateMat failed \n",NspFname(stack));
      goto exit;
    }
  cvConvertImage(nsp_pImage->img, image, CV_CVTIMG_SWAP_RB );
  if ((pix = gdk_pixbuf_new(GDK_COLORSPACE_RGB,FALSE, 8,nsp_pImage->img->width,
			    nsp_pImage->img->height)) == NULL) 
    {
      Scierror("Error: %f error in pixbuf new\n",NspFname(stack));
      goto exit;
    }
  
  /* rowstride = gdk_pixbuf_get_rowstride (pix); */
  pixels = gdk_pixbuf_get_pixels (pix);
  nChannels = 3;
  memcpy(pixels,image->data.ptr,nsp_pImage->img->height*nsp_pImage->img->width*nChannels);
  nsp_type_gdkpixbuf = new_type_gdkpixbuf(T_BASE);
  if ((ret = (NspObject *) gobject_create(NVOID,(GObject *)pix, (NspTypeBase *) nsp_type_gdkpixbuf))== NULL) 
    goto exit;
  MoveObj(stack,1,ret);
  nsp_ret = 1;
 exit: 
  if (nsp_ret != 1 && pix != NULL ) g_object_unref (pix);
  if (image) cvReleaseMat( &image );
  return nsp_ret;
}  


/* Converts a pixbuf to iplimage 
 * the pixbuf can have an alpha channel.
 */

int int_pixbuftoim(Stack stack, int rhs, int opt, int lhs)
{
  int code3[]={2,1,0}, code4[]={2,1,0,3}, *code;
  int width, height, rowstride, n_channels,ch,col,row;
  guchar *pixels, *p, *pSrc;
  int nsp_ret= RET_BUG;
  GdkPixbuf *pixbuf;
  NspGObject *nsp_pixbuf = NULL;
  NspIplImage *nsp_img;
  IplImage *pImage;

  CheckRhs(1, 1);
  CheckLhs(1, 1);

  if ((nsp_pixbuf = GetGObject(stack,1)) == NULL) return RET_BUG; 
  if ( !nspgobject_check(nsp_pixbuf,(NspTypeBase *) nsp_type_gdkpixbuf)) { 
    Scierror("first argument should be a GdkPixbuf\n");
    return RET_BUG;
  }
  pixbuf = GDK_PIXBUF(nsp_pixbuf->obj);
  n_channels = gdk_pixbuf_get_n_channels (pixbuf);
  width = gdk_pixbuf_get_width (pixbuf);
  height = gdk_pixbuf_get_height (pixbuf);
  rowstride = gdk_pixbuf_get_rowstride (pixbuf);
  pixels = gdk_pixbuf_get_pixels (pixbuf);

  pImage = cvCreateImage(cvSize(width,height),IPL_DEPTH_8U,n_channels);
  if ( pImage == NULL ||  cvGetErrStatus() < 0 )
    {
      cvSetErrStatus( CV_StsOk );
      Scierror("Error:  %s , cvCreateMat failed \n",NspFname(stack));
      return RET_BUG;
    }

  pSrc = (guchar*) pImage->imageData;

  code = (n_channels==3) ? code3: code4;

  for(ch = 0; ch < n_channels ; ch++) //the order of IplImage is BGR  
    for(col =0; col < width; col++)
      for(row = 0; row < height; row++)
	{
	  unsigned char *c= pSrc + pImage->widthStep*row + (col*n_channels + code[ch]);
	  p =  pixels + row * rowstride + col * pImage->nChannels;
	  *c = *(p+ch);
	}
  if((nsp_img = nsp_iplimage_create(NVOID))==NULL) goto exit;
  nsp_img->img = pImage;
  MoveObj(stack,1,NSP_OBJECT(nsp_img));
  return 1;
 exit:
  if ( pImage ) cvReleaseImage(&pImage);
  return nsp_ret;
}  
  


#ifdef __cplusplus
}
#endif
