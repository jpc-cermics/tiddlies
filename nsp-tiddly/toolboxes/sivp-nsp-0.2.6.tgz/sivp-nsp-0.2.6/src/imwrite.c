/***********************************************************************
 * SIVP - Scilab Image and Video Processing toolbox
 * Copyright (C) 2005  Vincent Etienne
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ***********************************************************************/

/* Ported to nsp: Jean-Philippe Chancelier 2005-2006.
 *
 */

#include "common.h"

#ifdef __cplusplus
extern "C" {
#endif

/************************************************************
 * write an image to a file
 * the first argument should be a matrix; only 8-bit single-channel or 3-channel can be saved.
 * other formats will be converted to one of these formats
 * the second argument should be the file name 
 * the format of the file is decided by the file name
 * return 0 if succeed, -1 otherwise

 * Attention fomat 8U 1,3 or 4 channels and BGR mode 
 * voir le man faire un cvCvtColor sinon 
 *
 ************************************************************/

int int_imwrite(Stack stack, int rhs, int opt, int lhs)
{
  int zero=0;
  int ret,nsp_ret = RET_BUG;
  NspIplImage *nsp_pImage=NULL;
  IplImage *pImage=NULL;
  double dScale = 1.0, dShift = 0.0;
  char *nom;
  CheckRhs(2, 2);
  CheckLhs(1, 1);

  if ((nsp_pImage= GetIplImage(stack,1))== NULL) return RET_BUG;
  pImage = nsp_pImage->img;
  if ((nom = GetString(stack,2)) == (char*)0) goto exit;
  
  if( pImage->nChannels != 1 && pImage->nChannels != 3)
    {
      Scierror( "%s: Single-channel or 3-channel can be saved.\n", NspFname(stack));
      goto exit;
    }

  if(pImage->depth != IPL_DEPTH_8U)
    {
      IplImage *pDstImage=NULL;
      pDstImage = cvCreateImage(cvSize(pImage->width, pImage->height), IPL_DEPTH_8U, pImage->nChannels);
      if(!pDstImage)
	{
	  Scierror("%f: Create IplImage error\n",NspFname(stack));
	  goto exit;
	}
      cvConvertScale(pImage, pDstImage, dScale, dShift);
      pImage = pDstImage;
    }
#if 0
  ret = cvSaveImage(nom, pImage);
#else 
  ret = cvSaveImage(nom, pImage, &zero);
#endif 
  if ( cvGetErrStatus() < 0 )
    {
      cvSetErrStatus( CV_StsOk );
      Scierror("Error:  %s , cvSaveImage failed \n",NspFname(stack));
      goto exit;
    }
  if ( nsp_move_double(stack,1,(double) ret)==FAIL) goto exit;
  nsp_ret =1;
 exit:
  if ( pImage != nsp_pImage->img ) cvReleaseImage(&pImage);
  return nsp_ret;
}

#ifdef __cplusplus
}
#endif
