#ifndef NSP_INC_IPLIMAGE
#define NSP_INC_IPLIMAGE

/*
 * This Software is GPL (Copyright ENPC 1998-2005) 
 * Jean-Philippe Chancelier Enpc/Cermics         
 */

#include "nsp/sciio.h" 
#include "nsp/object.h"
#include "nsp/xdr.h"
#include <cv.h>
#include <cxcore.h>

/*
 * NspIplImage inherits from NspObject 
 */

typedef struct _NspIplImage NspIplImage;

typedef struct _NspTypeIplImage { 
  NSP_TYPE_OBJECT__ 
  /*< public >*/
} NspTypeIplImage;

struct _NspIplImage {
  /*< private >*/
  NspObject father; 
  NspTypeIplImage *type; 
  /*< public >*/
  IplImage *img;
};

extern int nsp_type_iplimage_id;
extern NspTypeIplImage *nsp_type_iplimage;

NspTypeIplImage *new_type_iplimage(type_mode mode);

NspIplImage *nsp_new_iplimage();

/*
 * Object methods redefined for file 
 */

extern NspIplImage *nsp_iplimage_create(const char *name);
extern NspIplImage *nsp_iplimage_copy(NspIplImage *H);
extern void nsp_iplimage_destroy(NspIplImage *H);
extern int nsp_iplimage_info(NspIplImage *H, int indent,char *name, int rec_level);
extern int nsp_iplimage_print(NspIplImage *H, int indent,char *name, int rec_level);

#define NULLIPLIMAGE (NspIplImage *) 0

/* IplImageObj.c */

extern NspIplImage *nsp_iplimage_object(NspObject *O);
extern int IsIplImageObj (Stack stack, int i);
extern NspIplImage *GetIplImageCopy (Stack stack, int i);
extern NspIplImage *GetIplImage (Stack stack, int i);

#endif 

#ifdef IplImage_Private 
static int nsp_init_iplimage(NspIplImage *ob,NspTypeIplImage *type);
static int nsp_iplimage_size(NspIplImage *Mat, int flag);
static char *nsp_iplimage_type_as_string(void);
static char *nsp_iplimage_type_short_string(NspObject *v);
static int nsp_iplimage_eq(NspObject *A, NspObject *B);
static int nsp_iplimage_neq(NspObject *A, NspObject *B);
static NspMethods *nsp_iplimage_get_methods(void);
static AttrTab nsp_iplimage_attrs[];
#endif 
