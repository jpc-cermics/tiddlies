/* Nsp
 * Copyright (C) 2005 Jean-Philippe Chancelier Enpc/Cermics
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public
 * License along with this library; if not, write to the
 * Free Software Foundation, Inc., 59 Temple Place - Suite 330,
 * Boston, MA 02111-1307, USA.
 *
 * Interface with the opencv library. 
 *
 */


#include "common.h"

#ifdef __cplusplus
extern "C" {
#endif

#define IplImage_Private 
#include <nsp/nsp.h>
#include "nsp/object.h"
#include "nsp/pr-output.h" 
#include "nsp/interf.h"
#include "nsp/matutil.h"
#include "iplimage.h" 

/*
 * NspIplImage inherits from NspObject 
 */

int nsp_type_iplimage_id=0;
NspTypeIplImage *nsp_type_iplimage=NULL;

NspTypeIplImage *new_type_iplimage(type_mode mode)
{
  NspTypeIplImage *type = NULL;
  NspTypeObject *top;
  if ( nsp_type_iplimage != 0 && mode == T_BASE )
    {
      /* initialization performed and T_BASE requested */
      return nsp_type_iplimage;
    }
  if (( type = (NspTypeIplImage *) malloc(sizeof(NspTypeIplImage)))== NULL) return NULL;
  type->interface = NULL;
  type->surtype =(NspTypeBase *) new_type_object(T_DERIVED);
  if ( type->surtype == NULL) return NULL;
  type->attrs = nsp_iplimage_attrs ;
  type->get_attrs = (attrs_func *) int_get_attribute; 
  type->set_attrs = (attrs_func *) int_set_attribute; 
  type->methods =nsp_iplimage_get_methods; 
  type->new = (new_func *)nsp_new_iplimage;

  top = NSP_TYPE_OBJECT(type->surtype);
  while ( top->surtype != NULL ) top= NSP_TYPE_OBJECT(top->surtype);

  /* object methods redefined for iplimage */ 

  top->pr = (print_func *)nsp_iplimage_print;	              /* printing */   
  top->dealloc = (dealloc_func *)nsp_iplimage_destroy;           /* dealloc */  
  top->copy  =  (copy_func *)nsp_iplimage_copy;                  /* copy object */  
  top->size  = (size_func *)nsp_iplimage_size;                   /* m,n or m*n  */  
  top->s_type =  (s_type_func *)nsp_iplimage_type_as_string;               /* type as a String */  
  top->sh_type = (sh_type_func *)nsp_iplimage_type_short_string;           /* type as a short string */  
  top->info = (info_func *)nsp_iplimage_info;                    /* info */  
  /* top->is_true = (is_true_func  *) iplimage_IsTrue;  */         /* check if object can be considered as true */  
  /*top->loop =(loop_func *) iplimage_LoopExtract;     */	/* for loops */  
  top->path_extract =  NULL;					/* used for x(1)(2)(...) */  
  top->get_from_obj = (get_from_obj_func *)nsp_iplimage_object;    	/* get object stored in SciObj */  
  top->eq  = (eq_func *)nsp_iplimage_eq;			/* equality check */  
  top->neq  = (eq_func *)nsp_iplimage_neq;		        /* non-equality check */

  /* specific methods for iplimage */
  type->init = (init_func *)nsp_init_iplimage;

  /* 
   * interfaces can be added here 
   * type->interface = (NspTypeBase *) new_type_b();
   * type->interface->interface = (NspTypeBase *) new_type_C()
   * ....
   */
  
  if ( nsp_type_iplimage_id == 0 ) 
    {
      /* 
       * the first time we get here we initialize the type id and
       * an instance of NspTypeMatrix called nsp_type_iplimage
       */
      type->id =  nsp_type_iplimage_id = nsp_new_type_id();
      nsp_type_iplimage = type;
      if ( nsp_register_type(nsp_type_iplimage) == FALSE) return NULL;
      return ( mode == T_BASE ) ? type : new_type_iplimage(mode);
    }
  else 
    {
      type->id = nsp_type_iplimage_id;
      return type;
    }
}
/*
 * initialize Scifile instances 
 * locally and by calling initializer on parent class 
 */

static int nsp_init_iplimage(NspIplImage *o,NspTypeIplImage *type)
{
  /* to be done always */ 
  if ( type->surtype->init(&o->father,type->surtype) == FAIL) return FAIL;
  o->type = type; 
  NSP_OBJECT(o)->basetype = (NspTypeBase *)type;
  /* specific */
  return OK;
}

/*
 * new instance of IplImage 
 */

NspIplImage *nsp_new_iplimage() 
{
  NspIplImage *loc; 
  /* type must exists */
  nsp_type_iplimage = new_type_iplimage(T_BASE);
  if ( (loc = (NspIplImage *) malloc(sizeof(NspIplImage)))== NULLIPLIMAGE) return loc;
  /* initialize object */
  if (nsp_init_iplimage(loc,nsp_type_iplimage) == FAIL) return NULLIPLIMAGE;
  return loc;
}

/*----------------------------------------------
 * Object method redefined for iplimage 
 *-----------------------------------------------*/

/*
 * size 
 */

static int nsp_iplimage_size(NspIplImage  *H, int flag)
{
  return 0;
}

/*
 * type as string 
 */

static char nsp_iplimage_type_name[]="IplImage";
static char nsp_iplimage_short_type_name[]="iplim";

static char *nsp_iplimage_type_as_string(void)
{
  return(nsp_iplimage_type_name);
}

static char *nsp_iplimage_type_short_string(NspObject *v)
{
  return(nsp_iplimage_short_type_name);
}


static int nsp_iplimage_eq(NspObject *A, NspObject *B)
{
  if (check_cast (B, nsp_type_iplimage_id) == FALSE)     return FALSE;
  return ((NspIplImage *) A)->img == ((NspIplImage *) B)->img ? TRUE: FALSE;
}

static int nsp_iplimage_neq(NspObject *A, NspObject *B)
{
  if (check_cast (B, nsp_type_iplimage_id) == FALSE)     return TRUE;
  return ((NspIplImage *) A)->img != ((NspIplImage *) B)->img ? TRUE: FALSE;
}

/*
 * delete 
 */

void nsp_iplimage_destroy(NspIplImage  *F)
{
  cvReleaseImage(&F->img);
  FREE(F) ;
}

/*
 * info 
 */


static const char *iplimage_depth_to_string(int depth);


int nsp_iplimage_info(NspIplImage  *F, int indent,char *name,int rec_level)
{
  const char *pname = (name != NULL) ? name : NSP_OBJECT(F)->name;
  int i;
  for ( i=0 ; i < indent ; i++) Sciprintf(" ");
  if (user_pref.pr_as_read_syntax)
    {
      Sciprintf("error('Cannot print an image as_read\n')\n");
    }
  else 
    {
      Sciprintf("%s\t=\t\tipl %s (%dx%d)\n",pname,
		iplimage_depth_to_string(F->img->depth),
		F->img->height,F->img->width);
    }
  return TRUE;
}


/*
 * print 
 */

int nsp_iplimage_print(NspIplImage  *F, int indent,char *name, int rec_level)
{
  nsp_iplimage_info(F, indent,name,rec_level);
  return TRUE;
}


static const char *iplimage_depth_to_string(int depth)
{
  switch(depth) 
    {
    case IPL_DEPTH_8U: return "8u";
    case IPL_DEPTH_8S: return "8s";
    case IPL_DEPTH_16U:return "16u";
    case IPL_DEPTH_16S:return "16s";
    case IPL_DEPTH_32S:return "32s";
    case IPL_DEPTH_32F:return "32f";
    case IPL_DEPTH_64F:return "64f";
    default: 
      return "";
    }
}

/*-----------------------------------------------------
 * a set of functions used when writing interfaces 
 * for Hash objects 
 * Note that some of these functions could become MACROS XXXXX 
 *-----------------------------------------------------*/

NspIplImage  *nsp_iplimage_object(NspObject *O)
{
  /* Follow pointer **/
  HOBJ_GET_OBJECT(O,NULL);
  /* Check type **/
  if ( check_cast(O,nsp_type_iplimage_id) == TRUE) return ((NspIplImage *) O);
  else 
    Scierror("Error:\tArgument should be a %s\n",type_get_name(nsp_type_iplimage));
  return(NULL);
}


int IsIplImageObj(Stack stack, int i)
{
  return nsp_object_type(NthObj(i) , nsp_type_iplimage_id);
}

int IsIplImage(NspObject *obj)
{
  return nsp_object_type(obj, nsp_type_iplimage_id);
}

NspIplImage *GetIplImageCopy(Stack stack, int i)
{
  if (  GetIplImage(stack,i) == NULL ) return NULL;
  return (NspIplImage *) MaybeObjCopy(&NthObj(i));
}

NspIplImage *GetIplImage(Stack stack, int i)
{
  NspIplImage *M;
  if (( M =nsp_iplimage_object(NthObj(i))) == NULLIPLIMAGE  )
    ArgMessage(stack,i);
  return M;
}

/*-----------------------------------------------------
 * constructor 
 *-----------------------------------------------------*/

NspIplImage *nsp_iplimage_create(const char *name)
{
  NspIplImage *F =nsp_new_iplimage() ;
  if ( F == NULLIPLIMAGE) 
    {
      Scierror("Error:\tRunning out of memory\n");
      return NULLIPLIMAGE;
    }
  /* shared by all objects */
  if ( nsp_object_set_initial_name(NSP_OBJECT(F),name) == NULL)
    return(NULLIPLIMAGE);
  NSP_OBJECT(F)->ret_pos = -1 ; 
  F->img = NULL;
  return(F);
}

/*
 * copy: cloning image 
 */

NspIplImage *nsp_iplimage_copy(NspIplImage  *A)
{
  NspIplImage *F = nsp_iplimage_create(NVOID);
  if ( F == NULLIPLIMAGE) 
    {
      Scierror("Error:\tRunning out of memory\n");
      return NULLIPLIMAGE;
    }
  F->img  = cvCloneImage(A->img);
  if ( cvGetErrStatus() < 0 )
    {
      cvSetErrStatus( CV_StsOk );
      Scierror("Error: image copy failed\n");
      return NULLIPLIMAGE;
    }
  if ( F->img == NULL) 
    {
      Scierror("Error: image copy failed\n");
      return NULLIPLIMAGE;
    }
  return F;
}

/*------------------------------------------------------
 * attributes  (set/get methods) 
 *------------------------------------------------------*/

static NspObject * int_iplimage_get_width(void *Hv,const char *attr)
{
  return nsp_create_object_from_double(NVOID,((NspIplImage *) Hv)->img->width);
}

static NspObject * int_iplimage_get_height(void *Hv,const char *attr)
{
  return nsp_create_object_from_double(NVOID,((NspIplImage *) Hv)->img->height);
}

static NspObject * int_iplimage_get_bytes_per_pixel(void *Hv,const char *attr)
{
  int nBytes = ((NspIplImage *) Hv)->img->depth;
  if (nBytes > IPL_DEPTH_SIGN)
    nBytes -= IPL_DEPTH_SIGN;
  nBytes = nBytes >> 3;
  return nsp_create_object_from_double(NVOID,8*nBytes);
}

static NspObject * int_iplimage_get_nchannels(void *Hv,const char *attr)
{
  return nsp_create_object_from_double(NVOID,((NspIplImage *) Hv)->img->nChannels);
}

static int int_iplimage_set_void(void *Hv,const char *attr, NspObject *O)
{
  Scierror("Error: attribute of iplimage objects cannot be changed after creation\n");
  return FAIL;
}

static AttrTab nsp_iplimage_attrs[] = {
  {"width", int_iplimage_get_width, int_iplimage_set_void,NULL,NULL},
  {"height", int_iplimage_get_height, int_iplimage_set_void,NULL,NULL},
  {"nchannels", int_iplimage_get_nchannels, int_iplimage_set_void,NULL,NULL},
  {"bytes_per_pixel", int_iplimage_get_bytes_per_pixel, int_iplimage_set_void,NULL,NULL},
  { (char *) 0, NULL}
};


/*------------------------------------------------------
 * methods 
 *------------------------------------------------------*/


/*
 * f.show[] or f.show["window-name"]
 */

int int_meth_imshow(void *self,Stack stack, int rhs, int opt, int lhs)
{
  int autosize= TRUE;
  int flags=CV_WINDOW_AUTOSIZE;
  nsp_option opts[] ={{"autosize",s_bool,NULLOBJ,-1},
		      {"name",string,NULLOBJ,-1},
		      { NULL,t_end,NULLOBJ,-1}};
  char def_name[] ="Image view", *name = def_name;
  NspIplImage *obj= (NspIplImage *) self;
  IplImage *img1 = NULL;
  CheckStdRhs(0,0);
  CheckLhs(0,0);

  if ( get_optional_args(stack, rhs, opt, opts, &autosize, &name) == FAIL )
    return RET_BUG;

  /*
   * cvShowImage seams to work only with IPL_DEPTH_8U
   */

  img1 = obj->img;

  if( img1->nChannels != 1 && img1->nChannels != 3 && img1->nChannels != 4  )
    {
      Scierror( "Error: %s only single-channel, or 3-channels, or 4-channels images.\n", NspFname(stack));
      goto exit;
    }  
  if( img1->depth != IPL_DEPTH_8U)
    {
      IplImage  *pDstImage=NULL;
      double dScale = 1.0, dShift = 0.0;
      pDstImage = cvCreateImage(cvSize(img1->width, img1->height), IPL_DEPTH_8U, img1->nChannels);
      if(pDstImage == NULL)
	{
	  Scierror("%f: Create IplImage error\n",NspFname(stack));
	  goto exit ;
	}
      cvConvertScale(img1, pDstImage, dScale, dShift);
      img1 = pDstImage;
    }
  cvNamedWindow( name, (autosize == TRUE) ? flags: 0 );
  cvShowImage(name, img1 );
  cvWaitKey(1); /* very important, contains event processing loop inside 
		 * release extra copy */
  if ( img1 !=obj->img ) cvReleaseImage(&img1);
  return 0;
 exit:
  return RET_BUG;
}

/*
 * f.delete_imview[] 
 */

int int_meth_delete_imview(void *self,Stack stack, int rhs, int opt, int lhs)
{
  char def_name[] ="Image view", *name = def_name;
  CheckRhs(0,1);
  CheckLhs(0,0);
  if ( rhs == 1)
    {
      if ((name = GetString(stack,1)) == (char*)0) return RET_BUG;
    }
  cvDestroyWindow(name);
  return 0;
}

int int_meth_imwrite(void *self,Stack stack, int rhs, int opt, int lhs)
{
  int zero=0;
  NspIplImage *obj= (NspIplImage *) self;
  int ret,nsp_ret = RET_BUG;
  IplImage *pImage=NULL;
  double dScale = 1.0;
  double dShift = 0.0;
  char *nom;
  CheckRhs(1,1);
  CheckLhs(0,1);

  if ((nom = GetString(stack,1)) == (char*)0) goto exit;

  pImage =  obj->img;

  if( pImage->nChannels != 1 && pImage->nChannels != 3 && pImage->nChannels != 4)
    {
      Scierror( "%s: Single-channel or 3-channel can be saved.\n", NspFname(stack));
      goto exit;
    }

  if(pImage->depth != IPL_DEPTH_8U)
    {
      IplImage *pDstImage = cvCreateImage(cvSize(pImage->width, pImage->height), IPL_DEPTH_8U, pImage->nChannels);
      if(!pDstImage)
	{
	  Scierror("%f: Create IplImage error\n",NspFname(stack));
	  goto exit;
	}
      cvConvertScale(pImage, pDstImage, dScale, dShift);
      pImage = pDstImage;
    }
#if 0
  ret = cvSaveImage(nom, pImage);
#else 
  ret = cvSaveImage(nom, pImage,&zero);
#endif 
  if ( cvGetErrStatus() < 0 )
    {
      cvSetErrStatus( CV_StsOk );
      Scierror("Error:  %s , cvSaveImage failed \n",NspFname(stack));
      goto exit;
    }
  if ( nsp_move_double(stack,1,(double) ret)==FAIL) goto exit;
  nsp_ret =1;
 exit:
  if ( pImage !=obj->img ) cvReleaseImage(&pImage);
  return nsp_ret;
}


int int_meth_get_channels(void *self,Stack stack, int rhs, int opt, int lhs)
{
  NspCells *C;
  NspIplImage *obj= (NspIplImage *) self;
  CheckRhs(0,0);
  CheckLhs(0,1);

  if ((C = sivp_iplimage_to_nsp_cells(obj->img))==NULL) 
    {
      Scierror( "Error: %s get channels failed\n", NspFname(stack));
      return RET_BUG;
    }
  MoveObj(stack,1,NSP_OBJECT(C));
  return 1;
}

int int_meth_get_channel(void *self,Stack stack, int rhs, int opt, int lhs)
{
  NspMatrix *M;
  NspIplImage *obj= (NspIplImage *) self;
  int channel;

  CheckRhs(1,1);
  CheckLhs(0,1);
  if ( GetScalarInt(stack,1,&channel) == FAIL) return RET_BUG;
  if ( channel < 1 || channel > obj->img->nChannels )
    {
      Scierror( "Error: %s channel number %d does not exists\n", NspFname(stack),channel);
      return RET_BUG;
    }
  if ((M = sivp_iplimage_get_channel(obj->img,channel))==NULL) 
    {
      Scierror( "Error: %s get channels failed\n", NspFname(stack));
      return RET_BUG;
    }
  MoveObj(stack,1,NSP_OBJECT(M));
  return 1;
}

/* void cvRectangle( CvArr* img, CvPoint pt1, CvPoint pt2, CvScalar color,
 *                int thickness=1, int line_type=8, int shift=0 );
 * line_type = 8, 4 or CV_AA (antialiasing).
 * For non-antialiased lines with integer coordinates the 8-connected 
 * or 4-connected Bresenham algorithm is used. 
 * Thick lines are drawn with rounding endings. 
 * Antialiased lines are drawn using Gaussian filtering. 
 * To specify the line color, the user may use the macro CV_RGB( r, g, b ).
 * 
 * thickness <= 0 => filled.
 *
 */

int int_meth_rectangle(void *self,Stack stack, int rhs, int opt, int lhs)
{
  int thickness=1, line_type=8, shift=0;
  nsp_option opts[] ={{"line_type",s_int,NULLOBJ,-1},
		      {"shift",s_int,NULLOBJ,-1},
		      {"thickness",s_int,NULLOBJ,-1},
		      {"rgb", realmat ,NULLOBJ,-1},
		      { NULL,t_end,NULLOBJ,-1}};

  int red = 255, green= 0, blue= 0;
  NspMatrix *rect,*rgb=NULL; 
  NspIplImage *obj= (NspIplImage *) self;
  CvPoint pt1, pt2;

  CheckStdRhs(1,1);
  CheckLhs(0,1);

  if ((rect=GetRealMat(stack,1)) == NULLMAT ) return RET_BUG;
  CheckLength(NspFname(stack),1,rect,4);

  if ( get_optional_args(stack, rhs, opt, opts, &line_type,&shift, &thickness, &rgb) == FAIL )
    return RET_BUG;
  
  if ( rgb != NULL )
    {
      CheckLength(NspFname(stack),opts[3].position,rgb,3);
      red =rgb->R[0]; green =rgb->R[1]; blue=rgb->R[2]; 
    }
  
  if ( line_type != 8 && line_type != 4 ) line_type = CV_AA;

  pt1.x = rect->R[0];
  pt2.x = rect->R[0]+rect->R[2];
  pt1.y = rect->R[1];
  pt2.y = rect->R[1]+rect->R[3];
  
  cvRectangle(obj->img, pt1, pt2, CV_RGB(red,green,blue), thickness, line_type, shift );
  if ( cvGetErrStatus() < 0 )
    {
      cvSetErrStatus( CV_StsOk );
      Scierror("Error:  %s  failed \n",NspFname(stack));
      return RET_BUG;
    }

  return 0;
}

int int_meth_line(void *self,Stack stack, int rhs, int opt, int lhs)
{
  int thickness=1, line_type=8, shift=0;
  nsp_option opts[] ={{"line_type",s_int,NULLOBJ,-1},
		      {"shift",s_int,NULLOBJ,-1},
		      {"thickness",s_int,NULLOBJ,-1},
		      {"rgb", realmat ,NULLOBJ,-1},
		      { NULL,t_end,NULLOBJ,-1}};

  int red = 255, green= 0, blue= 0;
  NspMatrix *Mpt1,*Mpt2,*rgb=NULL; 
  NspIplImage *obj= (NspIplImage *) self;
  CvPoint pt1, pt2;

  CheckStdRhs(2,2);
  CheckLhs(0,1);

  if ((Mpt1=GetRealMat(stack,1)) == NULLMAT ) return RET_BUG;
  CheckLength(NspFname(stack),1,Mpt1,2);
  if ((Mpt2=GetRealMat(stack,2)) == NULLMAT ) return RET_BUG;
  CheckLength(NspFname(stack),2,Mpt2,2);
  
  if ( get_optional_args(stack, rhs, opt, opts, &line_type,&shift, &thickness, &rgb) == FAIL )
    return RET_BUG;
  
  if ( rgb != NULL )
    {
      CheckLength(NspFname(stack),opts[3].position,rgb,3);
      red =rgb->R[0]; green =rgb->R[1]; blue=rgb->R[2]; 
    }
  
  if ( line_type != 8 && line_type != 4 ) line_type = CV_AA;

  pt1.x = Mpt1->R[0];  pt1.y = Mpt1->R[1];
  pt2.x = Mpt2->R[0];  pt2.y = Mpt2->R[1];
  
  cvLine(obj->img, pt1, pt2, CV_RGB(red,green,blue), thickness, line_type, shift );
  if ( cvGetErrStatus() < 0 )
    {
      cvSetErrStatus( CV_StsOk );
      Scierror("Error:  %s  failed \n",NspFname(stack));
      return RET_BUG;
    }

  return 0;
}

int int_meth_circle(void *self,Stack stack, int rhs, int opt, int lhs)
{
  int thickness=1, line_type=8, shift=0;
  nsp_option opts[] ={{"line_type",s_int,NULLOBJ,-1},
		      {"shift",s_int,NULLOBJ,-1},
		      {"thickness",s_int,NULLOBJ,-1},
		      {"rgb", realmat ,NULLOBJ,-1},
		      { NULL,t_end,NULLOBJ,-1}};
  int red = 255, green= 0, blue= 0, radius;
  NspMatrix *center,*rgb=NULL; 
  NspIplImage *obj= (NspIplImage *) self;
  CvPoint pt1;

  CheckStdRhs(2,2);
  CheckLhs(0,1);

  if ((center=GetRealMat(stack,1)) == NULLMAT ) return RET_BUG;
  CheckLength(NspFname(stack),1,center,2);
  if ( GetScalarInt(stack,2,&radius) == FAIL) return RET_BUG;
  
  if ( get_optional_args(stack, rhs, opt, opts, &line_type,&shift, &thickness, &rgb) == FAIL )
    return RET_BUG;
  
  if ( rgb != NULL )
    {
      CheckLength(NspFname(stack),opts[3].position,rgb,3);
      red =rgb->R[0]; green =rgb->R[1]; blue=rgb->R[2]; 
    }
  
  if ( line_type != 8 && line_type != 4 ) line_type = CV_AA;
  
  pt1.x = center->R[0];
  pt1.y = center->R[1];
  
  cvCircle(obj->img, pt1, radius, CV_RGB(red,green,blue), thickness, line_type, shift );
  if ( cvGetErrStatus() < 0 )
    {
      cvSetErrStatus( CV_StsOk );
      Scierror("Error:  %s  failed \n",NspFname(stack));
      return RET_BUG;
    }

  return 0;
}


static NspMethods nsp_iplimage_methods[] = {
  {(char *)"show", int_meth_imshow},
  {(char *)"write", int_meth_imwrite },
  {(char *)"get_channels", int_meth_get_channels },
  {(char *)"get_channel", int_meth_get_channel },
  {(char *)"delete_imview", int_meth_delete_imview},
  {(char *)"rectangle", int_meth_rectangle},
  {(char *)"circle", int_meth_circle},
  {(char *)"line", int_meth_line},
  { (char *) 0, NULL}
};

static NspMethods *nsp_iplimage_get_methods(void) { return nsp_iplimage_methods;};

/*----------------------------------------------------
 * Interface 
 * i.e a set of function which are accessible at nsp level
 *----------------------------------------------------*/


/* get a cells: checking that it can be used as an image */

static NspCells *get_ipl_cells(Stack stack,int pos) 
{
  int i,nRow,nCol;
  NspCells *C; 
  if ((C = GetCells(stack,pos)) == NULL) return NULL;
  /* first checks that all the matrices in the cell are of same dimension */
  for ( i = 0 ; i < C->mn ; i++) 
    {
      if ( check_cast(C->objs[i],nsp_type_matrix_id) == FALSE) 
	{
	  Scierror("Error: element %d of cell array is not a Matrix\n",i+1);
	  return NULL;
	}
      if ( i==0) 
	{  nRow = ((NspMatrix *) C->objs[i])->m; nCol = ((NspMatrix *) C->objs[i])->n;}
      else 
	{
	  if (( nRow != ((NspMatrix *) C->objs[i])->m) || nCol != ((NspMatrix *) C->objs[i])->n) 
	    {
	      Scierror("Error: cell array elements should be of the same size\n",i+1);
	      return NULL;
	    }
	}
      if ( ((NspMatrix *) C->objs[i])->rc_type != 'r') 
	{
	  Scierror("Error: cell array elements should be a real matrix\n",i+1);
	  return NULL;
	}
    }
  return C;
}

/* 
 * fills the iplimage from cells 
 * C is supposed to have the good format 
 *
 */

static IplImage * cells_to_iplimage(NspCells *C,int depth)
{
  int col,row,ch,nBytes;
  IplImage *loc;
  char * pSrc;
  int nRow = ((NspMatrix *) C->objs[0])->m; 
  int nCol = ((NspMatrix *) C->objs[0])->n;
  /* create an IplImage for storing data*/
  if ((loc = cvCreateImage(cvSize(nCol, nRow), depth , C->mn))== NULL)
    {
      Scierror("Error: IplImage creation failed\n");
      return NULL;
    }
  /*how many bytes per pixel per channel*/
  nBytes = loc->depth;
  if (nBytes > IPL_DEPTH_SIGN)
    nBytes -= IPL_DEPTH_SIGN;
  nBytes = nBytes >> 3;
  
  pSrc = (char*) loc->imageData;
  for(ch = 0; ch < loc->nChannels ; ch++) //the order of IplImage is BGR  
    for(col =0; col < loc->width; col++)
      for(row = 0; row < loc->height; row++)
	{
	  guchar *psrc_8U;
	  gchar *psrc_8S; 
	  gshort *psrc_16U;
	  gushort *psrc_16S;
	  gint *psrc_32S;
	  /* guint *psrc_32U; */
	  gfloat *psrc_32F;
	  double *psrc_64F;
	  void *psrc= pSrc + loc->widthStep*row
	    + (col*loc->nChannels + (loc->nChannels-ch-1))*nBytes;
	  double d = ((NspMatrix *) C->objs[ch])->R[row+loc->height*col];
	  switch(loc->depth) 
	    {
	    case IPL_DEPTH_8U: psrc_8U = psrc;  *psrc_8U = (guchar) d;  break;
	    case IPL_DEPTH_8S: psrc_8S = psrc;  *psrc_8S = (gchar) d;  break;
	    case IPL_DEPTH_16U:psrc_16U = psrc;  *psrc_16U= (gushort) d;  break;
	    case IPL_DEPTH_16S:psrc_16S = psrc;  *psrc_16S = (gshort) d;  break;
	    case IPL_DEPTH_32S:psrc_32S = psrc;  *psrc_32S = (gint) d;  break;
	    case IPL_DEPTH_32F:psrc_32F = psrc;  *psrc_32F = (gfloat) d;  break;
	    case IPL_DEPTH_64F:psrc_64F = psrc;  *psrc_64F =  d;  break;
	    default: 
	      psrc_8U = psrc;  *psrc_8U = (guchar) d;
	    }
	}
  return loc ;
}

int int_iplimage_new(Stack stack, int rhs, int opt, int lhs)
{
  char *nom;
  NspIplImage *nsp_img;
  NspCells *C=NULL;
  int nsp_ret = RET_BUG,ret;
  IplImage *img1=NULL;
  const char *Table[]  ={"8U","8S","16U","16S","32S","32F","64F",NULL};
  const int op[] = {IPL_DEPTH_8U,IPL_DEPTH_8S,IPL_DEPTH_16U,IPL_DEPTH_16S,
		    IPL_DEPTH_32S,IPL_DEPTH_32F,IPL_DEPTH_64F};
  CheckRhs(2,2);
  CheckLhs(1,1);

  if ((C = get_ipl_cells(stack,1))==NULLCELLS) return RET_BUG;
  if ((nom = GetString(stack,2)) == (char*)0) goto exit;

  ret = is_string_in_array(nom,Table,1);
  if ( ret < 0 ) 
    {
      string_not_in_array(stack,nom,Table,(char *) "second argument");
      goto exit;
    }
  if ((img1 = cells_to_iplimage(C,op[ret]))==NULL) goto exit;
  if ( cvGetErrStatus() < 0 )
    {
      cvSetErrStatus( CV_StsOk );
      Scierror("Error:  % creation of iplimage failed \n",NspFname(stack));
      goto exit;
    }
  if((nsp_img = nsp_iplimage_create(NVOID))==NULL) 
    {
      goto exit;
    }
  nsp_img->img = img1;
  MoveObj(stack,1,NSP_OBJECT(nsp_img));
  return 1;
 exit:
  if (img1) cvReleaseImage( &img1 );
  return nsp_ret;
}

/* new without doc */
extern function int_imshow;
extern function int_convertscale;
extern function int_imtopixbuf;
extern function int_imresize;
extern function int_pixbuftoim;
extern function int_detectforeground;
extern function int_detectobjects;
extern function int_cvrectangle;
extern function int_cvimcrop;

/* end of new */

extern function int_sivp_init;
extern function int_imread;
extern function int_imwrite;
extern function int_vdopen;
extern function int_vdgetframe;
extern function int_vdshowopened;
extern function int_vdclose;
extern function int_vdcloseall;
extern function int_mat2utfimg;
extern function int_canny;
extern function int_convert;
extern function int_laplace;
extern function int_precornerdetec;
extern function int_imsmooth;
extern function int_sobel;
extern function int_threshold;
extern function int_adaptativethreshold;
extern function int_erode;
extern function int_dilate;
extern function int_pyrdown;
extern function int_pyrup;
extern function int_goodfeaturestotrack;
extern function int_xor;
extern function int_not;
extern function int_cmp;
extern function int_cvadd;
extern function int_cvsub;
extern function int_cvmul;
extern function int_cvdiv;
extern function int_hough;
extern function int_cvcapture_new;
extern function int_cvvideowriter_new;

/*
 * delete_imview[] 
 */

int int_delete_imview(Stack stack, int rhs, int opt, int lhs)
{
  char def_name[] ="Image view", *name = def_name;
  CheckRhs(0,1);
  CheckLhs(0,0);
  if ( rhs == 1)
    {
      if ((name = GetString(stack,1)) == (char*)0) return RET_BUG;
    }
  cvDestroyWindow(name);
  return 0;
}

static OpTab IplImage_func[]={
  {(char *)"adaptativethreshold",int_adaptativethreshold},
  {(char *)"canny",int_canny},
  {(char *)"cmp",int_cmp},
  {(char *)"convert",int_convert},
  {(char *)"convertscale",int_convertscale},
  {(char *)"cvcapture", int_cvcapture_new},
  {(char *)"cvvideowriter",int_cvvideowriter_new},
  {(char *)"delete_imview", int_delete_imview},
  {(char *)"detectforeground",int_detectforeground},
  {(char *)"detectobjects",int_detectobjects},
  {(char *)"dilate",int_dilate},
  {(char *)"erode",int_erode},
  {(char *)"goodfeaturestotrack",int_goodfeaturestotrack},
  {(char *)"hough",int_hough},
  {(char *)"imadd",int_cvadd},
  {(char *)"imcrop",int_cvimcrop},
  {(char *)"imdiv",int_cvdiv},
  {(char *)"immul",int_cvmul},
  {(char *)"imread",int_imread},
  {(char *)"imresize",int_imresize},
  {(char *)"imshow",int_imshow},
  {(char *)"imsmooth",int_imsmooth},
  {(char *)"imsub",int_cvsub},
  {(char *)"imtopixbuf",int_imtopixbuf},
  {(char *)"imwrite",int_imwrite},
  {(char *)"iplimage", int_iplimage_new},
  {(char *)"laplace",int_laplace},
  {(char *)"not",int_not},
  {(char *)"pixbuftoim",int_pixbuftoim},
  {(char *)"precornerdetec",int_precornerdetec},
  {(char *)"pyrdown",int_pyrdown},
  {(char *)"pyrup",int_pyrup},
  {(char *)"rectangle",int_cvrectangle},
  {(char *)"setrowscols_cvcap",int_set_attribute}, /* to enable x.attr=val */
  {(char *)"sivp_init",int_sivp_init},
  {(char *)"sobel",int_sobel},
  {(char *)"threshold",int_threshold},
  {(char *)"xor",int_xor},
  {NULL,NULL},
};

int IplImage_Interf(int i, Stack stack, int rhs, int opt, int lhs)
{
  return (*(IplImage_func[i].fonc))(stack,rhs,opt,lhs);
}

/* used to walk through the interface table 
 *  (for adding or removing functions) 
 */

void IplImage_Interf_Info(int i, char **fname, function (**f))
{
  *fname = IplImage_func[i].name;
  *f = IplImage_func[i].fonc;
}

#ifdef __cplusplus
}
#endif
