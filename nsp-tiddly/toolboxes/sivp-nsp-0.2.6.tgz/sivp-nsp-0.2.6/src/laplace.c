/***********************************************************************
 * SIVP - Scilab Image and Video Processing toolbox
 * Copyright (C) 2005  Vincent Etienne
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ***********************************************************************/

/* Ported to nsp: Jean-Philippe Chancelier 2005-2006.
 *
 */

#include "common.h"

#ifdef __cplusplus
extern "C" {
#endif

int int_laplace(Stack stack, int rhs, int opt, int lhs)
{
  int nsp_ret = RET_BUG,param1;
  IplImage* img2 = NULL, *img1=NULL;
  NspIplImage* nsp_img = NULL;
  CheckRhs(2,2);
  CheckLhs(1,1);

  if ((nsp_img= GetIplImage(stack,1))== NULL) goto exit;  
  img1 = nsp_img->img;

  if ( GetScalarInt(stack,2,&param1) == FAIL) goto exit;

  if ( (param1 % 2 != 1) || ( param1 <3 ) )
    {
      Scierror("Error: The size of laplace kernel must be 3,5,7, ...\n");
      goto exit;
    }
  
  if (! ((img1->depth==IPL_DEPTH_8U) && (img1->nChannels==1)))
    {
      Scierror("Error: wrong input matrice expecting 8U and 1 channel\n");
      goto exit;
    }
  if((img2=cvCreateImage(cvGetSize(img1),IPL_DEPTH_16S ,img1->nChannels))==NULL)
    {
      Scierror("Error: can't create the output matrix\n");
      goto exit;
    }
  //use the opencv function
  cvLaplace( img1, img2 ,param1);
  if ( cvGetErrStatus() < 0 )
    {
      cvSetErrStatus( CV_StsOk );
      Scierror("Error:  %s , cvLaplace failed \n",NspFname(stack));
      goto exit;
    }
  
  if((nsp_img = nsp_iplimage_create(NVOID))==NULL) goto exit;
  nsp_img->img = img2;
  MoveObj(stack,1,NSP_OBJECT(nsp_img));
  return 1;
 exit:
  if (img2) cvReleaseImage( &img2 );
  return nsp_ret ;
}

#ifdef __cplusplus
}
#endif
