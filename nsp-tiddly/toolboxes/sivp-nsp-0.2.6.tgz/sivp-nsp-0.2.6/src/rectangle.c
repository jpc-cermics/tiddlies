/***********************************************************************
 * SIVP - Scilab Image and Video Processing toolbox
 * Copyright (C) 2008  Jean-Philippe Chancelier 
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ***********************************************************************/

#include "common.h"
#ifdef __cplusplus
extern "C" {
#endif



int int_cvrectangle(Stack stack, int rhs, int opt, int lhs)
{
  int red = 255, green= 0, blue= 0;
  NspMatrix *rect,*rgb; 
  NspIplImage *nsp_img=NULL,*nsp_img_out=NULL;
  IplImage *img2=NULL,*img1=NULL;
  CvPoint pt1, pt2;
  
  CheckRhs(2,3);
  CheckLhs(1,1);
  
  if ((nsp_img= GetIplImage(stack,1))== NULL) return RET_BUG;
  img1 = nsp_img->img;

  if ((rect=GetRealMat(stack,2)) == NULLMAT ) return FAIL;
  CheckLength(NspFname(stack),2,rect,4);

  if ( rhs == 3 )
    {
      if ((rgb=GetRealMat(stack,3)) == NULLMAT ) return FAIL;
      CheckLength(NspFname(stack),3,rgb,3);
      red =rgb->R[0]; green =rgb->R[1]; blue=rgb->R[2]; 
    }

  pt1.x = rect->R[0];
  pt2.x = rect->R[0]+rect->R[2];
  pt1.y = rect->R[1];
  pt2.y = rect->R[1]+rect->R[3];

  img2 = cvCloneImage(img1 );  
  if ( cvGetErrStatus() < 0 )
    {
      cvSetErrStatus( CV_StsOk );
      Scierror("Error: Image clone failed\n");
      goto exit;
    }
  
  if((nsp_img_out = nsp_iplimage_create(NVOID))==NULL) goto exit;
  nsp_img_out->img  = img2;

  /* le 1 est la taille en pixel 
   * rajouter la possibilit� de passer les trois arguments 
   */ 
  
  cvRectangle( img2, pt1, pt2, CV_RGB(red,green,blue), 1, 8, 0 );
  
  MoveObj(stack,1,NSP_OBJECT(nsp_img_out));
  return 1;
 exit:
  return RET_BUG;
}

#ifdef __cplusplus
}
#endif
