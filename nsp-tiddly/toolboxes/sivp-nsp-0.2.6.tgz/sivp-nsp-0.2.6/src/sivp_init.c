/***********************************************************************
 * SIVP - Scilab Image and Video Processing toolbox
 * Copyright (C) 2006 Jean-Philippe Chancelier 
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Set up of the toolbox 
 * - initialize type for iplimage 
 * - set up errors in opencv to return back to nsp with nsp error mechanism.
 * - FIXME: we should add an link initializer in the dynamic link facilities.
 ***********************************************************************/

#include "common.h"
#include "error.h"

#ifdef __cplusplus
extern "C" {
#endif

static int send_error_to_nsp( int status, const char* func_name, const char* err_msg,
			      const char* file_name, int line, void* userdata)
{
  Scierror("Error: in opencv %s\n",(err_msg ? err_msg : "unknown error"));
  return 0;
}

char  sSIVP_PATH[FSIZE+1];

int int_sivp_init(Stack stack, int rhs, int opt, int lhs)
{
  char *str;
  CheckRhs(1,1);
  CheckLhs(0,1);

  if ((str  = GetString(stack,1)) ==  NULLSTRING) return RET_BUG;
  if ( str[0]== 0 ) 
    strncpy(sSIVP_PATH,"." , FSIZE);
  else
    strncpy(sSIVP_PATH, str , FSIZE);

  cvRedirectError(send_error_to_nsp,NULL,NULL);
  cvSetErrMode(CV_ErrModeParent);
  /* be sure that type is registered */
  nsp_type_iplimage = new_type_iplimage(T_BASE);
  return 0;
}


#ifdef __cplusplus
 }
#endif
