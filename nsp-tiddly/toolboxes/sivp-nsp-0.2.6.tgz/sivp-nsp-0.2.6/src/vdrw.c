/***********************************************************************
 * SIVP - Scilab Image and Video Processing toolbox
 * Copyright (C) 2005  Vincent Etienne
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ***********************************************************************/

/* Ported to nsp: Jean-Philippe Chancelier 2005-2006.
 *
 */

#include "common.h"

#ifdef __cplusplus
extern "C" {
#endif

#define MAX_VD_FILE_NUM 32

typedef struct OpenedVDfFile{
  char filename[FILENAME_MAX];
  AVFormatContext *pFormatCtx;
  AVCodecContext  *pCodecCtx;
  AVCodec         *pCodec;
  int nVdStream; //video stream index
  unsigned long  nCurFrame;
  BOOL bOpened;
} OpenedVdFile;
  
static OpenedVdFile VdFiles[MAX_VD_FILE_NUM];

int
vdopen(char * filename, char * fname)
{
  int nCurrFile;
  int i;
  static int inited = 0;
  
  /* init  */
  if(!inited)
    {
      memset(&VdFiles, 0, sizeof(VdFiles));
      inited = 1;
    }

  for (nCurrFile = 0; nCurrFile < MAX_VD_FILE_NUM; nCurrFile++)
    {
      if( !VdFiles[nCurrFile].bOpened)
	break;
    }

  if( nCurrFile ==  MAX_VD_FILE_NUM)
    {
      Scierror( "%s: Too many video files opened. Use vdclose or vdcloseall to close some file.\n", fname);
      return -1;
    }

  // Register all formats and codecs
  av_register_all ();

  strcpy(VdFiles[nCurrFile].filename, filename);

  // Open video file
  if (av_open_input_file (&(VdFiles[nCurrFile].pFormatCtx), filename, NULL, 0, NULL) != 0)
    {
      Scierror( "%s: Couldn't open file %s. Maybe this file does not exist.\n", fname, filename);
      return -1;		// Couldn't open file
    }
  

  // Retrieve stream information
  if (av_find_stream_info( VdFiles[nCurrFile].pFormatCtx ) < 0)
    {
      av_close_input_file(VdFiles[nCurrFile].pFormatCtx);
      Scierror( "%s: Couldn't find steam information.\n", fname);
      return -1;		// Couldn't find stream information
    }
  

  // Find the first video stream
  VdFiles[nCurrFile].nVdStream = -1;
  for (i = 0; i < VdFiles[nCurrFile].pFormatCtx->nb_streams; i++)
    if (VdFiles[nCurrFile].pFormatCtx->streams[i]->codec.codec_type == CODEC_TYPE_VIDEO)
      {
	VdFiles[nCurrFile].nVdStream = i;
	break;
      }
  
  // Can't find a video stream
  if ( VdFiles[nCurrFile].nVdStream == -1)
    {
      av_close_input_file(VdFiles[nCurrFile].pFormatCtx);
      Scierror ( "%s: No video stream in this file.\n", fname);
      return -1;
    }

  // Get a pointer to the codec context for the video stream
  VdFiles[nCurrFile].pCodecCtx = &(VdFiles[nCurrFile].pFormatCtx->streams[VdFiles[nCurrFile].nVdStream]->codec);
				    
  // Find the decoder for the video stream
  VdFiles[nCurrFile].pCodec = avcodec_find_decoder (VdFiles[nCurrFile].pCodecCtx->codec_id);
  if (VdFiles[nCurrFile].pCodec == NULL)
    {
      av_close_input_file(VdFiles[nCurrFile].pFormatCtx );
      Scierror( "%s: No codec for this video file.\n", fname);
      return -1;
    }

  // Open the codec
  if(avcodec_open(VdFiles[nCurrFile].pCodecCtx, VdFiles[nCurrFile].pCodec)<0)
    {
      av_close_input_file(VdFiles[nCurrFile].pFormatCtx );
      Scierror( "%s: Can not open the codec for this video file.\n", fname);
      return -1; 
    }

				    
  if( VdFiles[nCurrFile].pCodecCtx->frame_rate > 1000 
      && VdFiles[nCurrFile].pCodecCtx->frame_rate_base == 1 )
    {
      VdFiles[nCurrFile].pCodecCtx->frame_rate_base = 1000;
    }

  VdFiles[nCurrFile].bOpened = TRUE;
  
  return nCurrFile;

}

AVFrame *
vdgetframe(int nFile, char *fname)
{
  AVFrame         *pFrame; 
  AVFrame         *pFrameRGB;
  AVPacket        packet;
  
  int nMemSize;
  int nFinished;
  unsigned char * pBuffer;
  int nRet;

  // Allocate memory for video frame
  pFrame=avcodec_alloc_frame();

  // Allocate memory for an RGB image
  pFrameRGB=avcodec_alloc_frame();

  if(pFrame == NULL || pFrameRGB==NULL)
    {
      Scierror ( "%s: Can not allocate memory for video frame.\n", fname);
      return NULL;
    }    

  // Determine required buffer size and allocate buffer

  nMemSize=avpicture_get_size(PIX_FMT_RGB24, VdFiles[nFile].pCodecCtx->width, VdFiles[nFile].pCodecCtx->height);
  pBuffer=(unsigned char *) malloc(nMemSize);
  if(pBuffer == NULL)
    {
      Scierror ( "%s: Can not allocate memory for video frame.\n", fname);
      return NULL;
    }    

  // Assign appropriate parts of buffer to image planes in pFrameRGB
  avpicture_fill((AVPicture *)pFrameRGB, pBuffer, 
		 PIX_FMT_RGB24, 
		 VdFiles[nFile].pCodecCtx->width, 
		 VdFiles[nFile].pCodecCtx->height);

  //read the next frame
  while(1){
    nRet = av_read_packet(VdFiles[nFile].pFormatCtx, &packet);
    if(nRet < 0) 
      goto NO_FRAME;


    // if it's a packet from the video stream
    if(packet.stream_index== VdFiles[nFile].nVdStream)
      {
	// Decode video frame
	avcodec_decode_video(VdFiles[nFile].pCodecCtx, pFrame, &nFinished, packet.data, packet.size);
	
	// if we get a video frame
	if(nFinished)
	  {
	    // Convert the image format to RGB
	    img_convert((AVPicture *)pFrameRGB, PIX_FMT_RGB24, 
			(AVPicture*)pFrame, 
			VdFiles[nFile].pCodecCtx->pix_fmt, 
			VdFiles[nFile].pCodecCtx->width, 
			VdFiles[nFile].pCodecCtx->height);

	    VdFiles[nFile].nCurFrame++;

	    // Free the packet
	    av_free_packet(&packet);

	    break; //break the while loop
	  }
      }
    
  }


  // Free the frame
  av_free(pFrame);
  //the RGB image should be free out of this function

  return pFrameRGB;

 NO_FRAME:
  // Free the frame
  av_free(pFrame);
  // Free the RGB image
  free(pBuffer);
  av_free(pFrameRGB);

  return NULL;
}



int int_vdopen(Stack stack, int rhs, int opt, int lhs)
{
  char *nom;
  int ret;
  CheckRhs(1,1);
  CheckLhs(1,1);

  if ((nom = GetString(stack,1)) == (char*)0) return RET_BUG;
  ret = vdopen(nom, NspFname(stack));
  if(ret < 0)  return RET_BUG;
  if ( nsp_move_double(stack,1,(double) ret+1)==FAIL) return RET_BUG;
  return 1;
}

NspCells *sivp_vdrw_to_nsp_cells(unsigned char* pSrc, int nWidth, int nHeight, int nCh);

int int_vdgetframe(Stack stack, int rhs, int opt, int lhs)
{
  NspCells *C;
  AVFrame * pFrameRGB;
  int nFile;

  CheckRhs(1,1);
  CheckLhs(0,1);

  if ( GetScalarInt(stack,1,&nFile) == FAIL) return RET_BUG;
  nFile = nFile - 1;
  if (!(nFile >= 0 && nFile < MAX_VD_FILE_NUM))
    {
      Scierror( "%s: The argument should >=1 and <= %d.\n", NspFname(stack), MAX_VD_FILE_NUM);
      return RET_BUG;
    }
  if(! VdFiles[nFile].bOpened)
    {
      Scierror( "%s: The %d'th file is not opened.\n Please use vdshowopened command to show opened files.\n",
		NspFname(stack), nFile+1);
      return RET_BUG;
    }


  pFrameRGB = vdgetframe(nFile, NspFname(stack));
  //if this is the last frame, or can not get a frame, return zero
  if(pFrameRGB == NULL)
    {
      if ( nsp_move_double(stack,1,0.0)==FAIL) return RET_BUG;
      return 1;
    }
  if ((C = sivp_vdrw_to_nsp_cells(pFrameRGB->data[0], VdFiles[nFile].pCodecCtx->width, VdFiles[nFile].pCodecCtx->height, 3))
      == NULL) return RET_BUG;
  MoveObj(stack,1,NSP_OBJECT(C));
  // Free the RGB image
  free(pFrameRGB->data[0]);
  av_free(pFrameRGB);
  return 1;
}


NspCells *sivp_vdrw_to_nsp_cells(unsigned char* pSrc, int nWidth, int nHeight, int nCh)
{
  int row, col, ch=0;
  int i;
  NspCells *loc; 
  NspMatrix *mat;
  if (pSrc == NULL ) return nsp_cells_create(NVOID,0,0);
  if ( (loc =nsp_cells_create(NVOID,1,nCh)) == NULLCELLS) return NULLCELLS;
  for ( i = 0 ; i < nCh ; i++ ) 
    {
      if ((mat = nsp_matrix_create("ce",'r',nHeight,nWidth))== NULLMAT) return  NULLCELLS;
      loc->objs[i]= NSP_OBJECT(mat);
    }
  for(ch = 0; ch < nCh ; ch++) //the order of IplImage is BGR  
    for(col =0; col < nWidth; col++)
      for(row = 0; row < nHeight; row++)
	{
	  ((NspMatrix *) loc->objs[ch])->R[row+nHeight*col]=(double)  *(pSrc+(nWidth*nCh)*row+col*nCh+ch);
	}
  return loc;
}


/* interfaces 
 *
 */

int int_vdshowopened(Stack stack, int rhs, int opt, int lhs)
{
  int i;
  CheckRhs(0, 0);
  CheckLhs(0, 1);
  Sciprintf("Opened files:\n");
  for (i = 0; i < MAX_VD_FILE_NUM; i++)
    {
      if(VdFiles[i].bOpened==TRUE)
	{
	  Sciprintf("%d: %s\n", i+1, VdFiles[i].filename);
	}
    }
  return 0;
}

int int_vdclose(Stack stack, int rhs, int opt, int lhs)
{
  int nFile;
  CheckRhs(1,1);
  CheckLhs(0,1);

  if ( GetScalarInt(stack,1,&nFile) == FAIL) return RET_BUG;
  nFile -= 1;
  if (nFile >= 0 && nFile < MAX_VD_FILE_NUM)
    {
      if(VdFiles[nFile].bOpened)
	{
	  avcodec_close(VdFiles[nFile].pCodecCtx);
	  av_close_input_file(VdFiles[nFile].pFormatCtx);
	}
      
      memset(&(VdFiles[nFile]), 0, sizeof(OpenedVdFile));
    }
  else
    {
      Scierror( "%s: The argument should >=1 and <= %d.\n", NspFname(stack), MAX_VD_FILE_NUM);
      return RET_BUG;
    }
  return 0;
}


int  int_vdcloseall(Stack stack, int rhs, int opt, int lhs)
{
  int i;
  CheckRhs(0, 0);
  CheckLhs(0, 1);
  for (i = 0; i < MAX_VD_FILE_NUM; i++)
    {
      if(VdFiles[i].bOpened)
	{
	  avcodec_close(VdFiles[i].pCodecCtx);
	  av_close_input_file(VdFiles[i].pFormatCtx);
	}
    }
  memset( &VdFiles, 0, sizeof(OpenedVdFile) * MAX_VD_FILE_NUM);
  return 0;
}
#ifdef __cplusplus
}
#endif
