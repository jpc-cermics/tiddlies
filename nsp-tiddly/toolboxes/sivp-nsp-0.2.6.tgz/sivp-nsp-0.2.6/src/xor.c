/***********************************************************************
 * SIVP - Scilab Image and Video Processing toolbox
 * Copyright (C) 2005  Vincent Etienne
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 ***********************************************************************/


#include "common.h"

#ifdef __cplusplus
extern "C" {
#endif




/* XXX rajouter un masque optionnel */
/* sur le meme modele il y a or et orS and */

int int_xor(Stack stack, int rhs, int opt, int lhs)
{
  int nsp_ret = RET_BUG;
  IplImage *img3 = NULL,*img2=NULL, *img1=NULL;
  NspIplImage *nsp_img2=NULL, *nsp_img1=NULL,* nsp_img;
  CvSize size1,size2;

  CheckRhs(2,2);
  CheckLhs(1,1);

  if ((nsp_img1= GetIplImage(stack,1))== NULL) goto exit;  
  img1 = nsp_img1->img;
  if ((nsp_img2= GetIplImage(stack,2))== NULL) goto exit;  
  img2 = nsp_img2->img;

  size1=cvGetSize(img1);
  size2=cvGetSize(img2);
  if(img1->nChannels != img2->nChannels || img1->depth != img2->depth 
     || size1.width != size2.width || size1.height != size2.height) 
    {
      Scierror("Error: the two images should have same size, depth and channel\n",
	       NspFname(stack));
      goto exit;
    }
  if ((img3=cvCreateImage(cvGetSize(img1),img1->depth,img1->nChannels))==NULL)
    {
      Scierror("Error: can't create the output matrix\n");
      goto exit;
    }
  cvXor(img1,img2,img3,NULL);
  if ( cvGetErrStatus() < 0 )
    {
      cvSetErrStatus( CV_StsOk );
      Scierror("Error:  %s , cvXor failed \n",NspFname(stack));
      goto exit;
    }

  if((nsp_img = nsp_iplimage_create(NVOID))==NULL) goto exit;
  nsp_img->img = img3;
  MoveObj(stack,1,NSP_OBJECT(nsp_img));
  return 1;
 exit: 
  if (img3) cvReleaseImage( &img3 );
  return nsp_ret;
}

#ifdef __cplusplus
}
#endif
