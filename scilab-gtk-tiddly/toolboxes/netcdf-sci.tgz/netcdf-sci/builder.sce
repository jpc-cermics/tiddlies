// generated with intersci 
ilib_name = 'libscinetcdf'		// interface library name

files = ['sci_netcdf.o'];
libs = [];

table =["netcdf_open","intsnetcdf_open";
	"netcdf_close","intsnetcdf_close";
	"netcdf_getFloatVar","intsnetcdf_getFloatVar";
	"netcdf_getIntVar","intsnetcdf_getIntVar";
	"netcdf_getCharVar","intsnetcdf_getCharVar"];

cflags="-I./"
// need to give "netcdf.lib" for visual 
 ldflags = "netcdf.lib" 
//ldflags = "-lnetcdf" 
if exists('%nsp') then
  ilib_build(ilib_name,table,files,libs,ldflags=ldflags,cflags=cflags);
else
  ilib_build(ilib_name,table,files,libs,'Makelib',ldflags,cflags);
end


