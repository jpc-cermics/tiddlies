/* 
 * Copyright (C) 2006-2011 Duane Currie.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the
 * Free Software Foundation, Inc., 59 Temple Place - Suite 330,
 * Boston, MA 02111-1307, USA.
 *
 * updated by Jean-Philippe Chancelier Oct 2011
 */

#include <string.h>
#include <stdio.h>
#include "stack-c.h"
#include <netcdf.h>

static void scilab_netcdf_open(char *filename, int *fd) ;
static void scilab_netcdf_close(int *fd, int *close_status); 
static void scilab_netcdf_getFloatVar(int *fd, char *str, double **result, int *len);
static void scilab_netcdf_getIntVar(int *fd, char *str, int **result, int *len) ;
static void scilab_netcdf_getCharVar(int *fd, char *str, char **result, int *len) ;
static void nsp_netcdf_error(int err, const char *name);

/*
 * SCILAB function : netcdf_open, fin = 1
 */

int intsnetcdf_open(char *fname)
{
  int m1,n1,l1,un=1,l2;
  CheckRhs(1,1);
  CheckLhs(1,1);
  /*  checking variable str */
  GetRhsVar(1,"c",&m1,&n1,&l1);
  /* cross variable size checking */
  CreateVar(2,"i",&un,&un,&l2);/* named: fd */
  scilab_netcdf_open(cstk(l1),istk(l2));
  LhsVar(1)= 2;
  return 0;
}

/*
 * SCILAB function : netcdf_close, fin = 2
 */

int intsnetcdf_close(char *fname)
{
  int m1,n1,l1,un=1,l2;
  CheckRhs(1,1);
  CheckLhs(1,1);
  /*  checking variable fd */
  GetRhsVar(1,"i",&m1,&n1,&l1);
  CheckScalar(1,m1,n1);
  /* cross variable size checking */
  CreateVar(2,"i",&un,&un,&l2);/* named: close_status */
  scilab_netcdf_close(istk(l1),istk(l2));
  LhsVar(1)= 2;
  return 0;
}

/*
 * SCILAB function : netcdf_getFloatVar, fin = 3
 */

int intsnetcdf_getFloatVar(char *fname)
{
  int m1,n1,l1,m2,n2,l2,me3,loc2;
  double *le3;
  CheckRhs(2,2);
  CheckLhs(1,1);
  /*  checking variable fd */
  GetRhsVar(1,"i",&m1,&n1,&l1);
  CheckScalar(1,m1,n1);
  /*  checking variable str */
  GetRhsVar(2,"c",&m2,&n2,&l2);
  /* cross variable size checking */
  /* external variable named result (xxe3) */
  scilab_netcdf_getFloatVar(istk(l1),cstk(l2),&le3,&me3);
  CreateVarFromPtr(3,"d",&me3,(loc2=1,&loc2),&le3);
  if (me3*1 != 0) FreePtr(&le3);
  LhsVar(1)=3;
  return 0;
}

/*
 * SCILAB function : netcdf_getIntVar, fin = 4
 */

int intsnetcdf_getIntVar(char *fname)
{
  int m1,n1,l1,m2,n2,l2,me3,loc2;
  int  *le3;
  CheckRhs(2,2);
  CheckLhs(1,1);
  /*  checking variable fd */
  GetRhsVar(1,"i",&m1,&n1,&l1);
  CheckScalar(1,m1,n1);
  /*  checking variable str */
  GetRhsVar(2,"c",&m2,&n2,&l2);
  /* cross variable size checking */
  /* external variable named result (xxe3) */
  scilab_netcdf_getIntVar(istk(l1),cstk(l2),&le3,&me3);
  CreateVarFromPtr(3,"i",&me3,(loc2=1,&loc2),&le3);
  if (me3*1 != 0) FreePtr(&le3);
  LhsVar(1)=3;
  return 0;
}

/*
 * SCILAB function : netcdf_getCharVar, fin = 5
 */

int intsnetcdf_getCharVar(char *fname)
{
  int m1,n1,l1,m2,n2,l2,me3,loc2;
  char *le3;
  CheckRhs(2,2);
  CheckLhs(1,1);
  /*  checking variable fd */
  GetRhsVar(1,"i",&m1,&n1,&l1);
  CheckScalar(1,m1,n1);
  /*  checking variable str */
  GetRhsVar(2,"c",&m2,&n2,&l2);
  /* cross variable size checking */
  /* external variable named result (xxe3) */
  scilab_netcdf_getCharVar(istk(l1),cstk(l2),&le3,&me3);
  CreateVarFromPtr(3,"c",&me3,(loc2=1,&loc2),&le3);
  if (me3*1 != 0) FreePtr(&le3);
  LhsVar(1)=3;
  return 0;
}

static void scilab_netcdf_open(char *filename, int *fd) 
{
#if 0   
  int nvars_in, varids_in[10];
#endif
  int ncf;
  int status = nc_open(filename,NC_NOWRITE, &ncf);
  /* sciprint("Trying to open [%s] status %d\n",filename,status); */
  if (status != NC_NOERR ) goto err;
  status = nc_enddef(ncf);
  /* sciprint("Trying to ended [%s] status %d\n",filename,status);*/
  if (0 &&  status != NC_NOERR ) goto err;
#if 0   
  status=nc_inq_varids(ncf, &nvars_in, varids_in);
  if ( status != NC_NOERR ) goto err;
  sciprint("File contains %d variables \n",nvars_in);
#endif 
  *fd=ncf;
  return;
  err:
  *fd =0;
  nsp_netcdf_error(status,filename);
}

static void scilab_netcdf_close(int *fd, int *close_status) {
  *close_status = nc_close(*fd);
}

static void scilab_netcdf_getFloatVar(int *fd, char *str, double **result, int *len)
{
  int i, n_dims, var_id, status;
  int *dims;
  *len = 1;
  status = nc_inq_varid(*fd, str, &var_id);
  if ( status != NC_NOERR ) goto err;
  status = nc_inq_varndims(*fd, var_id, &n_dims);
#if DEBUG   
  sciprint("ndims %d\n",n_dims);
#endif 
  if ( status != NC_NOERR ) goto err;
  dims = (int *) calloc(n_dims, sizeof(int));
  status = nc_inq_vardimid(*fd, var_id, dims);
#if DEBUG   
  sciprint("dims[0] %d\n",dims[0]);
#endif 
  if ( status != NC_NOERR ) goto err;
  for (i = 0; i < n_dims; i++) {
    size_t dim_length;
    status = nc_inq_dimlen(*fd, dims[i], &dim_length);
    if (0 && status != NC_NOERR ) goto err;
#if DEBUG   
    sciprint("length %d\n",dim_length);
#endif 
    *len *= dim_length;
  }
  *result = (double *) malloc(*len * sizeof(double));
  status = nc_get_var_double(*fd, var_id, *result);
  free(dims);
  return;
 err:
  nsp_netcdf_error(status,str);
  *len=0;
  *result = NULL;
}

static void scilab_netcdf_getIntVar(int *fd, char *str, int **result, int *len) 
{
  int i, n_dims, var_id, status;
  int *dims;
  *len = 1;

  status = nc_inq_varid(*fd, str, &var_id);
  status = nc_inq_varndims(*fd, var_id, &n_dims);
  dims = (int *) calloc(n_dims, sizeof(int));
  status = nc_inq_vardimid(*fd, var_id, dims);

  for (i = 0; i < n_dims; i++) {
    size_t dim_length;
    status = nc_inq_dimlen(*fd, dims[i], &dim_length);
    *len *= dim_length;
  }

  *result = (int *) malloc(*len * sizeof(int));
  status = nc_get_var_int(*fd, var_id, *result);

  free(dims);
}

static void scilab_netcdf_getCharVar(int *fd, char *str, char **result, int *len) 
{
  int i, n_dims, var_id, status;
  int *dims;
  *len = 1;
  
  status = nc_inq_varid(*fd, str, &var_id);
  status = nc_inq_varndims(*fd, var_id, &n_dims);
  dims = (int *) calloc(n_dims, sizeof(int));
  status = nc_inq_vardimid(*fd, var_id, dims);

  for (i = 0; i < n_dims; i++) {
    size_t dim_length;
    status = nc_inq_dimlen(*fd, dims[i], &dim_length);
    *len *= dim_length;
  }

  *result = (char *) malloc(*len * sizeof(char));
  status = nc_get_var_text(*fd, var_id, *result);

  printf("         %s\n", *result);

  free(dims);
}


void nsp_netcdf_error(int err, const char *name)
{
  Scierror(999,"Error: netcdf error %s\r\n",nc_strerror(err));
}



