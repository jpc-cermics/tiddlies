exec loader.sce
x=netcdf_open('./testrh.nc');
z=netcdf_getFloatVar(x,'var1');
